# IDP Library — V44


### Processing Blocks (v44)

Core Blocks are powerful processing blocks necessary to build intelligent document processing solutions on Hyperscience. They include both manual and machine processing blocks.

#### NOTE
Classes in the idp_v44 implementation have parameters with ambiguous typing.
For example, a field of type integer could also be represented as a string reference
(e.g. that integer gets provided at runtime).
The types introduced in the example are therefore incomplete and are likely to be
revisioned in a future version.

<a id="module-flows_sdk.implementations.idp_v44.idp_blocks"></a>

### *class* flows_sdk.implementations.idp_v44.idp_blocks.IDPCoreBlock(idp_wf_config, reference_name='_\_idp_core_\_', title='Start Document Processing Subflow', description='Calls the Document Processing Subflow with the specified settings.', compatibility_spec=CompatibilitySpec(filter_roles=['idp_core'], filter_schema=None, label=None), identifier='IDP_CORE_V44', additional_inputs=None)

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

IDP core block includes the steps to process the passed documents into machine-readable
output.

Mandatory parameters:

* **Parameters:**
  **idp_wf_config** ([`IdpWorkflowConfig`](#flows_sdk.implementations.idp_v44.idp_values.IdpWorkflowConfig)) – IdpWorkflowConfig object with all flow-level configuration settings
  for IDP

Parameters with defaults:

* **Parameters:**
  * **reference_name** (`str` | `None`) – unique reference name within a flow, a unique one will be generated when
    not provided
  * **compatibility_spec** ([`CompatibilitySpec`](../source-docs.md#flows_sdk.types.CompatibilitySpec) | `None`) – defines a filter for flows that could be selected in the UI in place
    of “IDP Core” for the block. Defaults to flows with the role ‘idp_core’. The user will be
    able to pick any flow that matches the compatibility_spec. This serves to make upgrading
    to a new compatible version of “IDP Core” (e.g. IDP_CORE_V39) easier in future releases.
  * **identifier** (`str`) – The identifier of the flow. Defaults to the IDP_CORE_VXX identifier of the
    out-of-the-box flow that comes with the system.
  * **additional_inputs** (`dict`[`str`, `Any`] | `None`) – Dictionary containing key-value pairs that will be added to the
    inputs of the block. If a key is contained in the default inputs, its value will be
    overwritten by the value provided here. You generally do not need to provide
    additional_inputs, unless you are creating a custom derivative of the IDP_CODE_Vxx flow
    and are modifying or extending the list of inputs it accepts.

Example usage:

```default
idp_core = IDPCoreBlock(idp_wf_config=idp_wf_config)
```

#### REFERENCE_NAME *= '_\_idp_core_\_'*

### *class* flows_sdk.implementations.idp_v44.idp_blocks.SubmissionBootstrapBlock(reference_name=None, trigger='${workflow.input.$trigger}', layout_release_uuid='${workflow.input.layout_release_uuid}', s3_config='${workflow.input.submission_bootstrap_s3_config}', s3_endpoint_url='${workflow.input.submission_bootstrap_s3_endpoint_url}', ocs_config='${workflow.input.submission_bootstrap_ocs_config}', ocs_host_url='${workflow.input.submission_bootstrap_ocs_host_url}', ocs_username='${workflow.input.submission_bootstrap_ocs_username}', ocs_password='${workflow.input.submission_bootstrap_ocs_password}', ocs_ssl_cert='${workflow.input.submission_bootstrap_ocs_ssl_cert}', http_config='${workflow.input.submission_bootstrap_http_config}', oauth_token_url='${workflow.input.submission_bootstrap_oauth_token_url}', oauth_client_id='${workflow.input.submission_bootstrap_oauth_client_id}', oauth_client_secret='${workflow.input.submission_bootstrap_oauth_client_secret}', oauth_scope='${workflow.input.submission_bootstrap_oauth_scope}', abs_auth_type='${workflow.input.submission_bootstrap_abs_auth_type}', abs_account_url='${workflow.input.submission_bootstrap_abs_account_url}', abs_tenant_id='${workflow.input.submission_bootstrap_abs_tenant_id}', abs_client_id='${workflow.input.submission_bootstrap_abs_client_id}', abs_client_secret='${workflow.input.submission_bootstrap_abs_client_secret}', abs_authority_host='${workflow.input.submission_bootstrap_abs_authority_host}', abs_account_name='${workflow.input.submission_bootstrap_abs_account_name}', abs_account_key='${workflow.input.submission_bootstrap_abs_account_key}', gcs_credentials_json='${workflow.input.submission_bootstrap_gcs_credentials_json}', gcs_workload_identity='${workflow.input.submission_bootstrap_gcs_workload_identity}', max_number_pages_enabled='${workflow.input.submission_bootstrap_max_number_pages_enabled}', max_number_pages='${workflow.input.submission_bootstrap_max_number_pages}', notification_workflow='${workflow.input.notification_workflow_initialization}', workflow_uuid='${workflow.input.workflow_uuid}', workflow_name='${workflow.input.workflow_name}', workflow_version='${workflow.input.workflow_version}', submission='${workflow.input.submission}', oauth_client_auth_method='${workflow.input.submission_bootstrap_oauth_client_auth_method}')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Submission bootstrap block initializes the submission object and prepares external images
or other submission data if needed.
**This block should be called at the START of every flow** that
uses blocks included in the library.

Parameters with defaults:

* **Parameters:**
  * **reference_name** (`str` | `None`) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **trigger** (`str`) – the trigger input from a connector - if not set explicitly,
    it will default to the workflow input trigger (which is where this value is normally found)
  * **layout_release_uuid** (`str`) – Layout Release UUID at submission creation time,
    defaults to workflow_input(Settings.LayoutReleaseUuid)
  * **s3_config** (`str`) – Specify Amazon S3 credentials for submission retrieval store.
    Expects a json expression: `{"aws_access_key_id": "X", "aws_secret_access_key": "Y"}`,
    defaults to workflow_input(Settings.SubmissionBootstrapS3Config)
  * **s3_endpoint_url** (`str`) – Endpoint URL for S3 submission retrieval store,
    defaults to workflow_input(Settings.SubmissionBootstrapS3EndpointUrl)
  * **ocs_config** (`str`) – OCS Configuration for downloading submission data.
    @deprecated since v43.1; will be removed in v46.0.
    defaults to workflow_input(Settings.SubmissionBootstrapOCSConfig)
  * **ocs_host_url** (`str` | `None`) – Available from V42.3; OCS host URL for submission retrieval store,
    @deprecated since v43.1; will be removed in v46.0.
    defaults to workflow_input(Settings.SubmissionBootstrapOCSHostUrl)
  * **ocs_username** (`str` | `None`) – Available from V42.3; OCS username for authentication,
    @deprecated since v43.1; will be removed in v46.0.
    defaults to workflow_input(Settings.SubmissionBootstrapOCSUsername)
  * **ocs_password** (`str` | `None`) – Available from V42.3; OCS password for authentication,
    @deprecated since v43.1; will be removed in v46.0.
    defaults to workflow_input(Settings.SubmissionBootstrapOCSPassword)
  * **ocs_ssl_cert** (`str` | `None`) – Available from V42.3; CA bundle filename inside $HS_PATH/certs directory or
    “SKIP” to disable validation,
    @deprecated since v43.1; will be removed in v46.0.
    defaults to workflow_input(Settings.SubmissionBootstrapOCSSslCert)
  * **http_config** (`str` | `None`) – An optional system secret field expressing the HTTP Configuration for
    downloading submission data. The content is expected to be a json formatted as:
    `{"username": "X", "password": "Y", "ssl_cert": "CA bundle filename"}`,
    defaults to workflow_input(Settings.SubmissionBootstrapHTTPConfig)
  * **oauth_token_url** (`str` | `None`) – OAuth token endpoint for client credentials authentication.
  * **oauth_client_id** (`str` | `None`) – Client ID for OAuth client credentials.
  * **oauth_client_secret** (`str` | `None`) – Client secret for OAuth client credentials.
  * **oauth_scope** (`str` | `None`) – Optional OAuth scope sent with the OAuth client credentials token request.
  * **abs_auth_type** (`str` | `None`) – The type of authentication to use for Azure Blob Storage
    (‘SAS Token Only’ / ‘Service Principal’ / ‘Managed Identity’ / ‘Account Key’),
    defaults to workflow_input(Settings.SubmissionBootstrapABSAuthType)
  * **abs_account_url** (`str` | `None`) – The URL of the Azure Blob Storage account,
    defaults to workflow_input(Settings.SubmissionBootstrapABSAccountUrl)
  * **abs_tenant_id** (`str` | `None`) – The tenant ID of the service principal,
    defaults to workflow_input(Settings.SubmissionBootstrapABSTenantId)
  * **abs_client_id** (`str` | `None`) – The client ID of the service principal or managed identity,
    defaults to workflow_input(Settings.SubmissionBootstrapABSClientId)
  * **abs_client_secret** (`str` | `None`) – The client secret of the service principal,
    defaults to workflow_input(Settings.SubmissionBootstrapABSClientSecret)
  * **abs_authority_host** (`str` | `None`) – The authority host of the service principal,
    defaults to workflow_input(Settings.SubmissionBootstrapABSAuthorityHost)
  * **abs_account_name** (`str` | `None`) – The account name of the Azure Blob Storage account,
    defaults to workflow_input(Settings.SubmissionBootstrapABSAccountName)
  * **abs_account_key** (`str` | `None`) – The account key of the Azure Blob Storage account,
    defaults to workflow_input(Settings.SubmissionBootstrapABSAccountKey)
  * **gcs_credentials_json** (`str`) – GCS service account credentials in JSON format,
    defaults to workflow_input(Settings.SubmissionBootstrapGCSCredentialsJson)
  * **gcs_workload_identity** (`str`) – Whether to obtain the credentials by using the Workload Identity Federation,
    applicable for HS installations inside GKE clusters,
    defaults to workflow_input(Settings.SubmissionBootstrapGCSWorkloadIdentity)
  * **max_number_pages_enabled** (`str` | `None`) – An optional parameter (flag) controlling whether the
    configured max number of pages is taken into account
  * **max_number_pages** (`str` | `None`) – An optional parameter specifying the max number of pages for
    downstream processing. Submissions with pages exceeding this configured value will fail.
    The default value is set to 10_000 pages.
  * **notification_workflow** (`str` | `None`) – Notification flow name to run when the submission is initialized,
    defaults to workflow_input(Settings.SubmissionBootstrapNotificationWorkflow)
  * **workflow_uuid** (`str`) – UUID of the triggered workflow version,
    defaults to workflow_input(Inputs.WorkflowUuid)
  * **workflow_name** (`str`) – Name of the triggered workflow,
    defaults to workflow_input(Inputs.WorkflowName)
  * **workflow_version** (`str`) – Version of the triggered workflow,
    defaults to workflow_input(Inputs.WorkflowVersion)
  * **submission** (`dict`[`str`, `Any`] | `str` | `None`) – [`Submission`](#flows_sdk.implementations.idp_v44.contracts.Submission)
    object
  * **oauth_client_auth_method** (`str` | `None`) – How OAuth client credentials are sent to the token endpoint.

Output:
The block returns an object with the following keys:

* submission: [`Submission`](#flows_sdk.implementations.idp_v44.contracts.Submission)
  object.
* api_params: a dictionary containing the parameters with which the submission was
  initialized. Extracted from the block’s trigger input.

Example usage:

```default
submission_bootstrap = SubmissionBootstrapBlock(reference_name='submission_bootstrap')
```

#### IDENTIFIER *= 'SUBMISSION_BOOTSTRAP_4'*

### *class* flows_sdk.implementations.idp_v44.idp_blocks.MachineCollationBlock(submission, cases, dedupe_files='${workflow.input.machine_collation_dedupe_files}', refresh_retention_period='${workflow.input.machine_collation_refresh_retention_period}', remove_from_cases='${workflow.input.machine_collation_remove_from_cases}', retention_period='${workflow.input.machine_collation_retention_period}', reference_name=None)

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Machine collation block groups files, documents and pages (from the submission) into cases.

Mandatory parameters:

* **Parameters:**
  * **submission** (`dict`[`str`, `Any`] | `str`) – [`Submission`](#flows_sdk.implementations.idp_v44.contracts.Submission)
    object
  * **cases** (`list`[`dict`[`str`, `Any`]] | `str`) – 

    This parameter accepts an array of JSON objects that contain information on
    how Cases should be created. There are two ways to collate a case: by the filenames
    specified in the current Submission, or by the ids of the Documents or Pages submitted
    in previous submissions.

    This parameter follows the given format:
    ```default
    {
        'cases': [
            'external_case_id': 'HS-1',
            'filename': 'file1.pdf',
            'documents': [42],
            'pages': [43]
        ]
    }
    ```

Parameters with defaults:

* **Parameters:**
  * **dedupe_files** (`bool` | `str`) – Enabling this setting will replace case data from repeated file names
    within the same case. Cases will retain data from the most recently submitted version of
    a particular file. Note that this setting does not delete the old data, it just removes it
    from the case. Keep in mind this option is only relevant when adding to cases.
    Defaults to workflow_input(Settings.CollationDedupeFiles)
  * **refresh_retention_period** (`bool` | `str`) – If `True`, (re)applies Retention Period parameter to all
    cases passed into the block. If `False`, only updates those without a pre-existing
    deletion date. Defaults to workflow_input(Settings.CollationRefreshRetentionPeriod)
  * **remove_from_cases** (`list`[`dict`[`str`, `Any`]] | `str` | `None`) – 

    This parameter accepts an array of JSON objects that contains
    information on how documents or pages should be removed from a pre-existing case.
    Currently, the only way to de-collate from a case is by the ids of the Documents or
    Pages within a given case, defaults to workflow_input(Settings.CollationRemoveFromCases)

    This parameter follows the given format:
    ```default
    {
        'remove_from_cases': [
            'external_case_id': 'HS-1',
            'documents': [42],
            'pages': [43]
        ]
    }
    ```
  * **retention_period** (`int` | `str` | `None`) – The number of days to retain cases after they are updated by this
    block. If passed `None`, no changes to the deletion date will be made.
    Defaults to workflow_input(Settings.CollationRetentionPeriod)
  * **reference_name** (`str` | `None`) – unique identifier within a flow, a unique one will be generated when
    not provided

Output:
The block returns an object with the following keys:

* submission: [`Submission`](#flows_sdk.implementations.idp_v44.contracts.Submission)
  object.

Example usage:

```default
machine_collation = MachineCollationBlock(
    reference_name='machine_collation',
    submission=submission_bootstrap.output('submission'),
    cases=submission_bootstrap.output('api_params.cases'),
    dedupe_files=True,
    remove_from_cases=custom_supervision.output('remove_from_cases')
)
```

#### IDENTIFIER *= 'MACHINE_COLLATION_2'*

### *class* flows_sdk.implementations.idp_v44.idp_blocks.MachineClassificationBlock(submission, api_params, reference_name=None, rotation_correction_enabled='${workflow.input.machine_classification_rotation_correction_enabled}', mobile_processing_enabled='${workflow.input.machine_classification_mobile_processing_enabled}', file_transcription_enabled='${workflow.input.machine_classification_file_transcription_enabled}', layout_release_uuid='${workflow.input.layout_release_uuid}', vpc_registration_threshold='${workflow.input.structured_layout_match_threshold}', nlc_enabled='${workflow.input.semi_structured_classification}', nlc_target_accuracy='${workflow.input.semi_target_accuracy}', nlc_doc_grouping_logic='${workflow.input.semi_doc_grouping_logic}', layout_id_dealbreaker='${workflow.input.layout_id_dealbreaker}', layout_id_dealbreaker_bypass='${workflow.input.layout_id_dealbreaker_bypass}', manual_nlc_enabled='${workflow.input.manual_nlc_enabled}')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Machine classification block automatically matches documents to structured,
semi-structured or additional layouts

Mandatory parameters:

* **Parameters:**
  * **submission** (`dict`[`str`, `Any`] | `str`) – [`Submission`](#flows_sdk.implementations.idp_v44.contracts.Submission)
    object
  * **api_params** (`dict`[`str`, `Any`] | `str`)

Parameters with defaults:

* **Parameters:**
  * **reference_name** (`str` | `None`) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **rotation_correction_enabled** (`bool` | `str`) – Identifies and corrects the orientation of
    semi-structured images,
    defaults to workflow_input(Settings.RotationCorrectionEnabled)
  * **mobile_processing_enabled** (`bool` | `str`) – Improves the machine readability of photo
    captured documents,
    defaults to workflow_input(Settings.MobileProcessingEnabled)
  * **file_transcription_enabled** (`bool` | `str`) – Improves the transcription speed of pdf files.
    Make sure that the “Image Correction” option is disabled and the pdfs you
    submit do not contain any rotated images
    defaults to workflow_input(Settings.FileTranscriptionEnabled)
  * **layout_release_uuid** (`str`) – Layout Release UUID at submission creation time,
    defaults to workflow_input(Settings.LayoutReleaseUuid)
  * **vpc_registration_threshold** (`str` | `float`) – Structured pages above this threshold will be
    automatically matched to a layout variation,
    defaults to workflow_input(Settings.StructuredLayoutMatchThreshold)
  * **nlc_enabled** (`str` | `bool`) – Enables workflow to manage a model for automated classification
    of semi-structured and additional layout variations,
    defaults to workflow_input(Settings.SemiStructuredClassification)
  * **nlc_target_accuracy** (`str` | `float`) – defaults to workflow_input(Settings.SemiTargetAccuracy)
  * **nlc_doc_grouping_logic** (`str`) – Logic to handle multiple pages matched to the same
    layout variation a given submission,
    defaults to workflow_input(Settings.SemiDocGroupingLogic)
  * **layout_id_dealbreaker** (`str` | `bool`) – Validates structured document matching by ensuring that the
    Form ID on the document matches the Layout ID on the corresponding layout,
    defaults to workflow_input(Settings.LayoutIdDealbreaker)
  * **layout_id_dealbreaker_bypass** (`str` | `bool`) – Bypasses Form ID and Layout ID validation if there is
    no Layout ID present on the Layout Page,
    defaults to workflow_input(Settings.LayoutIdDealbreakerBypass)
  * **manual_nlc_enabled** (`str` | `bool`) – Available from V41.2; enables manual classification when applicable,
    defaults to workflow_input(Settings.ManualNlcEnabled)

Output:
The block returns an object with the following keys:

* submission: [`Submission`](#flows_sdk.implementations.idp_v44.contracts.Submission) with
  the documents and unassigned_pages fields updated with the classification results.
* needs_manual_classification: A boolean flag indicating whether the submission needs manual
  classification.
* vpc_metadata: Metadata related to the structured classification process.
* nlc_metadata: Metadata related to the non-structured classification process.

Example usage:

```default
machine_classification = MachineClassificationBlock(
    reference_name='machine_classification',
    submission=case_collation.output('submission'),
    api_params=submission_bootstrap.output('result.api_params'),
    rotation_correction_enabled=idp_wf_config.rotation_correction_enabled,
)
```

#### IDENTIFIER *= 'MACHINE_CLASSIFICATION_8'*

### *class* flows_sdk.implementations.idp_v44.idp_blocks.ManualClassificationBlock(submission, api_params, reference_name=None, layout_release_uuid='${workflow.input.layout_release_uuid}', manual_nlc_enabled='${workflow.input.manual_nlc_enabled}', task_restrictions='${workflow.input.manual_classification_task_restrictions}', notification_workflow='${workflow.input.notification_workflow_classification}', vpc_registration_threshold='${workflow.input.structured_layout_match_threshold}', nlc_metadata=None)

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Manual classification block allows keyers to manually match submissions to their layouts.
Keyers may perform manual classification if machine classification cannot automatically
match a submission to a layout with high confidence

Mandatory parameters:

* **Parameters:**
  * **submission** (`dict`[`str`, `Any`] | `str`) – [`Submission`](#flows_sdk.implementations.idp_v44.contracts.Submission)
    object
  * **api_params** (`dict`[`str`, `Any`] | `str`)

Parameters with defaults:

* **Parameters:**
  * **reference_name** (`str` | `None`) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **layout_release_uuid** (`str`) – Layout Release UUID at submission creation time,
    defaults to workflow_input(Settings.LayoutReleaseUuid)
  * **manual_nlc_enabled** (`str` | `bool`) – Enables manual classification when applicable,
    defaults to workflow_input(Settings.ManualNlcEnabled)
  * **task_restrictions** (`list`[`Any`] | `str` | `None`) – Defines what users can access Supervision tasks created
    by this block,
    defaults to workflow_input(Settings.ManualClassificationTaskRestrictions)
  * **notification_workflow** (`str` | `None`) – Notification flow name to run when the submission
    enters Manual Classification,
    defaults to workflow_input(Settings.ManualClassificationNotificationWorkflow)
  * **vpc_registration_threshold** (`str` | `float` | `None`) – Structured pages above this threshold will be
    automatically matched to a layout variation when performing light vpc registration
    in the doc-org task,
    defaults to workflow_input(Settings.StructuredLayoutMatchThreshold)
  * **nlc_metadata** (`dict`[`str`, `Any`] | `str` | `None`) – Optional NLC metadata containing predictions per page from
    machine classification, used to populate best-guess layout suggestions in
    the manual classification supervision task,
    defaults to None

Output:
The block returns an object with the following keys:

* submission: [`Submission`](#flows_sdk.implementations.idp_v44.contracts.Submission) with
  the documents and unassigned_pages fields updated with the classification results.
* supervision_metadata: Metadata about the created supervision task.

Example usage:

```default
manual_classification = ManualClassificationBlock(
    reference_name='manual_classification',
    submission=machine_classification.output('submission'),
    api_params=submission_bootstrap.output('result.api_params'),
)
```

#### IDENTIFIER *= 'MANUAL_CLASSIFICATION_7'*

### *class* flows_sdk.implementations.idp_v44.idp_blocks.MachineIdentificationBlock(submission, api_params, layout_release_uuid='${workflow.input.layout_release_uuid}', reference_name=None, manual_field_id_enabled='${workflow.input.manual_field_id_enabled}', force_required_missing_entries_to_sv='${workflow.input.force_required_entries_to_sv}', field_id_target_accuracy='${workflow.input.field_id_target_accuracy}', table_id_target_accuracy='${workflow.input.table_id_target_accuracy}', id_target_accuracies='${workflow.input.identification_target_accuracies}')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Machine identification automatically identifies fields and tables in the submission

Mandatory parameters:

* **Parameters:**
  * **submission** (`dict`[`str`, `Any`] | `str`) – [`Submission`](#flows_sdk.implementations.idp_v44.contracts.Submission)
    object
  * **api_params** (`dict`[`str`, `Any`] | `str`)

Parameters with defaults:

* **Parameters:**
  * **layout_release_uuid** (`str`) – Layout Release UUID at submission creation time,
    defaults to workflow_input(Settings.LayoutReleaseUuid)
  * **reference_name** (`str` | `None`) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **manual_field_id_enabled** (`bool` | `str`) – Enables manual identification when applicable,
    defaults to workflow_input(Settings.ManualFieldIdEnabled)
  * **force_required_missing_entries_to_sv** (`bool` | `str`) – defaults to workflow_input(Settings.ForceRequiredEntriesToSV)
  * **field_id_target_accuracy** (`float` | `str`) – Field ID Target Accuracy,
    defaults to workflow_input(Settings.FieldIdTargetAccuracy)
  * **table_id_target_accuracy** (`float` | `str`) – Table ID Target Accuracy,
    defaults to workflow_input(Settings.TableIdTargetAccuracy)
  * **id_target_accuracies** (`list`[`dict`[`str`, `Any`]] | `str`) – defaults to workflow_input(Settings.IdentificationTargetAccuracies)

Output:
The block returns an object with the following keys:

* submission: [`Submission`](#flows_sdk.implementations.idp_v44.contracts.Submission) with
  its documents updated with the identified fields and tables.
* needs_manual_identification: A boolean flag indicating whether the submission needs
  Identification Supervision.
* fl_metadata: Metadata related to the Field Identification process.
* tl_metadata: Metadata related to the Table Identification process.

Example usage:

```default
machine_identification = MachineIdentificationBlock(
    reference_name='machine_identification',
    submission=manual_classification.output('submission'),
    api_params=submission_bootstrap.output('result.api_params'),
)
```

#### IDENTIFIER *= 'MACHINE_IDENTIFICATION_9'*

### *class* flows_sdk.implementations.idp_v44.idp_blocks.ManualIdentificationBlock(submission, api_params, reference_name=None, task_restrictions='${workflow.input.manual_identification_task_restrictions}', manual_field_id_enabled='${workflow.input.manual_field_id_enabled}', layout_release_uuid='${workflow.input.layout_release_uuid}', notification_workflow='${workflow.input.notification_workflow_identification}')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Manual identification allows keyers to complete field identification or table identification
tasks, where they draw bounding boxes around the contents of certain fields, table columns
or table rows. This identification process ensures that the system will be able to
transcribe the correct content in the upcoming transcription process

Mandatory parameters:

* **Parameters:**
  * **submission** (`dict`[`str`, `Any`] | `str`) – [`Submission`](#flows_sdk.implementations.idp_v44.contracts.Submission)
    object
  * **api_params** (`dict`[`str`, `Any`] | `str`)

Parameters with defaults:

* **Parameters:**
  * **reference_name** (`str` | `None`) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **task_restrictions** (`list`[`Any`] | `str` | `None`) – Defines what users can access Supervision tasks created
    by this block,
    defaults to workflow_input(Settings.ManualFieldIdTaskRestrictions)
  * **manual_field_id_enabled** (`bool` | `str`) – Enables manual identification when applicable,
    defaults to workflow_input(Settings.ManualFieldIdEnabled)
  * **layout_release_uuid** (`str`) – Layout Release UUID at submission creation time,
    defaults to workflow_input(Settings.LayoutReleaseUuid)
  * **notification_workflow** (`str`) – Notification flow name to run when the submission
    enters Manual Identification,
    defaults to workflow_input(Settings.ManualFieldIdNotificationWorkflow)

Output:
The block returns an object with the following keys:

* submission: [`Submission`](#flows_sdk.implementations.idp_v44.contracts.Submission) with
  its documents updated with the identified fields and tables.

Example usage:

```default
manual_identification = ManualIdentificationBlock(
    reference_name='manual_identification',
    submission=machine_identification.output('submission'),
    api_params=submission_bootstrap.output('result.api_params'),
    task_restrictions=idp_wf_config.manual_identification_config.task_restrictions,
)
```

#### IDENTIFIER *= 'MANUAL_IDENTIFICATION_6'*

### *class* flows_sdk.implementations.idp_v44.idp_blocks.MachineTranscriptionBlock(submission, api_params, reference_name=None, layout_release_uuid='${workflow.input.layout_release_uuid}', transcription_model='${workflow.input.transcription_model}', finetuning_only_trained_layouts='${workflow.input.finetuning_only_trained_layouts}', force_normalization_errors_to_sv='${workflow.input.force_normalization_errors_to_sv}', force_required_blank_entries_to_sv='${workflow.input.force_required_entries_to_sv}', transcription_overrides='${workflow.input.transcription_overrides}', structured_text_target_accuracy='${workflow.input.structured_text_target_accuracy}', structured_text_confidence_threshold='${workflow.input.structured_text_threshold}', structured_text_acceptable_confidence='${workflow.input.structured_min_leg_threshold}', semi_structured_text_target_accuracy='${workflow.input.semi_structured_text_target_accuracy}', semi_structured_text_confidence_threshold='${workflow.input.semi_structured_text_threshold}', semi_structured_text_acceptable_confidence='${workflow.input.semi_structured_min_leg_threshold}', semi_structured_table_target_accuracy='${workflow.input.semi_structured_table_target_accuracy}', semi_structured_table_confidence_threshold='${workflow.input.semi_structured_table_threshold}', semi_structured_table_acceptable_confidence='${workflow.input.semi_structured_table_min_leg_threshold}', structured_checkbox_target_accuracy='${workflow.input.structured_checkbox_target_accuracy}', structured_checkbox_confidence_threshold='${workflow.input.structured_checkbox_threshold}', structured_checkbox_acceptable_confidence='${workflow.input.checkbox_min_leg_threshold}', structured_signature_target_accuracy='${workflow.input.structured_signature_target_accuracy}', structured_signature_confidence_threshold='${workflow.input.structured_signature_threshold}', structured_signature_acceptable_confidence='${workflow.input.signature_min_leg_threshold}', semi_structured_checkbox_target_accuracy='${workflow.input.semi_structured_checkbox_target_accuracy}', semi_structured_checkbox_confidence_threshold='${workflow.input.semi_structured_checkbox_threshold}', semi_structured_checkbox_acceptable_confidence='${workflow.input.semi_structured_checkbox_min_leg_threshold}', field_target_accuracies='${workflow.input.field_transcription_target_accuracies}', always_supervise_blank_cells='${workflow.input.manual_transcription_always_supervise_blank_cells}', manual_transcription_enabled='${workflow.input.manual_transcription_enabled}', address_parsing_enabled='${workflow.input.address_parsing_enabled}', address_parser_api_provider='${workflow.input.address_parser_api_provider}', address_parser_api_key='${workflow.input.address_parser_api_key}', address_parser_api_options='${workflow.input.address_parser_api_options}')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Machine transcription automatically transcribes the content of your submission

Mandatory parameters:

* **Parameters:**
  * **submission** (`Any`) – Submission object
  * **api_params** (`Any`)

Parameters with defaults:

* **Parameters:**
  * **reference_name** (`str` | `None`) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **layout_release_uuid** (`str`) – Layout Release UUID at submission creation time,
    defaults to workflow_input(Settings.LayoutReleaseUuid)
  * **transcription_model** (`str`) – The transcription model that will be used for this flow,
    defaults to workflow_input(Settings.TranscriptionModel)
  * **finetuning_only_trained_layouts** (`str` | `bool`) – defaults to workflow_input(Settings.FinetuningOnlyTrainedLayouts)
  * **force_normalization_errors_to_sv** (`str` | `bool`) – defaults to workflow_input(Settings.ForceNormalizationErrorsToSV)
  * **force_required_blank_entries_to_sv** (`str` | `bool`) – defaults to workflow_input(Settings.ForceRequiredEntriesToSV)
  * **transcription_overrides** (`str`) – defaults to workflow_input(Settings.TranscriptionOverrides)
  * **structured_text_target_accuracy** (`str` | `float`) – defaults to workflow_input(Settings.StructuredTextTargetAccuracy)
  * **structured_text_confidence_threshold** (`str` | `float`) – defaults to workflow_input(Settings.StructuredTextThreshold)
  * **structured_text_acceptable_confidence** (`str` | `float`) – defaults to workflow_input(Settings.StructuredTextMinLegThreshold)
  * **semi_structured_text_target_accuracy** (`str` | `float`) – defaults to workflow_input(Settings.SemiStructuredTextTargetAccuracy)
  * **semi_structured_text_confidence_threshold** (`str` | `float`) – defaults to workflow_input(Settings.SemiStructuredTextThreshold)
  * **semi_structured_text_acceptable_confidence** (`str` | `float`) – defaults to workflow_input(Settings.SemiStructuredTextMinLegThreshold)
  * **semi_structured_table_target_accuracy** (`str` | `float`) – defaults to workflow_input(Settings.SemiStructuredTableTargetAccuracy)
  * **semi_structured_table_confidence_threshold** (`str` | `float`) – defaults to workflow_input(Settings.SemiStructuredTableThreshold)
  * **semi_structured_table_acceptable_confidence** (`str` | `float`) – defaults to workflow_input(Settings.SemiStructuredTableMinLegThreshold)
  * **structured_checkbox_target_accuracy** (`str` | `float`) – defaults to workflow_input(Settings.StructuredCheckboxTargetAccuracy)
  * **structured_checkbox_confidence_threshold** (`str` | `float`) – defaults to workflow_input(Settings.StructuredCheckboxThreshold)
  * **structured_checkbox_acceptable_confidence** (`str` | `float`) – defaults to workflow_input(Settings.StructuredCheckboxMinLegThreshold)
  * **structured_signature_target_accuracy** (`str` | `float`) – defaults to workflow_input(Settings.StructuredSignatureTargetAccuracy)
  * **structured_signature_confidence_threshold** (`str` | `float`) – defaults to workflow_input(Settings.StructuredSignatureThreshold)
  * **structured_signature_acceptable_confidence** (`str` | `float`) – defaults to workflow_input(Settings.StructuredSignatureMinLegThreshold)
  * **semi_structured_checkbox_target_accuracy** (`str` | `float`) – defaults to workflow_input(Settings.SemiStructuredCheckboxTargetAccuracy)
  * **semi_structured_checkbox_confidence_threshold** (`str` | `float`) – defaults to workflow_input(Settings.SemiStructuredCheckboxThreshold)
  * **semi_structured_checkbox_acceptable_confidence** (`str` | `float`) – defaults to workflow_input(Settings.SemiStructuredCheckboxMinLegThreshold)
  * **field_target_accuracies** (`str`) – defaults to workflow_input(Settings.FieldTranscriptionTargetAccuracies)
  * **always_supervise_blank_cells** (`str` | `bool` | `None`) – Available from V41.2; if enabled, always send blank cells
    in transcribed tables to be supervised manually, regardless of confidence
    defaults to workflow_input(Settings.ManualTranscriptionAlwaysSuperviseBlankCells)
  * **manual_transcription_enabled** (`str` | `bool` | `None`) – Available from V41.2; enables manual transcription when
    applicable, defaults to workflow_input(Settings.ManualTranscriptionEnabled)
  * **address_parsing_enabled** (`str` | `bool`) – Available from V43.2; toggles AddressParser invocation on
    machine-transcribed address fields,
    defaults to workflow_input(AddressParserSettings.AddressParsingEnabled)
  * **address_parser_api_provider** (`str`) – Available from V43.2; selects the address parsing
    provider (‘none’ / ‘google’ / ‘smarty’ / ‘geoapify’),
    defaults to workflow_input(AddressParserSettings.ApiProvider)
  * **address_parser_api_key** (`str` | `None`) – Available from V43.2; API key for the configured provider,
    defaults to workflow_input(AddressParserSettings.ApiKey)
  * **address_parser_api_options** (`str` | `dict` | `None`) – Available from V43.2; provider-specific JSON options,
    defaults to workflow_input(AddressParserSettings.ApiOptions)

Output:
The block returns an object with the following keys:

* submission: [`Submission`](#flows_sdk.implementations.idp_v44.contracts.Submission) with
  the transcribed field values.
* transcription_metadata: Metadata related to the transcription process.
* needs_manual_transcription: A boolean flag indicating whether the submission needs
  manual transcription.
* needs_flexible_extraction: A boolean flag indicating whether the submission needs
  flexible extraction.

Example usage:

```default
machine_transcription = MachineTranscriptionBlock(
    reference_name='machine_transcription',
    submission=manual_identification.output('submission'),
    api_params=submission_bootstrap.output('result.api_params'),
)
```

#### IDENTIFIER *= 'MACHINE_TRANSCRIPTION_10'*

### *class* flows_sdk.implementations.idp_v44.idp_blocks.ManualTranscriptionBlock(submission, api_params, reference_name=None, supervision_transcription_masking='${workflow.input.manual_transcription_supervision_transcription_masking}', table_output_manual_review='${workflow.input.manual_transcription_table_output_manual_review}', always_supervise_blank_cells='${workflow.input.manual_transcription_always_supervise_blank_cells}', task_restrictions='${workflow.input.manual_transcription_task_restrictions}', manual_transcription_enabled='${workflow.input.manual_transcription_enabled}', notification_workflow='${workflow.input.notification_workflow_transcription}', address_parsing_enabled='${workflow.input.address_parsing_enabled}', address_parser_api_provider='${workflow.input.address_parser_api_provider}', address_parser_api_key='${workflow.input.address_parser_api_key}', address_parser_api_options='${workflow.input.address_parser_api_options}', title='Manual Transcription', description='Manually transcribe fields that could not be automatically transcribed')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Manual transcription lets your keyers manually enter the text found in fields or tables
that could not be automatically transcribed

Mandatory parameters:

* **Parameters:**
  * **submission** (`Any`) – Submission object
  * **api_params** (`Any`)

Parameters with defaults:

* **Parameters:**
  * **reference_name** (`str` | `None`) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **supervision_transcription_masking** (`bool` | `str`) – Prevents users from inputting invalid
    characters during Supervision Transcription tasks,
    defaults to workflow_input(Settings.ManualTranscriptionSupervisionTranscriptionMasking)
  * **table_output_manual_review** (`bool` | `str`) – Always generates a table transcription task if the
    layout contains a table. If disabled, a table transcription task will only be
    generated if one or more cells have transcribed values below the defined thresholds,
    defaults to workflow_input(Settings.ManualTranscriptionTableOutputManualReview)
  * **always_supervise_blank_cells** (`bool` | `str`) – If enabled, always send blank cells in transcribed
    tables to be supervised manually, regardless of confidence
    defaults to workflow_input(Settings.ManualTranscriptionAlwaysSuperviseBlankCells)
  * **task_restrictions** (`list`[`Any`] | `str` | `None`) – Defines what users can access Supervision tasks for
    submission from a particular source or submissions matching a specific layout,
    defaults to workflow_input(Settings.ManualTranscriptionTaskRestrictions)
  * **manual_transcription_enabled** (`bool` | `str`) – Enables manual transcription when applicable,
    defaults to workflow_input(Settings.ManualTranscriptionEnabled)
  * **notification_workflow** (`str` | `None`) – Notification flow name to run when the submission
    enters Manual Transcription,
    defaults to workflow_input(Settings.ManualTranscriptionNotificationWorkflow)
  * **address_parsing_enabled** (`str` | `bool`) – Available from V43.2; toggles AddressParser invocation on
    manually-transcribed address fields,
    defaults to workflow_input(AddressParserSettings.AddressParsingEnabled)
  * **address_parser_api_provider** (`str`) – Available from V43.2; selects the address parsing
    provider (‘none’ / ‘google’ / ‘smarty’ / ‘geoapify’),
    defaults to workflow_input(AddressParserSettings.ApiProvider)
  * **address_parser_api_key** (`str` | `None`) – Available from V43.2; API key for the configured provider,
    defaults to workflow_input(AddressParserSettings.ApiKey)
  * **address_parser_api_options** (`str` | `dict` | `None`) – Available from V43.2; provider-specific JSON options,
    defaults to workflow_input(AddressParserSettings.ApiOptions)
  * **title** (`str`) – overrides the block’s default title shown in Flow Studio,
    defaults to ‘Manual Transcription’
  * **description** (`str`) – overrides the block’s default description shown in Flow Studio,
    defaults to ‘Manually transcribe fields that could not be automatically transcribed’

Output:
The block returns an object with the following keys:

* submission: [`Submission`](#flows_sdk.implementations.idp_v44.contracts.Submission) with
  the manually transcribed field values.

Example usage:

```default
manual_transcription = ManualTranscriptionBlock(
    reference_name='manual_transcription',
    submission=machine_transcription.output('submission'),
    api_params=submission_bootstrap.output('result.api_params'),
    supervision_transcription_masking=(
        idp_wf_config.manual_transcription_config.supervision_transcription_masking
    ),
    table_output_manual_review=(
        idp_wf_config.manual_transcription_config.table_output_manual_review
    ),
    task_restrictions=idp_wf_config.manual_transcription_config.task_restrictions,
)
```

#### IDENTIFIER *= 'MANUAL_TRANSCRIPTION_6'*

### *class* flows_sdk.implementations.idp_v44.idp_blocks.FlexibleExtractionBlock(submission, api_params, reference_name=None, supervision_transcription_masking='${workflow.input.flexible_extraction_supervision_transcription_masking}', task_restrictions='${workflow.input.flexible_extraction_task_restrictions}', notification_workflow='${workflow.input.notification_workflow_flexible_extraction}', show_machine_predictions='${workflow.input.flexible_extraction_show_machine_predictions}', searchable_pages='${workflow.input.flexible_extraction_searchable_pages}', address_parsing_enabled='${workflow.input.address_parsing_enabled}', address_parser_api_provider='${workflow.input.address_parser_api_provider}', address_parser_api_key='${workflow.input.address_parser_api_key}', address_parser_api_options='${workflow.input.address_parser_api_options}')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Flexible extraction manually transcribes fields marked for review

Mandatory parameters:

* **Parameters:**
  * **submission** (`Any`) – Submission object
  * **api_params** (`Any`)

Parameters with defaults:

* **Parameters:**
  * **reference_name** (`str` | `None`) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **supervision_transcription_masking** (`bool` | `str` | `None`) – Prevents users from inputting invalid
    characters during the Flexible Extraction task,
    defaults to workflow_input(Settings.FlexibleExtractionSupervisionTranscriptionMasking)
  * **task_restrictions** (`list`[`Any`] | `str` | `None`) – Defines what users can access Supervision tasks created
    by this block,
    defaults to workflow_input(Settings.FlexibleExtractionTaskRestrictions)
  * **notification_workflow** (`str` | `None`) – Notification flow name to run when the submission
    enters Flexible Extraction,
    defaults to workflow_input(Settings.FlexibleExtractionNotificationWorkflow)
  * **show_machine_predictions** (`bool` | `str` | `None`) – Available from V42.3; Shows the machine predictions in the
    Flexible Extraction Supervision tasks,
    defaults to workflow_input(Settings.FlexibleExtractionShowMachinePredictions)
  * **searchable_pages** (`bool` | `str` | `None`) – Available from V43.2; When enabled, enables searching by text
    segments in the Flexible Extraction Supervision tasks,
    defaults to workflow_input(Settings.FlexibleExtractionSearchablePages)
  * **address_parsing_enabled** (`str` | `bool`) – Available from V43.2; toggles AddressParser invocation on
    flexibly-extracted address fields,
    defaults to workflow_input(AddressParserSettings.AddressParsingEnabled)
  * **address_parser_api_provider** (`str`) – Available from V43.2; selects the address parsing
    provider (‘none’ / ‘google’ / ‘smarty’ / ‘geoapify’),
    defaults to workflow_input(AddressParserSettings.ApiProvider)
  * **address_parser_api_key** (`str` | `None`) – Available from V43.2; API key for the configured provider,
    defaults to workflow_input(AddressParserSettings.ApiKey)
  * **address_parser_api_options** (`str` | `dict` | `None`) – Available from V43.2; provider-specific JSON options,
    defaults to workflow_input(AddressParserSettings.ApiOptions)

Output:
The block returns an object with the following keys:

* submission: [`Submission`](#flows_sdk.implementations.idp_v44.contracts.Submission) with
  the fields marked for review updated with the transcribed values.

Example usage:

```default
flexible_extraction = FlexibleExtractionBlock(
    reference_name='flexible_extraction',
    submission=manual_transcription.output('submission'),
    api_params=submission_bootstrap.output('result.api_params'),
    supervision_transcription_masking=(
        idp_wf_config.flexible_extraction_config.supervision_transcription_masking
    ),
    task_restrictions=idp_wf_config.flexible_extraction_config.task_restrictions,
)
```

#### IDENTIFIER *= 'FLEXIBLE_EXTRACTION_6'*

### *class* flows_sdk.implementations.idp_v44.idp_blocks.ReprocessingBlock(reference_name, submission, parent_flow='${workflow.definition.identifier}', idp_wf_config='${workflow.input}', trigger='${workflow.input.$trigger}', reprocessing_enabled='${workflow.input.reprocessing_enabled}')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Reprocessing block enables a second extraction attempt if documents were initially
confidently mis-classified by the machine. When an end-user specifies that a document layout
is incorrect during Manual Identification, Manual Transcription, or Flexible Extraction, the
flow will reach the Reprocessing block which will mark correctly classified documents as
“complete” status. Misclassified documents with “reprocess” status will be marked with
status “reprocessing” and processed in a second execution of the flow. This block should be
placed before the SubmissionCompleteBlock to enable reprocessing.

**How the Reprocessing block works**

The Reprocessing block examines whether any documents within the submission have been marked
with an incorrect layout, and if so, redirects the submission to the classification step for
proper classification. It does this by recursively calling the same flow or subflow with the
same inputs and documents, but with the addition of a status key for each document to denote
which were marked with an incorrect layout during supervision.

#### NOTE
The Reprocessing block works in tandem with the “Mark Incorrect Layout” option presented
to users during Manual Identification, Manual Transcription, and Flexible Extraction
supervision interfaces introduced in R38. Include the Reprocessing block in all custom
flows in order to take advantage of this feature. The feature will remain selectable
in supervision interfaces even if the Reprocessing block is not included in the flow.

The initial flow run will pause execution at the Reprocessing block until the recursive flow
has completed, at which point the initial flow will resume to finish its execution. If an
error occurs during the execution of the recursive flow, that error will be raised to the
Reprocessing block of the initial flow.

#### NOTE
The recursive flow run is linked with the same correlation_id as the initial flow run
and the submission. Users can click the “View related flow runs” link on the left
sidebar of the initial flow run to view any recursive flow runs.

As expected, recursively calling the same flow may cause some blocks to run again, resulting
in unnecessary work being performed, or work which doesn’t gracefully handle duplications
(non-idempotent blocks). To mitigate this, certain Hyperscience-provided blocks - including
Submission Initialization, Machine Collation, and Machine Classification - detect when the
submission object already contains the output from its block to avoid re-execution. It’s a
best practice to build custom blocks such that they are idempotent and reentrant; if that’s
not feasible, you can add similar logic to custom blocks which do not depend on the layout
for the documents being processed. Common methods for handling this include:

* Iterating through each status key within the submission.document[] collection to see if
  any documents are set to “reprocess” or “reprocessing”.
* Inspecting if the submission object already contains a key or value explicitly defined
  by the custom code block.

**Recommended Placement for the Reprocessing Block**

* The Reprocessing block should not be placed before any supervision blocks which allow
  users to mark a document with an incorrect layout. These supervision blocks include
  Manual Identification, Manual Transcription and Flexible Extraction.
* The Reprocessing block should always be placed before the SubmissionComplete Block.
* The Reprocessing block can be used with flows which include multiple branches and
  conditionals; however, it’s recommended to ensure the Reprocessing block is executed
  to honor user’s selection of marking layouts incorrectly when supervising documents.
* In general, any custom logic that is to be performed after data has been extracted from
  documents should be placed after the Reprocessing block. To avoid duplicate executions of
  this custom logic, it is recommended to separate the document processing blocks - inclusive
  of the Reprocessing block - from the custom logic. This can be handled in different ways:
  > * Split the flow into separate subflows, where the Reprocessing block is in a subflow
  >   that does not contain the custom logic.
  > * Add a decision to bypass the custom logic if the Reprocessing block was triggered.
  >   With this method, the recursive flow run will execute the custom logic, and the initial
  >   flow run will bypass the logic.

Mandatory parameters:

* **Parameters:**
  **submission** (`Any`) – Submission object

Parameters with defaults:

* **Parameters:**
  * **parent_flow** (`str`) – The identifier of the flow that this block is placed in, used to
    recursively call the same flow, defaults to ‘${workflow.definition.identifier}’
  * **idp_wf_config** (`Any`) – The workflow input config to pass through to the recursive flow
    run, defaults to ‘${workflow.input}’
  * **trigger** (`Any`) – Value used to trigger and correlate the recursive flow run,
    defaults to workflow_input(IdpFlowInputs.Trigger)
  * **reprocessing_enabled** (`str` | `bool`) – Enables reprocessing of documents marked with an incorrect
    layout, defaults to workflow_input(Settings.ReprocessingEnabled)

Output:
The block returns an object with the following keys:

* submission: [`Submission`](#flows_sdk.implementations.idp_v44.contracts.Submission)
  updated with the reprocessing results.
* is_reprocessing: A boolean flag indicating whether the submission was sent for
  reprocessing.

#### IDENTIFIER *= 'REPROCESSING_2'*

### *class* flows_sdk.implementations.idp_v44.idp_blocks.SubmissionCompleteBlock(submission, is_reprocessing=False, reference_name=None, nlc_qa_sampling_ratio='${workflow.input.semi_qa_sample_rate}', field_id_qa_enabled='${workflow.input.field_id_qa_enabled}', field_id_qa_sampling_ratio='${workflow.input.field_id_qa_sample_rate}', table_id_qa_enabled='${workflow.input.table_id_qa_enabled}', table_id_qa_sampling_ratio='${workflow.input.table_id_qa_sample_rate}', transcription_qa_enabled='${workflow.input.qa}', transcription_structured_entry_qa_sample_rate='${workflow.input.structured_entry_qa_sample_rate}', transcription_structured_signature_qa_sample_rate='${workflow.input.structured_signature_qa_sample_rate}', transcription_structured_checkbox_qa_sample_rate='${workflow.input.structured_checkbox_qa_sample_rate}', transcription_semi_structured_qa_sample_rate='${workflow.input.semi_structured_qa_sample_rate}', table_cell_transcription_qa_enabled='${workflow.input.table_cell_transcription_qa_enabled}', table_cell_transcription_qa_sample_rate='${workflow.input.table_cell_transcription_qa_sample_rate}', auto_qa_sampling_rate_enabled='${workflow.input.auto_qa_sampling_rate_enabled}', exclude_auto_transcribe_fields_from_qa='${workflow.input.exclude_auto_transcribe_fields_from_qa}', payload=None)

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Submission complete block finalizes submission processing and updates reporting data.
**This block should be called at the END of every flow** that
uses blocks included in the `flows_sdk.implementations.idp_v34` library.
The block requires both the `submission` object and a `payload` to be passed in.

Mandatory parameters:

* **Parameters:**
  * **submission** (`str`) – Submission object
  * **payload** (`Any`) – Object to pass to downstream systems

Parameters with defaults:

* **Parameters:**
  * **is_reprocessing** (`str` | `bool`) – boolean to handle execution when reprocessing,
    defaults to False
  * **reference_name** (`str` | `None`) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **nlc_qa_sampling_ratio** (`str` | `int` | `float`) – Defines the percentage of pages sampled for
    Classification QA, defaults to workflow_input(Settings.SemiQaSampleRate)
  * **field_id_qa_enabled** (`str` | `bool`) – defaults to workflow_input(Settings.FieldIdQaEnabled)
  * **field_id_qa_sampling_ratio** (`str` | `int` | `float`) – Defines the percentage of fields sampled for
    Identification QA, defaults to workflow_input(Settings.FieldIdQaSampleRate)
  * **table_id_qa_enabled** (`str` | `bool`) – Allows users to verify the location of table cells,
    defaults to workflow_input(Settings.TableIdQaEnabled)
  * **table_id_qa_sampling_ratio** (`str` | `int` | `float`) – Defines the percentage of tables the
    system samples for QA, defaults to workflow_input(Settings.TableIdQaSampleRate)
  * **transcription_qa_enabled** (`str` | `bool`) – defaults to workflow_input(Settings.TranscriptionQaEnabled)
  * **transcription_structured_entry_qa_sample_rate** (`str` | `float`) – Defines the percentage of structured
    text fields the system samples for Transcription QA, defaults to
    workflow_input(Settings.TranscriptionStructuredEntryQaSampleRate)
  * **transcription_structured_signature_qa_sample_rate** (`str` | `float`) – Defines the percentage of structured
    signature fields sampled for Transcription QA, defaults to
    workflow_input(Settings.TranscriptionStructuredSignatureQaSampleRate)
  * **transcription_structured_checkbox_qa_sample_rate** (`str` | `float`) – Defines the percentage of structured
    checkbox fields sampled for Transcription QA, defaults to
    workflow_input(Settings.TranscriptionStructuredCheckboxQaSampleRate)
  * **transcription_semi_structured_qa_sample_rate** (`str` | `float`) – Defines the percentage of semi-
    structured fields the system samples for Transcription QA, defaults to
    workflow_input(Settings.TranscriptionSemiStructuredQaSampleRate)
  * **table_cell_transcription_qa_enabled** (`str` | `bool`) – defaults to workflow_input(Settings.TableCellTranscriptionQaEnabled)
  * **table_cell_transcription_qa_sample_rate** (`str` | `int` | `float`) – Defines the percentage of cells the
    system samples for QA. This value is likely to be lower than
    “Transcription QA Sample Rate” since there are more table cells than fields
    on any given page, defaults to workflow_input(Settings.TableCellTranscriptionQaSampleRate)
  * **auto_qa_sampling_rate_enabled** (`str` | `bool`) – Enables automatic selection of QA sampling rates
    based on system configuration or heuristics, defaults to
    workflow_input(Settings.AutoQaSamplingRateEnabled)
  * **exclude_auto_transcribe_fields_from_qa** (`str` | `bool`) – Defines whether fields that are marked as
    auto-transcribe in layout should be excluded from QA or not,
    defaults to workflow_input(Settings.ExcludeAutoTranscribeFieldsFromQA)

Output:
The block returns an object with the following keys:

* submission: [`Submission`](#flows_sdk.implementations.idp_v44.contracts.Submission) with
  the finalized submission processing and reporting data.

Example usage:

```default
submission_complete = SubmissionCompleteBlock(
    reference_name='complete_submission',
    submission=flexible_extraction.output('submission')
)
```

#### IDENTIFIER *= 'SUBMISSION_COMPLETE_5'*

### *class* flows_sdk.implementations.idp_v44.idp_blocks.SetTransformedOutputBlock(submission, transformed_output, reference_name=None)

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Set Transformed Output block sets the transformed output for the provided submission. This can
later be used to send the transformed data downstream using output blocks. For more information
see [https://docs.hyperscience.ai/#retrieving-transformed-submissions](https://docs.hyperscience.ai/#retrieving-transformed-submissions).

Mandatory parameters:

* **Parameters:**
  * **submission** (`dict`[`str`, `Any`] | `str`) – [`Submission`](#flows_sdk.implementations.idp_v44.contracts.Submission)
    object
  * **transformed_output** (`dict`[`str`, `Any`] | `str`) – Object that will be set as the transformed output for this submission

Output:
The block returns an object with the following keys:

* submission_id: identifier of the submission for which the transformed output was set

#### IDENTIFIER *= 'SET_TRANSFORMED_OUTPUT'*

### *class* flows_sdk.implementations.idp_v44.idp_blocks.IdpCustomSupervisionBlock(submission, task_purpose, supervision_template, data=None, reference_name=None, supervision_transcription_masking=True, task_restrictions=None, page_ids=None, notification_workflow='IDP_SUBMISSION_NOTIFY', chat_flow_identifier=None, title='IDP Custom Supervision', description='IDP Custom Supervision')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

An IDP wrapper for the Custom Supervision block. It has the same functionality,
but handles reading/writing data from the IDP database.

Mandatory parameters:

* **Parameters:**
  * **submission** (`Any`) – Workflow Submission object from upstream IDP Blocks.
  * **task_purpose** (`str`) – The custom task name that’s given to all supervision tasks that run
    through a particular instance of a custom supervision block. This can be used to filter
    tasks in the task queue.
  * **supervision_template** (`Any`) – JSON used for configuration of the Custom Supervision Task.

Parameters with defaults:

* **Parameters:**
  * **data** (`dict`[`str`, `Any`] | `None`) – Optional JSON structure that extends the data used to populate the
    supervision_template. This is intended to append to the data already gathered by the IDP
    wrapper. If there are any conflicting keys, the keys in this input will take precedent.
  * **reference_name** (`str` | `None`) – Unique identifier within a flow. A unique one will be generated when
    not provided.
  * **supervision_transcription_masking** (`str` | `bool`) – Prevents users from inputting invalid
    characters during the Custom Supervision task. Defaults to True.
  * **task_restrictions** (`str` | `list`[`Any`] | `None`) – Defines what users can access Supervision tasks created
    by this block. Defaults to [].
  * **page_ids** (`str` | `list`[`int`] | `None`) – If left empty, the IDP wrapper will, by default, pull in all pages
    in the submission. Adding a list of page IDs will override the default list of pages.
    Defaults to [].
  * **notification_workflow** (`str`) – Notification flow name to run when the submission
    enters Custom Supervision. Defaults to IDP_SUBMISSION_NOTIFY_NAME.
  * **chat_flow_identifier** (`str` | `None`) – Available from V41.2; optional chat flow identifier to enable
    Document Chat.
  * **title** (*Optional* *[**str* *]*) – UI-visible title of the block. Defaults to ‘IDP Custom Supervision’.
  * **description** (*Optional* *[**str* *]*) – Description of the block. Useful for documentation and shown in Flow Studio.
    Defaults to ‘IDP Custom Supervision’.

Example usage:

```default
idp_custom_supervision = IdpCustomSupervisionBlock(
    reference_name='idp_custom_supervision',
    submission=manual_transcription.output('submission'),
    task_purpose='make_custom_decision',
    supervision_template=[
        {
            'name': 'three_column_template',
            'version': '1.0',
            'thumbnail': {
                'group_by_document': True,
                'group_by_case': True,
            },
            'action': [
                {
                    'name': 'my_tab',
                    'display': 'SSN Info',
                    'input': [
                        {
                            'name': 'ssn_field',
                            'type': 'transcription',
                            'data_identifier': '2afd7a67-ddee-484f-ab6b-2d292752e5ee',
                            'title': 'SSN',
                        },
                    ],
                    'ui': {
                        'groups': [
                            {
                                'title': 'My Group',
                                'fields': ['ssn_field'],
                            },
                        ],
                    },
                },
            ],
        },
    ],
    data={
        'documents': [
            {
                'id': 2,
                'layout_uuid': 'e31c3cbf-dcea-44fd-a052-902463c6040f',
                'layout_name': 'layout_name',
                'page_count': 2,
                'read_only': False,
            }
        ]
    },
    supervision_transcription_masking=False,
)
```

#### IDENTIFIER *= 'IDP_CUSTOM_SUPERVISION_4'*

### *class* flows_sdk.implementations.idp_v44.idp_blocks.IDPFullPageTranscriptionBlock(submission, reference_name=None, title='Full Page Transcription (Submission)', description='Transcribes the documents included in a submission', app_metadata=None, language_family=None, rerun_segmentation=False)

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

IDP Full Page Transcription Block machine-transcribes the pages contained in a submission.

Mandatory parameters:

* **Parameters:**
  **submission** (`dict`[`str`, `Any`] | `str`) – [`Submission`](#flows_sdk.implementations.idp_v44.contracts.Submission)
  object that includes the pages that need to be transcribed

Optional Parameters:

* **Parameters:**
  * **reference_name** (`str` | `None`) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **app_metadata** (`list`[`str`] | `None`) – used for capturing information about the flow
  * **language_family** (`str` | `None`) – language family to use when instantiating the underlying transcription
    model. If not provided, the system will default to latin. Language families are single
    word lowercase strings, e.g., latin, arabic, korean, chinese.
    You can read more about language families in the
    “Supported Languages” article in the application documentation:
    [https://help.hyperscience.ai/v44/docs/supported-languages](https://help.hyperscience.ai/v44/docs/supported-languages).
  * **rerun_segmentation** (`bool`) – Available from V42.3; controls whether segmentation should be
    rerun for already segmented pages.

Output:
The block returns an object with the following keys:

* submission: [`Submission`](#flows_sdk.implementations.idp_v44.contracts.Submission) with
  the combined_segments field populated on its pages with the transcription results.

Example usage:

```default
# This is one way to obtain the submission object (using SubmissionBootstrapBlock)
submission_bootstrap = SubmissionBootstrapBlock(reference_name='submission_bootstrap')

idp_fpt_block = IDPFullPageTranscriptionBlock(
    reference_name='idp_fpt',
    submission=submission_bootstrap.output('submission'),
)

# reference to the output of IDPFullPageTranscriptionBlock which can be passed as input to
# the next block. For more information on output() and output references, please take a
# look at class Block and its output() method
output_ref = idp_fpt_block.output()
```

#### IDENTIFIER *= 'FULL_PAGE_TRANSCRIPTION_SUBMISSION_3'*

### *class* flows_sdk.implementations.idp_v44.idp_blocks.DocumentRendererBlock(submission, is_reprocessing=False, title='Document Renderer', description='Renders a document into a PDF', reference_name=None, document_rendering_enabled='${workflow.input.document_rendering_enabled}', document_rendering_mime_type='${workflow.input.document_rendering_mime_type}', document_rendering_unit='${workflow.input.document_rendering_unit}', document_rendering_height='${workflow.input.document_rendering_height}', document_rendering_width='${workflow.input.document_rendering_width}', document_rendering_quality='${workflow.input.document_rendering_quality}', document_rendering_mode='${workflow.input.document_rendering_mode}', document_rendering_searchable_pdf_enabled='${workflow.input.document_rendering_searchable_pdf_enabled}')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Document File Generator Block renders a document into a PDF and stores it in the Blob storage.

This block should be placed ALWAYS after a Reprocessing block (if there is any) so that it
is not possible to have more changes in the documents’ organisation.

Mandatory parameters:

* **Parameters:**
  **submission** (`dict`[`str`, `Any`] | `str`) – [`Submission`](#flows_sdk.implementations.idp_v44.contracts.Submission)
  object that includes the documents that need to be rendered.

Optional parameters:

* **Parameters:**
  * **is_reprocessing** (`str` | `bool`) – boolean to handle execution when reprocessing.
    Defaults to False.
  * **title** (`str`) – overrides the block’s default title shown in Flow Studio,
    defaults to ‘Document Renderer’
  * **description** (`str`) – overrides the block’s default description shown in Flow Studio,
    defaults to ‘Renders a document into a PDF’
  * **document_rendering_enabled** (`bool` | `str`) – a boolean that enables or disables the document rendering.
    Default is False.
  * **document_rendering_mime_type** (`str`) – the mime type of the document to be generated. Default is
    ‘application/pdf’
  * **document_rendering_unit** (`str`) – the unit of the document to be generated. Default is ‘in’
  * **document_rendering_height** (`str` | `float`) – the height of the document to be generated. Default is 11
  * **document_rendering_width** (`str` | `float`) – the width of the document to be generated. Default is 8.5
  * **document_rendering_quality** (`str` | `int`) – Quality of pages (images) appended to the resulting document
    as a percentage (recommended 50%). Higher quality results in a larger file size for the
    generated PDF.
  * **document_rendering_mode** (`str`) – Available from V42.0;
    Mode of the images appended to the resulting document.
    Supported modes are RGB (default), L (grayscale) and 1 (black-and-white)
  * **document_rendering_searchable_pdf_enabled** (`bool` | `str`) – Available from V43.2; add a hidden
    searchable text layer to rendered PDFs using existing page segment geometry where
    available. Default is False.

Output:
The block returns an object with the following keys:

* submission: [`Submission`](#flows_sdk.implementations.idp_v44.contracts.Submission) with
  the document_file field populated on its documents with the rendered document file
  information.

Example usage:

```default
# Use the output of the reprocessing block.
reprocessing = ReprocessingBlock(reference_name='reprocessing')

document_renderer_block = DocumentRendererBlock(
    reference_name='document_renderer',
    submission=reprocessing.output('submission'),
    document_rendering_enabled=True,
    document_rendering_unit='in',
    document_rendering_width=8.5,
    document_rendering_height=11,
    document_rendering_quality=50,
    is_reprocessing=reprocessing.output('is_reprocessing'),
    document_rendering_mode='L'
)

output_ref = document_renderer_block.output()
```

#### IDENTIFIER *= 'DOCUMENT_RENDERER_2'*

### *class* flows_sdk.implementations.idp_v44.idp_blocks.IDPImageCorrectionBlock(submission, reference_name=None, rotation_correction_enabled=True, mobile_processing_enabled=False, language_family=None, title='Image Correction (Submission)', description='Rotate and de-skew documents included in a submission', app_metadata=None)

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

IDP Image Correction Block rotates and de-skews tilted/skewed images so that they are more
transcription-friendly

Mandatory parameters:

* **Parameters:**
  **submission** (`dict`[`str`, `Any`] | `str`) – [`Submission`](#flows_sdk.implementations.idp_v44.contracts.Submission)
  object that includes pages that need to be image-corrected

Optional Parameters:

* **Parameters:**
  * **reference_name** (`str` | `None`) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **rotation_correction_enabled** (`bool` | `str`) – Identifies and corrects the orientation of images.
    Enabled by default.
  * **mobile_processing_enabled** (`bool` | `str`) – Improves the machine readability of photo captured documents.
    Disabled by default.
  * **language_family** (`str` | `None`) – language family to use when performing image correction.
    If not provided, the system will default to latin. Language families are single
    word lowercase strings, e.g., latin, arabic, korean, chinese.
    You can read more about language families in the
    “Supported Languages” article in the application documentation:
    [https://help.hyperscience.ai/v44/docs/supported-languages](https://help.hyperscience.ai/v44/docs/supported-languages).
  * **app_metadata** (`list`[`str`] | `None`) – used for capturing information about the flow

Output:
The block returns an object with the following keys:

* submission: [`Submission`](#flows_sdk.implementations.idp_v44.contracts.Submission) with
  the corrected_image_uuid field populated on its pages with the rotated/de-skewed images.

Example usage:

```default
# This is one way to obtain the submission object (using SubmissionBootstrapBlock)
submission_bootstrap = SubmissionBootstrapBlock(reference_name='submission_bootstrap')

idp_image_correction_block = IDPImageCorrectionBlock(
    reference_name='idp_image_correction',
    submission=submission_bootstrap.output('submission'),
)

# reference to the output of IDPImageCorrectionBlock which can be passed as input to the
# next block. For more information on output() and output references, please take a look at
# class Block and its output() method
output_ref = idp_image_correction_block.output()
```

#### IDENTIFIER *= 'IMAGE_CORRECTION_SUBMISSION_2'*

### *class* flows_sdk.implementations.idp_v44.idp_blocks.OpticalReasoningCognitionAgentBlock(submission, api_params, model_type='${workflow.input.orca_type}', use_live_model='${workflow.input.orca_use_live_model}', base_model_id='${workflow.input.orca_base_model_uuid}', target_accuracy='${workflow.input.orca_target_accuracy}', sliding_window_size='${workflow.input.orca_sliding_window_size}', max_image_tokens='${workflow.input.orca_max_image_tokens}', max_tokens_per_image='${workflow.input.orca_max_tokens_per_image}', max_new_tokens='${workflow.input.orca_max_new_tokens}', max_num_bboxes='${workflow.input.orca_max_num_bboxes}', thresholds_dict=None, enable_location_hint='${workflow.input.orca_enable_location_hint}', disable_log_redaction=False, reference_name=None)

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Optical Reasoning Cognition Agent block extracts the textual content
from your submission. It acts like an intelligent agent that uses visual understanding
and reasoning to process submitted documents and pull out the relevant fields.
This block requires a GPU to function.

Mandatory parameters:

* **Parameters:**
  * **submission** (`dict`[`str`, `Any`] | `str`) – Submission object
  * **api_params** (`str` | `dict`[`str`, `Any`])

Parameters with defaults:

* **Parameters:**
  * **model_type** (`str`) – The model you would like to install, which will be used
    to process submissions
  * **use_live_model** (`bool` | `str` | `None`) – Available from V43.2; Whether to use the live ORCA model or a
    specific version of the model. Default value is set to False.
  * **base_model_id** (`str` | `None`) – The UUID of the block asset containing ORCA model weights
  * **target_accuracy** (`float` | `str`) – The submission-level machine + human transcription
    accuracy targeted by the system (fraction between 0.0 and 1.0, e.g. 0.95 for 95 %).
    Default value is set to 0.95.
  * **sliding_window_size** (`int` | `str`) – The number of pages processed by the model at once.
    Larger values improve throughput but raise GPU memory usage.
    Default value is set to 10.
  * **max_image_tokens** (`int` | `str` | `None`) – The maximum number of tokens allocated per image by the model.
    @deprecated since v44.0; will be removed in v47.0. Use `max_tokens_per_image`
    instead; this one is applied against the legacy image-token grid rather than the
    selected model’s own, so existing flows keep the resolution they ran at.
  * **max_tokens_per_image** (`int` | `str` | `None`) – Available from V44.0; The maximum number of tokens allocated
    per image by the model. This is conceptually similar to setting image resolution.
    Larger values may increase accuracy on dense / hard to read images but will raise GPU
    memory usage. Defaults to `None`, letting the selected base model choose a budget
    suited to its own vision grid.
  * **max_new_tokens** (`int` | `str`) – The maximum number of tokens the model can extract, which
    should be scaled based on the number and length of field values.
    Default value is set to 1024.
  * **max_num_bboxes** (`int` | `str`) – The maximum number of candidate bounding boxes per field occurrence.
    Larger values may improve the likelihood of identifying the correct location
    but may also increase false positives.
    Default value is set to 3.
  * **thresholds_dict** (`dict`[`str`, `Any`] | `None`) – Available from V42.2; Field level thresholds passed as a JSON dict.
    When provided, these will take precedence over any threshold dictionary present in the
    Binary KV. Default value is set to None.
  * **enable_location_hint** (`bool` | `str` | `None`) – Available from V44.0; When set to True, the model computes
    approximate locations (bounding boxes) for the extracted fields. Setting it to False
    lowers GPU memory usage and inference latency, but extracted fields will carry no
    location information. Default value is set to True.
  * **disable_log_redaction** (`bool` | `str` | `None`) – Available from V44.0; Debug only. When set to True, the VLM
    blocks skip the redaction of document content (which may contain PII) in their logs.
    Default value is set to False.
  * **reference_name** (`str` | `None`) – unique reference name within a flow, a unique one will be generated
    when not provided

Output:
The block returns an object with the following keys:

* submission: [`Submission`](#flows_sdk.implementations.idp_v44.contracts.Submission) with
  the fields extracted by the model.
* needs_flexible_extraction: A boolean flag indicating whether the submission needs
  flexible extraction.

Example usage:

```default
orca_extraction = OpticalReasoningCognitionAgentBlock(
    reference_name='orca_extraction',
    submission=manual_classification.output('submission'),
    api_params=submission_bootstrap.output('api_params'),
)
```

#### IDENTIFIER *= 'OPTICAL_REASONING_COGNITION_AGENT_GPU'*

### Additional Blocks (v44)

### *class* flows_sdk.implementations.idp_v44.additional_blocks.JSONOutputsBlock(inputs, blocks=None)

Bases: [`Outputs`](../source-docs.md#flows_sdk.blocks.Outputs)

Output block allows users to send JSON data extracted by an IDP flow to other systems
for downstream processing
Mandatory parameters:

* **Parameters:**
  **inputs** (`dict`[`str`, `Any`]) – Used by the UI to automatically pre-populate the input of
  newly added blocks. Extended in this class to include `'enabled': True`
  to visualize an enabled/disabled trigger that is controllable via Flow Studio.

Usage when parameters are to be defined in Flow Studio:

```default
outputs = JSONOutputBlock(
    inputs={'result': }
)
```

### *class* flows_sdk.implementations.idp_v44.additional_blocks.ImageCorrectionBlock(pages, reference_name=None, rotation_correction_enabled=True, mobile_processing_enabled=False, language_family=None, title='Image Correction (Pages)', description='Rotate and de-skew documents', app_metadata=None)

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Image Correction Block rotates and de-skews tilted/skewed images so that they are more
transcription-friendly.

Mandatory parameters:

* **Parameters:**
  **pages** (`list`[`dict`[`str`, `Any`]] | `str`) – list of [`Page`](#flows_sdk.implementations.idp_v44.contracts.Page) objects
  that need to be image-corrected

Optional Parameters:

* **Parameters:**
  * **reference_name** (`str` | `None`) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **rotation_correction_enabled** (`bool`) – Identifies and corrects the orientation of images.
    Enabled by default.
  * **mobile_processing_enabled** (`bool`) – Improves the machine readability of photo captured documents.
    Disabled by default.
  * **language_family** (`str` | `None`) – language family to use when performing image correction.
    If not provided, the system will default to latin. Language families are single
    word lowercase strings, e.g., latin, arabic, korean, chinese.
    You can read more about language families in the
    “Supported Languages” article in the application documentation:
    [https://help.hyperscience.ai/v44/docs/supported-languages](https://help.hyperscience.ai/v44/docs/supported-languages).
  * **app_metadata** (`list`[`str`] | `None`) – used for capturing information about the flow

Output:
The block returns an object with the following keys:

* pages: list of [`Page`](#flows_sdk.implementations.idp_v44.contracts.Page) objects with
  their corrected_image_uuid field populated with rotated/de-skewed images.

Example usage:

```default
# This is one way to obtain the submission object (using SubmissionBootstrapBlock)
submission_bootstrap = SubmissionBootstrapBlock(reference_name='submission_bootstrap')

image_correction_block = ImageCorrectionBlock(
    reference_name='image_correction',
    pages=submission_bootstrap.output('submission.unassigned_pages'),
)

# reference to the output of IDPImageCorrectionBlock which can be passed as input to the
# next block. For more information on output() and output references, please take a look
# at class Block and its output() method
output_ref = image_correction_block.output()
```

#### IDENTIFIER *= 'IMAGE_CORRECTION_PAGES_2'*

### *class* flows_sdk.implementations.idp_v44.additional_blocks.FullPageTranscriptionBlock(pages, reference_name=None, title='Full Page Transcription (Pages)', description='Transcribes documents', language_family=None, app_metadata=None, rerun_segmentation=False)

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Full Page Transcription Block machine-transcribes the provided pages.

Mandatory parameters:

* **Parameters:**
  **pages** (`list`[`dict`[`str`, `Any`]] | `str`) – list of [`Page`](#flows_sdk.implementations.idp_v44.contracts.Page) objects
  that need to be transcribed

Optional Parameters:

* **Parameters:**
  * **reference_name** (`str` | `None`) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **language_family** (`str` | `None`) – language family to use when instantiating the underlying transcription
    model. If not provided, the system will default to latin. Language families are single
    word lowercase strings, e.g., latin, arabic, korean, chinese.
    You can read more about language families in the
    “Supported Languages” article in the application documentation:
    [https://help.hyperscience.ai/v44/docs/supported-languages](https://help.hyperscience.ai/v44/docs/supported-languages).
  * **app_metadata** (`list`[`str`] | `None`) – used for capturing information about the flow
  * **rerun_segmentation** (`bool`) – Available from V42.3; controls whether segmentation should be
    rerun for already segmented pages.

Output:
The block returns an object with the following keys:

* pages: list of [`Page`](#flows_sdk.implementations.idp_v44.contracts.Page) objects with
  their combined_segments field populated with the transcription results.

Example usage:

```default
# This is one way to obtain the submission object (using SubmissionBootstrapBlock)
submission_bootstrap = SubmissionBootstrapBlock(reference_name='submission_bootstrap')

fpt_block = FullPageTranscriptionBlock(
    reference_name='fpt',
    pages=submission_bootstrap.output('submission.unassigned_pages'),
)

# reference to the output of FullPageTranscriptionBlock which can be passed as input to the
# next block. For more information on output() and output references, please take a look at
# class Block and its output() method
output_ref = fpt_block.output()
```

#### IDENTIFIER *= 'FULL_PAGE_TRANSCRIPTION_PAGES_3'*

### *class* flows_sdk.implementations.idp_v44.additional_blocks.QASchedulerBlock(flow_identifier, submission, qa_config, is_reprocessing=False, reference_name=None)

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Available from V41.2

Schedules Quality Assurance (QA) tasks for a specific workflow.

This class serves as a specialized block within a flow for scheduling Quality
Assurance tasks. It ensures the proper configuration and scheduling processes
for a given workflow instance. It leverages provided data and parameters such
as identification of the workflow, submission details, QA configuration, and
optional reprocessing cases.

Mandatory parameters:

* **Parameters:**
  * **flow_identifier** (`str`) – A unique string identifying the flow to associate this QA
    scheduler with.
  * **submission** (`dict`[`str`, `Any`] | `str`) – A dictionary containing submission details.
    Will be used as payload to trigger
    the target flow to be QA’d.
  * **qa_config** (`dict`[`str`, `Any`] | `str`) – A dictionary containing QA configuration. Will be used as payload to trigger
    the target flow to be QA’d.

Optional parameters:

* **Parameters:**
  * **is_reprocessing** (`bool` | `str` | `None`) – An optional value indicating whether this block is part of
    a reprocessing workflow. Defaults to False.
  * **reference_name** (`str` | `None`) – unique identifier within a flow, a unique one will be generated when
    not provided

Example usage:

```default
qa_scheduler = QASchedulerBlock(
    flow_identifier='my_qa_flow',
    submission={'submission_id': 12345, 'data': 'example_data'},
    qa_config={'sample_rate': 0.1, 'language_family': 'latin'},
    is_reprocessing=False,
)

# reference to the output of QASchedulerBlock which can be passed
 as input to the next block.
# For more information on output() and output references, please take a look at class Block
# and its output() method
output_ref = qa_scheduler.output()
```

#### IDENTIFIER *= 'QA_SCHEDULER'*

### *class* flows_sdk.implementations.idp_v44.additional_blocks.FullPageTranscriptionQABlock(submission, sample_rate, language_family, split_text_segments, min_characters_in_segment=4, task_restrictions=None, reference_name=None)

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Available from V41.2

Full Page Transcription QA Block performs Quality Assurance on the output of
Full Page Transcription Block. It samples a percentage of segments for QA
and allows users to split segments into smaller tokens for easier QA.

Mandatory parameters:

* **Parameters:**
  * **submission** (`dict`[`str`, `Any`] | `str`) – Submission object
  * **sample_rate** (`int` | `str`) – Defines the percentage of segments the system samples
    for Quality Assurance
  * **language_family** (`str`) – Specifies the language family for the class
  * **split_text_segments** (`bool` | `str`) – Enabling this option splits segments into smaller, more
    manageable tokens for easier QA

Parameters with defaults:

* **Parameters:**
  * **min_characters_in_segment** (*integer*) – Minimum number of characters in a token.
    Defaults to 4. Minimum value is 1, maximum is 100.
  * **task_restrictions** (*Optional* *[**TaskRestrictions* *]*) – Defines what users can access tasks created
    by this block. Defaults to None, which is treated as an empty list.
  * **reference_name** (`str` | `None`) – unique identifier within a flow, a unique one will be generated when
    not provided

Example usage:

```default
full_page_transcription_qa = FullPageTranscriptionQABlock(
    reference_name='full_page_transcription_qa',
    submission=manual_transcription.output('submission'),
    sample_rate=10,
    language_family='latin',
    split_text_segments=True,
    min_characters_in_segment=4,
    task_restrictions=[],
)

# reference to the output of FullPageTranscriptionQABlock which can be passed
as input to the
# next block. For more information on output() and output references, please take a look
# at class Block and its output() method
output_ref = full_page_transcription_qa.output()
```

#### IDENTIFIER *= 'FULL_PAGE_TRANSCRIPTION_QA_2'*

### *class* flows_sdk.implementations.idp_v44.additional_blocks.CustomSupervisionBlock(submission, task_purpose, data, supervision_template, reference_name=None, supervision_transcription_masking=True, task_restrictions=None, notification_workflow='IDP_SUBMISSION_NOTIFY', chat_flow_identifier=None, title='Custom Supervision', description='Custom Supervision')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

The CustomSupervisionBlock uses a JSON schema as a form builder to create customer-driven
UIs for Supervision tasks.

Mandatory parameters:

* **Parameters:**
  * **submission** (`Any`) – Submission object
  * **task_purpose** (`str`) – the custom task name that’s given to all supervision tasks that run
    through a particular instance of a custom supervision block. This can be used to filter
    tasks in the task queue.
  * **data** (`Any`) – JSON structure that supplies the data used to populate the supervision_template
  * **supervision_template** (`Any`) – JSON used for configuration of the Custom Supervision Task.

Parameters with defaults:

* **Parameters:**
  * **reference_name** (`str` | `None`) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **supervision_transcription_masking** (`bool`) – Prevents users from inputting invalid
    characters during the Custom Supervision task,
    defaults to True
  * **task_restrictions** (`list`[`Any`] | `None`) – Defines what users can access Supervision tasks created
    by this block,
    defaults to []
  * **notification_workflow** (`str`) – Notification flow name to run when the submission
    enters Custom Supervision,
    defaults to IDP_SUBMISSION_NOTIFY_NAME
  * **chat_flow_identifier** (`str` | `None`) – Available from V41.2; optional chat flow identifier to be populated
    to enable Document Chat in Custom Supervision
  * **title** (*Optional* *[**str* *]*) – UI-visible title of the block. Defaults to ‘IDP Custom Supervision’
  * **description** (*Optional* *[**str* *]*) – Description of the block. Both useful for documentation purpose and visible
    to users in the Flow studio. Defaults to ‘IDP Custom Supervision’

Example usage:

```default
custom_supervision = CustomSupervisionBlock(
    reference_name='custom_supervision',
    submission=manual_transcription.output('submission'),
    task_purpose='make_custom_decision',
    supervision_template=[
        {
            'name': 'three_column_template',
            'version': '1.0',
            'thumbnail': {
                'group_by_document': True,
                'group_by_case': True,
            },
            'action': [
                {
                    'name': 'my_tab',
                    'display': 'SSN Info',
                    'input': [
                        {
                            'name': 'ssn_field',
                            'type': 'transcription',
                            'data_identifier': '2afd7a67-ddee-484f-ab6b-2d292752e5ee',
                            'title': 'SSN',
                        },
                    ],
                    'ui': {
                        'groups': [
                            {
                                'title': 'My Group',
                                'fields': ['ssn_field'],
                            },
                        ],
                    },
                },
            ],
        },
    ],
    data={
        'fields': [
            {
                'id': 967,
                'uuid': 'fe8d4e7a-a82c-448c-85a1-0a3cbbe53b61',
                'value': '111-22-3333',
                'page_id': 15,
                'layout_field_id': '2afd7a67-ddee-484f-ab6b-2d292752e5ee',
                'validation_overridden': False,
                'bounding_box': [
                    0.09360783305186686,
                    0.25792617589433436,
                    0.6358913805295097,
                    0.28862414740388187,
                ],
                'occurrence_index': 1,
            },
        ],
        'template_fields': [
            {
                'uuid': '2afd7a67-ddee-484f-ab6b-2d292752e5ee',
                'notes': '',
                'type': 'entry',
                'data_type_uuid': 'b600a4e4-758f-4c4b-a2f4-cbb5dd870a0c',
                'name': 'SSN',
            },
        ],
        'pages': [
            {
                'id': 15,
                'file_page_number': 1,
                'document_page_number': 1,
                'image_url': '/image/2ed3d989-b64a-44bd-a9fb-6e0dcc5ccdb8',
                'form_id': 2,
                'submission_id': 1,
                'external_case_ids': [],
                'read_only': False,
                'filename': '1 page.pdf',
                'form_page_id': 1
            },
        ],
        'documents': [
            {
                'id': 2,
                'layout_uuid': 'e31c3cbf-dcea-44fd-a052-902463c6040f',
                'layout_name': 'layout_name',
                'page_count': 2,
                'read_only': False,
            },
        ],
        'cases': [],
        'selected_choices': [],
    },
    supervision_transcription_masking=False,
)
```

#### IDENTIFIER *= 'CUSTOM_SUPERVISION_3'*

### *class* flows_sdk.implementations.idp_v44.additional_blocks.SoapRequestBlock(method, reference_name=None, endpoint='', body_namespace=None, headers_namespace=None, headers=None, http_headers=None, params=None, use_wsdl=False, wsdl_uri='', wsdl_service_name='', wsdl_port_name='', title='HTTP REST Block', description='HTTP REST block')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Soap Block allows user to perform SOAP requests

Mandatory parameters:

* **Parameters:**
  * **method** (`str`) – SOAP method to invoke
  * **endpoint** (`str`) – absolute url including schema to HTTP endpoint for this request

Optional Parameters:

* **Parameters:**
  * **reference_name** (`str` | `None`) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **body_namespace** (`str` | `None`) – SOAP request body namespace url
  * **headers_namespace** (`str` | `None`) – SOAP request headers namespace url
  * **headers** (`dict`[`Any`, `Any`] | `None`) – SOAP headers to use
  * **http_headers** (`dict`[`str`, `Any`] | `None`) – Available from V42.1; HTTP headers to be sent on all requests
  * **params** (`dict`[`Any`, `Any`] | `None`) – key-value pair used as query parameters in the request to be
    inserted as SOAP body

Example usage:

```default
# minimum viable instantiation, the rest of the fields can later be added in the UI
soap_block = SoapRequestBlock(
    reference_name='soap_request',
    title='Soap Request',
    description='Perform soap request',
    method='ExampleMethod',
)
soap_block = SoapRequestBlock(
    reference_name='soap_request',
    title='Soap Request',
    description='Perform soap request',
    method='ExampleMethod',
    endpoint='http://example.org/abc.wso',
    body_namespace='http://www.example.org/abc.countryinfo',
    params={'example': 'stuff'},
    headers={},
    http_headers={}
)
# reference to the output of SoapRequestBlock which can be passed as input to the next block
# for more information on output() and output references, please take a look at class Block
# and its output() method
output_ref = soap_block.output()
```

#### IDENTIFIER *= 'SOAP_REQ'*

### *class* flows_sdk.implementations.idp_v44.additional_blocks.HttpRestBlock(method, endpoint, reference_name=None, headers=None, params=None, payload=None, json=None, timeout=600, authorization_type=None, handled_error_codes=None, auth_params=None, response_encoding=None, title='HTTP REST Block', description='HTTP REST block')

Bases: `BaseHttpRestBlock`

Http Rest Block allows user to perform HTTP requests

Mandatory parameters:

* **Parameters:**
  * **method** (`str`) – HTTP method to use
  * **endpoint** (`str`) – absolute url including schema to HTTP endpoint for this request

Optional Parameters:

* **Parameters:**
  * **reference_name** (`str` | `None`) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **headers** (`dict`[`str`, `str`] | `None`) – HTTP headers to use
  * **params** (`dict`[`str`, `Any`] | `None`) – key-value pair used as query parameters in the request
  * **payload** (`dict`[`str`, `str`] | `None`) – key-value pair to be used as x-www-form-urlencoded data.
    Mutually exclusive with json
  * **json** (`dict`[`str`, `Any`] | `None`) – key-value pair to be used as json data. Mutually exclusive
    with payload
  * **timeout** (`int` | `None`) – How long (in seconds) to keep the connection open if no bytes are received
    from the endpoint. Set to 0 to wait indefinitely (not recommended).
  * **authorization_type** (`str` | `None`) – authorization type (none, http_header,
    oauth_2_client_credentials)
  * **handled_error_codes** (`list`[`int` | `str`] | `None`) – specify HTTP error codes that will not fail
    the task, allowing for wildcards with the ‘x’ char. Example: [400, “5xx”]
  * **auth_params** (`None` | `HttpHeaderAuthorizationParams` | `OAuth2AuthorizationParams`) – authorization parameters to be passed when the authorization_type
    is set to “http_header” or “oauth_2_client_credentials”
  * **response_encoding** (`str` | `None`) – Character encoding to use when decoding the response. If not
    provided, the encoding from the Content-Type header or the requests library’s default
    detection will be used. Specify a standard encoding name (e.g., ‘utf-8’, ‘ISO-8859-1’,
    ‘windows-1252’) to override.

For a guide on working with secrets, review the Flows SDK page on “Secure Handling of Secrets”
and specifically the section on “Secrets cannot be nested within strings or objects”.

Example usage:

```default
# Minimum viable instantiation
http_rest_block = HttpRestBlock(
    reference_name='http_request',
    title='Http Request',
    description='Perform http request',
    method='GET',
    endpoint='http://www.example.com',
)

# Reference to the output of HttpRestBlock which can be passed as input to the next block
output_ref = http_rest_block.output()

# By default the output is wrapped under "result" (reference it via output('result.X')).
# When the HS_CODE_BLOCK_OUTPUT_WRAPPING_MODE env var selects no_wrapping, it is no longer
# wrapped, so reference it directly via output('X') instead.

# For more information on output() and output references,
# please take a look at class Block and its output() method.

# HTTP header authorization
header_auth_block = HttpRestBlock(
    reference_name='header_auth_request',
    title='Header Auth Request',
    description='Perform request with HTTP header auth',
    method='GET',
    endpoint='https://www.example.com',
    authorization_type='http_header',
    auth_params=HttpHeaderAuthorizationParams(
        authorization_header_name='Authorization',
        authorization_header=workflow_input('header_with_secret'),  # e.g.: Bearer 1234abcd
    ),
)

# OAuth2 Client Credentials authorization
oauth2_block = HttpRestBlock(
    reference_name='oauth2_request',
    title='OAuth2 Request',
    description='Perform request with OAuth2',
    method='GET',
    endpoint='https://api.example.com/v1/resources',
    authorization_type='oauth_2_client_credentials',
    auth_params=OAuth2AuthorizationParams(
        auth_url='https://auth.example.com/oauth2/token',
        client_id=workflow_input('oauth_client_id'),
        client_secret=workflow_input('oauth_client_secret'),
        audience='https://api.example.com',
        scope='read write',
    ),
)
```

### *class* flows_sdk.implementations.idp_v44.additional_blocks.HyperscienceRestApiBlock(method, app_endpoint, reference_name=None, headers=None, params=None, payload=None, json=None, handled_error_codes=None, timeout=600, response_encoding=None, title='Hyperscience HTTP REST Block', description='Hyperscience HTTP REST block')

Bases: `BaseHttpRestBlock`

Make Http requests to the Hyperscience platform APIs.
This block will automatically take care of prepending the base url and will include
the appropriate authentication headers with the request.

Mandatory parameters:

* **Parameters:**
  * **method** (`str`) – HTTP method to use
  * **app_endpoint** (`str`) – relative url, beginning with a forward slash, to an HTTP endpoint served
    by the Hypersciecne platform. For reference on the available endpoints, check out
    [https://docs.hyperscience.ai/](https://docs.hyperscience.ai/)

Optional Parameters:

* **Parameters:**
  * **reference_name** (`str` | `None`) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **headers** (`dict`[`str`, `str`] | `None`) – HTTP headers to use
  * **params** (`dict`[`str`, `Any`] | `None`) – key-value pair used as query parameters in the request
  * **payload** (`dict`[`str`, `str`] | `None`) – key-value pair to be used as x-www-form-urlencoded data.
    Mutually exclusive with json
  * **json** (`dict`[`str`, `Any`] | `None`) – key-value pair to be used as json data. Mutually exclusive
    with payload
  * **handled_error_codes** (`list`[`int` | `str`] | `None`) – specify HTTP error codes that will not fail
    the task, allowing for wildcards with the ‘x’ char. Example: [400, “5xx”]
  * **timeout** (`int` | `None`) – How long (in seconds) to keep the connection open if no bytes are received
    from the endpoint. Set to 0 to wait indefinitely (not recommended).
  * **response_encoding** (`str` | `None`) – Character encoding to use when decoding the response. If not
    provided, the encoding from the Content-Type header or the requests library’s default
    detection will be used. Specify a standard encoding name (e.g., ‘utf-8’, ‘ISO-8859-1’,
    ‘windows-1252’) to override.

Example usage:

```default
hs_rest_block = HyperscienceRestApiBlock(
    reference_name='http_request',
    app_endpoint='/api/healthcheck',
    method='GET',
)
```

### *class* flows_sdk.implementations.idp_v44.additional_blocks.DatabaseAccessBlock(reference_name=None, db_type='', database='', host='', username='', password='', query='', port=None, options=None, timeout=None, query_params=None, title='DB Block', description='DB access block')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Database Block allows user to access and perform queries on the specified database

Mandatory parameters:

* **Parameters:**
  * **db_type** (`str`) – database type (mssql, oracle, postgres)
  * **database** (`str`) – database name
  * **host** (`str`) – URL/IP address of the server database is hosted on
  * **username** (`str`) – database username
  * **password** (`str`) – database password
  * **query** (`str`) – parameterized query

Optional parameters:

* **Parameters:**
  * **reference_name** (`str` | `None`) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **port** (`int` | `None`) – database port number
  * **options** (`dict`[`Any`, `Any`] | `None`) – dictionary of additional connection string options
  * **timeout** (`int` | `None`) – timeout in seconds (mssql and postgres only)
  * **query_params** (`dict`[`Any`, `Any`] | `None`) – dictionary of values for query placeholders

Example usage:

```default
# minimum viable instantiation, the rest of the fields can later be added in the UI
db_lookup = DatabaseAccessBlock(
    reference_name='db_lookup',
    title='Database Lookup',
    description='Perform database lookup',
)
# note that storing password in plain text form is not recommended
# password can later be entered in the UI or defined as a flow secret.
db_lookup = DatabaseAccessBlock(
    reference_name='db_lookup',
    title='Database Lookup',
    description='Perform database lookup',
    db_type='mssql',
    database='cars',
    host='example.com',
    username='user',
    # we recommend skipping the password field or defining it as a system secret
    # e.g. system_secret('{your_secret_identifier}') (both allow for secret input via. UI)
    password='pw'
    port=1433,
    timeout=200,
    query='SELECT * from CAR',
)
# reference to the output of DBAccessBlock which can be passed as input to the next block
# for more information on output() and output references, please take a look at class Block
# and its output() method
output_ref = db_lookup.output()
# content of output_ref:
{
    "result": [
        {
            "id": 1,
            "brand": "Aston Martin",
            "model": "Vanquish"
        },
        {
            "id": 2,
            "brand": "Jaguar",
            "model": "XE 2018"
        }
    ]
}
```

Database output for the same query (SELECT \* FROM CAR)

![image](media/images/db_access_query_example.png)

#### IDENTIFIER *= 'DB_ACCESS_2'*

### *class* flows_sdk.implementations.idp_v44.additional_blocks.EntityRecognitionBlock(pages, regex_map=None, keyword_map=None, ner_enabled=True, ced_enabled=True, signature_enabled=True, page_batch_size=15, page_overlap=1, language_family=None, enable_multiline_detection=True, enable_cross_page_detection=True, deduplicate_entities=False, reference_name=None, title='Entity Recognition', description='Recognizes entities of different types in documents')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Entity Recognition Block detects entities of different types within the pages.

The block supports three recognition engines that can be enabled independently:

- **Named Entity Recognition (NER)** — detects Person Names, Organisation/Company Names,
  and Addresses using a trained ML model.
- **Custom Entity Detection (CED)** — detects words or word patterns described by regular
  expressions and keyword configurations. See *Regex Map Configuration* and
  *Keyword Map Configuration* below.
- **Signature Detection** — detects signatures on pages.

Mandatory parameters:

* **Parameters:**
  * **pages** (`list`[`dict`[`str`, `Any`]] | `str`) – list of [`Page`](#flows_sdk.implementations.idp_v44.contracts.Page) objects
  * **regex_map** (`dict`[`str`, `str`] | `str` | `None`) – mapping of entity type names to regex patterns (or `'default'`).
    See *Regex Map Configuration* below for the full format.
  * **keyword_map** (`dict`[`str`, `list`[`str`]] | `str` | `None`) – mapping of entity type names to keyword search configurations
    (or `['default']`). See *Keyword Map Configuration* below for the full format.

Optional Parameters:

* **Parameters:**
  * **ner_enabled** (`bool` | `str`) – a boolean flag that enables or disables Named Entity Recognition.
    Default value is True.
  * **ced_enabled** (`bool` | `str`) – a boolean flag that enables or disables Custom Entity Detection.
    Default value is True.
  * **signature_enabled** (`bool` | `str`) – a boolean flag that enables or disables Signature Detection.
    Default value is True.
  * **page_batch_size** (`int` | `None`) – Available from V42.3; an integer that specifies the number of pages to
    be processed in a batch. If set to None, all pages are processed in a single batch.
    Default value is 15.
  * **page_overlap** (`int`) – Available from V42.3; an integer that specifies the number of overlapping
    pages between batches. Default value is 1, which means that the last page of a batch will
    be repeated as the first page of the next batch. This is to ensure that entities that are
    located at the border of two batches are not missed.
  * **language_family** (`str` | `None`) – Available from V42.3; language family to use when performing
    segmentation. If not provided, the system will default to latin. Language families are
    single word lowercase strings, e.g., latin, arabic, korean, chinese.
    You can read more about language families in the “Supported Languages” article in the
    application documentation: [https://help.hyperscience.ai/v44/docs/supported-languages](https://help.hyperscience.ai/v44/docs/supported-languages).
  * **enable_multiline_detection** (`bool`) – a boolean flag that enables or disables multiline detection
    in Custom Entity Detection. When enabled, also looks for matches spanning multiple lines
    on the same page. Default value is True.
  * **enable_cross_page_detection** (`bool`) – a boolean flag that enables or disables cross-page detection
    in Custom Entity Detection. When enabled, also looks for matches straddling two consecutive
    pages. Default value is True.
  * **deduplicate_entities** (`bool` | `str`) – a boolean flag that enables or disables deduplication of entities
    detected by different recognition engines (NER, CED, Signature). When enabled, overlapping
    entities are resolved using entity-type priority. Default value is False.
  * **reference_name** (`str` | `None`) – unique identifier within a flow, a unique one will be generated when
    not provided

Output:
The block returns an object with the following keys:

* groups: list of [`EntityGroup`](#flows_sdk.implementations.idp_v44.contracts.EntityGroup)
  objects, containing the detected entities.

### Regex Map Configuration

The `regex_map` parameter is a dictionary that maps entity type names to regular expression
patterns. The block searches through the transcribed text and matches patterns corresponding
to each regex, regardless of surrounding keywords.

- Use `'default'` as the value to use the built-in regex for that entity type.
- Use a custom regex string to define your own pattern.

Example `regex_map`:

```default
regex_map = {
    # Use built-in regexes for these types
    'ssn': 'default',
    'email': 'default',
    'us phone number': 'default',
    # Custom regex for an account ID like "AB1385 957"
    'account id': '[A-Z]{2}\d{4}\s\d{3}',
}
```

### Keyword Map Configuration

The `keyword_map` parameter is a dictionary that maps entity type names to a list of
keyword search configurations. Unlike `regex_map`, keyword search looks for entity
patterns **near specific keywords** in the text.

Each value is a list where items can be:

- `'default'` — use the built-in keyword configuration for that entity type.
- A dictionary describing a custom keyword-entity pair with the following keys:
  - `keywords_regex` (required) — defines which keywords to search for:
    - `root_regexes` (required, list of str) — root keyword patterns,
      e.g. `['Account', 'Acc']`.
    - `suffix_sequence` (required, list of list of str) — each inner list contains
      suffix alternatives that combine with roots. For example,
      `[['ID', 'I.D'], ['Number', '#']]` generates combinations like
      `Account ID Number`, `Acc I.D #`, etc.
    - `is_suffix_optional` (optional, bool, default: `False`) — when `True`,
      root words alone also match (without any suffix).
    - `custom_targets` (optional, list of str) — additional standalone keywords that
      don’t follow the root+suffix pattern, e.g. `['SSN']`.
    - `is_case_sensitive` (optional, bool, default: `False`) — whether keyword
      matching is case-sensitive.
  - `entity_regex` (required, str) — the regex pattern for the entity value itself.
  - `entity_regex_error_tolerance` (optional, int, default: `0`) — fuzzy matching
    tolerance. Specifies how many wrong/additional/fewer symbols are allowed in a match.
  - `enable_table_search` (optional, bool, default: `False`) — when `True`,
    also considers the keyword as a potential column header and searches the column below.
  - `enable_closest_word_line_below` (optional, bool, default: `True`) — when
    `True`, considers the closest non-overlapping word in the line below the keyword.
  - `enable_block_above_search` (optional, bool, default: `True`) — when `True`,
    also searches above the keyword.
  - `allow_intervening_words` (optional, bool, default: `True`) — when `False`,
    rejects matches that have any words between the keyword and the entity.

Example `keyword_map`:

```default
keyword_map = {
    # Use built-in keyword config for passport numbers
    'passport number': ['default'],
    # Custom keyword config for a patient name entity
    'patient': [
        {
            'keywords_regex': {
                'root_regexes': ['patient', "patient's", 'veteran'],
                'suffix_sequence': [['name']],
                'custom_targets': ['name', 'chart'],
                'is_suffix_optional': True,
            },
            'entity_regex': '.*',
        }
    ],
    # Custom keyword config for an Account ID
    'account id': [
        {
            'keywords_regex': {
                'root_regexes': ['Account', 'Acc'],
                'suffix_sequence': [['ID', 'I.D'], ['Number', 'Num', '#']],
                'is_suffix_optional': True,
            },
            'entity_regex': '[A-Z]{2}\d{4}\s\d{3}',
        }
    ],
}
```

### Built-in Entity Types

The following entity types have built-in (`'default'`) regex and keyword definitions:

`ssn`, `email`, `employer id`, `us phone number`, `date`, `micr`,
`machine readable line`, `policy number`, `loan number`, `credit card number`,
`customer id`, `account number`, `employee id`, `passport number`,
`uscis number`, `driver license number`, `driver license restrictions`,
`i94 number`, `pin number`, `ptin number`, `judgment number`,
`case number`, `bankruptcy number`, `application number`, `file number`,
`routing number`, `nmls number`, `appraiser certification number`

Use `'default'` in `regex_map` and `['default']` in `keyword_map` to enable
the built-in detection for any of these types.

Example usage:

```default
# This is one way to obtain the pages (using SubmissionBootstrapBlock)
submission_bootstrap = SubmissionBootstrapBlock(reference_name='submission_bootstrap')

entity_recognition_block = EntityRecognitionBlock(
    reference_name='entity_recognition',
    pages=submission_bootstrap.output('submission.unassigned_pages'),
    regex_map=DEFAULT_PII_REGEX_MAP,
    keyword_map=DEFAULT_PII_KEYWORD_MAP,
)

# reference to the output of EntityRecognitionBlock which can be passed as input to the
# next block. For more information on output() and output references, please take a look at
# class Block and its output() method
output_ref = entity_recognition_block.output()
```

#### IDENTIFIER *= 'ENTITY_RECOGNITION_2'*

### *class* flows_sdk.implementations.idp_v44.additional_blocks.RedactionBlock(redaction_groups, text_content_mode='synthetic_data', sensitive_content_mode='opaque_box', replacements=None, skip_entity_types=None, add_watermark=True, watermark_text=None, reference_name=None, title='Redaction', description='Performs redaction on the provided pages.')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Redacts and masks the provided entities on the pages based on the corresponding settings.

Mandatory parameters:

* **Parameters:**
  **redaction_groups** (`list`[`dict`[`str`, `Any`]] | `str`) – list of
  [`EntityGroup`](#flows_sdk.implementations.idp_v44.contracts.EntityGroup) objects.
  Each group contains a list of entities to be redacted / masked together.

Optional Parameters:

* **Parameters:**
  * **text_content_mode** (`str`) – a discrete value, either “synthetic_data” or “opaque_box”,
    which defines the masking / redaction method to be performed on text entities.
    Default value is “synthetic_data”.
  * **sensitive_content_mode** (`str`) – a discrete value, either “opaque_box”, or “obfuscated_box”.
    Defines the masking method to be performed on entities with sensitive content. Default
    value is “opaque_box”.
  * **replacements** (`dict`[`str`, `dict`[`str`, `str`]] | `None` | `str`) – can be used to define the replacement text for a given entity type and
    original text. It is a dictionary where keys are entity types and values are dictionaries
    that map original text to replacement text.
  * **skip_entity_types** (`list`[`str`] | `None` | `str`) – a list of entity types that should be excluded from redaction
    / masking.
  * **add_watermark** (`bool` | `str`) – a boolean flag that indicates whether to add a watermark to the pages
    that have redaction / masking applied. Default value is True.
  * **watermark_text** (`str` | `None`) – a string that specifies the text to be used in the watermark, if
    add_watermark is set to True. If not provided, a default watermark text will be used.

Output:
The block returns an object with the following keys:

* redacted_groups: list of
  [`RedactedGroup`](#flows_sdk.implementations.idp_v44.contracts.RedactedGroup) objects,
  containing the redacted images.

Example usage:

```default
redaction = RedactionBlock(
    reference_name='redaction',
    redaction_groups=entity_recognition.output('groups'),
)
```

#### IDENTIFIER *= 'REDACTION_AND_MASKING'*

### *class* flows_sdk.implementations.idp_v44.additional_blocks.FileFilterBlock(trigger='${workflow.input.$trigger}', filter_type='${workflow.input.file_filter_filter_type}', minimum_image_width='${workflow.input.file_filter_minimum_image_width}', minimum_image_height='${workflow.input.file_filter_minimum_image_height}', minimum_file_size_kb='${workflow.input.file_filter_minimum_file_size_kb}', file_extensions_action='${workflow.input.file_filter_file_extensions_action}', file_extensions='${workflow.input.file_filter_file_extensions}', file_extensions_other='${workflow.input.file_filter_file_extensions_other}', reference_name=None, title='File Filter', description='Filters out unwanted files from the input of a flow')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Available from V40.2

File Filter Block filters out unwanted files from the input of a flow

This block is meant to be placed at the start of the flow/subflow -
BEFORE the SubmissionBootstrapBlock, not after it.
It requires the output of a connector (e.g. Email Listener) or an API submission
as input data, and its output is meant to be consumed by a SubmissionBootstrapBlock.

Mandatory parameters:

> This block has no strictly required parameters - all of its filters are optional.

Optional Parameters:

* **Parameters:**
  * **trigger** (`str`) – the trigger input from a connector - if not set explicitly,
    it will default to the workflow input trigger (which is where this value is normally found)
  * **filter_type** (`str`) – a discrete value, either “ALL_FILES” or “IMAGES_ONLY”. Determines
    what kind of files the filters will be applied to. Default value is “ALL_FILES”.
    If set to “IMAGES_ONLY”, all filtering options will be applied only to images, other files
    will pass through.
  * **minimum_image_width** (`int` | `str` | `None`) – image width in pixels - half of the image dimension filter.
    Any image with less width than configured here will be filtered out.
    Defaults to None (will do nothing).
  * **minimum_image_height** (`int` | `str` | `None`) – image height in pixels - second half of the image dimension filter.
    Any image with less height than configured here will be filtered out.
    Defaults to None (will do nothing).
  * **minimum_file_size_kb** (`float` | `str` | `None`) – represents the file size filter. Any file whose disk size is less
    than this number (in KB) will be filtered out. May be fractional.
    Defaults to None (will do nothing).
  * **file_extensions_action** (`str`) – a discrete value, either “ALLOW”, “DENY” or “NONE”.
    Represents the function of the file extension filter.
    “ALLOW” means we only allow the configured file extensions.
    “DENY” means we only deny the configured file extensions.
    “NONE” means no file extension filtering takes place.
    Defaults to “NONE”
  * **file_extensions** (`list`[`str`] | `str` | `None`) – a list of strings, representing the file extensions
    used for file extension filtering.
    Expected if file_extensions_action is not “NONE”.
    Otherwise, defaults to None (will do nothing).
  * **file_extensions_other** (`str` | `None`) – a comma separated list of file extensions
    used for file extension filtering.
    Meant for adding extra extensions that are not available in the pre-defined list.
    Optional, defaults to None (will do nothing). However, it is expected
    in case the file_extensions parameter contains “other”.
  * **reference_name** (`str` | `None`) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **title** (`str`) – overrides the block’s default title shown in Flow Studio,
    defaults to ‘File Filter’
  * **description** (`str`) – overrides the block’s default description shown in Flow Studio,
    defaults to ‘Filters out unwanted files from the input of a flow’

Output:
The block returns an object with the following keys:

* result.filtered_trigger: The trigger payload with filtered-out files removed, meant to
  be passed as the trigger input to a SubmissionBootstrapBlock.

Example usage:

```default
# File Filter Block filters out unwanted files from the input of a flow
file_filter_block = FileFilterBlock(
    # trigger: str = workflow_input(Inputs.Trigger),  # usually not necessary to set this
    reference_name='file_filter',
    filter_type='ALL_FILES',
    minimum_image_width=500,
    minimum_image_height=500,
    minimum_file_size_kb=2.5,
    file_extensions_action='ALLOW',
    file_extensions=['pdf', 'png'],
    file_extensions_other='jpg,svg,txt',
)

# reference to the output of FileFilterBlock which can be passed as input to the
# next block (a SubmissionBootstrapBlock)
output_ref = file_filter_block.output('result.filtered_trigger')
submission_bootstrap = SubmissionBootstrapBlock(trigger=output_ref)
```

When the `HS_CODE_BLOCK_OUTPUT_WRAPPING_MODE` env var selects `no_wrapping`, the output is
no longer wrapped under `result`, so reference it directly instead:

```default
output_ref = file_filter_block.output('filtered_trigger')
```

Example content of output_ref:

```default
{
    "payload": {
        "blob_storage_files": [
            {
                "uuid": "db58606e-32f9-42c9-a0bc-ed9848ff247a",
            }
        ],
        "filtered_files": [
            {
                "uuid": "db58606e-32f9-42c9-a0bc-ed9848ff246e",
                "filtered_by": [
                    "file_size_filter"
                ]
            },
        ]
    }
}
```

#### IDENTIFIER *= 'FILE_FILTER'*

### *class* flows_sdk.implementations.idp_v44.additional_blocks.GeneralPromptingORCABlock(model_type='${workflow.input.orca_type}', base_model_id='${workflow.input.orca_base_model_uuid}', messages=None, target_outputs=None, adapter_id=None, max_new_tokens=None, max_image_tokens=None, max_tokens_per_image=None, enable_location_hint=None, thinking_budget=None, json_schema=None, model_meta_overrides=None, concurrency_config_overrides=None, is_byo_model=False, disable_log_redaction=False, reference_name=None, title='Optical Reasoning & Cognition Agent for General Prompting', description='Optical Reasoning & Cognition Agent for General Prompting')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

General Prompting ORCA Block

This block requires a GPU to function.

Mandatory parameters:

* **Parameters:**
  * **model_type** (`str`) – Base model to be used for general prompting.
  * **base_model_id** (`str`) – The UUID of the block asset containing ORCA model weights.

Parameters with defaults:

* **Parameters:**
  * **messages** (`list`[`list`[`dict`[`str`, `Any`]]] | `str` | `None`) – A list of prompt message threads sent to the model.
    Each message thread is a list of messages.
    Each message is a dictionary containing the keys “role” and “content”.
    - Role is a string, with one of “system”, “user”, “assistant”, depending on what the
    related content represents.
    “system” - there is usually a single system prompt in any list of messages, which
    outlines rules and recommendations for the generative model to follow.
    “user” - User messages should be messages sent by a person to the model.
    “assistant” - Assistant messages should be model responses.
    - Content is a mixed list that can contain text and images. Each content entry is
    formatted either as {‘type’: ‘image’, ‘image’: image_uuid} or
    {‘type’: ‘text’, ‘text’: ‘content of the message’}
  * **target_outputs** (`list`[`str`] | `str` | `None`) – Available from V44.0; A list of completions, one per message thread
    in `messages`. When provided, the block scores each completion against its own thread
    (teacher forcing) instead of generating an answer: the output carries the target text
    back, along with the per-token confidences derived from the prompt log-probabilities.
    Because no tokens are generated, this cannot be combined with `json_schema`,
    `enable_location_hint` or `thinking_budget`. A completion that cannot be scored
    (e.g. empty, or not aligned with the model’s tokenization) degrades its own item
    instead of failing the task: that result carries a `scoring_error` code and no
    tokens, meaning its confidence is unknown. Defaults to `None` (the model
    generates its own answer).
  * **adapter_id** (`str` | `None`) – UUID of a previously imported adapter to use.
    The base model will be used when not provided.
    Default value is None.
  * **max_new_tokens** (`int` | `str` | `None`) – The maximum number of tokens the model can extract, which
    should be scaled based on the number and length of field values.
    Default value is set to 1024.
  * **max_image_tokens** (`int` | `str` | `None`) – The maximum number of tokens allocated per image by the model.
    @deprecated since v44.0; will be removed in v47.0. Use `max_tokens_per_image`
    instead; this one is applied against the legacy image-token grid rather than the
    selected model’s own, so existing flows keep the resolution they ran at.
  * **max_tokens_per_image** (`int` | `str` | `None`) – Available from V44.0; The maximum number of tokens allocated
    per image by the model. This is conceptually similar to setting image resolution.
    Larger values may increase accuracy on dense / hard to read images but will raise GPU
    memory usage. Defaults to `None`, letting the selected base model choose a budget
    suited to its own vision grid.
  * **enable_location_hint** (`bool` | `None`) – When set to True, the ORCA general
    prompting block will generate location hint related outputs. This can be useful for
    downstream tasks that require bounding boxes within the image. However, enable it will
    raise GPU memory usage and inference latency.
  * **thinking_budget** (`int` | `str` | `None`) – Available from V43.2; Soft cap on the number of reasoning
    (“thinking”) tokens the model may generate before it is forced to close its thinking
    phase and produce the answer. Only applies to thinking-capable models with thinking
    enabled. Defaults to `None` (no cap).
  * **json_schema** (`dict`[`str`, `Any`] | `None`) – Available from V43.2; Optional JSON Schema (a dict) used to constrain
    the model’s generated output to valid JSON that conforms to the schema. Enables
    structured JSON output via the SGLang `xgrammar` grammar backend. When `None` (the
    default), decoding is unconstrained.
    For a reference on how to author JSON Schemas, see
    [https://json-schema.org/understanding-json-schema/reference/type](https://json-schema.org/understanding-json-schema/reference/type).
  * **model_meta_overrides** (`dict`[`str`, `Any`] | `None`) – Available from V43.2; A dictionary of arguments used to
    override the model meta for the vlm_gpu atomic block. Defaults to `None`
    (no overrides).
  * **concurrency_config_overrides** (`dict`[`str`, `Any`] | `None`) – Available from V43.2; A dictionary of arguments used
    to override the concurrency config (e.g. `max_batch_size`, `num_kv_cache_tokens`)
    computed for the vlm_gpu atomic block. Defaults to `None` (no overrides).
  * **is_byo_model** (`bool`) – Available from V43.2; A boolean flag indicating whether the specified
    base model is a bring-your-own (BYO) model. Defaults to `False`.
  * **disable_log_redaction** (`bool` | `str` | `None`) – Available from V44.0; Debug only. When set to `True`, the
    VLM blocks skip the redaction of document content (which may contain PII) in their logs.
    Defaults to `False`.
  * **reference_name** (`str` | `None`) – unique reference name within a flow, a unique one will be generated
    when not provided.
  * **title** (`str` | `None`) – UI-visible title of the block. Defaults to
    ‘Optical Reasoning & Cognition Agent for General Prompting’.
  * **description** (`str` | `None`) – Description of the block. Both useful for documentation purpose and
    visible to users in the Flow studio. Defaults to
    ‘Optical Reasoning & Cognition Agent for General Prompting’.

Output:
The block returns an object with the following keys:

* orca_result: The result generated by the model for the given prompt messages.
* metadata: Metadata related to the general prompting process.

Example usage:

```default
# Here we construct a simple static set of messages. But these can also be dynamic
# and the output of a PythonCode block or other processing blocks.
system_message = {'role': 'system', 'content': [
        {'type': 'text', 'text': 'You are a helpful assistant'}
]}
prompt = {'role': 'user', 'content': [
    {'type': 'image', 'image': workflow_input('some_image_uuid')},
    {'type': 'text', 'text': 'Make a short summary of everything in the image'}
]}
message_thread = [system_message, prompt]

gp_block = GeneralPromptingORCABlock(messages=[message_thread])
```

#### IDENTIFIER *= 'OPTICAL_REASONING_COGNITION_AGENT_GENERAL_PROMPTING'*

### *class* flows_sdk.implementations.idp_v44.additional_blocks.ImagesToPrintableFileBlock(documents, height_in_mm=279.4, width_in_mm=215.9, use_native_dimensions=False, dpi=200, mime_type='application/pdf', quality=50, mode='RGB', reference_name=None)

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

This block renders each document’s sequence of images into a separate PDF file and
stores each resulting PDF in Blob storage. For every document provided,
a new blob is created containing the rendered PDF.

Available from V42.1.

Mandatory parameters:

* **Parameters:**
  **documents** (`list`[`dict`[`str`, `Any`]]) – List of documents, each containing a document_id and pages.
  Each page contains image_uuid for image-only output, and may optionally include
  searchable_words_blob_uuid for generating a searchable PDF text layer.

Optional parameters:

* **Parameters:**
  * **height_in_mm** (`float`) – the height of the document to be generated in millimeters.
    Default is 279.4 (US Letter height). Ignored when use_native_dimensions is True.
  * **width_in_mm** (`float`) – the width of the document to be generated in millimeters.
    Default is 215.9 (US Letter width). Ignored when use_native_dimensions is True.
  * **use_native_dimensions** (`bool`) – Available from V42.3; when True, each page uses its source
    image’s native dimensions instead of being resized to width_in_mm × height_in_mm.
    This preserves maximum image quality. Default is False. When enabled, the output
    height_in_mm and width_in_mm represent the bounding box (maximum dimensions across all
    pages).
  * **dpi** (`int`) – Available from V42.3; dots per inch to assume for images without embedded DPI
    metadata. Used to calculate physical dimensions in native dimensions mode. Default is 200
    (matching VECTOR_GRAPHICS_DPI used by the pagination pipeline).
  * **mime_type** (`str`) – the mime type of the document to be generated. Default is ‘application/pdf’
  * **quality** (`int`) – Quality of pages (images) appended to the resulting document
    as a percentage (recommended 50%). Higher quality results in a larger file size for the
    generated PDF.
  * **mode** (`str`) – Mode of the images appended to the resulting document.
    Supported modes are RGB (default), L (grayscale) and 1 (black-and-white)

Page-based document shape:

Each page contains the image UUID to render and may optionally include
searchable_words_blob_uuid. A page with no searchable words blob renders image-only
output; a page with a searchable words blob also emits an invisible searchable text
layer for those words.

PDF page order follows the order of entries in pages.

* image_uuid: UUID of the rendered image for that PDF page.
* searchable_words_blob_uuid: Optional UUID of a block-storage JSON blob whose
  records provide the minimal searchable word data: image_uuid, text, and bbox.

Example usage:

```default
documents = [
    {
        'document_id': '48212a99-c099-42e3-bb45-75664db65341',
        'pages': [
            {'image_uuid': 'f42fc9af-b551-4403-aba6-d0eba2c41973'},
            {'image_uuid': 'f42fc9af-b551-4403-aba6-d0eba2c41974'},
        ],
    },
    {
        'document_id': 'delivery_receipt_xyz',
        'pages': [
            {'image_uuid': 'f42fc9af-b551-4403-aba6-d0eba2c41975'},
        ],
    }
]

# Fixed dimensions mode (default) - all pages resized to specified dimensions
images_renderer_block = ImagesToPrintableFileBlock(
    reference_name='images_renderer',
    height_in_mm=279.4,
    width_in_mm=215.9,
    quality=50,
    mode='L',
    documents=documents
)

# Native dimensions mode - preserves original image quality
images_renderer_native = ImagesToPrintableFileBlock(
    reference_name='images_renderer_native',
    use_native_dimensions=True,
    dpi=200,
    quality=80,
    documents=documents
)

output_ref = images_renderer_block.output()

Searchable words are optional on each page. Store them in Blob storage and
reference the blob from the page::

    documents = [
        {
            'document_id': '48212a99-c099-42e3-bb45-75664db65341',
            'pages': [
                {
                    'image_uuid': 'f42fc9af-b551-4403-aba6-d0eba2c41972',
                },
                {
                    'image_uuid': 'f42fc9af-b551-4403-aba6-d0eba2c41973',
                    'searchable_words_blob_uuid': (
                        'd6f5a4bd-581d-4d3d-9eba-d0382b64fda6'
                    ),
                }
            ],
        }
    ]

The searchable words blob must be UTF-8 JSON with a `words` list::

    {
        "words": [
            {
                "image_uuid": "f42fc9af-b551-4403-aba6-d0eba2c41973",
                "text": "Example",
                "bbox": [0.11, 0.21, 0.19, 0.23]
            },
            {
                "image_uuid": "f42fc9af-b551-4403-aba6-d0eba2c41973",
                "text": "text",
                "bbox": [0.22, 0.21, 0.29, 0.23]
            }
        ]
    }

Only records whose `image_uuid` matches the rendered page image are converted
into searchable words. The blob reader also accepts `segments` as an alias for
the top-level `words` list, `transcription` as an alias for `text`, and
`tight_crop_bounding_box` or `bounding_box` as aliases for `bbox`. Extra fields
are ignored, so a ProcessedSegmentList-shaped blob can be reused directly as long
as those minimal fields are present. Each bbox is normalized to the rendered
image:

* `bbox[0]` / `bbox[1]`: top-left x/y.
* `bbox[2]` / `bbox[3]`: bottom-right x/y.
* `[0.0, 0.0]`: top-left of the rendered image.
* `[1.0, 1.0]`: bottom-right of the rendered image.
```

Example content of output_ref (fixed dimensions mode):

```default
{
    "rendered_documents": [
        {
            "document_id": "48212a99-c099-42e3-bb45-75664db65341",
            "blob_uuid": "52e81c7f-aef6-4f69-b4a6-91fd770a607d",
            "mime_type": "application/pdf",
            "height_in_mm": 279.4,
            "width_in_mm": 215.9,
            "quality": 50,
            "mode": "L",
            "page_dimensions": [
                {
                    "image_uuid": "f42fc9af-b551-4403-aba6-d0eba2c41973",
                    "width_in_mm": 215.9,
                    "height_in_mm": 279.4,
                },
                {
                    "image_uuid": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
                    "width_in_mm": 215.9,
                    "height_in_mm": 279.4,
                },
            ]
        }
    ]
}
```

Example content of output_ref (native dimensions mode):

```default
{
    "rendered_documents": [
        {
            "document_id": "48212a99-c099-42e3-bb45-75664db65341",
            "blob_uuid": "52e81c7f-aef6-4f69-b4a6-91fd770a607d",
            "mime_type": "application/pdf",
            "height_in_mm": 297.0,
            "width_in_mm": 215.9,
            "quality": 80,
            "mode": "RGB",
            "page_dimensions": [
                {
                    "image_uuid": "f42fc9af-b551-4403-aba6-d0eba2c41973",
                    "width_in_mm": 210.0,
                    "height_in_mm": 297.0,
                },
                {
                    "image_uuid": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
                    "width_in_mm": 215.9,
                    "height_in_mm": 279.4,
                },
            ]
        }
    ]
}
```

#### IDENTIFIER *= 'IMAGE_TO_PRINTABLE_FILE'*

### *class* flows_sdk.implementations.idp_v44.additional_blocks.VertexAIBlock(model, messages, project, location, service_acc_json=None, workload_identity=False, reference_name=None, generation_config=None, safety_settings=None, extra_body=None, title='GCP VertexAI Generate Content', description='Send prompts (text and files) to a model hosted on GCP Vertex AI')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Generate content using a GCP Vertex AI model.

Available from V43.1.

Mandatory parameters:

* **Parameters:**
  * **model** (`str`) – ID of the model to use. For example: gemini-2.5-flash or gemini-2.5-pro
  * **messages** (`list`[`dict`[`str`, `Any`]]) – A list of messages. Each message has a ‘role’ (e.g. user, model) and
    ‘content’ (list of text or file contents).
  * **project** (`str`) – GCP Project
  * **location** (`str`) – GCP Location. For more information, check out:
    [https://docs.cloud.google.com/vertex-ai/generative-ai/docs/learn/locations](https://docs.cloud.google.com/vertex-ai/generative-ai/docs/learn/locations)
  * **service_acc_json** (`str` | `None`) – Full service account auth json. Optional when
    workload_identity is True. For more information, check out:
    [https://cloud.google.com/iam/docs/service-account-creds](https://cloud.google.com/iam/docs/service-account-creds)
  * **workload_identity** (`bool`) – When True, authenticate via GCP Workload
    Identity instead of a service account key. Defaults to False.

Optional parameters:

* **Parameters:**
  * **reference_name** (`str` | `None`) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **generation_config** (`dict`[`str`, `Any`] | `None`) – Generation config. For more information, check out:
    [https://docs.cloud.google.com/vertex-ai/generative-ai/docs/reference/rest/v1/GenerationConfig](https://docs.cloud.google.com/vertex-ai/generative-ai/docs/reference/rest/v1/GenerationConfig)
  * **safety_settings** (`list`[`dict`[`str`, `Any`]] | `None`) – A list of SafetySetting objects passed directly to the Vertex AI API.
    For more information:
    [https://docs.cloud.google.com/vertex-ai/generative-ai/docs/reference/rest/v1/SafetySetting](https://docs.cloud.google.com/vertex-ai/generative-ai/docs/reference/rest/v1/SafetySetting)
  * **extra_body** (`dict`[`str`, `Any`] | `None`) – Additional fields merged into the API request body.

Output:
The block returns an object with the following keys:

* text: The text of the first response candidate, with all of its text parts joined.
  `None` when the response has no candidates or the first candidate has no text parts.
* response: The raw `generateContent` response body returned by the Vertex AI API.

If the request to Vertex AI fails, the block fails.

Example usage:

```default
vertexai = VertexAIBlock(
    reference_name='vertexai',
    model='gemini-2.5-flash',
    messages=[{'role': 'user', 'content': [{'type': 'text', 'text': 'Hello'}]}],
    project='my-gcp-project',
    location='us-central1',
    service_acc_json='${system.secrets.gcp_service_account}',
)
```

#### IDENTIFIER *= 'VERTEXAI_2'*

### *class* flows_sdk.implementations.idp_v44.additional_blocks.AddressParserBlock(transcriptions, address_parsing_enabled='${workflow.input.address_parsing_enabled}', address_parser_api_provider='${workflow.input.address_parser_api_provider}', address_parser_api_key='${workflow.input.address_parser_api_key}', address_parser_api_options='${workflow.input.address_parser_api_options}', reference_name=None, title='Address Parser', description='Parses address-typed transcriptions into structured components')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Address Parser Block parses address-typed fields into structured components (street, city,
zip, etc.), either locally (usaddress for US addresses, deepparse for international
addresses) or by routing them through a configured third-party address API.

Mandatory parameters:

* **Parameters:**
  **transcriptions** (`list`[`dict`[`str`, `Any`]] | `str`) – list of
  [`Transcription`](#flows_sdk.implementations.idp_v44.contracts.Transcription) objects that
  need to be parsed

Optional Parameters:

* **Parameters:**
  * **address_parsing_enabled** (`bool` | `str`) – flag to enable or disable address parsing,
    defaults to workflow_input(AddressParserSettings.AddressParsingEnabled)
  * **address_parser_api_provider** (`str`) – selects the address parsing provider
    (‘none’ / ‘google’ / ‘smarty’ / ‘geoapify’),
    defaults to workflow_input(AddressParserSettings.ApiProvider)
  * **address_parser_api_key** (`str` | `None`) – API key for the configured provider,
    defaults to workflow_input(AddressParserSettings.ApiKey)
  * **address_parser_api_options** (`str` | `dict` | `None`) – provider-specific JSON options,
    defaults to workflow_input(AddressParserSettings.ApiOptions)
  * **reference_name** (`str` | `None`) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **title** (`str`) – overrides the block’s default title shown in Flow Studio,
    defaults to ‘Address Parser’
  * **description** (`str`) – overrides the block’s default description shown in Flow Studio,
    defaults to ‘Parses address-typed transcriptions into structured components’

Output:
The block returns an object with the following keys:

* parsed_addresses: list of
  [`AddressData`](#flows_sdk.implementations.idp_v44.contracts.AddressData) objects

Example usage:

```default
address_parser = AddressParserBlock(
    reference_name='address_parser',
    transcriptions=extract_transcriptions.output('transcriptions'),
    address_parser_api_provider='google',
)
```

#### IDENTIFIER *= 'ADDRESS_PARSER_2'*

### Trigger Blocks (v44)

#### NOTE
“Triggers” are referred to as “Input Blocks” in our [application documentation](https://help.hyperscience.ai/v44/docs/input-blocks).

#### WARNING
Flows are built to allow full definition of triggers either in code or manually in the Flow Studio. **We recommend defining triggers manually in the Flow Studio**. Instructions on how to do so are in our [application documentation](https://help.hyperscience.ai/v44/docs/input-blocks).

To enable trigger definition via the Flow Studio UI, you need to instantiate the `IDPTriggers()` convenience class and pass it to the `triggers` property of the `Flow`

```default
return Flow(
   ...
   triggers=IDPTriggers()
)
```

If instead you wish to define specific triggers in Python, use the trigger definitions below.

#### Folder Listener (v44)

Identifier: FOLDER_TRIGGER

Deprecated in favor of the `Universal Folder Listener`

Parameters:

| Name                 | Type    | Default Value   | Title                          | Description                                                                                        |
|----------------------|---------|-----------------|--------------------------------|----------------------------------------------------------------------------------------------------|
| folder               | Path    | N/A             | Folder to scan for submissions | N/A                                                                                                |
| file_extensions      | string  | N/A             | File extensions                | List of file extensions to monitor for (e.g.: ‘png, jpg, pdf’)                                     |
| has_meta             | boolean | False           | Enable metadata                | Select this if a metadata file is to be expected along with document files (in XXX_index.txt file) |
| poll_interval        | integer | 10              | Poll interval                  | Poll interval in seconds                                                                           |
| warmup_interval      | integer | 15              | Warm-up interval               | Seconds to wait past document last modified time before processing it                              |
| folder_cleanup_delay | integer | 86400           | Folder cleanup delay           | Seconds to wait before cleaning up subfolders                                                      |
| api_params           | object  | {}              | API Parameters                 | N/A                                                                                                |
```python
folder_listener = IOBlock(
    identifier='FOLDER_TRIGGER',
    reference_name='folder_trigger',
    title='Folder listener',
    enabled=True,
    input={
        'folder': '/var/www/forms/forms/folder/',
        'file_extensions': 'png, pdf, jpg',
    },
)

triggers = IDPTriggers(blocks=[folder_listener])
```

#### S3 Listener (v44)

Identifier: S3_TRIGGER

Parameters:

| Name                         | Type     | Default Value   | Title                                     | Description                                                                                                                                                                                                                                                                   |
|------------------------------|----------|-----------------|-------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| bucket_uri                   | string   | N/A             | S3 source URI                             | S3 URI, where the files will be uploaded (e.g. s3://hs_bucket/prefix1/)                                                                                                                                                                                                       |
| archive_bucket_uri           | string   | N/A             | S3 archive URI                            | S3 URI to move the processed files to (e.g. s3://hs_bucket/prefix1/)                                                                                                                                                                                                          |
| file_extensions              | array    | []              | File extensions                           | Types of file extensions for which to monitor                                                                                                                                                                                                                                 |
| other_file_extensions        | string   | N/A             | Other file extensions                     | Comma separated list of file extensions for which to monitor (e.g. ‘png, jpg, pdf’)                                                                                                                                                                                           |
| has_meta                     | boolean  | false           | Include submission level parameters       | Select this to ingest JSON files along with document files and submission s3 prefixes. These JSON files can contain information such as metadata, cases and external_id. These JSON file names should match the related files or s3 prefixes (e.g., XXX.jpg.json for XXX.jpg) |
| aws_access_key_id            | string   | N/A             | AWS ACCESS KEY ID                         | Access Key used for authentication                                                                                                                                                                                                                                            |
| aws_secret_access_key        | password | N/A             | SECRET ACCESS KEY                         | Secret Key used for authentication                                                                                                                                                                                                                                            |
| use_ec2_instance_credentials | boolean  | true            | Use AWS EC2 Instance IAM Role Credentials | If selected, credentials are obtained from the EC2 instance directly, and the AWS Access Key ID and Secret Key are not used                                                                                                                                                   |
| poll_interval                | integer  | 10              | Polling interval (in seconds)             | How often the S3 Listener will check the S3 bucket for submissions                                                                                                                                                                                                            |
| warmup_interval              | integer  | 15              | Warm-up interval (in seconds)             | How long the S3 Listener will wait to process the document after it was first detected                                                                                                                                                                                        |
| api_params                   | object   | {}              | API Parameters                            | N/A                                                                                                                                                                                                                                                                           |
```python
s3_listener = IOBlock(
    identifier='S3_TRIGGER',
    reference_name='s3_trigger',
    title='S3 Listener',
    enabled=True,
    input={
        'bucket_uri': 's3://hs_bucket/prefix1/',
        'archive_bucket_uri': 's3://hs_bucket/prefix2/',
        'file_extensions': ['png', 'pdf', 'jpg'],
        'aws_access_key_id': 'admin',
        'aws_secret_access_key': system_secret('s3_secret_access_key'),
        'use_ec2_instance_credentials': False,
    },
)
triggers = IDPTriggers(blocks=[s3_listener])
```

#### GCS Listener (v44)

Identifier: GCS_TRIGGER

Parameters:

| Name                  | Type    | Default Value   | Title                               | Description                                                                                                                                                                                                                                                                 |
|-----------------------|---------|-----------------|-------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| bucket_uri            | string  | N/A             | GCS Source URI                      | GCS URI, where the files will be uploaded (e.g. gs://hs_bucket/prefix1/)                                                                                                                                                                                                    |
| archive_bucket_uri    | string  | N/A             | GCS archive URI                     | GCS URI to move the processed files to (e.g. gs://hs_bucket/prefix2/). Cannot be same as Source URI!                                                                                                                                                                        |
| file_extensions       | array   | N/A             | File extensions                     | Types of file extensions for which to monitor                                                                                                                                                                                                                               |
| other_file_extensions | string  | N/A             | Other file extensions               | Comma separated list of file extensions for which to monitor (e.g. ‘png, jpg, pdf’)                                                                                                                                                                                         |
| has_meta              | boolean | false           | Include submission level parameters | Select this to ingest JSON files along with document files and submission gcs prefixes. These JSON files can contain information such as metadata, cases and external_id. These JSON file names should match the related files or prefixes (e.g., XXX.jpg.json for XXX.jpg) |
| credentials_json      | json    | N/A             | GCP Service Account JSON            | GCP Service Account JSON used for authentication, must be a valid json.                                                                                                                                                                                                     |
| workload_identity     | boolean | false           | Use Workload Identity               | Credentials are obtained by using the Workload Identity Federation, applicable for HS installations inside GKE clusters.                                                                                                                                                    |
| poll_interval         | integer | 10              | Polling interval (in seconds)       | How often the GCS Listener will check the GCS bucket for submissions                                                                                                                                                                                                        |
| warmup_interval       | integer | 15              | Warm-up interval (in seconds)       | How long the GCS Listener will wait to process the document after it was first detected                                                                                                                                                                                     |
| api_params            | object  | {}              | API Parameters                      | N/A                                                                                                                                                                                                                                                                         |
```python
gcs_listener = IOBlock(
    identifier='GCS_TRIGGER',
    reference_name='gcs_trigger',
    title='GCS Listener',
    enabled=True,
    input={
        'bucket_uri': 'gs://hs_bucket/prefix1/',
        'archive_bucket_uri': 'gs://hs_bucket/prefix2/',
        'file_extensions': ['png', 'pdf', 'jpg'],
        'credentials_json': system_secret('gcs_credentials_json'),
        'workload_identity': False,
    },
)
triggers = IDPTriggers(blocks=[gcs_listener])
```

#### Azure Blob Listener (v44)

Identifier: AZURE_BLOB_TRIGGER

Parameters:

| Name                  | Type     | Default Value     | Title                               | Description                                                                                                                                                                                                                                                                             |
|-----------------------|----------|-------------------|-------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| container_uri         | string   | N/A               | Azure source URI                    | Azure URI, where the files will be uploaded, can contain prefix, can contain trailing slash (e.g.: https://<custom_domain>/<container_name>/<prefix>/ https://<account_name>.blob.core.windows.net/<container_name>)                                                                    |
| archive_container_uri | string   | N/A               | Azure archive URI                   | Azure URI to move the processed files to, can contain prefix, can contain trailing slash. Cannot be same as the source URI.                                                                                                                                                             |
| file_extensions       | array    | N/A               | File extensions                     | Types of file extensions for which to monitor                                                                                                                                                                                                                                           |
| other_file_extensions | string   | N/A               | Other file extensions               | Comma separated list of file extensions for which to monitor (e.g. ‘png, jpg, pdf’)                                                                                                                                                                                                     |
| has_meta              | boolean  | false             | Include submission level parameters | Select this to ingest JSON files along with document files and submission Azure container prefixes. These JSON files can contain information such as metadata, cases and external_id. These JSON file names should match the related files or prefixes (e.g., XXX.jpg.json for XXX.jpg) |
| auth_type [1]         | string   | service_principal | Authentication type                 | Authentication type.                                                                                                                                                                                                                                                                    |
| client_id             | string   | N/A               | Client ID                           | Application (client) ID for the corresponding application registered with the Microsoft Entra ID                                                                                                                                                                                        |
| client_secret         | Password | N/A               | Client secret                       | Client secret for the corresponding application registered with the Microsoft Entra ID                                                                                                                                                                                                  |
| tenant_id             | string   | N/A               | Tenant ID                           | Also called directory ID. Unique identifier of the tenant in which the corresponding application is registered with.                                                                                                                                                                    |
| account_name          | string   | N/A               | Storage Account Name                | Azure Storage Account name used for authentication                                                                                                                                                                                                                                      |
| account_key           | Password | N/A               | Storage Account Key                 | Azure Storage Account key                                                                                                                                                                                                                                                               |
| authority_host        | string   | N/A               | Authority Host                      | The authority host URL for the Azure Entra ID. Defaults to https://login.microsoftonline.com                                                                                                                                                                                            |
| poll_interval         | integer  | 10                | Polling interval (in seconds)       | How often the Azure Listener will check the container for submissions                                                                                                                                                                                                                   |
| warmup_interval       | integer  | 15                | Warm-up interval (in seconds)       | How long the Azure Listener will wait to process the document after it was first detected                                                                                                                                                                                               |
| api_params            | object   | {}                | API Parameters                      | N/A                                                                                                                                                                                                                                                                                     |

[1] one of:

```default
service_principal
account_key
```

```python
azure_blob_listener = IOBlock(
    identifier='AZURE_BLOB_TRIGGER',
    reference_name='azure_blob_trigger',
    title='Azure Blob Listener',
    enabled=True,
    input={
        'container_uri': 'https://hs_container.blob.core.windows.net/prefix1/',
        'archive_container_uri': 'https://hs_container.blob.core.windows.net/prefix2/',
        'file_extensions': ['png', 'pdf', 'jpg'],
        'auth_type': 'service_principal',
        'client_id': '123456',
        'tenant_id': '654321',
        'client_secret': system_secret('azure_blob_client_secret'),
    },
)
triggers = IDPTriggers(blocks=[azure_blob_listener])
```

#### Email Listener (v44)

Identifier: IMAP_TRIGGER

Parameters:

| Name                            | Type    | Default Value   | Title                       | Description                                                                                                                  |
|---------------------------------|---------|-----------------|-----------------------------|------------------------------------------------------------------------------------------------------------------------------|
| provider [1]                    | string  | imap            | Email Provider              | N/A                                                                                                                          |
| poll_interval                   | integer | 60              | Polling interval in seconds | The frequency at which the connection will monitor the email folder for submissions                                          |
| folder                          | Path    | N/A             | Folder to scan for emails   | The email folder to retrieve submissions from (e.g., “inbox”)                                                                |
| email_body_treatment            | string  | “ignore”        | Email body treatment        | What to do with the body of an email that is ingested. Available options are “process” and “ignore”.                         |
| post_process_action             | string  | “move”          | Post process action         | What to do with the email after it is processed. Available options are “move” and “delete”.                                  |
| post_process_move_folder        | string  | “”              | Post process archive folder | Folder to move emails to once they are processed. It will be included only if `post_process_action` is set to “move”.        |
| api_params                      | object  | {}              | API Parameters              | N/A                                                                                                                          |
| render_headers [2]              | array   | []              | Headers to include          | Headers to render at the top of the email body. Headers will be included only if `email_body_treatment` is set to “process”. |
| raw_email_treatment [3]         | string  | “ignore”        | Original email file         | If stored, the copy will be found under “raw_email” in the block output. Storing a copy will use additional storage.         |
| attachment_header_treatment [3] | string  | “ignore”        | Attachment headers          | If extracted, the attachment headers will be found under “attachment_metadata” in the block output.                          |

[1] one of:

```default
imap
graph
```

[2] any of:

```default
To
From
Subject
Date
```

[3] only available in specific Hyperscience versions:

- version 41: since patch 41.0.24
- version 41.2: since patch 41.2.15
- version 42: since patch 42.0.8
- version 42.1: since patch 42.1.2
- all versions past (and including) 42.2

**Additional inputs** when `"imap"` is the selected `provider`:

| Name     | Type     | Default Value   | Title               | Description   |
|----------|----------|-----------------|---------------------|---------------|
| host     | string   | N/A             | IMAP server address | N/A           |
| port     | integer  | 993             | Port Number         | N/A           |
| ssl      | boolean  | True            | Use SSL connection  | N/A           |
| username | string   | N/A             | Username            | N/A           |
| password | Password | N/A             | Password            | N/A           |

**Additional inputs** when `"graph"` is the selected `provider`:

| Name                     | Type     | Default Value      | Title                          | Description                                                                                                          |
|--------------------------|----------|--------------------|--------------------------------|----------------------------------------------------------------------------------------------------------------------|
| client_id                | string   | N/A                | Client id                      | Application (client) ID for the corresponding application registered with the Microsoft identity platform.           |
| tenant_id                | string   | N/A                | Tenant id                      | Also called directory ID. Unique identifier of the tenant in which the corresponding application is registered with. |
| graph_cloud_endpoint [1] | string   | Global             | Microsoft Graph Cloud Endpoint | Determines base URL used for accessing cloud services through Microsoft Graph.                                       |
| azure_ad_endpoint [2]    | string   | AZURE_PUBLIC_CLOUD | Azure AD Endpoint              | Determines base URL for the Azure Active Directory (Azure AD) endpoint to acquire token for each national cloud.     |
| client_secret            | Password | N/A                | Client secret                  | Client secret for the corresponding application registered with the Microsoft identity platform.                     |

[1] one of:

```default
Global
US_GOV
US_DoD
Germany
China
```

[2] one of:

```default
AZURE_PUBLIC_CLOUD
AZURE_CHINA
AZURE_GERMANY
AZURE_GOVERNMENT
```

```python
imap_trigger = IOBlock(
    identifier='IMAP_TRIGGER',
    reference_name='imap_trigger',
    title='IMAP trigger',
    enabled=True,
    input={
        'host': 'example@mail.com',
        'folder': '/var/www/forms/forms/imap/',
        'username': 'admin',
        'password': 'pass',
    }
)

triggers = IDPTriggers(blocks=[imap_trigger])
```

#### Box Folder Listener (v44)

Identifier: BOX_FOLDER_TRIGGER

Parameters:

| Name                   | Type     | Default Value   | Title                          | Description                                                                         |
|------------------------|----------|-----------------|--------------------------------|-------------------------------------------------------------------------------------|
| source_folder_id       | string   | N/A             | Folder to scan for submissions | Use the Box Folder ID found in the URL                                              |
| target_folder_id       | string   | N/A             | Folder to move completed files | Use the Box Folder ID found in the URL                                              |
| file_extensions        | array    | []              | File extensions                | Types of file extensions for which to monitor                                       |
| custom_file_extensions | string   | N/A             | Other file extension types     | Comma separated list of file extensions for which to monitor (e.g. ‘png, jpg, pdf’) |
| poll_interval          | integer  | 10              | Polling interval (in seconds)  | How often the connector will check the base folder for submissions                  |
| warmup_interval        | integer  | 15              | Warm-up interval (in seconds)  | How long the connector will wait to process the document after it was last modified |
| public_key_id          | string   | N/A             | Public-Key ID                  | ID of the Public-key used for authentication with Box                               |
| private_key            | Password | N/A             | Private-Key                    | Private key used for authentication with Box                                        |
| passphrase             | Password | N/A             | Passphrase                     | Passphrase used for authentication with Box                                         |
| client_id              | string   | N/A             | Client ID                      | Client Id used for authentication with Box                                          |
| client_secret          | Password | N/A             | Client Secret                  | Client Secret used for authentication with Box                                      |
| enterprise_id          | string   | N/A             | Enterprise ID                  | Enterprise Id used for authentication with Box                                      |
| api_params             | object   | {}              | API Parameters                 | N/A                                                                                 |
```python
box_folder_trigger = IOBlock(
    identifier='BOX_FOLDER_TRIGGER',
    reference_name='box_folder_trigger',
    title='Box folder',
    enabled=True,
    input={
        'file_extensions': ['png', 'pdf', 'jpg'],
        'source_folder_id': '24',
        'target_folder_id': '42',
        'public_key_id': 'admin',
        'private_key': 'secret',
        'passphrase': 'password',
        'client_id': 'admin',
        'client_secret': 'secret',
        'enterprise_id': 'admin',
    }
)

triggers = IDPTriggers(blocks=[box_folder_trigger])
```

#### Cron Listener (v44)

Identifier: CRON_TRIGGER

Inputs:

| Name       | Type   | Default Value   | Title              | Description   |
|------------|--------|-----------------|--------------------|---------------|
| cron_spec  | string | `"*/5 * * * *"` | Cron specification | N/A           |
| time_zone  | string | “US/Eastern”    | Time Zone          | N/A           |
| api_params | object | {}              | API Parameters     | N/A           |
```python
cron_trigger = IOBlock(
    identifier='CRON_TRIGGER',
    reference_name='cron_trigger',
    title='Cron Trigger',
    enabled=True,
    input={
        'cron_spec': '0 10 * * *',
        'time_zone': 'Europe/Sofia',
    }
)

triggers = IDPTriggers(blocks=[cron_trigger])
```

#### Salesforce Listener (v44)

Identifier: SALESFORCE_TRIGGER

Parameters:

| Name                | Type     | Default Value   | Title               | Description                                                                                                         |
|---------------------|----------|-----------------|---------------------|---------------------------------------------------------------------------------------------------------------------|
| channel_name        | string   | N/A             | Channel Name        | Configured in the Hyperscience app in Salesforce.                                                                   |
| username            | string   | N/A             | Associated Username | Username associated with the Salesforce Connected App.                                                              |
| consumer_key        | Password | N/A             | Consumer Key        | Consumer key used for authentication with Salesforce. Paired with the Salesforce instance from which it was issued. |
| private_key         | Password | N/A             | Private Key         | Private key used for authentication with Salesforce.                                                                |
| sandbox_environment | boolean  | false           | Private Key         | Enable if the Salesforce environment is a sandbox.                                                                  |
| api_params          | object   | {}              | API Parameters      | N/A                                                                                                                 |

#### Message Queue Listener (v44)

Identifier: `MQ_LISTENER`

Inputs:

| Name          | Type     | Default Value                                             | Title                      | Description                                                                                                     |
|---------------|----------|-----------------------------------------------------------|----------------------------|-----------------------------------------------------------------------------------------------------------------|
| MQ_TYPE       | string   | “ACTIVE_MQ”                                               | Message Queue type         | Type of the message queue to connect with. Valid values are “ACTIVE_MQ”, “AMAZON_SQS”, “IBM_MQ” and “RABBIT_MQ” |
| MQ_USERNAME   | string   | null                                                      | Username/Access Key ID     | N/A                                                                                                             |
| MQ_PASSWORD   | Password | null                                                      | Password/Secret Access Key | N/A                                                                                                             |
| MQ_QUEUE_NAME | string   | null                                                      | Queue Name                 | Name of the queue (topic) to connect to.                                                                        |
| MQ_HOST       | string   | null                                                      | Host Name                  | N/A                                                                                                             |
| MQ_PORT       | integer  | 5672 when “RABBIT_MQ”, 1414 when “IBM_MQ”, otherwise null | Port Number                | N/A                                                                                                             |
| api_params    | object   | {}                                                        | API Parameters             | N/A                                                                                                             |

**Additional inputs** when `"AMAZON_SQS"` is the selected `MQ_TYPE`:

| Name                            | Type    | Default Value   | Title                                     | Description                                                                                                                  |
|---------------------------------|---------|-----------------|-------------------------------------------|------------------------------------------------------------------------------------------------------------------------------|
| MQ_REGION                       | string  | null            | AWS Region                                | N/A                                                                                                                          |
| MQ_QUEUE_URL                    | string  | null            | Queue URL                                 | N/A                                                                                                                          |
| MQ_USE_EC2_INSTANCE_CREDENTIALS | boolean | True            | Use AWS EC2 Instance IAM Role Credentials | If selected, credentials are obtained from the EC2 instance directly, and the AWS Access Key ID and Secret Key are not used. |

**NOTE**: `MQ_USERNAME` can be used to provide `Access Key ID` and `MQ_PASSWORD` to provide `Secret Access Key`.

**Additional inputs** when `"IBM_MQ"` is the selected `MQ_TYPE`:

| Name                         | Type    | Default Value   | Title                        | Description                                        |
|------------------------------|---------|-----------------|------------------------------|----------------------------------------------------|
| MQ_QUEUE_MANAGER             | string  | null            | Queue Manager (IBM MQ)       | N/A                                                |
| MQ_SSL_CIPHER_SUITE [1]      | string  | null            | SSL cipher suite             | SSL cipher suite to use if SSL connection is used. |
| MQ_CHANNEL                   | string  | null            | Channel                      | N/A                                                |
| MQ_NO_AUTH_REQUIRED          | boolean | false           | No auth credentials required | N/A                                                |
| MQ_MQCSP_AUTHENTICATION_MODE | boolean | false           | MQCSP authentication mode    | N/A                                                |

**NOTE**: `MQ_NO_AUTH_REQUIRED` is `True`, `MQ_USERNAME` and `MQ_PASSWORD` are optional.

[1] one of:

```default
"NULL_MD5"
"NULL_SHA"
"RC4_MD5_EXPORT"
"RC4_MD5_US"
"RC4_SHA_US"
"RC2_MD5_EXPORT"
"DES_SHA_EXPORT"
"RC4_56_SHA_EXPORT1024"
"DES_SHA_EXPORT1024"
"TRIPLE_DES_SHA_US"
"TLS_RSA_WITH_NULL_SHA256"
"TLS_RSA_WITH_AES_128_CBC_SHA"
"TLS_RSA_WITH_AES_128_CBC_SHA256"
"TLS_RSA_WITH_AES_256_CBC_SHA"
"TLS_RSA_WITH_AES_256_CBC_SHA256"
"AES_SHA_US"
"TLS_RSA_WITH_DES_CBC_SHA"
"TLS_RSA_WITH_3DES_EDE_CBC_SHA"
"TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256"
"FIPS_WITH_DES_CBC_SHA"
"FIPS_WITH_3DES_EDE_CBC_SHA"
```

**Additional inputs** when `"RABBIT_MQ"` is the selected `MQ_TYPE`:

| Name               | Type   | Default Value   | Title                    | Description   |
|--------------------|--------|-----------------|--------------------------|---------------|
| MQ_VIRTUAL_HOST    | string | null            | Virtual Host (RABBIT MQ) | N/A           |
| MQ_EXCHANGE        | string | “”              | Exchange                 | N/A           |
| MQ_ROUTING_KEY     | string | “”              | Routing key              | N/A           |
| MQ_CONNECTION_TYPE | string | “TCP”           | Connection Type          | “TCP or SSL”  |
```python
rabbit_mq_listener = IOBlock(
    identifier='MQ_LISTENER',
    reference_name='mq_listener',
    title='RabbitMQ Listener',
    enabled=True,
    input={
        'MQ_TYPE': 'RABBIT_MQ',
        'MQ_QUEUE_NAME': 'some_queue_name',
        'MQ_HOST': 'somehost.com',
        'MQ_USERNAME': 'foo',
        'MQ_PASSWORD': system_secret('rabbit_mq_1_password'),
    }
)

triggers = IDPTriggers(blocks=[rabbit_mq_listener])
```

#### Universal Folder Listener (v44)

Identifier: UNIVERSAL_FOLDER_TRIGGER

Inputs:

| Name                  | Type    | Default Value   | Title                                 | Description                                                                                                                                                                                                                                                           |
|-----------------------|---------|-----------------|---------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| folder                | string  | N/A             | Folder to scan for submissions        | Enter the path relative to the base folder. Leave blank to monitor the base folder                                                                                                                                                                                    |
| file_extensions       | array   | []              | File extensions                       | Types of file extensions for which to monitor                                                                                                                                                                                                                         |
| other_file_extensions | string  | N/A             | Other file extensions                 | Comma separated list of file extensions for which to monitor (e.g. ‘png, jpg, pdf’)                                                                                                                                                                                   |
| has_meta              | boolean | false           | Include submission level parameters   | Select this to ingest JSON files along with document files and submission folders. These JSON files can contain information such as metadata, cases and external_id. These JSON file names should match the related files or folders (e.g., XXX.jpg.json for XXX.jpg) |
| poll_interval         | integer | 10              | Polling interval (in seconds)         | How often the Folder Listener will check the base folder for submissions                                                                                                                                                                                              |
| warmup_interval       | integer | 15              | Warm-up interval (in seconds)         | How long the Folder Listener will wait to process the document after it was last modified                                                                                                                                                                             |
| folder_cleanup_delay  | number  | 24              | Empty folder cleanup delay (in hours) | How often the Folder Listener will remove empty folders from the base folder                                                                                                                                                                                          |
| api_params            | object  | {}              | API Parameters                        | N/A                                                                                                                                                                                                                                                                   |
```python
universal_folder_listener = IOBlock(
    identifier='UNIVERSAL_FOLDER_TRIGGER',
    reference_name='universal_folder_trigger',
    title='Universal Folder Listener',
    enabled=True,
    input={
        'folder': '/var/www/forms/forms/folder/',
        'file_extensions': 'png, pdf, jpg',
    }
)

triggers = IDPTriggers(blocks=[universal_folder_listener])
```

#### Kafka Listener (v44)

Identifier: KAFKA_TRIGGER

Inputs:

| Name                 | Type    | Default Value   | Title                | Description                                                                                                                                                                                                                                                                                                                                                                |
|----------------------|---------|-----------------|----------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| bootstrap_servers    | string  | N/A             | Bootstrap Servers    | A Comma separated list of host:port pairs to use for establishing the initial connection to the cluster                                                                                                                                                                                                                                                                    |
| group_id             | string  | N/A             | Group Id             | A unique string that identifies the consumer group this consumer belongs to. BLOCK_THREADS_KAFKA_TRIGGER should be used to scale up or down the number of consumers (default: number of available cores)                                                                                                                                                                   |
| topics               | string  | N/A             | Topics               | Comma separated list of topic names that the block will subscribe to                                                                                                                                                                                                                                                                                                       |
| consumer_config_json | json    | N/A             | Consumer Config      | JSON formatted string containing key-value pairs of Kafka consumer configurations described in the official Kafka documentation                                                                                                                                                                                                                                            |
| api_params           | object  | {}              | API Parameters       | N/A                                                                                                                                                                                                                                                                                                                                                                        |
| consume_timeout      | integer | -1              | Consume Timeout      | Maximum time, in seconds, that the consumer will wait for new messages. If messages are received within the specified time, they are processed immediately. However, if no messages are received within that specified time, consumption cycle will be restarted internally to continue fetching messages. This ensures continuous message consumption (default: infinite) |
| consume_num_messages | integer | 1               | Consume Num Messages | Sets the maximum number of messages the consumer fetches in a single consumption cycle.If the number of available messages is less than the specified, and timeout is reached, messages will be processed. Consumption cycle will be restarted after the current finishes                                                                                                  |
```python
kafka_listener = IOBlock(
    identifier='KAFKA_TRIGGER',
    reference_name='kafka_trigger',
    title='Kafka Listener',
    enabled=True,
    input={
        'folder': '/var/www/forms/forms/folder/',
        'file_extensions': 'png, pdf, jpg',
         'bootstrap_servers': 'example.com',
         'group_id': 'test_group',
         'topics': 'test_topic1, test_topic2',
         'consumer_config_json': {},
         'number_of_workers': 1,
         'consume_timeout': 5,
         'consume_num_messages': 10
    }
)

triggers = IDPTriggers(blocks=[kafka_listener])
```

### Output Blocks (v44)

#### WARNING
Flows pass information to downstream systems using the IDPOutputsBlock. This block is specially built to allow full definition either in code or manually in the Flow Studio. **We recommend defining outputs manually in the Flow Studio**.

Instructions on how to do so are in our [application documentation](https://help.hyperscience.com/v44/docs/output-blocks). Simply include an IDPOutputsBlock in your Python flow definition wherever you wish to send information to downstream systems.

### *class* flows_sdk.implementations.idp_v44.idp_blocks.IDPOutputsBlock(inputs, blocks=None)

Bases: [`Outputs`](../source-docs.md#flows_sdk.blocks.Outputs)

Output block allows users to send data extracted by an IDP flow to other systems
for downstream processing

Mandatory parameters:

* **Parameters:**
  **inputs** (`dict`[`str`, `Any`]) – Used by the UI to automatically pre-populate the input of
  newly added blocks. Extended in this class to include `'enabled': True`
  to visualize an enabled/disabled trigger that is controllable via Flow Studio.

Usage when parameters are to be defined in Flow Studio:

```default
outputs = IDPOutputBlock(
    inputs={'submission': submission_bootstrap.output('result.submission')}
)
```

If instead you wish to define specific outputs in Python, use the outputs definitions below.

#### HTTP Notifier Output (v44)

The HTTP Notifier (REST) output connection will POST results from the system to a specified HTTP endpoint.

Identifier: COB_HTTP_EXPORT

Parameters:

| Name                                 | Type          | Default Value   | Title                                   | Description                                                                                                                                                                                                                                                                                  |
|--------------------------------------|---------------|-----------------|-----------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| submission                           | Submission    | N/A             | Submission Object                       | N/A                                                                                                                                                                                                                                                                                          |
| enabled                              | boolean       | True            | Enabled                                 | Enable or disable this output block                                                                                                                                                                                                                                                          |
| api_version [1]                      | string        | N/A             | API Version                             | API version to be used for rendering payload                                                                                                                                                                                                                                                 |
| export_type                          | string        | N/A             | Export Type                             | Payload rendering choice. If “Flat” is chosen, a simplified version of the payload will be sent, as described in the “flat” parameter for submission retrieval API                                                                                                                           |
| export_routing_filter                | string        | null            | Routing Filter                          | By default, status change notifications are sent for each submission processed by the system. You can filter what notifications are received through this connection by specifying an expression like has_layout_tag(‘some_layout_tag’) or has_source_routing_tag(‘some_source_routing_tag’) |
| endpoint                             | string        | N/A             | Endpoint URL                            | URL that output notifications will be posted to                                                                                                                                                                                                                                              |
| endpoint_secrets                     | string        | N/A             | Endpoint URL secrets                    | Endpoint URL Secrets, format: (one per line) secret_key_name=secret_value                                                                                                                                                                                                                    |
| timeout                              | int           | 600             | Timeout (seconds)                       | How long (in seconds) to keep the connection open if no bytes are received from the endpoint. Set to 0 to wait indefinitely.                                                                                                                                                                 |
| authorization_type [2]               | string        | “none”          | Authorization type                      | Type of authorization                                                                                                                                                                                                                                                                        |
| authorization_header_name            | string        | null            | Authorization header name               | Authorization header name to be set in the notification request                                                                                                                                                                                                                              |
| authorization_header                 | Password      | null            | Authorization header value              | Authorization header to be set in the notification request                                                                                                                                                                                                                                   |
| auth_url                             | string        | null            | OAuth2 authorization URL                | The endpoint for the authorization server                                                                                                                                                                                                                                                    |
| client_id                            | string        | null            | Client ID                               | The client identifier issued to the client during the application registration process                                                                                                                                                                                                       |
| client_secret                        | Password      | null            | Client Secret                           | The client secret issued to the client during the application registration process                                                                                                                                                                                                           |
| scope                                | string        | null            | Scope                                   | Scope to request to oauth server                                                                                                                                                                                                                                                             |
| audience                             | string        | null            | Audience                                | Resource service URL where token will be valid                                                                                                                                                                                                                                               |
| additional_oauth_parameters          | json          | {}              | Additional Oauth Request Parameters     | Additional parameters to send when requesting token                                                                                                                                                                                                                                          |
| ssl_cert_source [3]                  | string        | null            | Source                                  | N/A                                                                                                                                                                                                                                                                                          |
| ssl_cert_path                        | string        | null            | Trusted Certificate(s) path             | Enter the path relative to the base folder                                                                                                                                                                                                                                                   |
| ssl_cert_value                       | MultilineText | null            | Trusted Certificate(s)                  | N/A                                                                                                                                                                                                                                                                                          |
| additional_notification_http_headers | json          | null            | Additional Notification Request Headers | Key value pairs in json format which will be sent via the request as http headers                                                                                                                                                                                                            |

[1] one of:

```default
"v5"
"transformed"
```

[2] one of:

```default
"none"
"http_header"
"oauth_2_client_credentials"
```

[3] one of:

```default
"env_var"
"ca_bundle_path"
"certificate_value"
```

```python
cob_http_export = IOBlock(
    identifier='COB_HTTP_EXPORT',
    reference_name='cob_http_export',
    title='HTTP Notifier Output Block',
    enabled=True,
    input={
        'submission': submission_bootstrap.output('result.submission'),
        'enabled': True,
        'api_version': 'v5',
        'export_type': 'SUBMISSION',
        'endpoint': 'example.com',
        'authorization_type': 'none',
    }
)

outputs = IDPOutputsBlock(
    inputs={'submission': submission_bootstrap.output('result.submission')},
    blocks=[cob_http_export],
)
```

#### Message Queue Notifier Output (v44)

The Message Queue Notifier Output can configure connections to ActiveMQ, Amazon SQS, IBM MQ, and RabbitMQ message queues.

Identifier: COB_MQ_NOTIFIER

Parameters:

| Name                  | Type       | Default Value                                             | Title                      | Description                                                                                                                                                                                                                                                                                  |
|-----------------------|------------|-----------------------------------------------------------|----------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| submission            | Submission | N/A                                                       | Submission Object          | N/A                                                                                                                                                                                                                                                                                          |
| enabled               | boolean    | True                                                      | Enabled                    | Enable or disable this output block                                                                                                                                                                                                                                                          |
| api_version [1]       | string     | N/A                                                       | API Version                | API version to be used for rendering payload                                                                                                                                                                                                                                                 |
| export_type           | string     | N/A                                                       | Export Type                | Payload rendering choice. If “Flat” is chosen, a simplified version of the payload will be sent, as described in the “flat” parameter for submission retrieval API                                                                                                                           |
| export_routing_filter | string     | null                                                      | Routing Filter             | By default, status change notifications are sent for each submission processed by the system. You can filter what notifications are received through this connection by specifying an expression like has_layout_tag(‘some_layout_tag’) or has_source_routing_tag(‘some_source_routing_tag’) |
| MQ_TYPE               | string     | “ACTIVE_MQ”                                               | Message Queue type         | Type of the message queue to connect with. Valid values are “ACTIVE_MQ”, “AMAZON_SQS”, “IBM_MQ” and “RABBIT_MQ”                                                                                                                                                                              |
| MQ_USERNAME           | string     | null                                                      | Username/Access Key ID     | N/A                                                                                                                                                                                                                                                                                          |
| MQ_PASSWORD           | Password   | null                                                      | Password/Secret Access Key | N/A                                                                                                                                                                                                                                                                                          |
| MQ_QUEUE_NAME         | string     | null                                                      | Queue Name                 | Name of the queue (topic) to connect to.  It applies only to “ACTIVE_MQ”, “IBM_MQ” and “RABBIT_MQ” `MQ_TYPE`s.                                                                                                                                                                               |
| MQ_HOST               | string     | null                                                      | Host Name                  | N/A                                                                                                                                                                                                                                                                                          |
| MQ_PORT               | integer    | 5672 when “RABBIT_MQ”, 1414 when “IBM_MQ”, otherwise null | Port Number                | N/A                                                                                                                                                                                                                                                                                          |

[1] one of:

```default
"v5"
"transformed"
```

**Additional inputs** when `"AMAZON_SQS"` is the selected `MQ_TYPE`:

| Name                            | Type    | Default Value   | Title                                     | Description                                                                                                                                               |
|---------------------------------|---------|-----------------|-------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------|
| MQ_REGION                       | string  | null            | AWS Region                                | N/A                                                                                                                                                       |
| MQ_QUEUE_URL                    | string  | null            | Queue URL                                 | N/A                                                                                                                                                       |
| MQ_USE_EC2_INSTANCE_CREDENTIALS | boolean | True            | Use AWS EC2 Instance IAM Role Credentials | If selected, credentials are obtained from the EC2 instance directly, and the AWS Access Key ID and Secret Key are not used.                              |
| MQ_MESSAGE_GROUP_ID             | string  | null            | Group ID for FIFO queues                  | N/A                                                                                                                                                       |
| MQ_MESSAGE_METADATA             | string  | null            | Additional SQS Metadata                   | Input additional metadata key value pairs in the format of { “key”: {“TYPE”: “String”, “VALUE”: “<value1>”}, “key2”: {“TYPE”: “Number”, “VALUE”: “12345”} |

**NOTE**: `MQ_USERNAME` can be used to provide `Access Key ID` and `MQ_PASSWORD` to provide `Secret Access Key`.

**Additional inputs** when `"IBM_MQ"` is the selected `MQ_TYPE`:

| Name                         | Type    | Default Value   | Title                  | Description                                        |
|------------------------------|---------|-----------------|------------------------|----------------------------------------------------|
| MQ_QUEUE_MANAGER             | string  | null            | Queue Manager (IBM MQ) | N/A                                                |
| MQ_SSL_CIPHER_SUITE [1]      | string  | null            | SSL cipher suite       | SSL cipher suite to use if SSL connection is used. |
| MQ_CHANNEL                   | string  | null            | Channel                | N/A                                                |
| MQ_NO_AUTH_REQUIRED          | boolean | false           | Channel                | N/A                                                |
| MQ_MQCSP_AUTHENTICATION_MODE | boolean | false           | Channel                | N/A                                                |

**NOTE**: `MQ_NO_AUTH_REQUIRED` is `True`, `MQ_USERNAME` and `MQ_PASSWORD` are optional.

[1] one of:

```default
"NULL_MD5"
"NULL_SHA"
"RC4_MD5_EXPORT"
"RC4_MD5_US"
"RC4_SHA_US"
"RC2_MD5_EXPORT"
"DES_SHA_EXPORT"
"RC4_56_SHA_EXPORT1024"
"DES_SHA_EXPORT1024"
"TRIPLE_DES_SHA_US"
"TLS_RSA_WITH_NULL_SHA256"
"TLS_RSA_WITH_AES_128_CBC_SHA"
"TLS_RSA_WITH_AES_128_CBC_SHA256"
"TLS_RSA_WITH_AES_256_CBC_SHA"
"TLS_RSA_WITH_AES_256_CBC_SHA256"
"AES_SHA_US"
"TLS_RSA_WITH_DES_CBC_SHA"
"TLS_RSA_WITH_3DES_EDE_CBC_SHA"
"TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256"
"FIPS_WITH_DES_CBC_SHA"
"FIPS_WITH_3DES_EDE_CBC_SHA"
```

**Additional inputs** when `"RABBIT_MQ"` is the selected `MQ_TYPE`:

| Name               | Type   | Default Value   | Title                    | Description   |
|--------------------|--------|-----------------|--------------------------|---------------|
| MQ_VIRTUAL_HOST    | string | null            | Virtual Host (RABBIT MQ) | N/A           |
| MQ_EXCHANGE        | string | “”              | Exchange                 | N/A           |
| MQ_ROUTING_KEY     | string | “”              | Routing key              | N/A           |
| MQ_CONNECTION_TYPE | string | “TCP”           | Connection Type          | “TCP or SSL”  |
```python
mq_notifier = IOBlock(
    identifier='COB_MQ_NOTIFIER',
    reference_name='mq_notifier',
    title='MQ Notifier Output Block',
    enabled=True,
    input={
        'submission': submission_bootstrap.output('result.submission'),
        'enabled': True,
        'api_version': 'v5',
        'export_type': 'SUBMISSION',
        'MQ_USERNAME': 'admin',
        'MQ_PASSWORD': 'pass',
        'MQ_QUEUE_NAME': 'queue',
        'MQ_HOST': 'host',
    },
)

outputs = IDPOutputsBlock(
    inputs={'submission': submission_bootstrap.output('result.submission')},
    blocks=[mq_notifier],
)
```

#### Box Notifier Output (v44)

Provides an out-of-the-box integration into Box systems.

Identifier: COB_BOX_NOTIFIER

Parameters:

| Name                              | Type       | Default Value   | Title                                 | Description                                                                                                                                                                                                                                                                                  |
|-----------------------------------|------------|-----------------|---------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| submission                        | Submission | N/A             | Submission Object                     | N/A                                                                                                                                                                                                                                                                                          |
| enabled                           | boolean    | True            | Enabled                               | Enable or disable this output block                                                                                                                                                                                                                                                          |
| api_version [1]                   | string     | N/A             | API Version                           | API version to be used for rendering payload                                                                                                                                                                                                                                                 |
| export_type                       | string     | N/A             | Export Type                           | Payload rendering choice. If “Flat” is chosen, a simplified version of the payload will be sent, as described in the “flat” parameter for submission retrieval API                                                                                                                           |
| export_routing_filter             | string     | null            | Routing Filter                        | By default, status change notifications are sent for each submission processed by the system. You can filter what notifications are received through this connection by specifying an expression like has_layout_tag(‘some_layout_tag’) or has_source_routing_tag(‘some_source_routing_tag’) |
| public_key_id                     | string     | N/A             | Public-Key ID                         | ID of the Public-key used for authentication with Box                                                                                                                                                                                                                                        |
| private_key                       | Password   | N/A             | Private-Key                           | Private key used for authentication with Box                                                                                                                                                                                                                                                 |
| passphrase                        | Password   | N/A             | Passphrase                            | Passphrase used for authentication with Box                                                                                                                                                                                                                                                  |
| client_id                         | string     | N/A             | Client ID                             | Client Id used for authentication with Box                                                                                                                                                                                                                                                   |
| client_secret                     | Password   | N/A             | Client Secret                         | Client Secret used for authentication with Box                                                                                                                                                                                                                                               |
| enterprise_id                     | string     | N/A             | Enterprise ID                         | Enterprise Id used for authentication with Box                                                                                                                                                                                                                                               |
| template_key                      | string     | “”              | Box Metadata Template Key             | Enter the key of the Box Metadata template that you would like to map the Hyperscience metadata to.                                                                                                                                                                                          |
| static_output_fields_to_map       | array      | []              | Static Metadata Fields                | Specify the Hyperscience fields you want to store in Box metadata.                                                                                                                                                                                                                           |
| submission_id                     | string     | “”              | Key for Mapping Submission ID         | Specify a Box metadata field key from your chosen Box template.  The Hyperscience field will be stored in this specified field.                                                                                                                                                              |
| document_id                       | string     | “”              | Key for Mapping Document ID           | Specify a Box metadata field key from your chosen Box template.  The Hyperscience field will be stored in this specified field.                                                                                                                                                              |
| submission_state                  | string     | “”              | Key for Mapping Submission State      | Specify a Box metadata field key from your chosen Box template.  The Hyperscience field will be stored in this specified field.                                                                                                                                                              |
| document_state                    | string     | “”              | Key for Mapping Document State        | Specify a Box metadata field key from your chosen Box template.  The Hyperscience field will be stored in this specified field.                                                                                                                                                              |
| submission_exceptions             | string     | “”              | Key for Mapping Submission Exceptions | Specify a Box metadata field key from your chosen Box template.  The Hyperscience field will be stored in this specified field.                                                                                                                                                              |
| document_exceptions               | string     | “”              | Key for Mapping Document Exceptions   | Specify a Box metadata field key from your chosen Box template.  The Hyperscience field will be stored in this specified field.                                                                                                                                                              |
| document_layout_uuid              | string     | “”              | Key for Mapping Document Layout Uuid  | Specify a Box metadata field key from your chosen Box template.  The Hyperscience field will be stored in this specified field.                                                                                                                                                              |
| document_layout_name              | string     | “”              | Key for Mapping Document Layout Name  | Specify a Box metadata field key from your chosen Box template.  The Hyperscience field will be stored in this specified field.                                                                                                                                                              |
| start_time                        | string     | “”              | Key for Mapping Start Time            | Specify a Box metadata field key from your chosen Box template.  The Hyperscience field will be stored in this specified field.                                                                                                                                                              |
| complete_time                     | string     | “”              | Key for Mapping Complete Time         | Specify a Box metadata field key from your chosen Box template.  The Hyperscience field will be stored in this specified field.                                                                                                                                                              |
| document_fields_template_mappings | json       | {}              | JSON for Additional Metadata Fields   | Specify additional metadata fields using their key value. Please consult Box Integration setup manual for JSON template and instructions.                                                                                                                                                    |

[1] one of:

```default
"v5"
"transformed"
```

```python
box_notifier = IOBlock(
    identifier='COB_BOX_NOTIFIER',
    reference_name='box_notifier',
    title='Box Notifier Output Block',
    enabled=True,
    input={
        'submission': submission_bootstrap.output('result.submission'),
        'enabled': True,
        'private_key': 'password',
        'passphrase': 'password',
        'public_key_id': 'admin',
        'client_id': 'admin',
        'client_secret': 'secret',
        'enterprise_id': 'admin',
        'template_key': 'key',
    },
)

outputs = IDPOutputsBlock(
    inputs={'submission': submission_bootstrap.output('result.submission')},
    blocks=[box_notifier],
)
```

#### UiPath Notifier Output (v44)

Provides an out-of-the-box integration into UiPath systems.

Identifier: COB_EXPORT_UIPATH

Parameters:

| Name                  | Type       | Default Value   | Title                 | Description                                                                                                                                                                                                                                                                                  |
|-----------------------|------------|-----------------|-----------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| submission            | Submission | N/A             | Submission Object     | N/A                                                                                                                                                                                                                                                                                          |
| enabled               | boolean    | True            | Enabled               | Enable or disable this output block                                                                                                                                                                                                                                                          |
| api_version [1]       | string     | N/A             | API Version           | API version to be used for rendering payload                                                                                                                                                                                                                                                 |
| export_type           | string     | N/A             | Export Type           | Payload rendering choice. If “Flat” is chosen, a simplified version of the payload will be sent, as described in the “flat” parameter for submission retrieval API                                                                                                                           |
| export_routing_filter | string     | null            | Routing Filter        | By default, status change notifications are sent for each submission processed by the system. You can filter what notifications are received through this connection by specifying an expression like has_layout_tag(‘some_layout_tag’) or has_source_routing_tag(‘some_source_routing_tag’) |
| auth_method [2]       | string     | “basic_auth”    | Authentication method | N/A                                                                                                                                                                                                                                                                                          |
| url                   | string     | N/A             | URL                   | Base URL of the uipath instance                                                                                                                                                                                                                                                              |
| app_id                | string     | N/A             | App ID                | App ID provided by UiPath                                                                                                                                                                                                                                                                    |
| app_secret            | Password   | N/A             | App Secret            | App Secret provided by UiPath                                                                                                                                                                                                                                                                |
| oauth_token_endpoint  | string     | N/A             | OAuth token endpoint  | Endpoint to retrieve the token. Using https://cloud.uipath.com/identity_/connect/token by default                                                                                                                                                                                            |
| organization_unit_id  | string     | N/A             | Organization unit id  | Organization unit id                                                                                                                                                                                                                                                                         |
| tenant                | string     | N/A             | Tenant                | Tenant                                                                                                                                                                                                                                                                                       |
| username              | string     | N/A             | Username              | Username                                                                                                                                                                                                                                                                                     |
| password              | Password   | N/A             | Password              | Password                                                                                                                                                                                                                                                                                     |
| queue                 | string     | N/A             | Queue                 | Queue                                                                                                                                                                                                                                                                                        |

[1] one of:

```default
"v5"
"transformed"
```

[2] one of:

```default
"basic_auth"
"oauth"
```

```python
cob_export_uipath = IOBlock(
    identifier='COB_EXPORT_UIPATH',
    reference_name='cob_export_uipath',
    title='CCB Export UiPath',
    enabled=True,
    input={
        'submission': submission_bootstrap.output('result.submission'),
        'enabled': True,
        'api_version': 'v5',
        'export_type': 'FLAT_SUBMISSION',
        'url': 'example.com',
        'tenant': 'tenant',
        'username': 'admin',
        'password': 'pass',
        'queue': 'queue',
    }
)

outputs = IDPOutputsBlock(
    inputs={'submission': submission_bootstrap.output('result.submission')},
    blocks=[cob_export_uipath],
)
```

#### Salesforce Notifier Output (v44)

v44 ships two Salesforce output blocks. Use the first; the second is kept so existing flows keep
working, and is going away.

- **Salesforce Notifier Output Block** (`COB_SALESFORCE_NOTIFIER_2`) does not write to Salesforce
  itself. For every payload of a completed submission it runs an integration flow of your own,
  passing down the Salesforce credentials, so what gets written, where, and when is ordinary Python
  in a flow you control. The [Salesforce Integration Flow](salesforce_integration_flow.md) page covers it end to end,
  with a runnable example to start from.
- **Salesforce Notifier (Deprecated) Output Block** (`COB_SALESFORCE_NOTIFIER`) is the block from
  earlier releases, which updates fields on a Salesforce object from field mappings. **Deprecated
  as of v44.0 and removed in v46.0.** It takes the same connection settings, so migrating means
  moving its field mappings into an integration flow.

##### Salesforce Notifier Output Block (v44)

Identifier: COB_SALESFORCE_NOTIFIER_2

Parameters:

| Name                        | Type           | Default Value   | Title               | Description                                                                                                                                                                                                                                                                                  |
|-----------------------------|----------------|-----------------|---------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| submission                  | Submission     | N/A             | Submission Object   | N/A                                                                                                                                                                                                                                                                                          |
| enabled                     | boolean        | True            | Enabled             | Enable or disable this output block                                                                                                                                                                                                                                                          |
| api_version [1]             | string         | N/A             | API Version         | API version to be used for rendering payload                                                                                                                                                                                                                                                 |
| export_type                 | string         | N/A             | Export Type         | Payload rendering choice. `DOCUMENTS` runs the integration flow once per extracted document, `SUBMISSION` once per submission                                                                                                                                                                |
| export_routing_filter       | string         | null            | Routing Filter      | By default, status change notifications are sent for each submission processed by the system. You can filter what notifications are received through this connection by specifying an expression like has_layout_tag(‘some_layout_tag’) or has_source_routing_tag(‘some_source_routing_tag’) |
| username                    | string         | N/A             | Associated Username | Username associated with the Salesforce Connected App                                                                                                                                                                                                                                        |
| consumer_key                | password       | N/A             | Consumer Key        | Consumer key used for authentication with Salesforce. Paired with the Salesforce instance from which it was issued.                                                                                                                                                                          |
| private_key                 | password       | N/A             | Private Key         | Private key used for authentication with Salesforce.                                                                                                                                                                                                                                         |
| sandbox_environment         | boolean        | false           | Sandbox Environment | Enable if the Salesforce environment is a sandbox.                                                                                                                                                                                                                                           |
| integration_flow_identifier | FlowIdentifier | N/A             | Integration Flow    | Identifier of the flow to run for each payload. It receives the credentials above plus `submission_id` and `payload_uuid`, and must declare the `salesforce_integration` role.                                                                                                               |

[1] one of:

```default
"v5"
"transformed"
```

```python
cob_salesforce_notifier = IOBlock(
    identifier='COB_SALESFORCE_NOTIFIER_2',
    reference_name='cob_salesforce_notifier',
    title='Salesforce Notifier Output Block',
    enabled=True,
    input={
        'submission': submission_bootstrap.output('result.submission'),
        'enabled': True,
        # the IDENTIFIER of your integration flow
        'integration_flow_identifier': 'SALESFORCE_INTEGRATION_FLOW_EXAMPLE',
        'api_version': 'v5',
        'export_type': 'DOCUMENTS',
        # enter username, consumer_key and private_key on the block in Flow Studio rather than here
    }
)

outputs = IDPOutputsBlock(
    inputs={'submission': submission_bootstrap.output('result.submission')},
    blocks=[cob_salesforce_notifier],
)
```

##### Salesforce Notifier (Deprecated) Output Block (v44)

**Deprecated as of v44.0 and removed in v46.0.** Use the Salesforce Notifier Output Block above for
new flows; see [Salesforce Integration Flow](salesforce_integration_flow.md).

With the Salesforce Notifier Block, you can configure your flow to send extracted information to Salesforce.
The Salesforce Notifier Block can use extracted information to look up, and then update any number of fields on a Salesforce object.

Identifier: COB_SALESFORCE_NOTIFIER

Parameters:

| Name                          | Type       | Default Value   | Title                               | Description                                                                                                                                                                                                                                                                                  |
|-------------------------------|------------|-----------------|-------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| submission                    | Submission | N/A             | Submission Object                   | N/A                                                                                                                                                                                                                                                                                          |
| enabled                       | boolean    | True            | Enabled                             | Enable or disable this output block                                                                                                                                                                                                                                                          |
| api_version [1]               | string     | N/A             | API Version                         | API version to be used for rendering payload                                                                                                                                                                                                                                                 |
| export_type                   | string     | N/A             | Export Type                         | Payload rendering choice. If “Flat” is chosen, a simplified version of the payload will be sent, as described in the “flat” parameter for submission retrieval API                                                                                                                           |
| export_routing_filter         | string     | null            | Routing Filter                      | By default, status change notifications are sent for each submission processed by the system. You can filter what notifications are received through this connection by specifying an expression like has_layout_tag(‘some_layout_tag’) or has_source_routing_tag(‘some_source_routing_tag’) |
| username                      | string     | N/A             | Associated Username                 | Username associated with the Salesforce Connected App                                                                                                                                                                                                                                        |
| consumer_key                  | password   | N/A             | Consumer Key                        | Consumer key used for authentication with Salesforce. Paired with the Salesforce instance from which it was issued.                                                                                                                                                                          |
| private_key                   | password   | N/A             | Private Key                         | Private key used for authentication with Salesforce.                                                                                                                                                                                                                                         |
| sandbox_environment           | boolean    | false           | Sandbox Environment                 | Enable if the Salesforce environment is a sandbox.                                                                                                                                                                                                                                           |
| object_api_name               | string     | N/A             | Object API Name                     | API name of the object in Salesforce to lookup and update.                                                                                                                                                                                                                                   |
| new_record_on_lookup_failure  | boolean    | false           | Create new record on lookup failure | When enabled, it will create a new record if the lookup fails to find a record using the lookup parameters. When disabled, lookup will fail if it does not find a record using the lookup parameters.                                                                                        |
| object_lookup_mapping         | json       | N/A             | Lookup Field Mapping                | Specify which Salesforce fields (using their API name) to be queried with which extracted values from the document for the lookup using key-value format. For example: “DOCUMENT_FIELD_NAME”: “OBJECT_FIELD_API_NAME”.                                                                       |
| document_fields_mapping       | json       | N/A             | Document Field Mappings             | Specify which Salesforce fields (using their API name) you want to update with which extracted data from Hyperscience using key-value format. For example: “DOCUMENT_FIELD_NAME”: “OBJECT_FIELD_API_NAME”.”                                                                                  |
| overwrite_existing_field_data | boolean    | false           | Overwrite existing field data       | If this is checked and a selected field has data in it, Hyperscience will overwrite that data. If this is unchecked, existing data will not be overwritten and the operation will fail.                                                                                                      |

[1] one of:

```default
"v5"
"transformed"
```

```python
cob_salesforce_notifier = IOBlock(
    identifier='COB_SALESFORCE_NOTIFIER',
    reference_name='cob_salesforce_notifier',
    title='Salesforce Notifier (Deprecated) Output Block',
    enabled=True,
    input={
        'submission': submission_bootstrap.output('result.submission'),
        'enabled': True,
        'username': 'salesforce_user',
        'consumer_key': 'salesforce_consumer_key',
        'private_key': 'salesforce_private_key',
        'object_api_name': 'salesforce_object_api_name',
        'object_lookup_mapping': {"LAYOUT_VARIATION_XYZ_FIELD_NAME_1": "SF_FIELD_API_NAME_1", "LAYOUT_VARIATION_XYZ_FIELD_NAME_2": "SF_FIELD_API_NAME_2"},
        'document_fields_mapping': {"LAYOUT_VARIATION_XYZ_FIELD_NAME_3": "SF_FIELD_API_NAME_3", "LAYOUT_VARIATION_XYZ_FIELD_NAME_4": "SF_FIELD_API_NAME_4"}
    }
)

outputs = IDPOutputsBlock(
    inputs={'submission': submission_bootstrap.output('result.submission')},
    blocks=[cob_salesforce_notifier],
)
```

#### S3 Notifier Output (v44)

With the S3 Notifier Block, you can configure your flow to send extracted information to an S3 bucket.

Identifier: COB_S3_NOTIFIER

Parameters:

| Name                         | Type       | Default Value   | Title                                     | Description                                                                                                                                                                                                                                                                                  |
|------------------------------|------------|-----------------|-------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| submission                   | Submission | N/A             | Submission Object                         | N/A                                                                                                                                                                                                                                                                                          |
| enabled                      | boolean    | True            | Enabled                                   | Enable or disable this output block                                                                                                                                                                                                                                                          |
| api_version [1]              | string     | N/A             | API Version                               | API version to be used for rendering payload                                                                                                                                                                                                                                                 |
| export_type                  | string     | N/A             | Export Type                               | Payload rendering choice. If “Flat” is chosen, a simplified version of the payload will be sent, as described in the “flat” parameter for submission retrieval API                                                                                                                           |
| export_routing_filter        | string     | null            | Routing Filter                            | By default, status change notifications are sent for each submission processed by the system. You can filter what notifications are received through this connection by specifying an expression like has_layout_tag(‘some_layout_tag’) or has_source_routing_tag(‘some_source_routing_tag’) |
| bucket_uri                   | string     | N/A             | S3 URI                                    | S3 URI, where the data should be stored (e.g. s3://hs_bucket/prefix1/prefix2/)                                                                                                                                                                                                               |
| aws_access_key_id            | string     | N/A             | AWS ACCESS KEY ID                         | Access Key used for authentication                                                                                                                                                                                                                                                           |
| aws_secret_access_key        | password   | N/A             | SECRET ACCESS KEY                         | Secret Key used for authentication                                                                                                                                                                                                                                                           |
| use_ec2_instance_credentials | boolean    | true            | Use AWS EC2 Instance IAM Role Credentials | If selected, credentials are obtained from the EC2 instance directly, and the AWS Access Key ID and Secret Key are not used                                                                                                                                                                  |

[1] one of:

```default
"v5"
"transformed"
```

```python
cob_s3_notifier = IOBlock(
    identifier='COB_S3_NOTIFIER',
    reference_name='cob_s3_notifier',
    title='S3 Notifier Output Block',
    enabled=True,
    input={
        'submission': submission_bootstrap.output('result.submission'),
        'enabled': True,
        'api_version': 'v5',
        'export_type': 'FLAT_SUBMISSION',
        'bucket_uri': 's3://hs_bucket/prefix1/prefix2/',
        'aws_access_key_id': 'aws_access',
        'aws_secret_access_key': system_secret('aws_secret_access_key'),
    }
)

outputs = IDPOutputsBlock(
    inputs={'submission': submission_bootstrap.output('result.submission')},
    blocks=[cob_s3_notifier],
)
```

#### GCS Notifier Output (v44)

With the GCS Notifier Block, you can configure your flow to send extracted information to a GCS bucket.

Identifier: COB_GCS_NOTIFIER

Parameters:

| Name                  | Type       | Default Value   | Title                    | Description                                                                                                                                                                                                                                                                                  |
|-----------------------|------------|-----------------|--------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| submission            | Submission | N/A             | Submission Object        | N/A                                                                                                                                                                                                                                                                                          |
| enabled               | boolean    | True            | Enabled                  | Enable or disable this output block                                                                                                                                                                                                                                                          |
| api_version [1]       | string     | N/A             | API Version              | API version to be used for rendering payload                                                                                                                                                                                                                                                 |
| export_type           | string     | N/A             | Export Type              | Payload rendering choice. If “Flat” is chosen, a simplified version of the payload will be sent, as described in the “flat” parameter for submission retrieval API                                                                                                                           |
| export_routing_filter | string     | null            | Routing Filter           | By default, status change notifications are sent for each submission processed by the system. You can filter what notifications are received through this connection by specifying an expression like has_layout_tag(‘some_layout_tag’) or has_source_routing_tag(‘some_source_routing_tag’) |
| bucket_uri            | string     | N/A             | GCS Source URI           | GCS URI, where the files will be uploaded (e.g. gs://hs_bucket/prefix1/)                                                                                                                                                                                                                     |
| credentials_json      | json       | N/A             | GCP Service Account JSON | GCP Service Account JSON used for authentication, must be a valid json.                                                                                                                                                                                                                      |
| workload_identity     | boolean    | true            | Use Workload Identity    | Credentials are obtained by using the Workload Identity Federation, applicable for HS installations inside GKE clusters.                                                                                                                                                                     |

[1] one of:

```default
"v5"
"transformed"
```

```python
cob_gcs_notifier = IOBlock(
    identifier='COB_GCS_NOTIFIER',
    reference_name='cob_gcs_notifier',
    title='GCS Notifier Output Block',
    enabled=True,
    input={
        'submission': submission_bootstrap.output('result.submission'),
        'enabled': True,
        'api_version': 'v5',
        'export_type': 'FLAT_SUBMISSION',
        'bucket_uri': 'gs://hs_bucket/prefix1/prefix2/',
        'credentials_json': system_secret('gcs_credentials_json'),
        'workload_identity': False,
    }
)

outputs = IDPOutputsBlock(
    inputs={'submission': submission_bootstrap.output('result.submission')},
    blocks=[cob_gcs_notifier],
)
```

#### Azure Blob Notifier Output (v44)

With the Azure Blob Notifier Block, you can configure your flow to send extracted information to an Azure Blob container.

Identifier: COB_AZURE_BLOB_NOTIFIER

Parameters:

| Name                  | Type       | Default Value     | Title                | Description                                                                                                                                                                                                                                                                                  |
|-----------------------|------------|-------------------|----------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| submission            | Submission | N/A               | Submission Object    | N/A                                                                                                                                                                                                                                                                                          |
| enabled               | boolean    | True              | Enabled              | Enable or disable this output block                                                                                                                                                                                                                                                          |
| api_version [1]       | string     | N/A               | API Version          | API version to be used for rendering payload                                                                                                                                                                                                                                                 |
| export_type           | string     | N/A               | Export Type          | Payload rendering choice. If “Flat” is chosen, a simplified version of the payload will be sent, as described in the “flat” parameter for submission retrieval API                                                                                                                           |
| export_routing_filter | string     | null              | Routing Filter       | By default, status change notifications are sent for each submission processed by the system. You can filter what notifications are received through this connection by specifying an expression like has_layout_tag(‘some_layout_tag’) or has_source_routing_tag(‘some_source_routing_tag’) |
| container_uri         | string     | N/A               | Azure Blob URI       | Azure Blob URI, where the data will be stored, can contain prefix, can contain trailing slash (e.g.: https://<custom_domain>/<container_name>/<prefix>/ https://<account_name>.blob.core.windows.net/<container_name>)                                                                       |
| auth_type [2]         | string     | service_principal | Authentication type  | Authentication type.                                                                                                                                                                                                                                                                         |
| client_id             | string     | N/A               | Client ID            | Application (client) ID for the corresponding application registered with the Microsoft Entra ID                                                                                                                                                                                             |
| client_secret         | Password   | N/A               | Client secret        | Client secret for the corresponding application registered with the Microsoft Entra ID                                                                                                                                                                                                       |
| tenant_id             | string     | N/A               | Tenant ID            | Also called directory ID. Unique identifier of the tenant in which the corresponding application is registered with.                                                                                                                                                                         |
| account_name          | string     | N/A               | Storage Account Name | Azure Storage Account name used for authentication                                                                                                                                                                                                                                           |
| account_key           | Password   | N/A               | Storage Account Key  | Azure Storage Account key                                                                                                                                                                                                                                                                    |
| authority_host        | string     | N/A               | Authority Host       | The authority host URL for the Azure Entra ID. Defaults to https://login.microsoftonline.com                                                                                                                                                                                                 |
|                       |            |                   |                      |                                                                                                                                                                                                                                                                                              |
| [1] one of:           |            |                   |                      |                                                                                                                                                                                                                                                                                              |
```default
"v5"
"transformed"
```

[2] one of:

```default
service_principal
account_key
```

```python
cob_azure_blob_notifier = IOBlock(
    identifier='COB_AZURE_BLOB_NOTIFIER',
    reference_name='cob_azure_blob_notifier',
    title='Azure Blob Notifier Output Block',
    enabled=True,
    input={
        'submission': submission_bootstrap.output('result.submission'),
        'enabled': True,
        'api_version': 'v5',
        'export_type': 'FLAT_SUBMISSION',
        'container_uri': 'https://hs_container.blob.core.windows.net/',
        'auth_type': 'service_principal',
        'client_id': '123456',
        'tenant_id': '654321',
        'client_secret': system_secret('azure_blob_client_secret'),
    }
)

outputs = IDPOutputsBlock(
    inputs={'submission': submission_bootstrap.output('result.submission')},
    blocks=[cob_azure_blob_notifier],
)
```

#### Kafka Notifier Output (v44)

With the Kafka Notifier Block, you can configure your flow to send extracted information to a kafka topic.

Identifier: COB_KAFKA_NOTIFIER

Parameters:

| Name                  | Type       | Default Value   | Title                  | Description                                                                                                                                                                                                                                                                                  |
|-----------------------|------------|-----------------|------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| submission            | Submission | N/A             | Submission Object      | N/A                                                                                                                                                                                                                                                                                          |
| enabled               | boolean    | True            | Enabled                | Enable or disable this output block                                                                                                                                                                                                                                                          |
| api_version [1]       | string     | N/A             | API Version            | API version to be used for rendering payload                                                                                                                                                                                                                                                 |
| export_type           | string     | N/A             | Export Type            | Payload rendering choice. If “Flat” is chosen, a simplified version of the payload will be sent, as described in the “flat” parameter for submission retrieval API                                                                                                                           |
| export_routing_filter | string     | null            | Routing Filter         | By default, status change notifications are sent for each submission processed by the system. You can filter what notifications are received through this connection by specifying an expression like has_layout_tag(‘some_layout_tag’) or has_source_routing_tag(‘some_source_routing_tag’) |
| bootstrap_servers     | string     | N/A             | Bootstrap Servers      | A list of Kafka brokers to connect to. For example: “kafka1:9092,kafka2:9092”                                                                                                                                                                                                                |
| topic                 | string     | N/A             | Topic                  | The Kafka topic where your data will be sent                                                                                                                                                                                                                                                 |
| client_id             | string     | N/A             | SECRET ACCESS KEY      | An identifier for your application when connecting to Kafka, typically used for tracking and logging purposes                                                                                                                                                                                |
| producer_config_json  | json       | true            | Producer Config (JSON) | Configuration settings for the Kafka producer in JSON format. See https://kafka.apache.org/documentation/#producerconfigs for more information                                                                                                                                               |
| synchronous_publish   | boolean    | true            | Sync Publish           | If true, the publish call will block until the message is sent successfully or an error is raised. If false, the publish call will return immediately after enqueueing the message                                                                                                           |
| message_key           | string     | null            | Message Key            | The key associated with the message to be sent. This is used to determine which partition the message is sent to. If null, the message will be sent to a random partition                                                                                                                    |

[1] one of:

```default
"v5"
"transformed"
```

```python
cob_kafka_notifier = IOBlock(
    identifier='COB_KAFKA_NOTIFIER',
    reference_name='cob_kafka_notifier',
    title='Kafka Notifier Output Block',
    enabled=True,
    input={
        'submission': submission_bootstrap.output('result.submission'),
        'enabled': True,
        'api_version': 'v5',
        'export_type': 'FLAT_SUBMISSION',
        'bootstrap_servers': 'kafka1:9092,kafka2:9092',
        'topic': 'topic',
        'client_id': 'client_id',
        'producer_config_json': {},
        'synchronous_publish': True,
        'message_key': 'key'
    }
)

outputs = IDPOutputsBlock(
    inputs={'submission': submission_bootstrap.output('result.submission')},
    blocks=[cob_kafka_notifier],
)
```

### Helper Classes and Functions (v44)

The following classes are used to easily instantiate and manage a flow’s settings.

### flows_sdk.implementations.idp_v44.idp_values.get_idp_wf_inputs(idp_wf_config)

A helper function that maps the values provided by an `IdpWorkflowConfig` to their
corresponding IDP keys.

* **Parameters:**
  **idp_wf_config** ([`IdpWorkflowConfig`](#flows_sdk.implementations.idp_v44.idp_values.IdpWorkflowConfig)) – with static values to be filled.
* **Return type:**
  `dict`[`str`, `Any`]
* **Returns:**
  a dictionary with filled static values, compatible with IDP flows.

Example usage with default values:

```default
flow = Flow(
    input=get_idp_wf_inputs(get_idp_wf_config()),
    ...
)
```

Example usage:

```default
Example usage when instantiating an IDP flow with custom parameters::

flow = Flow(
    input=get_idp_wf_inputs({an instance of IdpWorkflowConfig}),
    ...
)
```

### flows_sdk.implementations.idp_v44.idp_values.get_idp_wf_config()

A helper function that instantiates an `IdpWorkflowConfig` pre-filled with default values.
`IdpWorkflowConfig` is the container class for defining flow-level settings.

* **Return type:**
  [`IdpWorkflowConfig`](#flows_sdk.implementations.idp_v44.idp_values.IdpWorkflowConfig)
* **Returns:**
  a valid, fully constructed IdpWorkflowConfig instance

Example usage when instantiating an IDP flow:

```default
flow = Flow(
    input=get_idp_wf_inputs(get_idp_wf_config()),
    ...
)
```

### *class* flows_sdk.implementations.idp_v44.idp_values.IdpWorkflowConfig

Convenience dataclass outlining all flow-level config values for IDP.

### *class* flows_sdk.implementations.idp_v44.idp_values.IDPTriggers(blocks=None)

An adapter class making it easier to instantiate `flows_sdk.flows.Triggers` for
IDP flows.
In particular, provides defaults for some fields (e.g. title, description, reference_name)
and defines api_params_manifest with IDP specific parameters.

* **Parameters:**
  **blocks** (`Sequence`[[`IOBlock`](../source-docs.md#flows_sdk.blocks.IOBlock)] | `None`) – [`flows_sdk.blocks.IOBlock`](../source-docs.md#flows_sdk.blocks.IOBlock) s to be included as triggers for
  an IDP Flow.
  Optional, defaults to an empty list.

Example usage when instantiating an IDP flow:

```default
folder_listener = IOBlock(...)
flow = Flow(
    triggers=IDPTriggers([folder_listener]),
    ...
)
```

### *class* flows_sdk.implementations.idp_v44.idp_values.IDPWrapperManifest(flow_identifier)

An adapter class making it easier to instantiate [`flows_sdk.flows.Manifest`](../source-docs.md#flows_sdk.flows.Manifest) for
IDP wrapper flows.
In particular, provides defaults for some fields (e.g. roles)
but more importantly, defines all [`flows_sdk.flows.Parameter`](../source-docs.md#flows_sdk.flows.Parameter) that construct the
Flow inputs and their UI representation (left-hand side menu in Flow studio).

* **Parameters:**
  **flow_identifier** (`str`) – A system-wide unique identifier for [`flows_sdk.flows.Flow`](../source-docs.md#flows_sdk.flows.Flow)

Example usage when instantiating an IDP flow:

```default
flow = Flow(
    manifest=IDPWrapperManifest(flow_identifier='FLOW_IDENTIFIER'),
    ...
)
```

### *class* flows_sdk.implementations.idp_v44.idp_values.IDPCoreManifest(flow_identifier, roles=None)

An adapter class making it easier to instantiate [`flows_sdk.flows.Manifest`](../source-docs.md#flows_sdk.flows.Manifest) for
IDP Core flows.
In particular, provides defaults for some fields (e.g. roles, output)
but more importantly, defines all [`flows_sdk.flows.Parameter`](../source-docs.md#flows_sdk.flows.Parameter) that construct the
Flow inputs and their UI representation (left-hand side menu in Flow studio).

* **Parameters:**
  * **flow_identifier** (`str`) – A system-wide unique identifier for [`flows_sdk.flows.Flow`](../source-docs.md#flows_sdk.flows.Flow)
  * **roles** (`list`[`str`] | `None`) – ‘read_only’, ‘supporting’ and ‘idp_core’ are the default roles of every subflow
    that can replace the default IDP_CORE subflow inside the top-level IDP flows.
    ‘supporting’ and ‘idp_core’ are mandatory roles that are necessary for all IDP Core flows.
    ‘supporting’ ensures that the subflow will be auto-deployed together with the
    top-level IDP flow.
    ‘idp_core’ ensures that this subflow can be selected in the UI in dropdowns which allow
    picking an alternative subflow to the default IDP_CORE subflow. If you are implementing
    a subflow that is not supposed to be a drop-in replacement for IDP_CORE, you will have to
    subclass or implement your own version of IDPCoreManifest class in order
    to remove the idp_core role.

Example usage when instantiating an IDP flow:

```default
flow = Flow(
    manifest=IDPCoreManifest(flow_identifier='FLOW_IDENTIFIER'),
    ...
)
```

### Contracts (v44)

### *class* flows_sdk.implementations.idp_v44.contracts.Submission

A Submission object is created when a set of files are submitted into the system together.
The system then interprets each file as a one or more Page objects.

#### id *: `int`*

Unique system-generated identifier.

#### cases *: `list`[[`Case`](#flows_sdk.implementations.idp_v44.contracts.Case)] | `None`* *= None*

Array of Case objects that contain Documents and Pages from this Submission.

#### flow_uuid *: `UUID`*

The UUID of the Flow that created this Submission.

#### flow_name *: `str`*

The name of the Flow that created this Submission.

#### flow_version *: `int`*

The version of the Flow that created this Submission.

#### status *: `Literal`[`'processing'`, `'complete'`, `'reprocessing'`]*

Current status of the Submission.

#### complete_time *: `datetime` | `None`* *= None*

Time the entire Submission entered the Complete state, including all of its Supervision tasks.

#### classification_review_needed *: `bool` | `None`* *= None*

Indicates whether Classification Supervision is needed for this Submission.

#### documents *: `list`[[`Document`](#flows_sdk.implementations.idp_v44.contracts.Document)] | `None`* *= None*

Array of Document objects identified as being part of this Submission.

#### unassigned_pages *: `list`[[`Page`](#flows_sdk.implementations.idp_v44.contracts.Page)]*

Array of Page objects included in this Submission that have not been grouped into a
Document.

#### failed_pages *: `list`[[`FailedPage`](#flows_sdk.implementations.idp_v44.contracts.FailedPage)]*

Array of Page objects included in this Submission that failed processing.

### *class* flows_sdk.implementations.idp_v44.contracts.Page

The Page object is the representation of a single image that was submitted into the system.

#### id *: `int`*

Unique system-generated identifier.

#### submission_page_number *: `int`*

Indicates page order for the Submission.

#### status *: `Literal`[`'processing'`, `'failed'`, `'complete'`]*

Current status of the Page.

#### page_type *: `Union`[`Literal`[`'unassigned_page'`, `'blank_page'`, `'other_page'`, `'additional_form_page'`, `'document_page'`, `'unknown_page'`, `'failed'`], `str`]*

The type of the Page.

#### origin *: [`FilePageOrigin`](#flows_sdk.implementations.idp_v44.contracts.FilePageOrigin)*

The origin of the Page, which can be used to determine from which submitted file the
Page was extracted.

#### classification_type *: `Optional`[`Literal`[`'manual'`, `'machine'`]]* *= None*

The method by which the Page was classified, if applicable. Present when the `page_type`
is not ‘unknown_page’ or ‘unassigned_page’.

#### machine_layout_page_uuid *: `UUID` | `None`* *= None*

Unique identifier of the layout page that the machine predicted this Page matches to, if
applicable.

#### manual_layout_page_uuid *: `UUID` | `None`* *= None*

Unique identifier of the layout page that a keyer assigned this Page to, if applicable.

#### combined_segments *: [`PageSegments`](#flows_sdk.implementations.idp_v44.contracts.PageSegments) | `None`* *= None*

The segments for the Page, if applicable.

#### image_uuid *: `UUID`*

Unique identifier of the image for this Page. Refers to the original image as extracted from
the source file before any transformations were applied.

#### image_name *: `str`*

The name of the original image file for this Page.

#### image_width *: `int`*

The width of the original image for this Page in pixels.

#### image_height *: `int`*

The height of the original image for this Page in pixels.

#### image_checksum *: `str`*

The checksum of the original image for this Page.

#### corrected_image_uuid *: `UUID` | `None`* *= None*

Unique identifier of the corrected image for this Page, if applicable. Refers to the image
after transformations such as rotation or perspective correction were applied.

#### image_correction_type *: `Optional`[`Literal`[`'layout_matching'`, `'image_correction'`, `'manual'`]]* *= None*

The type of image correction applied to this Page, if applicable. Available in v43.1 and later.

#### transformation_matrix *: `list`[`list`[`float`]] | `None`* *= None*

The 3x3 registration homography matrix for the Page, if applicable.

#### template_image_shapes *: `list`[`list`[`int`]] | `None`* *= None*

Registration shape metadata for the layout image, if applicable. Contains the
pre-computed layout shape and the original layout image shape.

#### submission_image_shape *: `list`[`int`] | `None`* *= None*

Registration pre-processing shape of the submission image, if applicable.

#### correction_model_info *: [`ImageCorrectionModelInfo`](#flows_sdk.implementations.idp_v44.contracts.ImageCorrectionModelInfo) | `None`* *= None*

Model version metadata for image correction on this Page, if applicable.

#### rotation_confidence *: `float` | `None`* *= None*

The confidence score for the applied rotation correction for the Page, if applicable. Ranges
from 0.0 to 1.0, or `None` if not applicable.

#### rotation_class *: `int` | `None`* *= None*

The applied rotation-correction class for the Page, if applicable. Values are `0`, `1`,
`2`, or `3`, representing the number of 90-degree counterclockwise rotations applied, or
`None` if not applicable.

#### deskew_confidence *: `float` | `None`* *= None*

The confidence score for the applied deskew correction for the Page, if applicable. Ranges
from 0.0 to 1.0, or `None` if not applicable.

#### skew_angle *: `float` | `None`* *= None*

The applied deskew-correction angle for the Page in degrees, if applicable. This value
represents the rotation applied to deskew the image (it may be 0 when no deskew is needed),
or `None` if not applicable.

#### mobile_correction_result *: `Optional`[`Literal`[`'PREDICTED_TRANSFORM'`, `'THRESHOLDED_AS_SCANNED'`, `'NO_VANISHING_POINT_CONSENSUS'`, `'TOO_FEW_DOCUMENT_PIXELS'`]]* *= None*

Outcome of mobile perspective correction for this Page, if applicable. Indicates whether a
perspective transform was applied or why it was not, or `None` if not applicable.

#### applied_transform *: [`ImageCorrectionPerspectiveTransform`](#flows_sdk.implementations.idp_v44.contracts.ImageCorrectionPerspectiveTransform) | `None`* *= None*

Applied mobile perspective transform for this Page, if applicable.

#### exceptions *: `list`[`str`]*

List of exceptions encountered during processing.

### *class* flows_sdk.implementations.idp_v44.contracts.Document

The Document object is a set of pages that have matched to a pre-defined layout.

#### id *: `int`*

Unique system-generated identifier.

#### uuid *: `UUID`*

Unique system-generated identifier.

#### status *: `Literal`[`'processing'`, `'reprocess'`, `'reprocessing'`, `'rejected'`, `'complete'`]*

Current status of the Document.

#### complete_time *: `datetime` | `None`* *= None*

Time the entire Document entered the Complete state, including all of its Supervision tasks.

#### layout_uuid *: `UUID`*

The unique identifier of the layout that this Document was matched to.

#### layout_name *: `str`*

The name of the layout that this Document was matched to.

#### layout_language *: `str`*

The language of the layout that this Document was matched to.

#### layout_kind *: `Literal`[`'structured'`, `'semi_structured'`, `'additional'`]*

The kind of the layout that this Document was matched to.

#### layout_tags *: `list`[`str`]*

The list of tags associated with the layout that this Document was matched to.

#### layout_version_uuid *: `UUID`*

The unique identifier of the specific layout version that this Document was matched to.

#### original_layout_version_uuid *: `UUID`*

The unique identifier of the original layout version that this Document was matched to.
Used to map partially matched Documents to a specific layout version.

#### classified_by_user_id *: `int`*

The unique identifier of the user who classified this Document.
`-1` if classified by an automated process.

#### needs_flexible_extraction_review *: `bool`*

Indicates whether the Document requires Flexible Extraction Supervision.

#### pages *: `list`[[`DocumentPage`](#flows_sdk.implementations.idp_v44.contracts.DocumentPage)]*

Array of Page objects included in this Document.

#### document_fields *: `list`[[`Field`](#flows_sdk.implementations.idp_v44.contracts.Field)] | `None`* *= None*

Array of Field objects identified as being part of this Document.

#### tables *: `list`[[`Table`](#flows_sdk.implementations.idp_v44.contracts.Table)] | `None`* *= None*

Array of Table objects identified as being part of this Document.

#### data_types *: `list`[[`DataType`](#flows_sdk.implementations.idp_v44.contracts.DataType)]*

Array of DataType objects identified as being part of this Document.

#### processed_segments *: `list`[[`FragmentedSegments`](#flows_sdk.implementations.idp_v44.contracts.FragmentedSegments)] | `None`* *= None*

Array of FragmentedSegments objects representing the segments that have been extracted for this
Document.

#### document_file *: [`DocumentFile`](#flows_sdk.implementations.idp_v44.contracts.DocumentFile) | `None`* *= None*

The printable file rendered from the Document’s page images, if applicable.

#### metadata *: `dict`[`str`, `Any`]*

A dictionary to store any additional metadata related to the Document.

#### exceptions *: `list`[`str`]*

List of exceptions encountered during processing.

### *class* flows_sdk.implementations.idp_v44.contracts.FailedPage

A FailedPage object represents a Page that failed processing during the execution of a Flow.

#### id *: `int`*

Unique system-generated identifier.

#### submission_page_number *: `int`*

Indicates page order for the Submission.

#### status *: `Literal`[`'processing'`, `'failed'`, `'complete'`]*

Current status of the Page. For failed pages, this property will be set to `failed`.

#### page_type *: `Literal`[`'unassigned_page'`, `'blank_page'`, `'other_page'`, `'additional_form_page'`, `'document_page'`, `'unknown_page'`, `'failed'`]*

The type of the Page, which can be used to determine how the system attempted to process
the Page before it failed.

#### image_uuid *: `UUID` | `None`*

Unique identifier of the image for this Page, if available. Refers to the original image as
extracted from the source file before any transformations were applied.

#### image_name *: `str` | `None`*

The name of the original image file for this Page, if available.

#### image_width *: `int`*

The width of the original image for this Page in pixels, if available.

#### image_height *: `int`*

The height of the original image for this Page in pixels, if available.

#### image_checksum *: `str` | `None`*

The checksum of the original image for this Page, if available.

#### origin *: [`FilePageOrigin`](#flows_sdk.implementations.idp_v44.contracts.FilePageOrigin) | [`FilenamePageOrigin`](#flows_sdk.implementations.idp_v44.contracts.FilenamePageOrigin)*

The origin of the Page, which can be used to determine from which submitted file the
Page was extracted.

#### exceptions *: `list`[`str`]*

List of exceptions encountered during processing that led to the failure of this Page.

### *class* flows_sdk.implementations.idp_v44.contracts.DocumentPage

Represents a page within a document.

#### id *: `int`*

Unique system-generated identifier of the original Page object.

#### document_page_id *: `int`*

Unique system-generated identifier.

#### document_page_number *: `int`*

Indicates page order for the Document.

#### classification_type *: `Literal`[`'manual'`, `'machine'`]* *= None*

The method by which the Page was classified.

#### layout_page_uuid *: `UUID` | `None`* *= None*

Unique identifier of the layout page that this Page was matched to, if applicable.

#### layout_image_uuid *: `UUID` | `None`* *= None*

Unique identifier of the layout image that this Page was matched to, if applicable.

#### submission_page_number *: `int`*

Indicates page order for the Submission.

#### status *: `Literal`[`'processing'`, `'failed'`, `'complete'`]*

Current status of the Page.

#### page_type *: `Union`[`Literal`[`'unassigned_page'`, `'blank_page'`, `'other_page'`, `'additional_form_page'`, `'document_page'`, `'unknown_page'`, `'failed'`], `str`]*

The type of the Page.

#### origin *: [`FilePageOrigin`](#flows_sdk.implementations.idp_v44.contracts.FilePageOrigin)*

The origin of the Page, which can be used to determine from which submitted file the
Page was extracted.

#### machine_layout_page_uuid *: `UUID` | `None`* *= None*

Unique identifier of the layout page that the machine predicted this Page matches to, if
applicable.

#### manual_layout_page_uuid *: `UUID` | `None`* *= None*

Unique identifier of the layout page that a keyer assigned this Page to, if applicable.

#### combined_segments *: [`PageSegments`](#flows_sdk.implementations.idp_v44.contracts.PageSegments) | `None`* *= None*

The segments for the Page, if applicable.

#### image_uuid *: `UUID`*

Unique identifier of the image for this Page. Refers to the original image as extracted from
the source file before any transformations were applied.

#### image_name *: `str`*

The name of the original image file for this Page.

#### image_width *: `int`*

The width of the original image for this Page in pixels.

#### image_height *: `int`*

The height of the original image for this Page in pixels.

#### image_checksum *: `str`*

The checksum of the original image for this Page.

#### corrected_image_uuid *: `UUID` | `None`* *= None*

Unique identifier of the corrected image for this Page, if applicable. Refers to the image
after transformations such as rotation or perspective correction were applied.

#### image_correction_type *: `Optional`[`Literal`[`'layout_matching'`, `'image_correction'`, `'manual'`]]* *= None*

The type of image correction applied to this Page, if applicable. Available in v43.1 and later.

#### transformation_matrix *: `list`[`list`[`float`]] | `None`* *= None*

The 3x3 registration homography matrix for the Page, if applicable.

#### template_image_shapes *: `list`[`list`[`int`]] | `None`* *= None*

Registration shape metadata for the layout image, if applicable. Contains the
pre-computed layout shape and the original layout image shape.

#### submission_image_shape *: `list`[`int`] | `None`* *= None*

Registration pre-processing shape of the submission image, if applicable.

#### correction_model_info *: [`ImageCorrectionModelInfo`](#flows_sdk.implementations.idp_v44.contracts.ImageCorrectionModelInfo) | `None`* *= None*

Model version metadata for image correction on this Page, if applicable.

#### rotation_confidence *: `float` | `None`* *= None*

The confidence score for the applied rotation correction for the Page, if applicable. Ranges
from 0.0 to 1.0, or `None` if not applicable.

#### rotation_class *: `int` | `None`* *= None*

The applied rotation-correction class for the Page, if applicable. Values are `0`, `1`,
`2`, or `3`, representing the number of 90-degree counterclockwise rotations applied, or
`None` if not applicable.

#### deskew_confidence *: `float` | `None`* *= None*

The confidence score for the applied deskew correction for the Page, if applicable. Ranges
from 0.0 to 1.0, or `None` if not applicable.

#### skew_angle *: `float` | `None`* *= None*

The applied deskew-correction angle for the Page in degrees, if applicable. This value
represents the rotation applied to deskew the image (it may be 0 when no deskew is needed),
or `None` if not applicable.

#### mobile_correction_result *: `Optional`[`Literal`[`'PREDICTED_TRANSFORM'`, `'THRESHOLDED_AS_SCANNED'`, `'NO_VANISHING_POINT_CONSENSUS'`, `'TOO_FEW_DOCUMENT_PIXELS'`]]* *= None*

Outcome of mobile perspective correction for this Page, if applicable. Indicates whether a
perspective transform was applied or why it was not, or `None` if not applicable.

#### applied_transform *: [`ImageCorrectionPerspectiveTransform`](#flows_sdk.implementations.idp_v44.contracts.ImageCorrectionPerspectiveTransform) | `None`* *= None*

Applied mobile perspective transform for this Page, if applicable.

#### exceptions *: `list`[`str`]*

List of exceptions encountered during processing.

### *class* flows_sdk.implementations.idp_v44.contracts.Field

Represents a concrete occurrence of a field that has been defined for extraction as part of a
layout.

#### id *: `int`*

Unique system-generated identifier.

#### uuid *: `UUID`*

Unique system-generated identifier.

#### status *: `Optional`[`Literal`[`'processing'`, `'complete'`]]* *= None*

Current status of the Field.

#### layout_field_uuid *: `UUID`*

The unique identifier of the specific layout field this Field was matched to.

#### layout_page_uuid *: `UUID`*

The unique identifier of the layout page that this Field was matched to.

#### data_type_uuid *: `UUID`*

The unique identifier of the data type of the Field.

#### source_uuid *: `UUID` | `None`*

Stable layout-level field identifier used to map equivalent Fields across versions of the same
layout.

#### original_source_uuid *: `UUID` | `None`*

The original stable layout-level field identifier. Used to map Fields from partially matched
Documents to a specific layout field.

#### shared_field_uuid *: `UUID` | `None`*

The unique identifier of the shared field, if applicable.

#### field_number *: `int`*

One-based index, defining the number of the Field within the layout.

#### field_name *: `str`*

The name of the layout field that this Field was matched to.

#### output_name *: `str`*

The output name of the layout field that this Field was matched to.

#### required *: `bool`*

Indicates whether this Field was defined as required in the layout.

#### repeated *: `bool`*

For fields in Structured layouts, indicates whether this Field can appear multiple times. Data
from repeated fields is extracted only from the Field’s first occurrence in a Document.

#### dropout *: `bool`*

Indicates whether text in the Field’s background is removed from the transcription, as defined
in the layout.

#### multiline *: `bool`*

Indicates whether this Field is expected to have multiple lines of text, as defined in the
layout.

#### identification_sv_mode *: `int`*

Indicates how Supervision affects the identification of the Field. Possible values are:

> * `0` (default) - using the default identification process.
> * `2` (auto_identify) - the field will never go to Identification Supervision, regardless
>   of the machine’s confidence.
> * `3` (sv_always) - the field will always go to Identification Supervision, regardless of
>   the machine’s confidence.

Ignored when `process_manual_identification_type` is set.

#### transcription_sv_mode *: `int`*

Indicates how Supervision affects the transcription of the Field. Possible values are:

> * `0` (default) - using the default transcription process.
> * `1` (consensus) - this field requires multiple sources to agree on the transcription
>   before its processing is complete.
> * `2` (auto_transcribe) - the field will never go to Transcription Supervision, regardless
>   of the machine’s confidence.
> * `3` (sv_always) - the field will always go to Transcription Supervision, regardless of
>   the machine’s confidence.

#### language *: `str` | `None`*

The language of the layout field that this Field was matched to.

#### notes *: `str` | `None`*

Additional notes or comments related to the Field.

#### transcription_target_accuracy *: `float` | `None`*

The target accuracy for the transcription of this Field, as defined in the layout.

#### process_manual_identification_type *: `Optional`[`Literal`[`'FORCE'`, `'ALWAYS_FORCE'`, `'SKIP'`, `'ALWAYS_SKIP'`]]* *= None*

Overrides the normal extraction process by forcing or bypassing Identification Supervision for
this Field.

When set, this value overrides `identification_sv_mode`.

#### process_machine_transcription_type *: `Optional`[`Literal`[`'FORCE'`, `'ALWAYS_FORCE'`, `'SKIP'`, `'ALWAYS_SKIP'`]]* *= None*

Overrides the normal extraction process by forcing or bypassing machine transcription for
this Field.

#### process_manual_transcription_type *: `Optional`[`Literal`[`'FORCE'`, `'ALWAYS_FORCE'`, `'SKIP'`, `'ALWAYS_SKIP'`]]* *= None*

Overrides the normal extraction process by forcing or bypassing Manual Transcription Supervision
for this Field.

#### process_flexible_extraction_type *: `Optional`[`Literal`[`'FORCE'`, `'ALWAYS_FORCE'`, `'SKIP'`, `'ALWAYS_SKIP'`]]* *= None*

Overrides the normal extraction process by forcing or bypassing Flexible Extraction Supervision
for this Field.

#### process_orca_type *: `Optional`[`Literal`[`'FORCE'`, `'ALWAYS_FORCE'`, `'SKIP'`, `'ALWAYS_SKIP'`]]* *= None*

Overrides the normal extraction process by forcing or bypassing ORCA extraction for
this Field.

#### identification_source *: `Literal`[`'machine'`, `'human'`]*

The method by which the Field was identified.

#### identification_confidence *: `Literal`[`'sure'`, `'not_sure'`]*

The confidence of the Field’s identification.

#### occurrence_index *: `int`*

Zero-based index of this occurrence among all occurrences for the same layout field and in the
same Document.

#### locations *: `list`[[`FieldLocation`](#flows_sdk.implementations.idp_v44.contracts.FieldLocation)]*

Array of locations where the Field appears.

#### page_number *: `int`*

Corresponds to the page number of the first `FieldLocation` of the Field.
If the Field has no locations, will reference the first page of the Document.

#### bounding_box *: `list`[`float`] | `None`*

Coordinates of the bounding box of the first `FieldLocation` of the Field.
If the Field has no locations, will be `None`.

#### exceptions *: `list`[`str`]*

List of exceptions encountered during processing.

### *class* flows_sdk.implementations.idp_v44.contracts.FieldLocation

Represents the location of a field on a page.

#### type *: `Literal`[`'approximate'`, `'exact'`]*

The type of location.

#### position *: `int`*

One-based index of this location among all locations for the same Field,
ordered by reading order. Sort by this property to reconstruct the Field’s
content in the sequence it appears in across pages.

#### page_number *: `int`*

Reference to the `document_page_number` of the Page where the Field is located.

#### bounding_box *: `list`[`float`]*

The location of the Field on the Page, as an array of four normalized coordinates in the format
`[start_x, start_y, end_x, end_y]`, relative to page dimensions.

### *class* flows_sdk.implementations.idp_v44.contracts.Table

Represents a concrete table that has been defined for extraction as part of a layout.

#### layout_table_uuid *: `UUID`*

The unique identifier of the specific layout table this Table was matched to.

#### layout_table_name *: `str`*

The name of the layout table that this Table was matched to.

#### parent_layout_table_uuid *: `UUID` | `None`* *= None*

Indicates the `layout_table_uuid` of the parent Table, if applicable.

#### process_manual_identification_type *: `Optional`[`Literal`[`'FORCE'`, `'ALWAYS_FORCE'`, `'SKIP'`, `'ALWAYS_SKIP'`]]* *= None*

Overrides the normal extraction process by forcing or bypassing Identification Supervision for
this Table.

#### identification_confidence *: `Literal`[`'sure'`, `'not_sure'`]*

The combined Identification confidence for the entire table hierarchy. If any table in the
parent/child hierarchy is not confidently predicted, the value will be `not_sure` even if the
individual table prediction is `sure`.

#### model_prediction *: `Literal`[`'sure'`, `'not_sure'`]*

The Identification confidence for this specific Table only, independent of its parent or child
tables.

#### rows *: `list`[[`Row`](#flows_sdk.implementations.idp_v44.contracts.Row)]*

Array of Row objects identified as being part of this Table.

#### columns *: `list`[[`Column`](#flows_sdk.implementations.idp_v44.contracts.Column)]*

Array of Column objects identified as being part of this Table.

### *class* flows_sdk.implementations.idp_v44.contracts.Column

Represents a concrete column in a table that has been defined for extraction as part of a
layout.

#### layout_column_uuid *: `UUID`*

The unique identifier of the specific layout column.

#### data_type_uuid *: `UUID`*

The unique identifier of the data type of the TableColumn.

#### source_uuid *: `UUID` | `None`*

Stable layout-level column identifier used to map equivalent Columns across versions of the same
layout.

#### column_number *: `int`*

One-based index, defining the number of the Column within the layout.

#### field_name *: `str`*

The name of the Column as defined in the layout.

#### output_name *: `str`*

The output name of the Column as defined in the layout.

#### required *: `bool`*

Indicates whether this Column was defined as required in the layout.

#### dropout *: `bool`*

Indicates whether text in the background of the cells in this Column is removed from the
transcription, as defined in the layout.

#### multiline *: `bool`*

Indicates whether this Column is expected to have multiple lines of text, as defined in the
layout.

#### transcription_sv_mode *: `int`*

Indicates how Supervision affects the transcription of the cells in this Column.
Possible values are:

> * `0` (default) - using the default transcription process.
> * `1` (consensus) - the cells require multiple sources to agree on the transcription
>   before their processing is complete.
> * `2` (auto_transcribe) - the cells will never go to Transcription Supervision,
>   regardless of the machine’s confidence.
> * `3` (sv_always) - the cells will always go to Transcription Supervision, regardless of
>   the machine’s confidence.

#### language *: `str` | `None`*

The language of the Column as defined in the layout.

#### notes *: `str` | `None`*

Additional notes or comments related to the Column.

#### transcription_target_accuracy *: `float` | `None`* *= None*

The target accuracy for the transcription of the cells in this Column, as defined in the layout.

#### cells *: `list`[[`Cell`](#flows_sdk.implementations.idp_v44.contracts.Cell)]*

Array of Cell objects identified as being part of this Column.

### *class* flows_sdk.implementations.idp_v44.contracts.Row

Represents a row of cells in a table that has been defined for extraction as part of a layout.

#### row_number *: `int`*

Indicates the order in which this Row appears in the Table.

#### parent_row_number *: `int` | `None`* *= None*

Indicates the `row_number` of the parent Row, if part of a child Table.

#### missing_row_iteration *: `int` | `None`* *= None*

Indicates which iteration of the missing-row-detection algorithm identified this Row.

### *class* flows_sdk.implementations.idp_v44.contracts.Cell

Represents a concrete cell in a table that has been defined for extraction as part of a layout.

#### id *: `int`*

Unique system-generated identifier.

#### uuid *: `UUID`*

Unique system-generated identifier.

#### status *: `Optional`[`Literal`[`'processing'`, `'complete'`]]* *= None*

Current status of the Cell.

#### process_machine_transcription_type *: `Optional`[`Literal`[`'FORCE'`, `'ALWAYS_FORCE'`, `'SKIP'`, `'ALWAYS_SKIP'`]]* *= None*

Overrides the normal extraction process by forcing or bypassing machine transcription for
this Cell.

#### process_manual_transcription_type *: `Optional`[`Literal`[`'FORCE'`, `'ALWAYS_FORCE'`, `'SKIP'`, `'ALWAYS_SKIP'`]]* *= None*

Overrides the normal extraction process by forcing or bypassing Manual Transcription Supervision
for this Cell.

#### process_flexible_extraction_type *: `Optional`[`Literal`[`'FORCE'`, `'ALWAYS_FORCE'`, `'SKIP'`, `'ALWAYS_SKIP'`]]* *= None*

Overrides the normal extraction process by forcing or bypassing Flexible Extraction Supervision
for this Cell.

#### identification_source *: `Literal`[`'machine'`, `'human'`]*

The method by which the Cell was identified.

#### identification_confidence *: `Literal`[`'sure'`, `'not_sure'`]*

The confidence of the Cell’s identification.

#### layout_column_uuid *: `UUID`*

The unique identifier of the specific layout column this Cell was matched to.

#### row_number *: `int`*

Reference to the `row_number` of the Row where the Cell is located.

#### page_number *: `int`*

Reference to the `document_page_number` of the Page where the Cell is located.

#### bounding_box *: `list`[`float`] | `None`* *= None*

The location of the Cell on the Page, as an array of four normalized coordinates in the format
`[start_x, start_y, end_x, end_y]`, relative to page dimensions.

#### exceptions *: `list`[`str`]*

List of exceptions encountered during processing.

### *class* flows_sdk.implementations.idp_v44.contracts.Case

The Case object represents a set of documents collated for a particular purpose.

#### id *: `int`*

Unique system-generated identifier.

#### uuid *: `UUID`*

Unique system-generated identifier that remains unique when there is a need to migrate case
data between systems.

#### external_case_id *: `str`*

User-defined identifier that can be included as part of the Case object during case creation.

#### notes *: `str`*

User-defined string that can be included as part of the Case object during case creation
or update.

#### start_time *: `datetime`*

Time the Case was created.

#### update_time *: `datetime`*

Time the Case was last updated.

#### to_delete_time *: `datetime` | `None`* *= None*

Time the Case is scheduled to be deleted, if applicable.

#### submissions *: `list`[`int`]*

Array of `id`s of Submissions with Pages (or Documents) included in this Case.

#### submission_files *: `list`[`str`]*

Array of strings representing the names of files comprising the Case.

#### unassigned_pages *: `list`[`int`]*

Array of `id`s of Pages that are included in the Case but not yet assigned to a Document.

#### documents *: `list`[`int`]*

Array of `id`s of Documents included in the Case.

### *class* flows_sdk.implementations.idp_v44.contracts.FilePageOrigin

Represents the origin of a page when detailed file information is available.

#### file_uuid *: `UUID`*

Unique identifier of the file from which this Page was extracted.

#### file_name *: `str` | `None`* *= None*

The name of the file from which this Page was extracted. Available in v43.1 and later.

#### sub_file_number *: `int`*

The number of the sub-file from which this Page was extracted. For example, if a ZIP
file contains three PDFs, the Pages extracted from the first PDF would have
`sub_file_number` 1, the second PDF would have `sub_file_number` 2, and the third
PDF would have `sub_file_number` 3.

#### file_page_number *: `int` | `None`*

The page number within the file / sub-file. This value is 1-indexed.

#### file_group *: `str`*

The group to which the file belongs.

#### intermediate_file_uuid *: `UUID` | `None`* *= None*

UUID of the intermediate PDF blob produced when paginating a non-PDF file type (e.g., DOCX,
HTML). `None` for native PDFs and image-only formats. Available in v43.2 and later.

### *class* flows_sdk.implementations.idp_v44.contracts.FilenamePageOrigin

Represents the origin of a page when the file name is the only available information.
This situation can occur when the system fails to extract the referenced file.

#### file_name *: `str`*

The name of the file from which this Page was extracted.

### *class* flows_sdk.implementations.idp_v44.contracts.PageSegments

Represents the segmentation details of a page, including the number of text, checkbox, and
signature segments.

#### uuid *: `UUID`*

Unique identifier used to link the Page to its corresponding segments in the file store.

#### model_version *: `str`*

The version of the segmentation model used to extract the segments.

#### segmentation_date *: `datetime`*

The date and time when the segmentation was performed.

#### n_text_segments *: `int`*

The number of text segments identified on the Page.

#### n_checkbox_segments *: `int`*

The number of checkbox segments identified on the Page.

#### n_signature_segments *: `int`*

The number of signature segments identified on the Page.

### *class* flows_sdk.implementations.idp_v44.contracts.DataType

Provides means for configuring the data-extraction and normalization processes.

#### uuid *: `UUID`*

Unique system-generated identifier.

#### name *: `str`*

Human-readable name of the DataType.

#### entry_type *: `Literal`[`1`, `2`, `3`]*

Represents the method by which the data is extracted. Possible values are:

> * `1` (builtin) - extraction using a built-in model.
> * `2` (pattern) - extraction using a regex pattern.
> * `3` (list) - extraction by matching against a list of accepted values.

#### ml_model *: `Literal`[`'checkbox'`, `'signature'`, `'entry'`, `'barcode'`]*

Top-level category of the DataType.

#### meta_type *: `str` | `None`*

Sub-category of the DataType. For example, for an `entry` DataType, the `meta_type` could be
`date`, `address`, etc.

### *class* flows_sdk.implementations.idp_v44.contracts.ImageCorrectionModelInfo

Provides information about the models used for image correction.

#### rotation_model *: `str`*

The version of the rotation-detection model used for image correction.

#### mobile_model *: `str` | `None`*

The version of the mobile-correction model used for image correction, if applicable.

### *class* flows_sdk.implementations.idp_v44.contracts.ImageCorrectionPerspectiveTransform

Provides information about the perspective transform applied during mobile correction.

#### absolute_matrix *: `list`[`list`[`float`]]*

The 3x3 perspective (homography) matrix in absolute pixel coordinates.

#### relative_matrix *: `list`[`list`[`float`]]*

The 3x3 perspective (homography) matrix in normalized relative coordinates.

#### relative_corner_points *: `list`[`list`[`float`]]*

The corner points of the perspective transform, represented as relative
coordinates (between 0 and 1) with respect to the original image dimensions.

### *class* flows_sdk.implementations.idp_v44.contracts.DocumentFile

Metadata for a printable file rendered from a document’s page images.

#### document_uuid *: `UUID`*

UUID of the source Document this printable file was rendered for.

#### uuid *: `UUID`*

UUID of the stored rendered file.

#### checksum *: `str`*

Checksum of the stored rendered file.

#### mime_type *: `str`*

MIME type of the rendered file (e.g., `application/pdf`).

#### height_in_mm *: `float`*

The maximum page height across all rendered pages in millimeters.

#### width_in_mm *: `float`*

The maximum page width across all rendered pages in millimeters.

#### quality *: `int`*

Rendering quality used when generating the printable file.

#### mode *: `str`*

Color mode used during rendering (e.g., `RGB`, `GRAYSCALE`, or `BW`).

#### download_url *: `str`*

API URL for downloading the rendered file.

#### page_dimensions *: `list`[[`DocumentFilePage`](#flows_sdk.implementations.idp_v44.contracts.DocumentFilePage)]*

Per-page rendered metadata listed in the same order as pages in the output file.

### *class* flows_sdk.implementations.idp_v44.contracts.DocumentFilePage

Metadata for one rendered page in a DocumentFile.

Includes the source page image identifier and the rendered page size in millimeters.

#### image_uuid *: `UUID`*

UUID of the source image used for this rendered page.

#### width_in_mm *: `float` | `None`*

Rendered page width in millimeters.

#### height_in_mm *: `float` | `None`*

Rendered page height in millimeters.

### *class* flows_sdk.implementations.idp_v44.contracts.FragmentedSegments

Metadata for a stored artifact that contains fragmented segments from a document.

Each instance represents one derived segment set produced from the document’s original
segments using a particular splitting configuration.

#### uuid *: `UUID`*

Unique identifier of the stored fragmented segments.

#### flex_model_type *: `str`*

Specifies the splitting strategy used to derive these fragmented segments from the original
segments.

#### custom_split_char *: `str` | `None`*

Optional custom split-character configuration used when these fragmented segments were derived.

### *class* flows_sdk.implementations.idp_v44.contracts.EntityGroup

The EntityGroup object represents a group of pages and entities extracted from those pages.

#### identifier *: `str`*

Unique system-generated identifier.

#### pages *: `list`[[`Page`](#flows_sdk.implementations.idp_v44.contracts.Page)]*

Array of Page objects included in this EntityGroup.

#### entities *: `list`[[`Entity`](#flows_sdk.implementations.idp_v44.contracts.Entity)]*

Array of Entity objects included in this EntityGroup.

### *class* flows_sdk.implementations.idp_v44.contracts.Entity

The Entity object presents a single extracted occurrence of a given type.

#### uuid *: `UUID`*

Unique system-generated identifier.

#### origin *: `Literal`[`'NER'`, `'CED'`, `'Signature'`]*

The origin of the Entity, indicating which method was used for extracting it.

#### type *: `str`*

The type of the Entity (e.g., `Person Name`, `Location`, etc.).

#### text *: `str`*

The text extracted from the Entity.

#### locations *: `list`[[`EntityLocation`](#flows_sdk.implementations.idp_v44.contracts.EntityLocation)]*

Array of locations where the Entity appears.

#### confidence *: `float`*

A number between 0 and 1 indicating the confidence the machine has in the accuracy of the
Entity’s extraction.

### *class* flows_sdk.implementations.idp_v44.contracts.EntityLocation

Represents the location of an entity on a page.

#### position *: `int`*

One-based index of this location among all locations for the same Entity,
ordered by reading order. Sort by this property to reconstruct the Entity’s
content in the sequence it appears across pages.

#### page_number *: `int`*

Reference to the `submission_page_number` of the Page where the Entity is located.

#### bounding_box *: `list`[`float`]*

The location of the Entity on the Page, as array of four numbers in the format
`[start_x, start_y, end_x, end_y]`.

#### text *: `str`*

The text extracted from the Entity location.

#### raw_text *: `str`*

The raw text extracted from the Entity location.

### *class* flows_sdk.implementations.idp_v44.contracts.RedactedGroup

The RedactedGroup object represents a group of redacted pages.

#### identifier *: `str`*

Identifier of the source redaction group.

#### pages *: `list`[[`RedactedPage`](#flows_sdk.implementations.idp_v44.contracts.RedactedPage)]*

Array of RedactedPage objects included in this RedactedGroup.

### *class* flows_sdk.implementations.idp_v44.contracts.RedactedPage

Represents a page with redaction data.

#### id *: `int`*

Unique system-generated identifier.

#### redaction_data *: [`PageRedactionData`](#flows_sdk.implementations.idp_v44.contracts.PageRedactionData)*

A PageRedactionData object containing the redaction data for the Page.

#### submission_page_number *: `int`*

Indicates page order for the Submission.

#### status *: `Literal`[`'processing'`, `'failed'`, `'complete'`]*

Current status of the Page.

#### page_type *: `Union`[`Literal`[`'unassigned_page'`, `'blank_page'`, `'other_page'`, `'additional_form_page'`, `'document_page'`, `'unknown_page'`, `'failed'`], `str`]*

The type of the Page.

#### origin *: [`FilePageOrigin`](#flows_sdk.implementations.idp_v44.contracts.FilePageOrigin)*

The origin of the Page, which can be used to determine from which submitted file the
Page was extracted.

#### classification_type *: `Optional`[`Literal`[`'manual'`, `'machine'`]]* *= None*

The method by which the Page was classified, if applicable. Present when the `page_type`
is not ‘unknown_page’ or ‘unassigned_page’.

#### machine_layout_page_uuid *: `UUID` | `None`* *= None*

Unique identifier of the layout page that the machine predicted this Page matches to, if
applicable.

#### manual_layout_page_uuid *: `UUID` | `None`* *= None*

Unique identifier of the layout page that a keyer assigned this Page to, if applicable.

#### combined_segments *: [`PageSegments`](#flows_sdk.implementations.idp_v44.contracts.PageSegments) | `None`* *= None*

The segments for the Page, if applicable.

#### image_uuid *: `UUID`*

Unique identifier of the image for this Page. Refers to the original image as extracted from
the source file before any transformations were applied.

#### image_name *: `str`*

The name of the original image file for this Page.

#### image_width *: `int`*

The width of the original image for this Page in pixels.

#### image_height *: `int`*

The height of the original image for this Page in pixels.

#### image_checksum *: `str`*

The checksum of the original image for this Page.

#### corrected_image_uuid *: `UUID` | `None`* *= None*

Unique identifier of the corrected image for this Page, if applicable. Refers to the image
after transformations such as rotation or perspective correction were applied.

#### image_correction_type *: `Optional`[`Literal`[`'layout_matching'`, `'image_correction'`, `'manual'`]]* *= None*

The type of image correction applied to this Page, if applicable. Available in v43.1 and later.

#### transformation_matrix *: `list`[`list`[`float`]] | `None`* *= None*

The 3x3 registration homography matrix for the Page, if applicable.

#### template_image_shapes *: `list`[`list`[`int`]] | `None`* *= None*

Registration shape metadata for the layout image, if applicable. Contains the
pre-computed layout shape and the original layout image shape.

#### submission_image_shape *: `list`[`int`] | `None`* *= None*

Registration pre-processing shape of the submission image, if applicable.

#### correction_model_info *: [`ImageCorrectionModelInfo`](#flows_sdk.implementations.idp_v44.contracts.ImageCorrectionModelInfo) | `None`* *= None*

Model version metadata for image correction on this Page, if applicable.

#### rotation_confidence *: `float` | `None`* *= None*

The confidence score for the applied rotation correction for the Page, if applicable. Ranges
from 0.0 to 1.0, or `None` if not applicable.

#### rotation_class *: `int` | `None`* *= None*

The applied rotation-correction class for the Page, if applicable. Values are `0`, `1`,
`2`, or `3`, representing the number of 90-degree counterclockwise rotations applied, or
`None` if not applicable.

#### deskew_confidence *: `float` | `None`* *= None*

The confidence score for the applied deskew correction for the Page, if applicable. Ranges
from 0.0 to 1.0, or `None` if not applicable.

#### skew_angle *: `float` | `None`* *= None*

The applied deskew-correction angle for the Page in degrees, if applicable. This value
represents the rotation applied to deskew the image (it may be 0 when no deskew is needed),
or `None` if not applicable.

#### mobile_correction_result *: `Optional`[`Literal`[`'PREDICTED_TRANSFORM'`, `'THRESHOLDED_AS_SCANNED'`, `'NO_VANISHING_POINT_CONSENSUS'`, `'TOO_FEW_DOCUMENT_PIXELS'`]]* *= None*

Outcome of mobile perspective correction for this Page, if applicable. Indicates whether a
perspective transform was applied or why it was not, or `None` if not applicable.

#### applied_transform *: [`ImageCorrectionPerspectiveTransform`](#flows_sdk.implementations.idp_v44.contracts.ImageCorrectionPerspectiveTransform) | `None`* *= None*

Applied mobile perspective transform for this Page, if applicable.

#### exceptions *: `list`[`str`]*

List of exceptions encountered during processing.

### *class* flows_sdk.implementations.idp_v44.contracts.PageRedactionData

Contains the redaction data for a Page.

#### image_uuid *: `str`*

Unique identifier of the primary redacted image for the Page.

#### debug_image_uuid *: `str`*

Unique identifier of a separate debug rendering of the same redacted Page. Contains visual
indicators of where redactions were applied.

#### redactions *: `list`[[`Redaction`](#flows_sdk.implementations.idp_v44.contracts.Redaction)]*

Array of Redaction objects associated with the Page.

### *class* flows_sdk.implementations.idp_v44.contracts.Redaction

Represents a single redaction applied to a page.

#### kind *: `str`*

The normalized redaction category.

#### bounding_box *: `list`[`float`]*

The location of the redacted text on the Page, as an array of four numbers in the format
`[start_x, start_y, end_x, end_y]`.

#### original_text *: `str`*

The original text before redaction.

#### redacted_text *: `str`*

The replacement text written into the page image. May be empty when text is not replaced
(e.g., in opaque/box-based redaction modes).

### *class* flows_sdk.implementations.idp_v44.contracts.Transcription

Represents a transcription of text with a unique identifier.

#### uuid *: `UUID`*

Unique system-generated identifier.

#### value *: `str`*

The transcribed text value.

### *class* flows_sdk.implementations.idp_v44.contracts.AddressData

Represents the address data structure, including parsed, normalized, and verification details.

#### uuid *: `UUID`*

The unique identifier for the address data.

#### parse_error *: `str` | `None`* *= None*

The error encountered during the parsing of the address, if any.

#### normalized_address *: `str` | `None`* *= None*

The normalized address as a string.

#### parsed_address_json *: [`ParsedAddress`](#flows_sdk.implementations.idp_v44.contracts.ParsedAddress) | `None`* *= None*

The parsed address data, if available.

#### verification_json *: `dict`[`str`, `Any`] | `None`* *= None*

The verification details of the parsed address, if available.

### *class* flows_sdk.implementations.idp_v44.contracts.ParsedAddress

Represents the parsed address data extracted by the specified parser.

#### parser *: `Literal`[`'geoapify'`, `'google'`, `'smarty'`, `'usaddress'`, `'deepparse'`]*

The parser used to extract the address data.

#### recipient *: `str` | `None`* *= None*

The recipient name, if available.

#### street_number *: `str` | `None`* *= None*

The street number, if available.

#### street_name *: `str` | `None`* *= None*

The street name, if available.

#### unit *: `str` | `None`* *= None*

The unit or apartment number, if available.

#### po_box *: `str` | `None`* *= None*

The PO box number, if available.

#### city *: `str` | `None`* *= None*

The city name, if available.

#### state *: `str` | `None`* *= None*

The state or province name, if available.

#### postal_code *: `str` | `None`* *= None*

The postal code, if available.

#### country *: `str` | `None`* *= None*

The country name, if available.

#### country_code *: `str` | `None`* *= None*

The country code, if available.

#### raw *: `dict`[`str`, `Any`] | `None`* *= None*

The raw address data as a dictionary, if available.
