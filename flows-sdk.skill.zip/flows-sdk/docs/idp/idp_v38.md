# IDP Library — V38


#### Processing Blocks (v38)

Core Blocks are powerful processing blocks necessary to build intelligent document processing solutions on Hyperscience. They include both manual and machine processing blocks.

#### NOTE
Classes in the idp_v38 implementation have parameters with ambiguous typing.
For example, a field of type integer could also be represented as a string reference
(e.g. that integer gets provided at runtime).
The types introduced in the example are therefore incomplete and are likely to be
revisioned in a future version.

<a id="module-flows_sdk.implementations.idp_v38.idp_blocks"></a>

### *class* flows_sdk.implementations.idp_v38.idp_blocks.IDPCoreBlock(idp_wf_config, reference_name='_\_idp_core_\_', title='Start Document Processing Subflow', description='Calls the Document Processing Subflow with the specified settings.', compatibility_spec=CompatibilitySpec(filter_roles=['idp_core'], filter_schema=None, label=None), identifier='IDP_CORE_V38', additional_inputs=None)

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

IDP core block includes the steps to process the passed documents into machine-readable
output.

Mandatory parameters:

* **Parameters:**
  **idp_wf_config** ([`IdpWorkflowConfig`](#flows_sdk.implementations.idp_v38.idp_values.IdpWorkflowConfig)) – IdpWorkflowConfig object with all flow-level configuration settings
  for IDP

Parameters with defaults:

* **Parameters:**
  * **reference_name** (`Optional`[`str`]) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **compatibility_spec** (`Optional`[[`CompatibilitySpec`](../source-docs.md#flows_sdk.types.CompatibilitySpec)]) – defines a filter for flows that could be selected in the UI in place
    of “IDP Core” for the block. Defaults to flows with the role ‘idp_core’. The user will be
    able to pick any flow that matches the compatibility_spec. This serves to make upgrading
    to a new compatible version of “IDP Core” (e.g. IDP_CORE_V39) easier in future releases.
  * **identifier** (`str`) – The identifier of the flow. Defaults to the IDP_CORE_VXX identifier of the
    out-of-the-box flow that comes with the system.
  * **additional_inputs** (`Optional`[`Dict`[`str`, `Any`]]) – Dictionary containing key-value pairs that will be added to the
    inputs of the block. If a key is contained in the default inputs, its value will be
    overwritten by the value provided here. You generally do not need to provide
    additional_inputs, unless you are creating a custom derivative of the IDP_CODE_Vxx flow
    and are modifying or extending the list of inputs it accepts.

Example usage:

```default
idp_core = IDPCoreBlock(idp_wf_config=idp_wf_config)
```

#### REFERENCE_NAME *= '_\_idp_core_\_'*

### *class* flows_sdk.implementations.idp_v38.idp_blocks.SubmissionBootstrapBlock(reference_name=None, layout_release_uuid='${workflow.input.layout_release_uuid}', s3_config='${workflow.input.submission_bootstrap_s3_config}', s3_endpoint_url='${workflow.input.submission_bootstrap_s3_endpoint_url}', ocs_config='${workflow.input.submission_bootstrap_ocs_config}', http_config='${workflow.input.submission_bootstrap_http_config}', notification_workflow='${workflow.input.notification_workflow_initialization}', workflow_uuid='${workflow.input.workflow_uuid}', workflow_name='${workflow.input.workflow_name}', workflow_version='${workflow.input.workflow_version}', submission='${workflow.input.submission}')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Submission bootstrap block initializes the submission object and prepares external images
or other submission data if needed.
**This block should be called at the START of every flow** that
uses blocks included in the library.

Parameters with defaults:

* **Parameters:**
  * **reference_name** (`Optional`[`str`]) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **layout_release_uuid** (`str`) – Layout Release UUID at submission creation time,
    defaults to workflow_input(Settings.LayoutReleaseUuid)
  * **s3_config** (`str`) – Specify Amazon S3 credentials for submission retrieval store.
    Expects a json expression: `{"aws_access_key_id": "X", "aws_secret_access_key": "Y"}`,
    defaults to system_secret(S3_SECRET_KEY)
  * **s3_endpoint_url** (`str`) – Endpoint URL for S3 submission retrieval store, defaults to None
  * **ocs_config** (`str`) – OCS Configuration for downloading submission data,
    defaults to system_secret(OCS_SECRET_KEY)
  * **http_config** (`Optional`[`str`]) – An optional system secret field expressing the HTTP Configuration for
    downloading submission data. The content is expected to be a json formatted as:
    `{"username": "X", "password": "Y", "ssl_cert": "CA bundle filename"}`,
    defaults to None
  * **notification_workflow** (`str`) – Notification flow name to run when the submission is initialized,
    defaults to IDP_SUBMISSION_NOTIFY_NAME
  * **workflow_uuid** (`str`) – UUID of the triggered workflow version,
    defaults to workflow_input(Inputs.WorkflowUuid)
  * **workflow_name** (`str`) – Name of the triggered workflow,
    defaults to workflow_input(Inputs.WorkflowName)
  * **workflow_version** (`str`) – Version of the triggered workflow,
    defaults to workflow_input(Inputs.WorkflowVersion)

Example usage:

```default
submission_bootstrap = SubmissionBootstrapBlock(reference_name='submission_bootstrap')
```

#### IDENTIFIER *= 'SUBMISSION_BOOTSTRAP_2'*

#### output(key=None)

Submission bootstrap ends with a CodeBlock, which nests the actual outputs under
the ‘result’ key. This method overrides the default output in the same manner that
`flows_sdk.blocks.Routing.CodeBlock` does for convenience.

* **Parameters:**
  **key** (`Optional`[`str`]) – 

  Optionally provide a key to directly get a nested property.
  When not provided, the entire ‘result’ will be returned.
  For example, we have:
  ```default
  {
      "result": {
          "a": {
              "b": 42
          }
      }
  }
  ```

  - skipping the key `output()` will return ``{"a": {"b": 42}}`
  - calling with `output("a")` will result in `{"b": 42}`
  - calling with `output("a.b")` will return `42`
* **Return type:**
  `str`
* **Returns:**
  the value under the provided key

### *class* flows_sdk.implementations.idp_v38.idp_blocks.MachineCollationBlock(submission, cases, dedupe_files='${workflow.input.machine_collation_dedupe_files}', refresh_retention_period='${workflow.input.machine_collation_refresh_retention_period}', remove_from_cases='${workflow.input.machine_collation_remove_from_cases}', retention_period='${workflow.input.machine_collation_retention_period}', reference_name=None)

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Machine collation block groups files, documents and pages (from the submission) into cases.

Mandatory parameters:

* **Parameters:**
  * **submission** (`Any`) – Submission object
  * **cases** (`Any`) – 

    This parameter accepts an array of JSON objects that contain information on
    how Cases should be created. There are two ways to collate a case: by the filenames
    specified in the current Submission, or by the ids of the Documents or Pages submitted
    in previous submissions.

    This parameter follows the given format:
    ```default
    {
        'cases': [
            'external_case_id': 'HS-1',
            'filename': 'file1.pdf',
            'documents': [42],
            'pages': [43]
        ]
    }
    ```

Parameters with defaults:

* **Parameters:**
  * **reference_name** (`Optional`[`str`]) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **dedupe_files** (`Union`[`bool`, `str`]) – Enabling this setting will replace case data from repeated file names
    within the same case. Cases will retain data from the most recently submitted version of
    a particular file. Note that this setting does not delete the old data, it just removes it
    from the case. Keep in mind this option is only relevant when adding to cases
  * **remove_from_cases** (`Optional`[`Any`]) – 

    This parameter accepts an array of JSON objects that contains
    information on how documents or pages should be removed from a pre-existing case.
    Currently, the only way to de-collate from a case is by the ids of the Documents or
    Pages within a given case

    This parameter follows the given format:
    ```default
    {
        'remove_from_cases': [
            'external_case_id': 'HS-1',
            'documents': [42],
            'pages': [43]
        ]
    }
    ```
  * **retention_period** (`Union`[`int`, `str`, `None`]) – The number of days to retain cases after they are updated by this
    block. If passed `None`, no changes to the deletion date will be made.
    By default, this value is `None`
  * **refresh_retention_period** (`Union`[`bool`, `str`]) – If `True`, (re)applies Retention Period parameter to all
    cases passed into the block. If `False`, only updates those without a pre-existing
    deletion date. By default, this value is `True`

Example usage:

```default
machine_collation = MachineCollationBlock(
    reference_name='machine_collation',
    submission=submission_bootstrap.output('result.submission'),
    cases=submission_bootstrap.output('result.api_params.cases'),
    dedupe_files=True,
    remove_from_cases=custom_supervision.output('remove_from_cases')
)
```

#### IDENTIFIER *= 'MACHINE_COLLATION_2'*

### *class* flows_sdk.implementations.idp_v38.idp_blocks.MachineClassificationBlock(submission, api_params, reference_name=None, rotation_correction_enabled='${workflow.input.machine_classification_rotation_correction_enabled}', mobile_processing_enabled='${workflow.input.machine_classification_mobile_processing_enabled}', file_transcription_enabled='${workflow.input.machine_classification_file_transcription_enabled}', layout_release_uuid='${workflow.input.layout_release_uuid}', vpc_registration_threshold='${workflow.input.structured_layout_match_threshold}', nlc_enabled='${workflow.input.semi_structured_classification}', nlc_target_accuracy='${workflow.input.semi_target_accuracy}', nlc_doc_grouping_logic='${workflow.input.semi_doc_grouping_logic}')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Machine classification block automatically matches documents to structured,
semi-structured or additional layouts

Mandatory parameters:

* **Parameters:**
  * **submission** (`Any`) – Submission object
  * **api_params** (`Any`)

Parameters with defaults:

* **Parameters:**
  * **reference_name** (`Optional`[`str`]) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **rotation_correction_enabled** (`Union`[`bool`, `str`]) – Identifies and corrects the orientation of
    semi-structured images,
    defaults to True
  * **mobile_processing_enabled** (`Union`[`bool`, `str`]) – Improves the machine readability of photo
    captured documents,
    defaults to False
  * **layout_release_uuid** (`str`) – Layout Release UUID at submission creation time,
    defaults to workflow_input(Settings.LayoutReleaseUuid)
  * **vpc_registration_threshold** (`str`) – Structured pages above this threshold will be
    automatically matched to a layout variation,
    defaults to workflow_input(Settings.StructuredLayoutMatchThreshold)
  * **nlc_enabled** (`str`) – Enables workflow to manage a model for automated classification
    of semi-structured and additional layout variations,
    defaults to workflow_input(Settings.SemiStructuredClassification)
  * **nlc_target_accuracy** (`str`) – defaults to workflow_input(Settings.SemiTargetAccuracy)
  * **nlc_doc_grouping_logic** (`str`) – Logic to handle multiple pages matched to the same
    layout variationin a given submission,
    defaults to workflow_input(Settings.SemiDocGroupingLogic)

Example usage:

```default
machine_classification = MachineClassificationBlock(
    reference_name='machine_classification',
    submission=case_collation.output('submission'),
    api_params=submission_bootstrap.output('result.api_params'),
    rotation_correction_enabled=idp_wf_config.rotation_correction_enabled,
)
```

#### IDENTIFIER *= 'MACHINE_CLASSIFICATION_5'*

### *class* flows_sdk.implementations.idp_v38.idp_blocks.ManualClassificationBlock(submission, api_params, reference_name=None, layout_release_uuid='${workflow.input.layout_release_uuid}', manual_nlc_enabled='${workflow.input.manual_nlc_enabled}', task_restrictions='${workflow.input.manual_classification_task_restrictions}', notification_workflow='${workflow.input.notification_workflow_classification}', nlc_enabled='${workflow.input.semi_structured_classification}', nlc_target_accuracy='${workflow.input.semi_target_accuracy}', mobile_processing_enabled='${workflow.input.machine_classification_mobile_processing_enabled}')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Manual classification block allows keyers to manually match submissions to their layouts.
Keyers may perform manual classification if machine classification cannot automatically
match a submission to a layout with high confidence

Mandatory parameters:

* **Parameters:**
  * **submission** (`Any`) – Submission object
  * **api_params** (`Any`)

Parameters with defaults:

* **Parameters:**
  * **reference_name** (`Optional`[`str`]) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **layout_release_uuid** (`str`) – Layout Release UUID at submission creation time,
    defaults to workflow_input(Settings.LayoutReleaseUuid)
  * **manual_nlc_enabled** (`str`) – Enables manual classification when applicable,
    defaults to workflow_input(Settings.ManualNlcEnabled)
  * **task_restrictions** (`Union`[`List`[`Any`], `str`, `None`]) – Defines what users can access Supervision tasks created
    by this block,
    defaults to None
  * **notification_workflow** (`str`) – Notification flow name to run when the submission
    enters Manual Classification,
    defaults to IDP_SUBMISSION_NOTIFY_NAME

Example usage:

```default
manual_classification = ManualClassificationBlock(
    reference_name='manual_classification',
    submission=machine_classification.output('submission'),
    api_params=submission_bootstrap.output('result.api_params'),
)
```

#### IDENTIFIER *= 'MANUAL_CLASSIFICATION_2'*

### *class* flows_sdk.implementations.idp_v38.idp_blocks.MachineIdentificationBlock(submission, api_params, layout_release_uuid='${workflow.input.layout_release_uuid}', reference_name=None, manual_field_id_enabled='${workflow.input.manual_field_id_enabled}', field_id_target_accuracy='${workflow.input.field_id_target_accuracy}', table_id_target_accuracy='${workflow.input.table_id_target_accuracy}')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Machine identification automatically identify fields and tables in the submission

Mandatory parameters:

* **Parameters:**
  * **submission** (`Any`) – Submission object
  * **api_params** (`Any`)

Parameters with defaults:

* **Parameters:**
  * **reference_name** (`Optional`[`str`]) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **manual_field_id_enabled** (`str`) – Enables manual identification when applicable,
    defaults to workflow_input(Settings.ManualFieldIdEnabled)
  * **field_id_target_accuracy** (`str`) – Field ID Target Accuracy,
    defaults to workflow_input(Settings.FieldIdTargetAccuracy)
  * **table_id_target_accuracy** (`str`) – Table ID Target Accuracy,
    defaults to workflow_input(Settings.TableIdTargetAccuracy)

Example usage:

```default
machine_identification = MachineIdentificationBlock(
    reference_name='machine_identification',
    submission=manual_classification.output('submission'),
    api_params=submission_bootstrap.output('result.api_params'),
)
```

#### IDENTIFIER *= 'MACHINE_IDENTIFICATION_6'*

### *class* flows_sdk.implementations.idp_v38.idp_blocks.ManualIdentificationBlock(submission, api_params, reference_name=None, task_restrictions='${workflow.input.manual_identification_task_restrictions}', manual_field_id_enabled='${workflow.input.manual_field_id_enabled}', layout_release_uuid='${workflow.input.layout_release_uuid}', notification_workflow='${workflow.input.notification_workflow_identification}')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Manual identification allows keyers to complete field identification or table identification
tasks, where they draw bounding boxes around the contents of certain fields, table columns
or table rows. This identification process ensures that the system will be able to
transcribe the correct content in the upcoming transcription process

Mandatory parameters:

* **Parameters:**
  * **submission** (`Any`) – Submission object
  * **api_params** (`Any`)

Parameters with defaults:

* **Parameters:**
  * **reference_name** (`Optional`[`str`]) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **task_restrictions** (`Union`[`List`[`Any`], `str`, `None`]) – Defines what users can access Supervision tasks created
    by this block,
    defaults to []
  * **manual_field_id_enabled** (`str`) – Enables manual identification when applicable,
    defaults to workflow_input(Settings.ManualFieldIdEnabled)
  * **layout_release_uuid** (`str`) – Layout Release UUID at submission creation time,
    defaults to workflow_input(Settings.LayoutReleaseUuid)
  * **notification_workflow** (`str`) – Notification flow name to run when the submission
    enters Manual Identification,
    defaults to DEFAULT_IDP_SUBMISSION_NOTIFY_IDENTIFIER

Example usage:

```default
manual_identification = ManualIdentificationBlock(
    reference_name='manual_identification',
    submission=machine_identification.output('submission'),
    api_params=submission_bootstrap.output('result.api_params'),
    task_restrictions=idp_wf_config.manual_identification_config.task_restrictions,
)
```

#### IDENTIFIER *= 'MANUAL_IDENTIFICATION_5'*

### *class* flows_sdk.implementations.idp_v38.idp_blocks.MachineTranscriptionBlock(submission, api_params, reference_name=None, layout_release_uuid='${workflow.input.layout_release_uuid}', transcription_model='${workflow.input.transcription_model}', finetuning_only_trained_layouts='${workflow.input.finetuning_only_trained_layouts}', transcription_overrides='${workflow.input.transcription_overrides}', structured_text_target_accuracy='${workflow.input.structured_text_target_accuracy}', structured_text_confidence_threshold='${workflow.input.structured_text_threshold}', structured_text_acceptable_confidence='${workflow.input.structured_min_leg_threshold}', semi_structured_text_target_accuracy='${workflow.input.semi_structured_text_target_accuracy}', semi_structured_text_confidence_threshold='${workflow.input.semi_structured_text_threshold}', semi_structured_text_acceptable_confidence='${workflow.input.semi_structured_min_leg_threshold}', semi_structured_table_target_accuracy='${workflow.input.semi_structured_table_target_accuracy}', semi_structured_table_confidence_threshold='${workflow.input.semi_structured_table_threshold}', semi_structured_table_acceptable_confidence='${workflow.input.semi_structured_table_min_leg_threshold}', structured_checkbox_target_accuracy='${workflow.input.structured_checkbox_target_accuracy}', structured_checkbox_confidence_threshold='${workflow.input.structured_checkbox_threshold}', structured_checkbox_acceptable_confidence='${workflow.input.checkbox_min_leg_threshold}', structured_signature_target_accuracy='${workflow.input.structured_signature_target_accuracy}', structured_signature_confidence_threshold='${workflow.input.structured_signature_threshold}', structured_signature_acceptable_confidence='${workflow.input.signature_min_leg_threshold}', semi_structured_checkbox_target_accuracy='${workflow.input.semi_structured_checkbox_target_accuracy}', semi_structured_checkbox_confidence_threshold='${workflow.input.semi_structured_checkbox_threshold}', semi_structured_checkbox_acceptable_confidence='${workflow.input.semi_structured_checkbox_min_leg_threshold}')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Machine transcription automatically transcribes the content of your submission

Mandatory parameters:

* **Parameters:**
  * **submission** (`Any`) – Submission object
  * **api_params** (`Any`)

Parameters with defaults:

* **Parameters:**
  * **reference_name** (`Optional`[`str`]) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **layout_release_uuid** (`str`) – Layout Release UUID at submission creation time,
    defaults to workflow_input(Settings.LayoutReleaseUuid)
  * **transcription_model** (`str`) – The transcription model that will be used for this flow,
    defaults to workflow_input(Settings.TranscriptionModel)
  * **finetuning_only_trained_layouts** (`str`) – defaults to workflow_input( Settings.FinetuningOnlyTrainedLayouts )
  * **transcription_overrides** (`str`) – defaults to workflow_input( Settings.TranscriptionOverrides )
  * **structured_text_target_accuracy** (`str`) – defaults to workflow_input( Settings.StructuredTextTargetAccuracy )
  * **structured_text_confidence_threshold** (`str`) – defaults to workflow_input( Settings.StructuredTextThreshold )
  * **structured_text_acceptable_confidence** (`str`) – defaults to workflow_input( Settings.StructuredTextMinLegThreshold )
  * **semi_structured_text_target_accuracy** (`str`) – defaults to workflow_input( Settings.SemiStructuredTextTargetAccuracy )
  * **semi_structured_text_confidence_threshold** (`str`) – defaults to workflow_input( Settings.SemiStructuredTextThreshold )
  * **semi_structured_text_acceptable_confidence** (`str`) – defaults to workflow_input( Settings.SemiStructuredTextMinLegThreshold )
  * **structured_checkbox_target_accuracy** (`str`) – defaults to workflow_input( Settings.StructuredCheckboxTargetAccuracy )
  * **structured_checkbox_confidence_threshold** (`str`) – defaults to workflow_input( Settings.StructuredCheckboxThreshold )
  * **structured_checkbox_acceptable_confidence** (`str`) – defaults to workflow_input( Settings.StructuredCheckboxMinLegThreshold )
  * **structured_signature_target_accuracy** (`str`) – defaults to workflow_input( Settings.StructuredSignatureTargetAccuracy )
  * **structured_signature_confidence_threshold** (`str`) – defaults to workflow_input( Settings.StructuredSignatureThreshold )
  * **structured_signature_acceptable_confidence** (`str`) – defaults to workflow_input( Settings.StructuredSignatureMinLegThreshold )
  * **semi_structured_checkbox_target_accuracy** (`str`) – defaults to workflow_input( Settings.SemiStructuredCheckboxTargetAccuracy )
  * **semi_structured_checkbox_confidence_threshold** (`str`) – defaults to workflow_input( Settings.SemiStructuredCheckboxThreshold )
  * **semi_structured_checkbox_acceptable_confidence** (`str`) – defaults to workflow_input( Settings.SemiStructuredCheckboxMinLegThreshold )

Example usage:

```default
machine_transcription = MachineTranscriptionBlock(
    reference_name='machine_transcription',
    submission=manual_identification.output('submission'),
    api_params=submission_bootstrap.output('result.api_params'),
)
```

#### IDENTIFIER *= 'MACHINE_TRANSCRIPTION_9'*

### *class* flows_sdk.implementations.idp_v38.idp_blocks.ManualTranscriptionBlock(submission, api_params, reference_name=None, supervision_transcription_masking='${workflow.input.manual_transcription_supervision_transcription_masking}', table_output_manual_review='${workflow.input.manual_transcription_table_output_manual_review}', always_supervise_blank_cells='${workflow.input.manual_transcription_always_supervise_blank_cells}', task_restrictions='${workflow.input.manual_transcription_task_restrictions}', manual_transcription_enabled='${workflow.input.manual_transcription_enabled}', notification_workflow='${workflow.input.notification_workflow_transcription}', title='Manual Transcription', description='Manually transcribe fields that could not be automatically transcribed')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Manual transcription lets your keyers manually enter the text found in fields or tables
that could not be automatically transcribed

Mandatory parameters:

* **Parameters:**
  * **submission** (`Any`) – Submission object
  * **api_params** (`Any`)

Parameters with defaults:

* **Parameters:**
  * **reference_name** (`Optional`[`str`]) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **supervision_transcription_masking** (`Union`[`bool`, `str`]) – Prevents users from inputting invalid
    characters during Supervision Transcription tasks,
    defaults to True
  * **table_output_manual_review** (`Union`[`bool`, `str`]) – Always generates a table transcription task if the
    layout contains a table. If disabled, a table transcription task will only be
    generated if one or more cells have transcribed values below the defined thresholds,
    defaults to False
  * **task_restrictions** (`Union`[`List`[`Any`], `str`, `None`]) – Defines what users can access Supervision tasks for
    submission from a particular source or submissions matching a specific layout,
    defaults to []
  * **manual_transcription_enabled** (`str`) – Enables manual transcription when applicable,
    defaults to workflow_input(Settings.ManualTranscriptionEnabled)
  * **notification_workflow** (`str`) – Notification flow name to run when the submission
    enters Manual Transcription,
    defaults to DEFAULT_IDP_SUBMISSION_NOTIFY_IDENTIFIER

Example usage:

```default
manual_transcription = ManualTranscriptionBlock(
    reference_name='manual_transcription',
    submission=machine_transcription.output('submission'),
    api_params=submission_bootstrap.output('result.api_params'),
    supervision_transcription_masking=(
        idp_wf_config.manual_transcription_config.supervision_transcription_masking
    ),
    table_output_manual_review=(
        idp_wf_config.manual_transcription_config.table_output_manual_review
    ),
    task_restrictions=idp_wf_config.manual_transcription_config.task_restrictions,
)
```

#### IDENTIFIER *= 'MANUAL_TRANSCRIPTION_5'*

### *class* flows_sdk.implementations.idp_v38.idp_blocks.FlexibleExtractionBlock(submission, api_params, reference_name=None, supervision_transcription_masking='${workflow.input.flexible_extraction_supervision_transcription_masking}', task_restrictions='${workflow.input.flexible_extraction_task_restrictions}', layout_release_uuid='${workflow.input.layout_release_uuid}', notification_workflow='${workflow.input.notification_workflow_flexible_extraction}')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Flexible extraction manually transcribes fields marked for review

Mandatory parameters:

* **Parameters:**
  * **submission** (`Any`) – Submission object
  * **api_params** (`Any`)

Parameters with defaults:

* **Parameters:**
  * **reference_name** (`Optional`[`str`]) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **supervision_transcription_masking** (`Union`[`bool`, `str`, `None`]) – Prevents users from inputting invalid
    characters during the Flexible Extraction task,
    defaults to True
  * **task_restrictions** (`Union`[`List`[`Any`], `str`, `None`]) – Defines what users can access Supervision tasks created
    by this block,
    defaults to []
  * **layout_release_uuid** (`str`) – Layout Release UUID at submission creation time,
    defaults to workflow_input(Settings.LayoutReleaseUuid)
  * **notification_workflow** (`str`) – Notification flow name to run when the submission
    enters Flexible Extraction,
    defaults to DEFAULT_IDP_SUBMISSION_NOTIFY_IDENTIFIER

Example usage:

```default
flexible_extraction = FlexibleExtractionBlock(
    reference_name='flexible_extraction',
    submission=manual_transcription.output('submission'),
    api_params=submission_bootstrap.output('result.api_params'),
    supervision_transcription_masking=(
        idp_wf_config.flexible_extraction_config.supervision_transcription_masking
    ),
    task_restrictions=idp_wf_config.flexible_extraction_config.task_restrictions,
)
```

#### IDENTIFIER *= 'FLEXIBLE_EXTRACTION_4'*

### *class* flows_sdk.implementations.idp_v38.idp_blocks.ReprocessingBlock(reference_name, submission, parent_flow='${workflow.definition.identifier}', idp_wf_config=None, trigger='${workflow.input.$trigger}')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Reprocessing block enables a second extraction attempt if documents were initially
confidently mis-classified by the machine. When an end-user specifies that a document layout
is incorrect during Manual Identification, Manual Transcription, or Flexible Extraction, the
flow will reach the Reprocessing block which will mark correctly classified documents as
“complete” status, and misclassified documents with “reprocess” status will be processed in a
second execution of the flow. This block should be placed before the SubmissionCompleteBlock
to enable reprocessing.

Mandatory parameters:

* **Parameters:**
  **submission** (`Any`) – Submission object

#### IDENTIFIER *= 'REPROCESSING'*

### *class* flows_sdk.implementations.idp_v38.idp_blocks.SubmissionCompleteBlock(submission, is_reprocessing=False, reference_name=None, nlc_qa_sampling_ratio='${workflow.input.semi_qa_sample_rate}', field_id_qa_enabled='${workflow.input.field_id_qa_enabled}', field_id_qa_sampling_ratio='${workflow.input.field_id_qa_sample_rate}', table_id_qa_enabled='${workflow.input.table_id_qa_enabled}', table_id_qa_sampling_ratio='${workflow.input.table_id_qa_sample_rate}', transcription_qa_enabled='${workflow.input.qa}', transcription_structured_entry_qa_sample_rate='${workflow.input.structured_entry_qa_sample_rate}', transcription_structured_signature_qa_sample_rate='${workflow.input.structured_signature_qa_sample_rate}', transcription_structured_checkbox_qa_sample_rate='${workflow.input.structured_checkbox_qa_sample_rate}', transcription_semi_structured_qa_sample_rate='${workflow.input.semi_structured_qa_sample_rate}', table_cell_transcription_qa_enabled='${workflow.input.table_cell_transcription_qa_enabled}', table_cell_transcription_qa_sample_rate='${workflow.input.table_cell_transcription_qa_sample_rate}', auto_qa_sampling_rate_enabled='${workflow.input.auto_qa_sampling_rate_enabled}', exclude_auto_transcribe_fields_from_qa='${workflow.input.exclude_auto_transcribe_fields_from_qa}', payload=None)

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Submission complete block finalizes submission processing and updates reporting data.
**This block should be called at the END of every flow** that
uses blocks included in the `flows_sdk.implementations.idp_v34` library.
The block requires both the `submission` object and a `payload` to be passed in.

Mandatory parameters:

* **Parameters:**
  * **submission** (`str`) – Submission object
  * **payload** (`Any`) – Object to pass to downstream systems

Parameters with defaults:

* **Parameters:**
  * **reference_name** (`Optional`[`str`]) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **nlc_qa_sampling_ratio** (`Union`[`str`, `int`]) – Defines the percentage of documents sampled for
    Classification QA,
    defaults to workflow_input(Settings.SemiQaSampleRate)
  * **field_id_qa_enabled** (`Union`[`str`, `bool`]) – defaults to workflow_input(Settings.FieldIdQaEnabled)
  * **field_id_qa_sampling_ratio** (`Union`[`str`, `int`]) – Defines the percentage of documents sampled for
    Identification QA,
    defaults to workflow_input(Settings.FieldIdQaSampleRate)
  * **table_id_qa_enabled** (`Union`[`str`, `bool`]) – Allows users to verify the location of table cells,
    defaults to workflow_input(Settings.TableIdQaEnabled)
  * **table_id_qa_sampling_ratio** (`Union`[`str`, `int`]) – Defines the percentage of tables the
    system samples for QA,
    defaults to workflow_input(Settings.TableIdQaSampleRate)
  * **transcription_qa_enabled** (`Union`[`str`, `bool`]) – defaults to workflow_input(Settings.TranscriptionQaEnabled)
  * **transcription_qa_sampling_ratio** – Defines the percentage of fields sampled for
    Transcription QA,
    defaults to workflow_input(Settings.TranscriptionQaSampleRate)
  * **table_cell_transcription_qa_enabled** (`Union`[`str`, `bool`]) – defaults to workflow_input(Settings.TableCellTranscriptionQaEnabled)
  * **table_cell_transcription_qa_sample_rate** (`Union`[`str`, `int`]) – Defines the percentage of cells the
    system samples for QA. This value is likely to be lower than
    “Transcription QA Sample Rate” since there are more table cells than fields
    on any given page,
    defaults to workflow_input(Settings.TableCellTranscriptionQaSampleRate)
  * **exclude_auto_transcribe_fields_from_qa** (`Union`[`str`, `bool`]) – Defines fields that are marked as auto-transcribe
    in layout should be excluded from QA or not.
    defaults to workflow_input(Settings.ExcludeAutoTranscribeFieldsFromQA)
  * **is_reprocessing** (`Union`[`str`, `bool`]) – boolean to handle execution when reprocessing
    defaults to False

Example usage:

```default
submission_complete = SubmissionCompleteBlock(
    reference_name='complete_submission',
    submission=flexible_extraction.output('submission')
)
```

#### IDENTIFIER *= 'SUBMISSION_COMPLETE_4'*

### *class* flows_sdk.implementations.idp_v38.idp_blocks.SetTransformedOutputBlock(submission, transformed_output, reference_name=None)

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Set Transformed Output block sets the transformed output for the provided submission. This can
later be used to send the transformed data downstream using output blocks. For more information
see [https://docs.hyperscience.ai/#retrieving-transformed-submissions](https://docs.hyperscience.ai/#retrieving-transformed-submissions).

Mandatory parameters:

* **Parameters:**
  * **submission** (`str`) – Submission object
  * **transformed_output** (`str`) – Object that will be set as the transformed output for this submission

#### IDENTIFIER *= 'SET_TRANSFORMED_OUTPUT'*

### *class* flows_sdk.implementations.idp_v38.idp_blocks.IdpCustomSupervisionBlock(submission, task_purpose, supervision_template, reference_name=None, supervision_transcription_masking=True, task_restrictions=None, page_ids=None, notification_workflow='IDP_SUBMISSION_NOTIFY_V38', title='IDP Custom Supervision', description='IDP Custom Supervision')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

An IDP wrapper for the Custom Supervision block. It has the same functionality,
but handles reading/writing data from the IDP database.

Mandatory parameters:

* **Parameters:**
  * **submission** (`Any`) – Submission object
  * **task_purpose** (`str`) – the custom task name that’s given to all supervision tasks that run
    through a particular instance of a custom supervision block. This can be used to filter
    tasks in the task queue.
  * **supervision_template** (`Any`) – JSON used for configuration of the Custom Supervision Task.

Parameters with defaults:

* **Parameters:**
  * **reference_name** (`Optional`[`str`]) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **supervision_transcription_masking** (`bool`) – Prevents users from inputting invalid
    characters during the Custom Supervision task,
    defaults to True
  * **task_restrictions** (`Optional`[`List`[`Any`]]) – Defines what users can access Supervision tasks created
    by this block,
    defaults to []
  * **page_ids** (`Optional`[`List`[`int`]]) – This is an optional parameter. If left empty, the IDP wrapper will, by
    default, pull in all pages in the submission. Adding a list of page IDs will override
    the default list of pages.
    defaults to []
  * **notification_workflow** (`str`) – Notification flow name to run when the submission
    enters Custom Supervision (which is called within the IDP Custom Supervision block),
    defaults to DEFAULT_IDP_SUBMISSION_NOTIFY_IDENTIFIER
  * **title** (*Optional* *[**str* *]*) – UI-visible title of the block. Defaults to ‘IDP Custom Supervision’
  * **description** (*Optional* *[**str* *]*) – Description of the block. Both useful for documentation purpose and visible
    to users in the Flow studio. Defaults to ‘IDP Custom Supervision’

Example usage:

```default
idp_custom_supervision = IdpCustomSupervisionBlock(
    reference_name='idp_custom_supervision',
    submission=manual_transcription.output('submission'),
    task_purpose='make_custom_decision',
    supervision_template=[
        {
            'name': 'three_column_template',
            'version': '1.0',
            'thumbnail': {
                'group_by_document': True,
                'group_by_case': True,
            },
            'action': [
                {
                    'name': 'my_tab',
                    'display': 'SSN Info',
                    'input': [
                        {
                            'name': 'ssn_field',
                            'type': 'transcription',
                            'data_identifier': '2afd7a67-ddee-484f-ab6b-2d292752e5ee',
                            'title': 'SSN',
                        },
                    ],
                    'ui': {
                        'groups': [
                            {
                                'title': 'My Group',
                                'fields': ['ssn_field'],
                            },
                        ],
                    },
                },
            ],
        },
    ],
    supervision_transcription_masking=False,
)
```

#### IDENTIFIER *= 'IDP_CUSTOM_SUPERVISION_2'*

### *class* flows_sdk.implementations.idp_v38.idp_blocks.IDPFullPageTranscriptionBlock(submission, reference_name=None, title='Full Page Transcription (Submission)', description='Transcribes the documents included in a submission', app_metadata=None)

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

IDP Full Page Transcription Block machine-transcribes the unassigned pages in a submission

Mandatory parameters:

* **Parameters:**
  **submission** (`str`) – submission object that includes the raw documents that need to be transcribed

Optional Parameters:

* **Parameters:**
  * **reference_name** (`Optional`[`str`]) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **app_metadata** (`Optional`[`List`[`str`]]) – used for capturing information about the flow

Example usage:

```default
# This is one way to obtain the submission object (using SubmissionBootstrapBlock)
submission_bootstrap = SubmissionBootstrapBlock(reference_name='submission_bootstrap')
# IDPFullPageTranscriptionBlock transcribes the documents contained in the submission object
idp_fpt_block = IDPFullPageTranscriptionBlock(
    reference_name='idp_fpt',
    submission=submission_bootstrap.output(),
)
# reference to the output of IDPFullPageTranscriptionBlock which can be passed as input to
# the next block. For more information on output() and output references, please take a
# look at class Block and its output() method
output_ref = idp_fpt_block.output()
```

#### IDENTIFIER *= 'FULL_PAGE_TRANSCRIPTION_SUBMISSION'*

### *class* flows_sdk.implementations.idp_v38.idp_blocks.IDPImageCorrectionBlock(submission, reference_name=None, rotation_correction_enabled=True, mobile_processing_enabled=False, title='Image Correction (Submission)', description='Rotate and de-skew documents included in a submission', app_metadata=None)

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

IDP Image Correction Block rotates and de-skews tilted/skewed images so that they are more
transcription-friendly

Mandatory parameters:

* **Parameters:**
  **submission** (`str`) – submission object that includes the raw documents that need to be
  image-corrected

Optional Parameters:

* **Parameters:**
  * **reference_name** (`Optional`[`str`]) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **app_metadata** (`Optional`[`List`[`str`]]) – used for capturing information about the flow

Example usage:

```default
# This is one way to obtain the submission object (using SubmissionBootstrapBlock)
submission_bootstrap = SubmissionBootstrapBlock(reference_name='submission_bootstrap')
# IDPImageCorrectionBlock takes in the submission object and outputs in the same format with
# its images
idp_image_correct_block = IDPImageCorrectionBlock(
    reference_name='idp_image_correct',
    submission=submission_bootstrap.output(),
)
# reference to the output of IDPImageCorrectionBlock which can be passed as input to the
# next block. For more information on output() and output references, please take a look at
# class Block and its output() method
output_ref = idp_image_correct_block.output()
```

#### IDENTIFIER *= 'IMAGE_CORRECTION_SUBMISSION'*

#### Additional Blocks (v38)

### *class* flows_sdk.implementations.idp_v38.additional_blocks.JSONOutputsBlock(inputs, blocks=None)

Bases: [`Outputs`](../source-docs.md#flows_sdk.blocks.Outputs)

Output block allows users to send JSON data extracted by an IDP flow to other systems
for downstream processing
Mandatory parameters:

* **Parameters:**
  **inputs** (`Dict`[`str`, `Any`]) – Used by the UI to automatically pre-populate the input of
  newly added blocks. Extended in this class to include `'enabled': True`
  to visualize an enabled/disabled trigger that is controllable via Flow Studio.

Usage when parameters are to be defined in Flow Studio:

```default
outputs = JSONOutputBlock(
    inputs={'result': }
)
```

### *class* flows_sdk.implementations.idp_v38.additional_blocks.ImageCorrectionBlock(pages, reference_name=None, rotation_correction_enabled=True, mobile_processing_enabled=False, title='Image Correction (Pages)', description='Rotate and de-skew documents', app_metadata=None)

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Image Correction Block rotates and de-skews tilted/skewed images so that they are more
transcription-friendly
Mandatory parameters:

* **Parameters:**
  **pages** (`str`) – list of page object that includes the raw documents that need to be
  image-corrected

Optional Parameters:

* **Parameters:**
  * **reference_name** (`Optional`[`str`]) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **app_metadata** (`Optional`[`List`[`str`]]) – used for capturing information about the flow

Example usage:

```default
# This is one way to obtain the submission object (using SubmissionBootstrapBlock)
submission_bootstrap = SubmissionBootstrapBlock(reference_name='submission_bootstrap')
# ImageCorrectionBlock takes in the submission object and outputs in the same format with
# its images
image_correct_block = ImageCorrectionBlock(
    reference_name='image_correct',
    pages=submission_bootstrap.output(submission.unassigned_pages),
)
# reference to the output of IDPImageCorrectionBlock which can be passed as input to the
# next block. For more information on output() and output references, please take a look
# at class Block and its output() method
output_ref = image_correct_block.output()
```

#### IDENTIFIER *= 'IMAGE_CORRECTION_PAGES'*

### *class* flows_sdk.implementations.idp_v38.additional_blocks.FullPageTranscriptionBlock(pages, reference_name=None, title='Full Page Transcription (Pages)', description='Transcribes documents', app_metadata=None)

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Full Page Transcription Block machine-transcribes the document pages passed to it
Mandatory parameters:

* **Parameters:**
  **pages** (`str`) – list of pages that includes the raw documents that need to be transcribed

Optional Parameters:

* **Parameters:**
  * **reference_name** (`Optional`[`str`]) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **app_metadata** (`Optional`[`List`[`str`]]) – used for capturing information about the flow

Example usage:

```default
# This is one way to obtain the submission object (using SubmissionBootstrapBlock)
submission_bootstrap = SubmissionBootstrapBlock(reference_name='submission_bootstrap')
# FullPageTranscriptionBlock transcribes the documents contained in the submission object
fpt_block = FullPageTranscriptionBlock(
    reference_name='fpt',
    submission=submission_bootstrap.output(submission.unassigned_pages),
)
# reference to the output of FullPageTranscriptionBlock which can be passed as input to the
# next block. For more information on output() and output references, please take a look at
# class Block and its output() method
output_ref = fpt_block.output()
```

#### IDENTIFIER *= 'FULL_PAGE_TRANSCRIPTION_PAGES'*

### *class* flows_sdk.implementations.idp_v38.additional_blocks.CustomSupervisionBlock(submission, task_purpose, data, supervision_template, reference_name=None, supervision_transcription_masking=True, task_restrictions=None, notification_workflow='IDP_SUBMISSION_NOTIFY_V38')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

The CustomSupervisionBlock uses a JSON schema as a form builder to create customer-driven
UIs for Supervision tasks.

Mandatory parameters:

* **Parameters:**
  * **submission** (`Any`) – Submission object
  * **task_purpose** (`str`) – the custom task name that’s given to all supervision tasks that run
    through a particular instance of a custom supervision block. This can be used to filter
    tasks in the task queue.
  * **data** (`Any`) – JSON structure that supplies the data used to populated the supervision_template
  * **supervision_template** (`Any`) – JSON used for configuration of the Custom Supervision Task.

Parameters with defaults:

* **Parameters:**
  * **reference_name** (`Optional`[`str`]) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **supervision_transcription_masking** (`bool`) – Prevents users from inputting invalid
    characters during the Custom Supervision task,
    defaults to True
  * **task_restrictions** (`Optional`[`List`[`Any`]]) – Defines what users can access Supervision tasks created
    by this block,
    defaults to []
  * **notification_workflow** (`Optional`[`str`]) – Notification flow name to run when the submission
    enters Custom Supervision,
    defaults to IDP_SUBMISSION_NOTIFY_NAME
  * **title** (*Optional* *[**str* *]*) – UI-visible title of the block. Defaults to ‘IDP Custom Supervision’
  * **description** (*Optional* *[**str* *]*) – Description of the block. Both useful for documentation purpose and visible
    to users in the Flow studio. Defaults to ‘IDP Custom Supervision’

Example usage:

```default
custom_supervision = CustomSupervisionBlock(
    reference_name='custom_supervision',
    submission=manual_transcription.output('submission'),
    task_purpose='make_custom_decision',
    supervision_template=[
        {
            'name': 'three_column_template',
            'version': '1.0',
            'thumbnail': {
                'group_by_document': True,
                'group_by_case': True,
            },
            'action': [
                {
                    'name': 'my_tab',
                    'display': 'SSN Info',
                    'input': [
                        {
                            'name': 'ssn_field',
                            'type': 'transcription',
                            'data_identifier': '2afd7a67-ddee-484f-ab6b-2d292752e5ee',
                            'title': 'SSN',
                        },
                    ],
                    'ui': {
                        'groups': [
                            {
                                'title': 'My Group',
                                'fields': ['ssn_field'],
                            },
                        ],
                    },
                },
            ],
        },
    ],
    data={
        'fields': [
            {
                'id': 967,
                'uuid': 'fe8d4e7a-a82c-448c-85a1-0a3cbbe53b61',
                'value': '111-22-3333',
                'page_id': 15,
                'layout_field_id': '2afd7a67-ddee-484f-ab6b-2d292752e5ee',
                'validation_overridden': False,
                'bounding_box': [
                    0.09360783305186686,
                    0.25792617589433436,
                    0.6358913805295097,
                    0.28862414740388187,
                ],
                'occurrence_index': 1,
            },
        ],
        'template_fields': [
            {
                'uuid': '2afd7a67-ddee-484f-ab6b-2d292752e5ee',
                'notes': '',
                'type': 'entry',
                'data_type_uuid': 'b600a4e4-758f-4c4b-a2f4-cbb5dd870a0c',
                'name': 'SSN',
            },
        ],
        'pages': [
            {
                'id': 15,
                'file_page_number': 1,
                'document_page_number': 1,
                'image_url': '/image/2ed3d989-b64a-44bd-a9fb-6e0dcc5ccdb8',
                'form_id': 2,
                'submission_id': 1,
                'external_case_ids': [],
                'read_only': False,
                'filename': '1 page.pdf',
                'form_page_id': 1
            },
        ],
        'documents': [
            {
                'id': 2,
                'layout_uuid': 'e31c3cbf-dcea-44fd-a052-902463c6040f',
                'layout_name': 'layout_name',
                'page_count': 2,
                'read_only': False,
            },
        ],
        'cases': [],
        'selected_choices': [],
    },
    supervision_transcription_masking=False,
)
```

#### IDENTIFIER *= 'CUSTOM_SUPERVISION_2'*

### *class* flows_sdk.implementations.idp_v38.additional_blocks.SoapRequestBlock(method, reference_name=None, endpoint='', body_namespace=None, headers_namespace=None, headers=None, params=None, title='HTTP REST Block', description='HTTP REST block')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Soap Block allows user to perform SOAP requests
Mandatory parameters:

* **Parameters:**
  * **method** (`str`) – SOAP method to invoke
  * **endpoint** (`str`) – absolute url including schema to HTTP endpoint for this request

Optional Parameters:

* **Parameters:**
  * **reference_name** (`Optional`[`str`]) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **body_namespace** (`Optional`[`str`]) – SOAP request body namespace url
  * **headers_namespace** (`Optional`[`str`]) – SOAP request headers namespace url
  * **headers** (`Optional`[`Dict`[`Any`, `Any`]]) – SOAP headers to use
  * **params** (`Optional`[`Dict`[`Any`, `Any`]]) – key-value pair used as query parameters in the request to be
    inserted as SOAP body

Example usage:

```default
# minimum viable instantiation, the rest of the fields can later be added in the UI
soap_block = SoapRequestBlock(
    reference_name='soap_request',
    title='Soap Request',
    description='Perform soap request',
    method='ExampleMethod',
)
soap_block = SoapRequestBlock(
    reference_name='soap_request',
    title='Soap Request',
    description='Perform soap request',
    method='ExampleMethod',
    endpoint='http://example.org/abc.wso',
    body_namespace='http://www.example.org/abc.countryinfo',
    params={'example': 'stuff'},
    headers={}
)
# reference to the output of SoapRequestBlock which can be passed as input to the next block
# for more information on output() and output references, please take a look at class Block
# and its output() method
output_ref = soap_block.output()
```

#### IDENTIFIER *= 'SOAP_REQ'*

### *class* flows_sdk.implementations.idp_v38.additional_blocks.HttpRestBlock(method, endpoint, reference_name=None, headers=None, params=None, payload=None, json=None, authorization_type=None, handled_error_codes=None, auth_params=None, title='HTTP REST Block', description='HTTP REST block')

Bases: `BaseHttpRestBlock`

Http Rest Block allows user to perform HTTP requests
Mandatory parameters:

* **Parameters:**
  * **method** (`str`) – HTTP method to use
  * **endpoint** (`str`) – absolute url including schema to HTTP endpoint for this request

Optional Parameters:

* **Parameters:**
  * **reference_name** (`Optional`[`str`]) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **headers** (`Optional`[`Dict`[`str`, `str`]]) – HTTP headers to use
  * **params** (`Optional`[`Dict`[`str`, `Any`]]) – key-value pair used as query parameters in the request
  * **payload** (`Optional`[`Dict`[`str`, `str`]]) – key-value pair to be used as x-www-form-urlencoded data.
    Mutually exclusive with json
  * **json** (`Optional`[`Dict`[`str`, `Any`]]) – key-value pair to be used as json data. Mutually exclusive
    with payload
  * **authorization_type** (`Optional`[`str`]) – authorization type (none, http_header,
    oauth_2_client_credentials)
  * **handled_error_codes** (`Optional`[`List`[`Union`[`int`, `str`]]]) – specify HTTP error codes that will not fail
    the task, allowing for wildcards with the ‘x’ char. Example: [400, “5xx”]
  * **auth_params** (`Union`[`HttpHeaderAuthorizationParams`, `OAuth2AuthorizationParams`, `None`]) – authorization parameters to be passed when the authorization_type
    is set to “http_header” or “oauth_2_client_credentials”

Example usage:

```default
# minimum viable instantiation, the rest of the fields can later be added in the UI
http_rest_block = HttpRestBlock(
    reference_name='http_request',
    title='Http Request',
    description='Perform http request',
    method='GET',
)
http_rest_block = HttpRestBlock(
    reference_name='http_request',
    title='Http Request',
    description='Perform http request',
    method='GET',
    endpoint='https://sheets.googleapis.com/v4/spreadsheets/example',
)
# reference to the output of HttpRestBlock which can be passed as input to the next block
# for more information on output() and output references, please take a look at class Block
# and its output() method
output_ref = http_rest_block.output()
```

### *class* flows_sdk.implementations.idp_v38.additional_blocks.HyperscienceRestApiBlock(method, app_endpoint, reference_name=None, headers=None, params=None, payload=None, json=None, handled_error_codes=None, title='Hyperscience HTTP REST Block', description='Hyperscience HTTP REST block')

Bases: `BaseHttpRestBlock`

Make HTTP requests to the Hyperscience platform APIs.
This block will automatically take care of prepending the base url and will include
the appropriate authentication headers with the request.

Mandatory parameters:

* **Parameters:**
  * **method** (`str`) – HTTP method to use, e.g. ‘GET’, ‘POST’, etc.
  * **app_endpoint** (`str`) – relative url, beginning with a forward slash, to an HTTP endpoint
    served by the Hyperscience platform. For reference on the available endpoints, check out
    [https://docs.hyperscience.ai/](https://docs.hyperscience.ai/).
    Absolute URLs that include a hostname are allowed only if the flow has received them
    as part of the response of a previous API request that the flow has made.
    Do not hardcode the hostname of the Hyperscience instance in your flow definitions as
    they will not work when you run the flows on another instance,
    or if the hostname changes.
    For making requests to external systems, use the HttpRestBlock or a library like “requests”.

Optional Parameters:

* **Parameters:**
  * **reference_name** (`Optional`[`str`]) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **headers** (`Optional`[`Dict`[`str`, `str`]]) – HTTP headers to use
  * **params** (`Optional`[`Dict`[`str`, `Any`]]) – key-value pair used as query parameters in the request
  * **payload** (`Optional`[`Dict`[`str`, `str`]]) – key-value pair to be used as x-www-form-urlencoded data.
    Mutually exclusive with json
  * **json** (`Optional`[`Dict`[`str`, `Any`]]) – key-value pair to be used as json data. Mutually exclusive
    with payload
  * **handled_error_codes** (`Optional`[`List`[`Union`[`int`, `str`]]]) – specify HTTP error codes that will not fail
    the task, allowing for wildcards with the ‘x’ char. Example: [400, “5xx”]

Example usage:

```default
hs_rest_block = HyperscienceRestApiBlock(
    reference_name='http_request',
    app_endpoint='/api/healthcheck',
    method='GET',
)
```

### *class* flows_sdk.implementations.idp_v38.additional_blocks.DatabaseAccessBlock(reference_name=None, db_type='', database='', host='', username='', password='', query='', port=None, options=None, timeout=None, query_params=None, title='DB Block', description='DB access block')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Database Block allows user to access and perform queries on the specified database
Mandatory parameters:

* **Parameters:**
  * **db_type** (`str`) – database type (mssql, oracle, postgres)
  * **host** (`str`) – URL/IP address of the server database is hosted on
  * **database** (`str`) – database name
  * **username** (`str`) – database username
  * **password** (`str`) – database password
  * **query** (`str`) – parameterized query

Optional parameters:

* **Parameters:**
  * **reference_name** (`Optional`[`str`]) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **port** (`Optional`[`int`]) – database port number
  * **options** (`Optional`[`Dict`[`Any`, `Any`]]) – dictionary of additional connection string options
  * **query_params** (`Optional`[`Dict`[`Any`, `Any`]]) – dictionary of values for query placeholders
  * **timeout** (`Optional`[`int`]) – timeout in seconds (mssql and postgres only)

Example usage:

```default
# minimum viable instantiation, the rest of the fields can later be added in the UI
db_lookup = DatabaseAccessBlock(
    reference_name='db_lookup',
    title='Database Lookup',
    description='Perform database lookup',
)
# note that storing password in plain text form is not recommended
# password can later be entered in the UI or defined as a flow secret.
db_lookup = DatabaseAccessBlock(
    reference_name='db_lookup',
    title='Database Lookup',
    description='Perform database lookup',
    db_type='mssql',
    database='cars',
    host='example.com',
    username='user',
    # we recommend skipping the password field or defining it as a system secret
    # e.g. system_secret('{your_secret_identifier}') (both allow for secret input via. UI)
    password='pw'
    port=1433,
    timeout=200,
    query='SELECT * from CAR',
)
# reference to the output of DBAccessBlock which can be passed as input to the next block
# for more information on output() and output references, please take a look at class Block
# and its output() method
output_ref = db_lookup.output()
# content of output_ref:
{
    "result": [
        {
            "id": 1,
            "brand": "Aston Martin",
            "model": "Vanquish"
        },
        {
            "id": 2,
            "brand": "Jaguar",
            "model": "XE 2018"
        }
    ]
}
```

Database output for the same query (SELECT \* FROM CAR)

![image](media/images/db_access_query_example.png)

#### IDENTIFIER *= 'DB_ACCESS'*

### *class* flows_sdk.implementations.idp_v38.additional_blocks.LlamaBlock(model_id, prompt, reference_name=None, consent=False, tokenize_only=False, predict_extra_kwargs=None, title='Llama Text Generation', description='Text generation using the Llama 2 model')

Bases: [`Block`](../source-docs.md#flows_sdk.blocks.Block)

Text generation using the Llama 2 model by Meta.

This block utilizes Llama 2 by Meta. Llama 2 is licensed under the LLAMA 2 Community License
([https://ai.meta.com/llama/license/](https://ai.meta.com/llama/license/)). By using the Llama Block, you acknowledge that you have
received a copy of the LLAMA 2 Community License.

Note: This block is still experimental and not ready for production use.

Mandatory parameters:

* **Parameters:**
  * **model_id** (`str`) – UUID, identifier of the asset with the ML model.
    Model assets are not part of the Hypersicence bundle and must first be downloaded and
    imported into the system before they can be used. Please contact your Hyperscience
    representative to discuss the usecase and the appropriate model and to get instructions on
    downloading the models.
    Once downloaded, here are the available model asset UUIDs:
    b3da05c7-061c-4a58-af6d-4c905d2e618f - Llama 2, 13B, 8-bit quantized
  * **prompt** (`str`) – The prompt to generate text from. Use a CodeBlock ahead of the LlamaBlock in
    order to build the prompt. The context window of the model is limited to 4096 tokens.
    If the prompt has more tokens, the block would return an error. The total input and output
    length also cannot exceed 4096 tokens, which means that if the input is too long, the output
    may be truncated. Also see tokenize_only for a more detailed explanation of how to handle
    longer texts.

Optional parameters:

* **Parameters:**
  * **reference_name** (`Optional`[`str`]) – unique identifier within a flow, a unique one will be generated when
    not provided
  * **consent** (`Optional`[`bool`]) – Has the business user read and acknowledged the Llama 2 legal notice.
    Unless the flow would be used in CI automation, this should be set to False so that a
    business user can read and acknowledge the notice in the Hyperscience UI. Setting this
    to True in the Python definition of the flow is also treated as acknowledgement of the
    notice on behalf of the entity that will be using the flow.
  * **tokenize_only** (`Optional`[`bool`]) – In the context of LLMs, tokens correspond roughly to words, partial words
    and punctuation. A rough way to compute the number of tokens in a text is
    number_of_tokens = 1.25 \* number_of_words. The Llama block works with a context window
    of 4096 tokens. If a longer prompt is passed in, it would return an error. Also, if the
    prompt is shorter, but still close to 4096, the output may be truncated.
    Since the length of the prompt in tokens cannot be known ahead of time, sometimes the flow
    may need to make dynamic decisions whether to pass the text to the Llama block, or to
    split it into multiple chunks, or to use some alternative method for processing it (e.g. a
    custom supervision manual task).
    The tokenize_only option enables flows to take such dynamic decisions based on the length
    of the prompt in tokens.
    The default is false - it instructs the block to run the ML model inference over the
    prompt, i.e. to generate a text response.
    When true is passed, the model will simply tokenize the prompt without running inference
    and return the list of tokens - this will work regardless of the length of the prompt.
    A subsequent Decision task can then route longer prompts to an alternative path in the
    flow, while routing shorter prompts to the LlamaBlock for actual text generation.
  * **predict_extra_kwargs** (`Optional`[`Dict`[`Any`, `Any`]]) – Extra keyword arguments used for model inference.
    (Used to fine-tune the model prediction. Not recommended to change this unless you know
    what you are doing)

Example usage:

```default
llama = LlamaBlock(
    reference_name='llama',
    model_id='b3da05c7-061c-4a58-af6d-4c905d2e618f',
    prompt='${previous_block.output.llama_prompt}',
)
```

#### IDENTIFIER *= 'LLAMA'*

#### Trigger Blocks (v38)

#### NOTE
“Triggers” are referred to as “Input Blocks” in our [application documentation](https://help.hyperscience.ai/docs/input-blocks).

#### WARNING
Flows are built to allow full definition of triggers either in code or manually in the Flow Studio. **We recommend defining triggers manually in the Flow Studio**. Instructions on how to do so are in our [application documentation](https://help.hyperscience.ai/docs/input-blocks).

To enable trigger definition via the Flow Studio UI, you need to instantiate the `IDPTriggers()` convenience class and pass it to the `triggers` property of the `Flow`

```default
return Flow(
   ...
   triggers=IDPTriggers()
)
```

If instead you wish to define specific triggers in Python, use the trigger definitions below.

##### Folder Listener (v38)

Identifier: FOLDER_TRIGGER

Parameters:

| Name                 | Type    | Default Value   | Title                          | Description                                                                                        |
|----------------------|---------|-----------------|--------------------------------|----------------------------------------------------------------------------------------------------|
| folder               | Path    | N/A             | Folder to scan for submissions | N/A                                                                                                |
| file_extensions      | string  | N/A             | File extensions                | List of file extensions to monitor for (e.g.: ‘png, jpg, pdf’)                                     |
| has_meta             | boolean | False           | Enable metadata                | Select this if a metadata file is to be expected along with document files (in XXX_index.txt file) |
| poll_interval        | integer | 10              | Poll interval                  | Poll interval in seconds                                                                           |
| warmup_interval      | integer | 15              | Warm-up interval               | Seconds to wait past document last modified time before processing it                              |
| folder_cleanup_delay | integer | 86400           | Folder cleanup delay           | Seconds to wait before cleaning up subfolders                                                      |
| api_params           | object  | {}              | API Parameters                 | N/A                                                                                                |
```python
folder_listener = IOBlock(
    identifier='FOLDER_TRIGGER',
    reference_name='folder_trigger',
    title='Folder listener',
    enabled=True,
    input={
        'folder': '/var/www/forms/forms/folder/',
        'file_extensions': 'png, pdf, jpg',
    },
)

triggers = IDPTriggers(blocks=[folder_listener])
```

##### Email Listener (v38)

Identifier: IMAP_TRIGGER

Parameters:

| Name                     | Type    | Default Value   | Title                       | Description                                                                                                                  |
|--------------------------|---------|-----------------|-----------------------------|------------------------------------------------------------------------------------------------------------------------------|
| provider [1]             | string  | imap            | Email Provider              | N/A                                                                                                                          |
| poll_interval            | integer | 60              | Polling interval in seconds | The frequency at which the connection will monitor the email folder for submissions                                          |
| folder                   | Path    | N/A             | Folder to scan for emails   | The email folder to retrieve submissions from (e.g., “inbox”)                                                                |
| email_body_treatment     | string  | “ignore”        | Email body treatment        | What to do with the body of an email that is ingested. Available options are “process” and “ignore”.                         |
| post_process_action      | string  | “move”          | Post process action         | What to do with the email after it is processed. Available options are “move” and “delete”.                                  |
| post_process_move_folder | string  | “”              | Post process archive folder | Folder to move emails to once they are processed. It will be included only if `post_process_action` is set to “move”.        |
| api_params               | object  | {}              | API Parameters              | N/A                                                                                                                          |
| render_headers [2]       | array   | []              | Headers to include          | Headers to render at the top of the email body. Headers will be included only if `email_body_treatment` is set to “process”. |

[1] one of:

```default
imap
graph
```

[2] any of:

```default
To
From
Subject
Date
```

**Additional inputs** when `"imap"` is the selected `provider`:

| Name     | Type     | Default Value   | Title               | Description   |
|----------|----------|-----------------|---------------------|---------------|
| host     | string   | N/A             | IMAP server address | N/A           |
| port     | integer  | 993             | Port Number         | N/A           |
| ssl      | boolean  | True            | Use SSL connection  | N/A           |
| username | string   | N/A             | Username            | N/A           |
| password | Password | N/A             | Password            | N/A           |

**Additional inputs** when `"graph"` is the selected `provider`:

| Name                     | Type     | Default Value      | Title                          | Description                                                                                                          |
|--------------------------|----------|--------------------|--------------------------------|----------------------------------------------------------------------------------------------------------------------|
| client_id                | string   | N/A                | Client id                      | Application (client) ID for the corresponding application registered with the Microsoft identity platform.           |
| tenant_id                | string   | N/A                | Tenant id                      | Also called directory ID. Unique identifier of the tenant in which the corresponding application is registered with. |
| graph_cloud_endpoint [1] | string   | Global             | Microsoft Graph Cloud Endpoint | Determines base URL used for accessing cloud services through Microsoft Graph.                                       |
| azure_ad_endpoint [2]    | string   | AZURE_PUBLIC_CLOUD | Azure AD Endpoint              | Determines base URL for the Azure Active Directory (Azure AD) endpoint to acquire token for each national cloud.     |
| client_secret            | Password | N/A                | Client secret                  | Client secret for the corresponding application registered with the Microsoft identity platform.                     |

[1] one of:

```default
Global
US_GOV
US_DoD
Germany
China
```

[2] one of:

```default
AZURE_PUBLIC_CLOUD
AZURE_CHINA
AZURE_GERMANY
AZURE_GOVERNMENT
```

```python
imap_trigger = IOBlock(
    identifier='IMAP_TRIGGER',
    reference_name='imap_trigger',
    title='IMAP trigger',
    enabled=True,
    input={
        'host': 'example@mail.com',
        'folder': '/var/www/forms/forms/imap/',
        'username': 'admin',
        'password': 'pass',
    }
)

triggers = IDPTriggers(blocks=[imap_trigger])
```

##### Box Folder Listener (v38)

Identifier: BOX_FOLDER_TRIGGER

Parameters:

| Name                   | Type     | Default Value   | Title                          | Description                                                                         |
|------------------------|----------|-----------------|--------------------------------|-------------------------------------------------------------------------------------|
| source_folder_id       | string   | N/A             | Folder to scan for submissions | Use the Box Folder ID found in the URL                                              |
| target_folder_id       | string   | N/A             | Folder to move completed files | Use the Box Folder ID found in the URL                                              |
| file_extensions        | array    | []              | File extensions                | Types of file extensions for which to monitor                                       |
| custom_file_extensions | string   | N/A             | Other file extension types     | Comma separated list of file extensions for which to monitor (e.g. ‘png, jpg, pdf’) |
| poll_interval          | integer  | 10              | Polling interval (in seconds)  | How often the connector will check the base folder for submissions                  |
| warmup_interval        | integer  | 15              | Warm-up interval (in seconds)  | How long the connector will wait to process the document after it was last modified |
| public_key_id          | string   | N/A             | Public-Key ID                  | ID of the Public-key used for authentication with Box                               |
| private_key            | Password | N/A             | Private-Key                    | Private key used for authentication with Box                                        |
| passphrase             | Password | N/A             | Passphrase                     | Passphrase used for authentication with Box                                         |
| client_id              | string   | N/A             | Client ID                      | Client Id used for authentication with Box                                          |
| client_secret          | Password | N/A             | Client Secret                  | Client Secret used for authentication with Box                                      |
| enterprise_id          | string   | N/A             | Enterprise ID                  | Enterprise Id used for authentication with Box                                      |
| api_params             | object   | {}              | API Parameters                 | N/A                                                                                 |
```python
box_folder_trigger = IOBlock(
    identifier='BOX_FOLDER_TRIGGER',
    reference_name='box_folder_trigger',
    title='Box folder',
    enabled=True,
    input={
        'file_extensions': ['png', 'pdf', 'jpg'],
        'source_folder_id': '24',
        'target_folder_id': '42',
        'public_key_id': 'admin',
        'private_key': 'secret',
        'passphrase': 'password',
        'client_id': 'admin',
        'client_secret': 'secret',
        'enterprise_id': 'admin',
    }
)

triggers = IDPTriggers(blocks=[box_folder_trigger])
```

##### Cron Listener (v38)

Identifier: CRON_TRIGGER

Inputs:

| Name       | Type   | Default Value   | Title              | Description   |
|------------|--------|-----------------|--------------------|---------------|
| cron_spec  | string | `"*/5 * * * *"` | Cron specification | N/A           |
| time_zone  | string | “US/Eastern”    | Time Zone          | N/A           |
| api_params | object | {}              | API Parameters     | N/A           |
```python
cron_trigger = IOBlock(
    identifier='CRON_TRIGGER',
    reference_name='cron_trigger',
    title='Cron Trigger',
    enabled=True,
    input={
        'cron_spec': '0 10 * * *',
        'time_zone': 'Europe/Sofia',
    }
)

triggers = IDPTriggers(blocks=[cron_trigger])
```

##### Salesforce Listener (v38)

Identifier: SALESFORCE_TRIGGER

Parameters:

| Name                | Type     | Default Value   | Title               | Description                                                                                                         |
|---------------------|----------|-----------------|---------------------|---------------------------------------------------------------------------------------------------------------------|
| channel_name        | string   | N/A             | Channel Name        | Configured in the Hyperscience app in Salesforce.                                                                   |
| username            | string   | N/A             | Associated Username | Username associated with the Salesforce Connected App.                                                              |
| consumer_key        | Password | N/A             | Consumer Key        | Consumer key used for authentication with Salesforce. Paired with the Salesforce instance from which it was issued. |
| private_key         | Password | N/A             | Private Key         | Private key used for authentication with Salesforce.                                                                |
| sandbox_environment | boolean  | false           | Private Key         | Enable if the Salesforce environment is a sandbox.                                                                  |
| api_params          | object   | {}              | API Parameters      | N/A                                                                                                                 |

##### Message Queue Listener (v38)

Identifier: `MQ_LISTENER`

Inputs:

| Name          | Type     | Default Value                                             | Title                      | Description                                                                                                     |
|---------------|----------|-----------------------------------------------------------|----------------------------|-----------------------------------------------------------------------------------------------------------------|
| MQ_TYPE       | string   | “ACTIVE_MQ”                                               | Message Queue type         | Type of the message queue to connect with. Valid values are “ACTIVE_MQ”, “AMAZON_SQS”, “IBM_MQ” and “RABBIT_MQ” |
| MQ_USERNAME   | string   | null                                                      | Username/Access Key ID     | N/A                                                                                                             |
| MQ_PASSWORD   | Password | null                                                      | Password/Secret Access Key | N/A                                                                                                             |
| MQ_QUEUE_NAME | string   | null                                                      | Queue Name                 | Name of the queue (topic) to connect to.                                                                        |
| MQ_HOST       | string   | null                                                      | Host Name                  | N/A                                                                                                             |
| MQ_PORT       | integer  | 5672 when “RABBIT_MQ”, 1414 when “IBM_MQ”, otherwise null | Port Number                | N/A                                                                                                             |
| api_params    | object   | {}                                                        | API Parameters             | N/A                                                                                                             |

**Additional inputs** when `"AMAZON_SQS"` is the selected `MQ_TYPE`:

| Name                            | Type    | Default Value   | Title                                     | Description                                                                                                                  |
|---------------------------------|---------|-----------------|-------------------------------------------|------------------------------------------------------------------------------------------------------------------------------|
| MQ_REGION                       | string  | null            | AWS Region                                | N/A                                                                                                                          |
| MQ_QUEUE_URL                    | string  | null            | Queue URL                                 | N/A                                                                                                                          |
| MQ_USE_EC2_INSTANCE_CREDENTIALS | boolean | True            | Use AWS EC2 Instance IAM Role Credentials | If selected, credentials are obtained from the EC2 instance directly, and the AWS Access Key ID and Secret Key are not used. |

**NOTE**: `MQ_USERNAME` can be used to provide `Access Key ID` and `MQ_PASSWORD` to provide `Secret Access Key`.

**Additional inputs** when `"IBM_MQ"` is the selected `MQ_TYPE`:

| Name                         | Type    | Default Value   | Title                        | Description                                        |
|------------------------------|---------|-----------------|------------------------------|----------------------------------------------------|
| MQ_QUEUE_MANAGER             | string  | null            | Queue Manager (IBM MQ)       | N/A                                                |
| MQ_SSL_CIPHER_SUITE [1]      | string  | null            | SSL cipher suite             | SSL cipher suite to use if SSL connection is used. |
| MQ_CHANNEL                   | string  | null            | Channel                      | N/A                                                |
| MQ_NO_AUTH_REQUIRED          | boolean | false           | No auth credentials required | N/A                                                |
| MQ_MQCSP_AUTHENTICATION_MODE | boolean | false           | MQCSP authentication mode    | N/A                                                |

**NOTE**: `MQ_NO_AUTH_REQUIRED` is `True`, `MQ_USERNAME` and `MQ_PASSWORD` are optional.

[1] one of:

```default
"NULL_MD5"
"NULL_SHA"
"RC4_MD5_EXPORT"
"RC4_MD5_US"
"RC4_SHA_US"
"RC2_MD5_EXPORT"
"DES_SHA_EXPORT"
"RC4_56_SHA_EXPORT1024"
"DES_SHA_EXPORT1024"
"TRIPLE_DES_SHA_US"
"TLS_RSA_WITH_NULL_SHA256"
"TLS_RSA_WITH_AES_128_CBC_SHA"
"TLS_RSA_WITH_AES_128_CBC_SHA256"
"TLS_RSA_WITH_AES_256_CBC_SHA"
"TLS_RSA_WITH_AES_256_CBC_SHA256"
"AES_SHA_US"
"TLS_RSA_WITH_DES_CBC_SHA"
"TLS_RSA_WITH_3DES_EDE_CBC_SHA"
"TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256"
"FIPS_WITH_DES_CBC_SHA"
"FIPS_WITH_3DES_EDE_CBC_SHA"
```

**Additional inputs** when `"RABBIT_MQ"` is the selected `MQ_TYPE`:

| Name               | Type   | Default Value   | Title                    | Description   |
|--------------------|--------|-----------------|--------------------------|---------------|
| MQ_VIRTUAL_HOST    | string | null            | Virtual Host (RABBIT MQ) | N/A           |
| MQ_EXCHANGE        | string | “”              | Exchange                 | N/A           |
| MQ_ROUTING_KEY     | string | “”              | Routing key              | N/A           |
| MQ_CONNECTION_TYPE | string | “TCP”           | Connection Type          | “TCP or SSL”  |
```python
rabbit_mq_listener = IOBlock(
    identifier='MQ_LISTENER',
    reference_name='mq_listener',
    title='RabbitMQ Listener',
    enabled=True,
    input={
        'MQ_TYPE': 'RABBIT_MQ',
        'MQ_QUEUE_NAME': 'some_queue_name',
        'MQ_HOST': 'somehost.com',
        'MQ_USERNAME': 'foo',
        'MQ_PASSWORD': system_secret('rabbit_mq_1_password'),
    }
)

triggers = IDPTriggers(blocks=[rabbit_mq_listener])
```

##### Universal Folder Listener (v38)

Identifier: UNIVERSAL_FOLDER_TRIGGER

Inputs:

| Name                  | Type    | Default Value   | Title                                 | Description                                                                                                                                                                                                                                                           |
|-----------------------|---------|-----------------|---------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| folder                | string  | N/A             | Folder to scan for submissions        | Enter the path relative to the base folder. Leave blank to monitor the base folder                                                                                                                                                                                    |
| file_extensions       | array   | []              | File extensions                       | Types of file extensions for which to monitor                                                                                                                                                                                                                         |
| other_file_extensions | string  | N/A             | Other file extensions                 | Comma separated list of file extensions for which to monitor (e.g. ‘png, jpg, pdf’)                                                                                                                                                                                   |
| has_meta              | boolean | false           | Include submission level parameters   | Select this to ingest JSON files along with document files and submission folders. These JSON files can contain information such as metadata, cases and external_id. These JSON file names should match the related files or folders (e.g., XXX.jpg.json for XXX.jpg) |
| poll_interval         | integer | 10              | Polling interval (in seconds)         | How often the Folder Listener will check the base folder for submissions                                                                                                                                                                                              |
| warmup_interval       | integer | 15              | Warm-up interval (in seconds)         | How long the Folder Listener will wait to process the document after it was last modified                                                                                                                                                                             |
| folder_cleanup_delay  | number  | 24              | Empty folder cleanup delay (in hours) | How often the Folder Listener will remove empty folders from the base folder                                                                                                                                                                                          |
| api_params            | object  | {}              | API Parameters                        | N/A                                                                                                                                                                                                                                                                   |
```python
universal_folder_listener = IOBlock(
    identifier='UNIVERSAL_FOLDER_TRIGGER',
    reference_name='universal_folder_trigger',
    title='Universal Folder Listener',
    enabled=True,
    input={
        'folder': '/var/www/forms/forms/folder/',
        'file_extensions': 'png, pdf, jpg',
    }
)

triggers = IDPTriggers(blocks=[universal_folder_listener])
```

##### Kafka Listener (v38)

Identifier: KAFKA_TRIGGER

Inputs:

| Name                 | Type    | Default Value   | Title                | Description                                                                                                                                                                                                                                                                                                                                                                |
|----------------------|---------|-----------------|----------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| bootstrap_servers    | string  | N/A             | Bootstrap Servers    | A Comma separated list of host:port pairs to use for establishing the initial connection to the cluster                                                                                                                                                                                                                                                                    |
| group_id             | string  | N/A             | Group Id             | A unique string that identifies the consumer group this consumer belongs to. BLOCK_THREADS_KAFKA_TRIGGER should be used to scale up or down the number of consumers (default: number of available cores)                                                                                                                                                                   |
| topics               | string  | N/A             | Topics               | Comma separated list of topic names that the block will subscribe to                                                                                                                                                                                                                                                                                                       |
| consumer_config_json | json    | N/A             | Consumer Config      | JSON formatted string containing key-value pairs of Kafka consumer configurations described in the official Kafka documentation                                                                                                                                                                                                                                            |
| api_params           | object  | {}              | API Parameters       | N/A                                                                                                                                                                                                                                                                                                                                                                        |
| consume_timeout      | integer | -1              | Consume Timeout      | Maximum time, in seconds, that the consumer will wait for new messages. If messages are received within the specified time, they are processed immediately. However, if no messages are received within that specified time, consumption cycle will be restarted internally to continue fetching messages. This ensures continuous message consumption (default: infinite) |
| consume_num_messages | integer | 1               | Consume Num Messages | Sets the maximum number of messages the consumer fetches in a single consumption cycle.If the number of available messages is less than the specified, and timeout is reached, messages will be processed. Consumption cycle will be restarted after the current finishes                                                                                                  |
```python
kafka_listener = IOBlock(
    identifier='KAFKA_TRIGGER',
    reference_name='kafka_trigger',
    title='Kafka Listener',
    enabled=True,
    input={
        'folder': '/var/www/forms/forms/folder/',
        'file_extensions': 'png, pdf, jpg',
         'bootstrap_servers': 'example.com',
         'group_id': 'test_group',
         'topics': 'test_topic1, test_topic2',
         'consumer_config_json': {},
         'number_of_workers': 1,
         'consume_timeout': 5,
         'consume_num_messages': 10
    }
)

triggers = IDPTriggers(blocks=[kafka_listener])
```

#### Output Blocks (v38)

#### WARNING
Flows pass information to downstream systems using the IDPOutputsBlock. This block is specially built to allow full definition either in code or manually in the Flow Studio. **We recommend defining outputs manually in the Flow Studio**.

Instructions on how to do so are in our [application documentation](https://help.hyperscience.ai/docs/output-blocks). Simply include an IDPOutputsBlock in your Python flow definition wherever you wish to send information to downstream systems.

### *class* flows_sdk.implementations.idp_v38.idp_blocks.IDPOutputsBlock(inputs, blocks=None)

Bases: [`Outputs`](../source-docs.md#flows_sdk.blocks.Outputs)

Output block allows users to send data extracted by an IDP flow to other systems
for downstream processing

Mandatory parameters:

* **Parameters:**
  **inputs** (`Dict`[`str`, `Any`]) – Used by the UI to automatically pre-populate the input of
  newly added blocks. Extended in this class to include `'enabled': True`
  to visualize an enabled/disabled trigger that is controllable via Flow Studio.

Usage when parameters are to be defined in Flow Studio:

```default
outputs = IDPOutputBlock(
    inputs={'submission': submission_bootstrap.output('result.submission')}
)
```

If instead you wish to define specific outputs in Python, use the outputs definitions below.

##### HTTP Notifier Output (v38)

The HTTP Notifier (REST) output connection will POST results from the system to a specified HTTP endpoint.

Identifier: COB_HTTP_EXPORT

Parameters:

| Name                                 | Type          | Default Value   | Title                                   | Description                                                                                                                                                                                                                                                                                  |
|--------------------------------------|---------------|-----------------|-----------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| submission                           | Submission    | N/A             | Submission Object                       | N/A                                                                                                                                                                                                                                                                                          |
| enabled                              | boolean       | True            | Enabled                                 | Enable or disable this output block                                                                                                                                                                                                                                                          |
| api_version [1]                      | string        | N/A             | API Version                             | API version to be used for rendering payload                                                                                                                                                                                                                                                 |
| export_type                          | string        | N/A             | Export Type                             | Payload rendering choice. If “Flat” is chosen, a simplified version of the payload will be sent, as described in the “flat” parameter for submission retrieval API                                                                                                                           |
| export_routing_filter                | string        | null            | Routing Filter                          | By default, status change notifications are sent for each submission processed by the system. You can filter what notifications are received through this connection by specifying an expression like has_layout_tag(‘some_layout_tag’) or has_source_routing_tag(‘some_source_routing_tag’) |
| endpoint                             | string        | N/A             | Endpoint URL                            | URL that output notifications will be posted to                                                                                                                                                                                                                                              |
| endpoint_secrets                     | string        | N/A             | Endpoint URL secrets                    | Endpoint URL Secrets, format: (one per line) secret_key_name=secret_value                                                                                                                                                                                                                    |
| timeout                              | int           | 600             | Timeout (seconds)                       | How long (in seconds) to keep the connection open if no bytes are received from the endpoint. Set to 0 to wait indefinitely.                                                                                                                                                                 |
| authorization_type [2]               | string        | “none”          | Authorization type                      | Type of authorization                                                                                                                                                                                                                                                                        |
| authorization_header_name            | string        | null            | Authorization header name               | Authorization header name to be set in the notification request                                                                                                                                                                                                                              |
| authorization_header                 | Password      | null            | Authorization header value              | Authorization header to be set in the notification request                                                                                                                                                                                                                                   |
| auth_url                             | string        | null            | OAuth2 authorization URL                | The endpoint for the authorization server                                                                                                                                                                                                                                                    |
| client_id                            | string        | null            | Client ID                               | The client identifier issued to the client during the application registration process                                                                                                                                                                                                       |
| client_secret                        | Password      | null            | Client Secret                           | The client secret issued to the client during the application registration process                                                                                                                                                                                                           |
| scope                                | string        | null            | Scope                                   | Scope to request to oauth server                                                                                                                                                                                                                                                             |
| audience                             | string        | null            | Audience                                | Resource service URL where token will be valid                                                                                                                                                                                                                                               |
| additional_oauth_parameters          | json          | {}              | Additional Oauth Request Parameters     | Additional parameters to send when requesting token                                                                                                                                                                                                                                          |
| ssl_cert_source [3]                  | string        | null            | Source                                  | N/A                                                                                                                                                                                                                                                                                          |
| ssl_cert_path                        | string        | null            | Trusted Certificate(s) path             | Enter the path relative to the base folder                                                                                                                                                                                                                                                   |
| ssl_cert_value                       | MultilineText | null            | Trusted Certificate(s)                  | N/A                                                                                                                                                                                                                                                                                          |
| additional_notification_http_headers | json          | null            | Additional Notification Request Headers | Key value pairs in json format which will be sent via the request as http headers                                                                                                                                                                                                            |

[1] one of:

```default
"v5"
"transformed"
```

[2] one of:

```default
"none"
"http_header"
"oauth_2_client_credentials"
```

[3] one of:

```default
"env_var"
"ca_bundle_path"
"certificate_value"
```

```python
cob_http_export = IOBlock(
    identifier='COB_HTTP_EXPORT',
    reference_name='cob_http_export',
    title='HTTP Notifier Output Block',
    enabled=True,
    input={
        'submission': submission_bootstrap.output('result.submission'),
        'enabled': True,
        'api_version': 'v5',
        'export_type': 'SUBMISSION',
        'endpoint': 'example.com',
        'authorization_type': 'none',
    }
)

outputs = IDPOutputsBlock(
    inputs={'submission': submission_bootstrap.output('result.submission')},
    blocks=[cob_http_export],
)
```

##### Message Queue Notifier Output (v38)

The Message Queue Notifier Output can configure connections to ActiveMQ, Amazon SQS, IBM MQ, and RabbitMQ message queues.

Identifier: COB_MQ_NOTIFIER

Parameters:

| Name                  | Type       | Default Value                                             | Title                      | Description                                                                                                                                                                                                                                                                                  |
|-----------------------|------------|-----------------------------------------------------------|----------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| submission            | Submission | N/A                                                       | Submission Object          | N/A                                                                                                                                                                                                                                                                                          |
| enabled               | boolean    | True                                                      | Enabled                    | Enable or disable this output block                                                                                                                                                                                                                                                          |
| api_version [1]       | string     | N/A                                                       | API Version                | API version to be used for rendering payload                                                                                                                                                                                                                                                 |
| export_type           | string     | N/A                                                       | Export Type                | Payload rendering choice. If “Flat” is chosen, a simplified version of the payload will be sent, as described in the “flat” parameter for submission retrieval API                                                                                                                           |
| export_routing_filter | string     | null                                                      | Routing Filter             | By default, status change notifications are sent for each submission processed by the system. You can filter what notifications are received through this connection by specifying an expression like has_layout_tag(‘some_layout_tag’) or has_source_routing_tag(‘some_source_routing_tag’) |
| MQ_TYPE               | string     | “ACTIVE_MQ”                                               | Message Queue type         | Type of the message queue to connect with. Valid values are “ACTIVE_MQ”, “AMAZON_SQS”, “IBM_MQ” and “RABBIT_MQ”                                                                                                                                                                              |
| MQ_USERNAME           | string     | null                                                      | Username/Access Key ID     | N/A                                                                                                                                                                                                                                                                                          |
| MQ_PASSWORD           | Password   | null                                                      | Password/Secret Access Key | N/A                                                                                                                                                                                                                                                                                          |
| MQ_QUEUE_NAME         | string     | null                                                      | Queue Name                 | Name of the queue (topic) to connect to.  It applies only to “ACTIVE_MQ”, “IBM_MQ” and “RABBIT_MQ” `MQ_TYPE`s.                                                                                                                                                                               |
| MQ_HOST               | string     | null                                                      | Host Name                  | N/A                                                                                                                                                                                                                                                                                          |
| MQ_PORT               | integer    | 5672 when “RABBIT_MQ”, 1414 when “IBM_MQ”, otherwise null | Port Number                | N/A                                                                                                                                                                                                                                                                                          |

[1] one of:

```default
"v5"
"transformed"
```

**Additional inputs** when `"AMAZON_SQS"` is the selected `MQ_TYPE`:

| Name                            | Type    | Default Value   | Title                                     | Description                                                                                                                                               |
|---------------------------------|---------|-----------------|-------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------|
| MQ_REGION                       | string  | null            | AWS Region                                | N/A                                                                                                                                                       |
| MQ_QUEUE_URL                    | string  | null            | Queue URL                                 | N/A                                                                                                                                                       |
| MQ_USE_EC2_INSTANCE_CREDENTIALS | boolean | True            | Use AWS EC2 Instance IAM Role Credentials | If selected, credentials are obtained from the EC2 instance directly, and the AWS Access Key ID and Secret Key are not used.                              |
| MQ_MESSAGE_GROUP_ID             | string  | null            | Group ID for FIFO queues                  | N/A                                                                                                                                                       |
| MQ_MESSAGE_METADATA             | string  | null            | Additional SQS Metadata                   | Input additional metadata key value pairs in the format of { “key”: {“TYPE”: “String”, “VALUE”: “<value1>”}, “key2”: {“TYPE”: “Number”, “VALUE”: “12345”} |

**NOTE**: `MQ_USERNAME` can be used to provide `Access Key ID` and `MQ_PASSWORD` to provide `Secret Access Key`.

**Additional inputs** when `"IBM_MQ"` is the selected `MQ_TYPE`:

| Name                         | Type    | Default Value   | Title                  | Description                                        |
|------------------------------|---------|-----------------|------------------------|----------------------------------------------------|
| MQ_QUEUE_MANAGER             | string  | null            | Queue Manager (IBM MQ) | N/A                                                |
| MQ_SSL_CIPHER_SUITE [1]      | string  | null            | SSL cipher suite       | SSL cipher suite to use if SSL connection is used. |
| MQ_CHANNEL                   | string  | null            | Channel                | N/A                                                |
| MQ_NO_AUTH_REQUIRED          | boolean | false           | Channel                | N/A                                                |
| MQ_MQCSP_AUTHENTICATION_MODE | boolean | false           | Channel                | N/A                                                |

**NOTE**: `MQ_NO_AUTH_REQUIRED` is `True`, `MQ_USERNAME` and `MQ_PASSWORD` are optional.

[1] one of:

```default
"NULL_MD5"
"NULL_SHA"
"RC4_MD5_EXPORT"
"RC4_MD5_US"
"RC4_SHA_US"
"RC2_MD5_EXPORT"
"DES_SHA_EXPORT"
"RC4_56_SHA_EXPORT1024"
"DES_SHA_EXPORT1024"
"TRIPLE_DES_SHA_US"
"TLS_RSA_WITH_NULL_SHA256"
"TLS_RSA_WITH_AES_128_CBC_SHA"
"TLS_RSA_WITH_AES_128_CBC_SHA256"
"TLS_RSA_WITH_AES_256_CBC_SHA"
"TLS_RSA_WITH_AES_256_CBC_SHA256"
"AES_SHA_US"
"TLS_RSA_WITH_DES_CBC_SHA"
"TLS_RSA_WITH_3DES_EDE_CBC_SHA"
"TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256"
"FIPS_WITH_DES_CBC_SHA"
"FIPS_WITH_3DES_EDE_CBC_SHA"
```

**Additional inputs** when `"RABBIT_MQ"` is the selected `MQ_TYPE`:

| Name               | Type   | Default Value   | Title                    | Description   |
|--------------------|--------|-----------------|--------------------------|---------------|
| MQ_VIRTUAL_HOST    | string | null            | Virtual Host (RABBIT MQ) | N/A           |
| MQ_EXCHANGE        | string | “”              | Exchange                 | N/A           |
| MQ_ROUTING_KEY     | string | “”              | Routing key              | N/A           |
| MQ_CONNECTION_TYPE | string | “TCP”           | Connection Type          | “TCP or SSL”  |
```python
mq_notifier = IOBlock(
    identifier='COB_MQ_NOTIFIER',
    reference_name='mq_notifier',
    title='MQ Notifier Output Block',
    enabled=True,
    input={
        'submission': submission_bootstrap.output('result.submission'),
        'enabled': True,
        'api_version': 'v5',
        'export_type': 'SUBMISSION',
        'MQ_USERNAME': 'admin',
        'MQ_PASSWORD': 'pass',
        'MQ_QUEUE_NAME': 'queue',
        'MQ_HOST': 'host',
    },
)

outputs = IDPOutputsBlock(
    inputs={'submission': submission_bootstrap.output('result.submission')},
    blocks=[mq_notifier],
)
```

##### Box Notifier Output (v38)

Provides an out-of-the-box integration into Box systems.

Identifier: COB_BOX_NOTIFIER

Parameters:

| Name                              | Type       | Default Value   | Title                                 | Description                                                                                                                                                                                                                                                                                  |
|-----------------------------------|------------|-----------------|---------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| submission                        | Submission | N/A             | Submission Object                     | N/A                                                                                                                                                                                                                                                                                          |
| enabled                           | boolean    | True            | Enabled                               | Enable or disable this output block                                                                                                                                                                                                                                                          |
| api_version [1]                   | string     | N/A             | API Version                           | API version to be used for rendering payload                                                                                                                                                                                                                                                 |
| export_type                       | string     | N/A             | Export Type                           | Payload rendering choice. If “Flat” is chosen, a simplified version of the payload will be sent, as described in the “flat” parameter for submission retrieval API                                                                                                                           |
| export_routing_filter             | string     | null            | Routing Filter                        | By default, status change notifications are sent for each submission processed by the system. You can filter what notifications are received through this connection by specifying an expression like has_layout_tag(‘some_layout_tag’) or has_source_routing_tag(‘some_source_routing_tag’) |
| public_key_id                     | string     | N/A             | Public-Key ID                         | ID of the Public-key used for authentication with Box                                                                                                                                                                                                                                        |
| private_key                       | Password   | N/A             | Private-Key                           | Private key used for authentication with Box                                                                                                                                                                                                                                                 |
| passphrase                        | Password   | N/A             | Passphrase                            | Passphrase used for authentication with Box                                                                                                                                                                                                                                                  |
| client_id                         | string     | N/A             | Client ID                             | Client Id used for authentication with Box                                                                                                                                                                                                                                                   |
| client_secret                     | Password   | N/A             | Client Secret                         | Client Secret used for authentication with Box                                                                                                                                                                                                                                               |
| enterprise_id                     | string     | N/A             | Enterprise ID                         | Enterprise Id used for authentication with Box                                                                                                                                                                                                                                               |
| template_key                      | string     | “”              | Box Metadata Template Key             | Enter the key of the Box Metadata template that you would like to map the Hyperscience metadata to.                                                                                                                                                                                          |
| static_output_fields_to_map       | array      | []              | Static Metadata Fields                | Specify the Hyperscience fields you want to store in Box metadata.                                                                                                                                                                                                                           |
| submission_id                     | string     | “”              | Key for Mapping Submission ID         | Specify a Box metadata field key from your chosen Box template.  The Hyperscience field will be stored in this specified field.                                                                                                                                                              |
| document_id                       | string     | “”              | Key for Mapping Document ID           | Specify a Box metadata field key from your chosen Box template.  The Hyperscience field will be stored in this specified field.                                                                                                                                                              |
| submission_state                  | string     | “”              | Key for Mapping Submission State      | Specify a Box metadata field key from your chosen Box template.  The Hyperscience field will be stored in this specified field.                                                                                                                                                              |
| document_state                    | string     | “”              | Key for Mapping Document State        | Specify a Box metadata field key from your chosen Box template.  The Hyperscience field will be stored in this specified field.                                                                                                                                                              |
| submission_exceptions             | string     | “”              | Key for Mapping Submission Exceptions | Specify a Box metadata field key from your chosen Box template.  The Hyperscience field will be stored in this specified field.                                                                                                                                                              |
| document_exceptions               | string     | “”              | Key for Mapping Document Exceptions   | Specify a Box metadata field key from your chosen Box template.  The Hyperscience field will be stored in this specified field.                                                                                                                                                              |
| document_layout_uuid              | string     | “”              | Key for Mapping Document Layout Uuid  | Specify a Box metadata field key from your chosen Box template.  The Hyperscience field will be stored in this specified field.                                                                                                                                                              |
| document_layout_name              | string     | “”              | Key for Mapping Document Layout Name  | Specify a Box metadata field key from your chosen Box template.  The Hyperscience field will be stored in this specified field.                                                                                                                                                              |
| start_time                        | string     | “”              | Key for Mapping Start Time            | Specify a Box metadata field key from your chosen Box template.  The Hyperscience field will be stored in this specified field.                                                                                                                                                              |
| complete_time                     | string     | “”              | Key for Mapping Complete Time         | Specify a Box metadata field key from your chosen Box template.  The Hyperscience field will be stored in this specified field.                                                                                                                                                              |
| document_fields_template_mappings | json       | {}              | JSON for Additional Metadata Fields   | Specify additional metadata fields using their key value. Please consult Box Integration setup manual for JSON template and instructions.                                                                                                                                                    |

[1] one of:

```default
"v5"
"transformed"
```

```python
box_notifier = IOBlock(
    identifier='COB_BOX_NOTIFIER',
    reference_name='box_notifier',
    title='Box Notifier Output Block',
    enabled=True,
    input={
        'submission': submission_bootstrap.output('result.submission'),
        'enabled': True,
        'private_key': 'password',
        'passphrase': 'password',
        'public_key_id': 'admin',
        'client_id': 'admin',
        'client_secret': 'secret',
        'enterprise_id': 'admin',
        'template_key': 'key',
    },
)

outputs = IDPOutputsBlock(
    inputs={'submission': submission_bootstrap.output('result.submission')},
    blocks=[box_notifier],
)
```

##### UiPath Notifier Output (v38)

Provides an out-of-the-box integration into UiPath systems.

Identifier: COB_EXPORT_UIPATH

Parameters:

| Name                  | Type       | Default Value   | Title                 | Description                                                                                                                                                                                                                                                                                  |
|-----------------------|------------|-----------------|-----------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| submission            | Submission | N/A             | Submission Object     | N/A                                                                                                                                                                                                                                                                                          |
| enabled               | boolean    | True            | Enabled               | Enable or disable this output block                                                                                                                                                                                                                                                          |
| api_version [1]       | string     | N/A             | API Version           | API version to be used for rendering payload                                                                                                                                                                                                                                                 |
| export_type           | string     | N/A             | Export Type           | Payload rendering choice. If “Flat” is chosen, a simplified version of the payload will be sent, as described in the “flat” parameter for submission retrieval API                                                                                                                           |
| export_routing_filter | string     | null            | Routing Filter        | By default, status change notifications are sent for each submission processed by the system. You can filter what notifications are received through this connection by specifying an expression like has_layout_tag(‘some_layout_tag’) or has_source_routing_tag(‘some_source_routing_tag’) |
| auth_method [2]       | string     | “basic_auth”    | Authentication method | N/A                                                                                                                                                                                                                                                                                          |
| url                   | string     | N/A             | URL                   | Base URL of the uipath instance                                                                                                                                                                                                                                                              |
| app_id                | string     | N/A             | App ID                | App ID provided by UiPath                                                                                                                                                                                                                                                                    |
| app_secret            | Password   | N/A             | App Secret            | App Secret provided by UiPath                                                                                                                                                                                                                                                                |
| oauth_token_endpoint  | string     | N/A             | OAuth token endpoint  | Endpoint to retrieve the token. Using https://cloud.uipath.com/identity_/connect/token by default                                                                                                                                                                                            |
| organization_unit_id  | string     | N/A             | Organization unit id  | Organization unit id                                                                                                                                                                                                                                                                         |
| tenant                | string     | N/A             | Tenant                | Tenant                                                                                                                                                                                                                                                                                       |
| username              | string     | N/A             | Username              | Username                                                                                                                                                                                                                                                                                     |
| password              | Password   | N/A             | Password              | Password                                                                                                                                                                                                                                                                                     |
| queue                 | string     | N/A             | Queue                 | Queue                                                                                                                                                                                                                                                                                        |

[1] one of:

```default
"v5"
"transformed"
```

[2] one of:

```default
"basic_auth"
"oauth"
```

```python
cob_export_uipath = IOBlock(
    identifier='COB_EXPORT_UIPATH',
    reference_name='cob_export_uipath',
    title='CCB Export UiPath',
    enabled=True,
    input={
        'submission': submission_bootstrap.output('result.submission'),
        'enabled': True,
        'api_version': 'v5',
        'export_type': 'FLAT_SUBMISSION',
        'url': 'example.com',
        'tenant': 'tenant',
        'username': 'admin',
        'password': 'pass',
        'queue': 'queue',
    }
)

outputs = IDPOutputsBlock(
    inputs={'submission': submission_bootstrap.output('result.submission')},
    blocks=[cob_export_uipath],
)
```

##### Salesforce Notifier Output (v38)

With the Salesforce Notifier Block, you can configure your flow to send extracted information to Salesforce.
The Salesforce Notifier Block can use extracted information to look up, and then update any number of fields on a Salesforce object.
The Salesforce Notifier Block is available in both SaaS and on-premise versions of the Hyperscience application.

Identifier: COB_SALESFORCE_NOTIFIER

Parameters:

| Name                          | Type       | Default Value   | Title                               | Description                                                                                                                                                                                                                                                                                  |
|-------------------------------|------------|-----------------|-------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| submission                    | Submission | N/A             | Submission Object                   | N/A                                                                                                                                                                                                                                                                                          |
| enabled                       | boolean    | True            | Enabled                             | Enable or disable this output block                                                                                                                                                                                                                                                          |
| api_version [1]               | string     | N/A             | API Version                         | API version to be used for rendering payload                                                                                                                                                                                                                                                 |
| export_type                   | string     | N/A             | Export Type                         | Payload rendering choice. If “Flat” is chosen, a simplified version of the payload will be sent, as described in the “flat” parameter for submission retrieval API                                                                                                                           |
| export_routing_filter         | string     | null            | Routing Filter                      | By default, status change notifications are sent for each submission processed by the system. You can filter what notifications are received through this connection by specifying an expression like has_layout_tag(‘some_layout_tag’) or has_source_routing_tag(‘some_source_routing_tag’) |
| username                      | string     | N/A             | Associated Username                 | Username associated with the Salesforce Connected App                                                                                                                                                                                                                                        |
| consumer_key                  | password   | N/A             | Consumer Key                        | Consumer key used for authentication with Salesforce. Paired with the Salesforce instance from which it was issued.                                                                                                                                                                          |
| private_key                   | password   | N/A             | Private Key                         | Private key used for authentication with Salesforce.                                                                                                                                                                                                                                         |
| sandbox_environment           | boolean    | false           | Private Key                         | Enable if the Salesforce environment is a sandbox.                                                                                                                                                                                                                                           |
| object_api_name               | string     | N/A             | Object API Name                     | API name of the object in Salesforce to lookup and update.                                                                                                                                                                                                                                   |
| new_record_on_lookup_failure  | boolean    | false           | Create new record on lookup failure | When enabled, it will create a new record if the lookup fails to find a record using the lookup parameters. When disabled, lookup will fail if it does not find a record using the lookup parameters.                                                                                        |
| object_lookup_mapping         | json       | N/A             | Lookup Field Mapping                | Specify which Salesforce fields (using their API name) to be queried with which extracted values from the document for the lookup using key-value format. For example: “DOCUMENT_FIELD_NAME”: “OBJECT_FIELD_API_NAME”.                                                                       |
| document_fields_mapping       | json       | N/A             | Document Field Mappings             | Specify which Salesforce fields (using their API name) you want to update with which extracted data from Hyperscience using key-value format. For example: “DOCUMENT_FIELD_NAME”: “OBJECT_FIELD_API_NAME”.”                                                                                  |
| overwrite_existing_field_data | boolean    | false           | Overwrite existing field data       | If this is checked and a selected field has data in it, Hyperscience will overwrite that data. If this is unchecked, existing data will not be overwritten and the operation will fail.                                                                                                      |

[1] one of:

```default
"v5"
"transformed"
```

```python
cob_salesforce_notifier = IOBlock(
    identifier='COB_SALESFORCE_NOTIFIER',
    reference_name='cob_salesforce_notifier',
    title='Salesforce Notifier Output Block',
    enabled=True,
    input={
        'submission': submission_bootstrap.output('result.submission'),
        'enabled': True,
        'username': 'salesforce_user',
        'consumer_key': 'salesforce_consumer_key',
        'private_key': 'salesforce_private_key',
        'object_api_name': 'salesforce_object_api_name',
        'object_lookup_mapping': {"LAYOUT_VARIATION_XYZ_FIELD_NAME_1": "SF_FIELD_API_NAME_1", "LAYOUT_VARIATION_XYZ_FIELD_NAME_2": "SF_FIELD_API_NAME_2"},
        'document_fields_mapping': {"LAYOUT_VARIATION_XYZ_FIELD_NAME_3": "SF_FIELD_API_NAME_3", "LAYOUT_VARIATION_XYZ_FIELD_NAME_4": "SF_FIELD_API_NAME_4"}
    }
)

outputs = IDPOutputsBlock(
    inputs={'submission': submission_bootstrap.output('result.submission')},
    blocks=[cob_salesforce_notifier],
)
```

#### Helper Classes and Functions (v38)

The following classes are used to easily instantiate and manage a flow’s settings.

### flows_sdk.implementations.idp_v38.idp_values.get_idp_wf_inputs(idp_wf_config)

A helper function that maps the values provided by an `IdpWorkflowConfig` to their
corresponding IDP keys.

* **Parameters:**
  **idp_wf_config** ([`IdpWorkflowConfig`](#flows_sdk.implementations.idp_v38.idp_values.IdpWorkflowConfig)) – with static values to be filled.
* **Return type:**
  `Dict`[`str`, `Any`]
* **Returns:**
  a dictionary with filled static values, compatible with IDP flows.

Example usage with default values:

```default
flow = Flow(
    input=get_idp_wf_inputs(get_idp_wf_config()),
    ...
)
```

Example usage:

```default
Example usage when instantiating an IDP flow with custom parameters::

flow = Flow(
    input=get_idp_wf_inputs({an instance of IdpWorkflowConfig}),
    ...
)
```

### flows_sdk.implementations.idp_v38.idp_values.get_idp_wf_config()

A helper function that instantiates an `IdpWorkflowConfig` pre-filled with default values.
`IdpWorkflowConfig` is the container class for defining flow-level settings.

* **Return type:**
  [`IdpWorkflowConfig`](#flows_sdk.implementations.idp_v38.idp_values.IdpWorkflowConfig)
* **Returns:**
  a valid, fully constructed IdpWorkflowConfig instance

Example usage when instantiating an IDP flow:

```default
flow = Flow(
    input=get_idp_wf_inputs(get_idp_wf_config()),
    ...
)
```

### *class* flows_sdk.implementations.idp_v38.idp_values.IdpWorkflowConfig

Convenience dataclass outlining all flow-level config values for IDP.

### *class* flows_sdk.implementations.idp_v38.idp_values.IDPTriggers(blocks=None)

An adapter class making it easier to instantiate `flows_sdk.flows.Triggers` for
IDP flows.
In particular, provides defaults for some fields (e.g. title, description, reference_name)
and defines api_params_manifest with IDP specific parameters.

* **Parameters:**
  **blocks** (`Optional`[`Sequence`[[`IOBlock`](../source-docs.md#flows_sdk.blocks.IOBlock)]]) – [`flows_sdk.blocks.IOBlock`](../source-docs.md#flows_sdk.blocks.IOBlock) s to be included as triggers for
  an IDP Flow.
  Optional, defaults to an empty list.

Example usage when instantiating an IDP flow:

```default
folder_listener = IOBlock(...)
flow = Flow(
    triggers=IDPTriggers([folder_listener]),
    ...
)
```

### *class* flows_sdk.implementations.idp_v38.idp_values.IDPWrapperManifest(flow_identifier)

An adapter class making it easier to instantiate [`flows_sdk.flows.Manifest`](../source-docs.md#flows_sdk.flows.Manifest) for
IDP wrapper flows.
In particular, provides defaults for some fields (e.g. roles)
but more importantly, defines all [`flows_sdk.flows.Parameter`](../source-docs.md#flows_sdk.flows.Parameter) that construct the
Flow inputs and their UI representation (left-hand side menu in Flow studio).

* **Parameters:**
  **flow_identifier** (`str`) – A system-wide unique identifier for [`flows_sdk.flows.Flow`](../source-docs.md#flows_sdk.flows.Flow)

Example usage when instantiating an IDP flow:

```default
flow = Flow(
    manifest=IDPWrapperManifest(flow_identifier='FLOW_IDENTIFIER'),
    ...
)
```

### *class* flows_sdk.implementations.idp_v38.idp_values.IDPCoreManifest(flow_identifier, roles=None)

An adapter class making it easier to instantiate [`flows_sdk.flows.Manifest`](../source-docs.md#flows_sdk.flows.Manifest) for
IDP Core flows.
In particular, provides defaults for some fields (e.g. roles, output)
but more importantly, defines all [`flows_sdk.flows.Parameter`](../source-docs.md#flows_sdk.flows.Parameter) that construct the
Flow inputs and their UI representation (left-hand side menu in Flow studio).

* **Parameters:**
  * **flow_identifier** (`str`) – A system-wide unique identifier for [`flows_sdk.flows.Flow`](../source-docs.md#flows_sdk.flows.Flow)
  * **roles** (`Optional`[`List`[`str`]]) – ‘read_only’, ‘supporting’ and ‘idp_core’ are the default roles of every subflow
    that can replace the default IDP_CORE subflow inside the top-level IDP flows.
    ‘supporting’ and ‘idp_core’ are mandatory roles that are necessary for all IDP Core flows.
    ‘supporting’ ensures that the subflow will be auto-deployed together with the
    top-level IDP flow.
    ‘idp_core’ ensures that this subflow can be selected in the UI in dropdowns which allow
    picking an alternative subflow to the default IDP_CORE subflow. If you are implementing
    a subflow that is not supposed to be a drop-in replacement for IDP_CORE, you will have to
    subclass or implement your own version of IDPCoreManifest class in order
    to remove the idp_core role.

Example usage when instantiating an IDP flow:

```default
flow = Flow(
    manifest=IDPCoreManifest(flow_identifier='FLOW_IDENTIFIER'),
    ...
)
```
