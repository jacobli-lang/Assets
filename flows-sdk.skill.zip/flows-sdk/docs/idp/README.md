# IDP Library

This IDP Library (`flows_sdk.implementations`) includes the latest performant blocks and functions for building **intelligent document processing (IDP)**.

The IDP Library contains:

- Processing Blocks, which are provided as convenient Python subclasses for plug-and-play use.
- Trigger and Output Blocks, which require use of [base classes](../source-docs.md#flows_sdk.blocks.IOBlock).
- Helper functions for ease of development.

<!-- Comment: need to add simple subclasses of Trigger and Output blocks -->

#### NOTE
Most solutions will also require use of base classes, such as Flow or CodeBlock, found in the [Source Documentation](../source-docs.md#source-documentation).



## Per-version files

Pick the file matching the target platform version (`flows_sdk.implementations.idp_vXX`).

- [V44](idp_v44.md)
- [V43](idp_v43.md)
- [V42](idp_v42.md)
- [V41](idp_v41.md)
- [V40](idp_v40.md)
- [V39.1](idp_v39_1.md)
- [V39](idp_v39.md)
- [V38](idp_v38.md)
- [V37](idp_v37.md)
- [V36](idp_v36.md)
- [V35](idp_v35.md)
- [V34](idp_v34.md)
