<a id="testing-flows"></a>

# Testing Flows

A flow is code, and like any code it deserves a fast, reliable test suite. The Flows SDK
ships a complete testing toolkit under `flows_sdk.testing` that lets you test every layer
of a flow **locally** for the fast tiers, against a **live instance with synthetic data** for
the flow’s end-to-end behaviour, and **inside the customer’s instance** for the few questions
only customer data can answer.

That split turns on one question: *whose data does the test use?* Synthetic data — documents
and records made up for the purpose — belongs to you. It can live in git beside the tests, be
sent to any instance, and be asserted on value by value, so a test using it is an ordinary
pytest test with no restrictions at all. A customer’s data carries PII, so a test cannot pull it
to a developer’s machine or into a CI log; those tests are themselves flows, deployed to the
customer’s instance, that assert there and report back only pass or fail.

Most of what a flow does can be tested with synthetic data, so most live tests should use it. Keep
customer data for what genuinely needs it — evaluation, such as whether extraction stays accurate
on the documents a customer actually receives.

This guide follows the **testing pyramid**: many fast, deterministic tests at the bottom and
a few high-fidelity tests at the top.


```mermaid
flowchart TD
    I["<b>In-flow</b> — customer data<br/>Is it accurate on what the customer sends?"]
    E["<b>End-to-end</b> — synthetic data<br/>Does the flow behave on the real platform?"]
    F["<b>Flow graph</b><br/>Do the blocks hand off the right data?"]
    C["<b>Contract</b><br/>Did anything a caller depends on change?"]
    W["<b>Wiring</b><br/>Does every reference point at something real?"]
    U["<b>Unit</b><br/>Does one function return the right answer?"]
    I --> E --> F --> C --> W --> U

    classDef customer fill:#fee2e2,stroke:#dc2626,color:#7f1d1d,font-size:15px
    classDef live fill:#fef3c7,stroke:#d97706,color:#78350f,font-size:15px
    classDef offline fill:#dbeafe,stroke:#2563eb,color:#1e3a8a,font-size:15px
    classDef fast fill:#dcfce7,stroke:#16a34a,color:#14532d,font-size:15px
    class I customer
    class E live
    class F offline
    class C,W,U fast
```

The top two tiers need a live instance. The end-to-end tier runs against a development instance
from your CI pipeline; the in-flow tier runs on the customer’s. Everything below them runs on your
machine and in CI.

#### IMPORTANT
Some things are testable **only** on a live instance, and no amount of offline testing substitutes
for them:

* **The platform’s own behaviour.** Its validation rules, its sandbox — where a custom code block
  runs with its own installed package set, so an import that resolves locally can be missing
  there — and how settings actually reach the flows that read them. The end-to-end tier covers
  all of this with synthetic data.
* **Extraction accuracy on customer documents.** Offline the IDP blocks are stubbed, so
  transcriptions are whatever the stub says; in the end-to-end tier the document is synthetic.
  Whether extraction holds up on what a customer actually sends is measured only by the in-flow
  tier, where those documents live.

<a id="installing-test-tooling"></a>

## Installing the test tooling

There are two things you can install:

```bash
pip install flows_sdk              # authoring flows
pip install flows_sdk[testing]     # authoring flows and testing them
```

Install the `testing` extra in any repository that has a test suite. Plain `flows_sdk` is for a
process that only builds and uploads flows.

The framework’s pytest plugin makes each in-flow suite entry a pytest test and adds the
`--merge-test-flows` and `--force-test-flows` options. Installing the SDK does not load it: enable
it in the project’s `pyproject.toml`, which `hs-flows init` does for you:

```toml
[tool.pytest.ini_options]
addopts = "-p flows_sdk.testing.plugin"
```

<a id="marking-tiers"></a>

## Marking tests with their tier

Each tier on this page has a matching pytest marker, and we recommend marking every test with
the one it belongs to — `unit`, `flow`, `contract`, `e2e`, `in_flow`. They are
ordinary pytest markers: nothing applies them for you, and nothing requires them. A marker is
what lets you run one tier on its own, and lets CI run the fast tiers on every push and the live
ones where they belong.

Mark a whole module at once with `pytestmark`:

```python
# flows/<name>/tests/contract/test_contract.py
import pytest

pytestmark = pytest.mark.contract
```

A live test usually needs to skip where no instance is configured, so combine the two:

```python
import pytest
from flows_sdk.testing.harness import requires_instance

pytestmark = [pytest.mark.e2e, requires_instance()]
```

Declare the markers in your project’s `pyproject.toml`, which is where `hs-flows init` puts them
— that lists them under `pytest --markers` and keeps `--strict-markers` happy. They are yours to
extend, rename or drop:

```toml
[tool.pytest.ini_options]
markers = [
    "unit: functions called directly, the platform mocked",
    "flow: the whole graph offline, FlowTestRunner",
    "contract: flow wiring, interface and contract snapshots",
    "e2e: a live instance with synthetic data from this repository",
    "in_flow: customer data, executed as flows inside the customer's instance",
]
```

Then select with `-m`:

```bash
pytest -m contract                  # one tier
pytest -m "not e2e and not in_flow" # everything that runs offline
pytest -m e2e                       # the synthetic live tier, against a development instance
```

Run the offline tiers **by exclusion**, as above, so a test someone forgot to mark still runs.

Organise the files however suits the project. The showcase and the scaffold keep one directory
per tier beside each flow (`flows/<name>/tests/unit/`, `…/contract/`, …), but pytest selects on the
marker, not the directory.

## The example flows

Throughout this guide we use the **testing showcase**, a project you can run. It starts from
the IDP starter flow that ships with the SDK — out-of-the-box document processing: collate,
classify, identify, transcribe — and adds custom logic on top of it.

What it adds, and what the tests are about:

- It reads a **Form W-9** and normalises the taxpayer identification number it finds.
- It decides whether the document can be **released automatically or needs human review**,
  using a list of exempt payee codes it pages out of a knowledge store.
- It validates the identification numbers in a **separate flow**, called as a subflow.

The SDK ships the material this needs: a Form W-9 layout release and a sample W-9 document.
Because the sample contains no real person’s data, the same document is safe both for a live
run and as an offline fixture — which is unusual, and the reason this is the example.

A correct run of that document classifies it as a W-9, transcribes a well-formed TIN and an
exempt code the knowledge store lists, and releases it without review. Each tier below checks
a different part of that sentence.

It is three flows, and knowing which is which decides what each test can stub:


```mermaid
flowchart TD
    subgraph WRAPPER["document_processing"]
        direction LR
        CORE["IDPCoreBlock<br/><i>calls idp_core</i>"] --> OUT["IDPOutputsBlock<br/><i>emits the submission</i>"]
    end

    subgraph CORESUB["idp_core"]
        direction TB
        P["IDP platform blocks<br/>file_filter → … → document_rendering<br/><i>stubbed offline</i>"]
        P --> L["load_exempt_payee_codes<br/><i>reads a knowledge store</i>"]
        L --> R["route_for_review<br/><i>decides, and says why</i>"]
        R --> D{"review_decision<br/><i>Routing</i>"}
        D -->|release| V["validate_tins<br/><i>calls tin_validation</i>"] --> M["mark_released"]
        D -->|default| H["mark_held"]
        M --> Z["complete_submission"]
        H --> Z
    end

    CORE -.-> CORESUB
```

The custom blocks are **inside `idp_core`**, not between the core and the outputs block. That
is the normal shape for IDP work: the core is the flow you customise, and the wrapper exists to
call it. It follows that:

- **`document_processing` has almost nothing to test offline.** Two blocks, both platform
  blocks. Its worthwhile tiers are contract (does its interface still hold) and the live tiers:
  end-to-end for its behaviour, in-flow for accuracy.
- **`idp_core` is what the flow-graph tier runs.** You stub the standard IDP blocks —
  classification, identification, transcription are the platform’s code and their accuracy can
  only be judged against real models — and let this project’s own blocks run for real.
- Stubbing the core wholesale from the wrapper and then asserting on `route_for_review` is
  incoherent: the block lives in the thing you just replaced with a dict.

The blocks worth knowing by name, all in `idp_core`:

- `load_exempt_payee_codes` is a **custom code block that calls the platform**, paging through a
  knowledge store. It is the block that needs `ScriptedHsBlockInstance` rather than the default
  mock.
- `route_for_review` is a **custom code block** producing a decision *and its reasons*, which is what makes a
  routing block testable and readable when it does the wrong thing.
- `validate_tins` is a **subflow call**, so the same rig can exercise a hierarchy of flows —
  either stubbed or executed inline through a nested runner.
- `review_decision` is a **Routing** block; both of its branches need a test, or half the flow is
  untested.

Each flow lives in its own package with its logic and tests beside it:

```default
showcase/flows/
├── document_processing/
│   ├── flow.py          # entry_point_workflow() — the wrapper
│   └── tests/{contract,e2e,in_flow,data}/
├── idp_core/
│   ├── flow.py          # entry_point_workflow() — the core, with the custom logic
│   ├── functions.py     # normalise_tin, classify_tax_entity, route_for_review, …
│   └── tests/{unit,flow,contract}/
└── tin_validation/
    ├── flow.py          # tin_validation_subflow()
    ├── functions.py     # validate_tin_digits, summarise_validation
    └── tests/{unit,contract}/
```

The custom code lives in `functions.py`, not inline in `flow.py`, so a unit test can import and
call it. A function defined inside the flow definition has no importable name, and only a whole
flow run reaches it. Define custom code block functions at module level and reference them from
the flow.

The exception is **lambdas**. A lambda is cheaper for the platform to run than a full function
block, so it is the right choice for small data transformations — reshaping a dict, picking a
field. Keep them to expressions with no branching: anything with a decision in it is logic,
and logic wants a name and a unit test.

#### NOTE
The complete, runnable project — flow, functions, and a test file for every
layer below — is available as a downloadable example at the end of this
guide.

<a id="unit-tests"></a>

## Unit tests: functions

The bottom of the pyramid: a function your flow runs, called directly — no flow, no runner.
Anything a custom code block does belongs in a plain function you can call this way.
Transformation is the obvious case, but so are validation rules, classification decisions,
threshold comparisons, formatting and parsing.

```python
import pytest
from showcase.flows.idp_core.functions import classify_tax_entity, normalise_tin


@pytest.mark.parametrize(('raw', 'digits'), [
    ('202-26-7197', '202267197'),
    ('202 26 7197', '202267197'),
    ('  202-26-7197  ', '202267197'),
])
def test_separators_are_stripped(raw, digits):
    assert normalise_tin(raw)['digits'] == digits


def test_an_ssn_is_recognised_by_its_grouping():
    assert normalise_tin('202-26-7197')['looks_like'] == 'ssn'
    assert normalise_tin('12-0719651')['looks_like'] == 'ein'
    # An SSN and an EIN are both nine digits, so an unseparated number is not guessed at.
    assert normalise_tin('202267197')['looks_like'] == 'unknown'


def test_several_checked_boxes_are_ambiguous_not_resolved_to_the_first():
    document = {'document_fields': [
        {'field_name': 'Tax Classification - LLC', 'transcription': 'X'},
        {'field_name': 'Tax Classification - Trust', 'transcription': 'X'},
    ]}
    result = classify_tax_entity(document)
    assert result['classification'] == 'unknown'
    assert sorted(result['checked']) == ['LLC', 'Trust']
```

Note what the unit tier is *good* at: edge cases. Three separator formats and two conflicting
checkboxes are cheap here and expensive anywhere else.

<a id="unit-testing-ccbs"></a>

### Functions that call the platform

A custom code block’s function receives the platform runtime as `_hs_block_instance` — to log,
store a blob, call the API. That is still a unit test: call the function directly and pass one of
the SDK’s mock objects in its place, then assert on what it did with it.

```python
from flows_sdk.mocks import MockHsBlockInstance
from showcase.flows.idp_core.functions import route_for_review

# a W-9 as the transcription blocks leave it — the TIN has eight digits, one short
_SUBMISSION = {
    'documents': [
        {
            'id': 1,
            'document_fields': [
                {'field_name': 'Social Security Number', 'transcription': '12345678'},
                {'field_name': 'Tax Classification - Individual', 'transcription': 'Yes'},
            ],
        }
    ]
}


def test_a_short_tin_is_routed_to_review():
    mock = MockHsBlockInstance()
    out = route_for_review(
        submission=_SUBMISSION,
        require_valid_tin=True,
        valid_exempt_codes=[],
        _hs_block_instance=mock,
    )
    assert out['decision'] == 'review'
    assert out['reasons'] == ['document 1: TIN has 8 digits, expected 9']
    # assert on the platform interaction — the structured log line
    assert 'routing 1 document(s) to review' in mock.log_data[0]
```

A direct call gives a normal traceback and lets your editor jump to the function, so test every
function you can import this way, platform or not.

### Mock objects

The mocks live in `flows_sdk.mocks`. All stored data — blobs, logs, measurements — is kept in
memory so you can inspect and assert against it.

**`MockHsBlockInstance`** simulates the runtime and implements:

- **Blob storage**: `store_blob()`, `store_blobs()`, `fetch_blob()`
- **Logging**: `log()`
- **HTTP requests**: `hs_request()`, `hs_get()`, `hs_post()`
- **Measurements**: `publish_measurements()`

#### NOTE
This class is *versioned* — use the version matching the Python version of
the block you are testing. The default `MockHsBlockInstance` is the
latest.

| Mock class              | Corresponding Python versions   |
|-------------------------|---------------------------------|
| `MockHsBlockInstanceV1` | PYTHON_3_12 and earlier         |
| `MockHsBlockInstanceV2` | PYTHON_3_13 and later           |

**`MockHsTask`** simulates task metadata: `task_id`, `flow_run_id`,
`correlation_id`, `task_name`, `reference_name`.

### Custom code blocks backed by modules

Custom code blocks can be backed by an entire module rather than a single function, letting you
organize logic into classes and helpers and test each piece independently. Pass
`include_module=True` to serialize the whole module.

#### CAUTION
When using `include_module=True` you need to make sure that the module
imports everything it needs to run. Boilerplate imports will NOT be
automatically included the way they are when the code is only a function.

```python
# report_module.py
from flows_sdk.types import HsBlockInstance, HsTask, StoreBlobRequest


class ReportGenerator:
    """Business logic that depends on the platform."""

    def __init__(self, hs_block_instance: HsBlockInstance):
        self.hs_block_instance = hs_block_instance

    def generate_report(self, data: dict) -> str:
        self.hs_block_instance.log('Generating report')
        blob = self.hs_block_instance.store_blob(
            StoreBlobRequest(name='report.txt', content=f'Report: {data}'.encode())
        )
        return blob.uuid


def store_expense_report(
    data: dict, _hs_block_instance: HsBlockInstance, _hs_task: HsTask
) -> dict:
    """The function wired as the block's `code` — name it after what it does."""
    generator = ReportGenerator(_hs_block_instance)
    return {'blob_uuid': generator.generate_report(data), 'correlation_id': _hs_task.correlation_id}
```

The function passed as `code` is found by reference, not by name, so call it
whatever describes its job — there is no required entry-point name.

Test it with the mock objects:

```python
from flows_sdk.mocks import MockHsBlockInstance, MockHsTask
from report_module import ReportGenerator, store_expense_report


def test_generate_report():
    mock_block = MockHsBlockInstance()
    blob_uuid = ReportGenerator(mock_block).generate_report({'key': 'value'})

    # blob was stored, with the expected content
    assert mock_block.blobs[blob_uuid] == b"Report: {'key': 'value'}"
    # and the operation was logged
    assert 'Generating report' in mock_block.log_data[0]


def test_store_expense_report_passes_correlation_id():
    result = store_expense_report(
        data={'key': 'value'},
        _hs_block_instance=MockHsBlockInstance(),
        _hs_task=MockHsTask(correlation_id='test-123'),
    )
    assert result['correlation_id'] == 'test-123'
```

### Custom code blocks that import custom Python packages

A code block may import a package the customer uploaded to the instance and made available to its
code blocks. Those packages are **not** in the container’s base package set and are not on a
developer’s machine either, so a unit test importing one fails locally for a reason unrelated to
the code being tested.

#### IMPORTANT
**Run the unit tier in an environment that installs the same third-party packages the instance
provides.** Keep a requirements file beside the flow, apply it in CI and locally, and
the two stay in step.

The offline tiers cannot tell you whether an import will work on the platform: offline your code
runs in **your** virtual environment, and on the platform in a **container with its own installed
package set**. Whether an import resolves on the instance is established by the end-to-end tier.

### Testing HTTP requests

When a custom code block calls the Hyperscience API, configure the mock’s response. Because the
mock methods conform to the `unittest.mock` interface you can also assert on how
they were called.

```python
from unittest.mock import Mock
from flows_sdk.mocks import MockHsBlockInstance
from flows_sdk.types import HsBlockInstance


def fetch_submission(submission_id: str, _hs_block_instance: HsBlockInstance) -> dict:
    response = _hs_block_instance.hs_get(f'/api/v5/submissions/{submission_id}')
    if response.status_code == 200:
        return response.json()
    raise Exception(f'Failed to fetch submission: {response.status_code}')


def test_successful_fetch():
    mock_block = MockHsBlockInstance()
    mock_response = Mock(status_code=200)
    mock_response.json.return_value = {'id': '123', 'status': 'complete'}
    mock_block.hs_request.return_value = mock_response

    result = fetch_submission('123', mock_block)

    assert result['status'] == 'complete'
    mock_block.hs_request.assert_called_once_with('GET', '/api/v5/submissions/123')
```

<a id="third-party-calls"></a>

### Calls to third-party services

A test must not reach a real external service: it would be slow, flaky, and could change data you
do not own. Replace the call with pytest’s `monkeypatch`. Take a code block that reads a rate from
an external HTTP API:

```python
# my_flows/invoice/functions.py
def fetch_exchange_rate(currency: str) -> dict:
    import requests  # inside the function: only the function's own source ships to the platform

    response = requests.get(
        'https://rates.example.com/latest', params={'base': currency}, timeout=10
    )
    response.raise_for_status()
    return {'rate': response.json()['rate']}
```

Patch `requests.get` for the duration of the test, and assert on how it was called:

```python
from unittest.mock import Mock

import requests

from my_flows.invoice.functions import fetch_exchange_rate


def test_the_rate_is_read_from_the_service(monkeypatch):
    response = Mock(status_code=200)
    response.json.return_value = {'rate': 1.08}
    get = Mock(return_value=response)
    monkeypatch.setattr(requests, 'get', get)

    assert fetch_exchange_rate('EUR') == {'rate': 1.08}
    get.assert_called_once_with(
        'https://rates.example.com/latest', params={'base': 'EUR'}, timeout=10
    )
```

The same patch works in the [flow-graph tier](#flow-graph-tests): `FlowTestRunner` runs the
block’s code in the test’s own process, so the code runs for real and only the call is replaced:

```python
from unittest.mock import Mock

import requests
from flows_sdk.blocks import PythonBlock
from flows_sdk.flows import Flow, Manifest
from flows_sdk.testing.flow_test_runner import FlowTestRunner

from my_flows.invoice.functions import fetch_exchange_rate


def test_the_flow_reads_the_rate(monkeypatch):
    response = Mock(status_code=200)
    response.json.return_value = {'rate': 1.08}
    monkeypatch.setattr(requests, 'get', Mock(return_value=response))

    flow = Flow(
        title='Rates',
        owner_email='flows@example.com',
        manifest=Manifest(identifier='RATES', input=[]),
        blocks=[
            PythonBlock(
                reference_name='rate', code=fetch_exchange_rate, code_input={'currency': 'EUR'}
            )
        ],
    )
    runner = FlowTestRunner(flow=flow)
    runner.run()
    assert runner.ccb_result('rate') == {'rate': 1.08}
```

Patch the attribute the code looks up when it runs, `requests.get`, as here. A name a module
imported at its top with `from requests import get` keeps the original. A platform block that
calls an external service, such as `HTTP_REST`, is not your code: [emulate it](#block-emulators)
instead.

### Block code with no importable name

A unit test normally imports the function it tests. **A custom code block whose function has no
importable name** — defined inside the flow builder, or passed as a lambda — has nothing to
import, so reach it through the flow instead: `invoke_block` finds the block in the built flow by
its `reference_name` and calls its code, injecting the platform mocks.

```python
from flows_sdk.testing.flow_test_runner import invoke_block
from my_flows.invoice.flow import entry_point_workflow

def test_inline_ccb():
    # `normalize` is defined inside entry_point_workflow(), so there is nothing
    # to import — invoke_block is the only way to reach it.
    assert invoke_block(entry_point_workflow(), 'normalize', {'value': 5}) == {'doubled': 10}
```

#### NOTE
`invoke_block` couples the test to the block’s `reference_name`, so renaming the
block breaks the test even when the function is untouched. For an importable function
that is churn with no benefit — import and call the function instead, and keep
`invoke_block` for the code nothing can import.

<a id="wiring-tests"></a>

## Wiring tests: validate references without stubs

Every `${...}` reference is checked against what declares it — no stubs, no execution, no
instance.

Get it by inheriting `FlowStaticChecksSuite`. Every check it runs is static — nothing executes the
flow — so it is cheap enough to put on every flow you own.

```python
from pathlib import Path

from flows_sdk.testing.suites import FlowStaticChecksSuite
from showcase.flows.idp_core.flow import entry_point_workflow


class TestIdpCoreContract(FlowStaticChecksSuite):
    flow = entry_point_workflow    # the builder, not called
    snapshot_path = Path(__file__).parent / 'snapshots' / 'idp_core.json'
```

Inheriting the class runs the checks: `test_flow_wiring`, `test_flow_interface`,
`test_flow_python_version` and `test_contract_snapshot`. Each builds the flow once and asserts on
the whole report, so a flow with several problems reports all of them in one failure.

`test_flow_python_version` requires every `PythonBlock` in the flow, nested ones included, to run
on the same Python version. A block’s version comes from its `python_version` argument, the
`HS_PYTHON_CODE_BLOCK_PYTHON_VERSION` environment variable, or the environment the flow is built
in; the failure lists each version with the blocks that use it.

`test_flow_interface` holds a flow to the interface it declares, three ways: an output the mapping
returns but the manifest omits (`undeclared-output`), one the manifest declares but nothing fills
(`unmapped-output`), and an **input nothing reads** (`unused-input`). The last is a setting an
operator can change to no effect — the classic case is a wrapper that declares a setting and never
passes it to the subflow that needs it, since a subflow does not inherit its caller’s inputs. An
input counts as read when something in the flow references it by name, at a position the engine
resolves: a block’s input or the output mapping. A `${workflow.input.x}` inside a code block’s
source does not count, since the engine leaves the code as it is. The platform settings the
SDK’s own IDP definitions declare are exempt, because platform services read those from the flow’s
configuration.

If an input of yours genuinely reaches its reader by a route no reference names, which should be
rare, exempt it by name:

```python
from pathlib import Path

from flows_sdk.testing.suites import FlowStaticChecksSuite
from showcase.flows.idp_core.flow import entry_point_workflow


class TestIdpCoreContract(FlowStaticChecksSuite):
    flow = entry_point_workflow
    snapshot_path = Path(__file__).parent / 'snapshots' / 'idp_core.json'
    tolerated_unused_inputs = frozenset({'legacy_threshold'})
```

One flow per suite. A repository with several flows writes a class per flow, beside that flow’s
own code, next to its golden and its other tiers:

```python
class TestCoreContract(FlowStaticChecksSuite):
    flow = core_workflow
    snapshot_path = SNAPSHOTS / 'core.json'


class TestUsMainContract(FlowStaticChecksSuite):
    flow = us_main_workflow
    snapshot_path = SNAPSHOTS / 'us_main.json'
```

Either way the whole repository’s wiring is checked by `pytest -m contract`, so CI needs no
separate command:

```bash
pytest -m contract
```

It reports:

- **unknown blocks** — `${no_such_block.output.x}`. The triggers section counts as a block named
  after its `reference_name`, so `${triggers.output...}` in a flow without one is unknown too
- **forward references** — a block consuming one declared later, which fails at run time
  because the producer has not completed
- **undeclared workflow inputs** — `${workflow.input.foo}` where the manifest declares no `foo`
- **unknown system references** — a `${workflow.…}` path the engine does not provide, such as
  the easy typo `${workflow.inputs.foo}`, a bare `${workflow}`, or a `${system.…}` the platform
  does not rewrite into a setting or a secret, such as `${system.setting.x}` or
  `${system.settings.my-key}`
- **block references without `input` or `output`** — `${boot.submission}` where
  `${boot.output.submission}` was meant, which the engine refuses on every run
- **two references in one value** — `'${a.output.x}-${b.output.y}'`; the engine resolves one
  reference per value, so it reads that as a single one spanning both, which resolves to nothing
- **references into a sibling `Fork` or `Routing` branch** — `Fork` branches run in parallel,
  so nothing guarantees the other branch’s block has completed when the reader starts; read it
  after the `Fork` instead. Only one `Routing` branch runs, so a block in another branch never
  has; put both blocks in one branch
- **loop variables used wrongly** — inside a `Foreach` template, anything but
  `${<foreach>.item...}` or `${<foreach>.index}`, which resolves to nothing; outside it, a loop
  variable at all
- **`code_input` keys the function does not accept**
- **subflow calls missing a required input**, and a declared subflow the flow never calls — when
  the suite declares the subflows the flow calls (see below)
- **references into fields a block cannot emit** — where the producing block has a registered
  contract
- **blocks invoked without a required input** — likewise, where a contract declares one

A reference to a **`Foreach`-generated block** — `${identify_0.output.result}` — is reported as
an unknown block, because those names exist only at run time. Read the `Foreach`’s own output
instead, which holds every iteration’s result. If a flow genuinely needs one, `validate_flow_wiring`
returns the report rather than raising, so a test can filter that issue and assert on the rest.

To check a **subflow call site** — that the caller passes every input the subflow requires —
declare the subflows the flow calls, by their builders:

```python
from pathlib import Path

from flows_sdk.testing.suites import FlowStaticChecksSuite
from showcase.flows.idp_core.flow import entry_point_workflow
from showcase.flows.tin_validation.flow import tin_validation_subflow


class TestIdpCoreContract(FlowStaticChecksSuite):
    flow = entry_point_workflow
    snapshot_path = Path(__file__).parent / 'snapshots' / 'idp_core.json'
    subflows = (tin_validation_subflow,)
```

`test_flow_wiring` then checks every block that calls one of them, and fails if a declared
subflow is not called at all — so a wrapper pointed at the SDK’s default IDP core instead of
yours fails here, rather than deploying and silently skipping your blocks. Each subflow’s own
wiring is checked by its own suite.

### When a check reports something you cannot fix

Two situations have a declared waiver, so a project never overrides an inherited test — an
override silences everything else that test would catch.

**A reference the flow cannot fix.** On `idp_v41` and `idp_v42`, every flow reads
`${workflow.input.submission}`, which the platform injects but only `idp_v43` declares, and
the SDK’s own `MachineTranscriptionBlock` still reads a deprecated input. Both are reported as
`undeclared-input` against a flow whose author can do nothing about either:

```python
class TestCoreContract(FlowStaticChecksSuite):
    flow = entry_point_workflow
    snapshot_path = SNAPSHOTS / 'core.json'
    tolerated_references = frozenset({
        'workflow.input.submission',
        'workflow.input.column_transcription_target_accuracies',
    })
```

**A stock IDP wrapper.** One built from `IDPWrapperManifest` maps `submission` without the
manifest declaring it, which `test_flow_interface` reports as `undeclared-output`:

```python
class TestWrapperContract(FlowStaticChecksSuite):
    flow = entry_point_workflow
    snapshot_path = SNAPSHOTS / 'wrapper.json'
    tolerated_interface_issues = frozenset({'undeclared-output'})
```

Both waive exactly what they name and nothing else. Prefer fixing the flow; reach for these
when the thing reporting is not yours to fix.

<a id="block-contracts"></a>

### Block contracts

A block contract declares what a block takes and what it emits. It is what lets the wiring check
reject a reference into a field a block cannot produce, and flag a block invoked without a
required input — both fall out of the contract tier once a contract exists.

`flows_sdk.testing.contracts` is a **registry**, not a table of blocks. Whoever owns a block
registers its contract, in the same vocabulary the block’s own `Manifest` uses:

```python
from flows_sdk.flows import Parameter
from flows_sdk.testing.contracts import register_block_contract, register_contract_type

register_contract_type('Submission', Submission)
register_block_contract(
    'SUBMISSION_BOOTSTRAP_3',
    inputs=[Parameter(name='layout_release_uuid', type='UUID')],
    outputs=[Parameter(name='submission', type='Submission')],
)
```

An output whose `type` names a registered type has the paths beneath it validated; any other
type is an open shape. If the block already has a `Manifest`, register that directly instead of
transcribing it — the version that cannot drift from what it describes:

```python
from flows_sdk.testing.contracts import register_block_contract_from_manifest

register_block_contract_from_manifest(my_block_manifest)
```

`inputs=None` means *not declared here* and skips the required-input check; `inputs=[]` asserts
the block takes none. `outputs` reads the same way, and a manifest that never sets `output`
registers its outputs as not declared, so references into the block are not checked.

#### CAUTION
**Nothing is registered by default.** An unregistered identifier is skipped, never failed, so
“no wiring issues” does not mean every reference path was verified.

<a id="contract-tests"></a>

## Contract tests: flow snapshots

A snapshot test pins the flow’s **contract** — not its definition — to a committed golden
file. The golden holds exactly four things:

```json
{
  "identifier": "SHOWCASE_IDP_CORE",
  "roles": ["idp_core", "read_only", "supporting"],
  "inputs":  [{"has_default": true, "name": "require_valid_tin", "optional": false,
               "type": "boolean"}],
  "outputs": [{"name": "submission", "optional": false, "type": "object"},
              {"name": "outcome", "optional": false, "type": "object"}]
}
```

(abridged — the showcase core declares 161 inputs, which is normal for an IDP core.)

That is everything a caller of the flow can observe: what it is called, where it can be used,
what it takes and what it returns. It comes from `test_contract_snapshot`, inherited with
`FlowStaticChecksSuite`:

```python
from pathlib import Path

from flows_sdk.testing.suites import FlowStaticChecksSuite
from showcase.flows.idp_core.flow import entry_point_workflow


class TestIdpCoreContract(FlowStaticChecksSuite):
    flow = entry_point_workflow
    snapshot_path = Path(__file__).parent / 'snapshots' / 'idp_core.json'
```

The block graph is **not** recorded: a flow’s internals are not a contract with any caller, and
recording them would move the golden on every refactor.

What that means in practice:

| Change                                                                   | Moves the golden?                    |
|--------------------------------------------------------------------------|--------------------------------------|
| Editing a custom code block’s body                                       | no                                   |
| Renaming a block, reordering the graph                                   | no                                   |
| Changing a block’s title or a literal parameter                          | no                                   |
| Changing the value of an input’s default                                 | no                                   |
| Upgrading the SDK                                                        | no, unless it changes your interface |
| Renaming or dropping a declared input or output                          | **yes**                              |
| Making an input or output optional, or mandatory                         | **yes**                              |
| Giving an input a default, or dropping its default                       | **yes**                              |
| Changing an input or output’s declared `type` (`string` → `object`, say) | **yes**                              |
| Adding or losing a role                                                  | **yes**                              |

So when the golden does move, the diff is always worth reading: it means a consumer of this
flow is affected. For a deployed flow, the input list is also a live instance’s saved
configuration surface.

Create or refresh a golden file deliberately:

```bash
UPDATE_SNAPSHOTS=1 pytest
```

#### NOTE
A **missing** golden file is a failure, not an implicit write, so a snapshot that was never
committed cannot pass in CI. Create it with `UPDATE_SNAPSHOTS=1` and commit it.

<a id="flow-graph-tests"></a>

## Flow-graph tests: FlowTestRunner

Unit tests check pieces in isolation. `FlowTestRunner` checks how
the pieces fit together: it executes the flow’s **whole block graph offline**.
Your custom code blocks run for real, while platform/IDP blocks are replaced with
stubs you provide. It resolves `${...}` references, and runs `Fork`, `Routing`,
`Foreach` and inline subflows — so it catches wiring and orchestration bugs that
per-block tests cannot.

A custom code block runs with only what ships to the platform: its function’s own source, or
its whole module with `include_module=True`. A function that calls a helper, reads a constant
or uses an import from elsewhere in its module fails here with `NameError`, as it would on the
platform. Each block also gets its own copy of every value it reads, so a block that changes its
input in place changes nothing another block sees.

<a id="recorded-stubs"></a>

### Stubs come from a real run

A stub stands in for a platform block, so it is only as useful as its resemblance to what that
block really emits. That output is large, and each IDP block adds to the submission it hands on,
so do not write stubs by hand: a key the stub leaves out reaches the next block as `None`, and
nothing tells you. Instead, run a **synthetic** document through the flow on a development
instance and record what each block emitted:

```python
import json
from pathlib import Path

from flows_sdk.testing.e2e import HsClient

#: The core's platform blocks — the ones the flow-graph tests stub. A stub replaces a block, so
#: this project's own blocks are left out: they are what the tests run for real.
PLATFORM_BLOCKS = (
    'file_filter', 'submission_bootstrap', 'machine_collation', 'machine_classification',
    'machine_identification', 'machine_transcription', 'reprocessing', 'document_rendering',
    'complete_submission',
)

client = HsClient.from_env()
submission_id = client.create_submission(
    'tests/data/form-w9-sample.png', flow_identifier='SHOWCASE_DOCUMENT_PROCESSING'
)
run = client.wait_submission(submission_id)
recorded = client.recorded_flow_run(run['flow_run_id'], subflow='__idp_core__')

Path('tests/data/w9_recorded_run.json').write_text(json.dumps({
    'workflow_input': recorded['workflow_input'],
    'block_outputs': {ref: recorded['block_outputs'][ref] for ref in PLATFORM_BLOCKS},
}, indent=2))
```

`subflow='__idp_core__'` records the core’s run rather than the wrapper’s, because a customised
IDP core is where the blocks under test live. The recording holds the workflow input the core
received and each block’s output. Commit it beside the tests, and record again when an SDK or
platform upgrade changes the IDP blocks — the diff shows what changed. The showcase keeps this as
`record_platform_outputs.py`.

#### WARNING
**Record synthetic data only.** A recording copies a run’s data to your machine and into git,
which must never happen to a customer’s document.

Then stub from the recording:

```python
import json
from pathlib import Path

from flows_sdk.testing.flow_test_runner import FlowTestRunner
from flows_sdk.testing.harness import ScriptedHsBlockInstance
from showcase.flows.idp_core.flow import entry_point_workflow
from showcase.flows.tin_validation.flow import TIN_VALIDATION_IDENTIFIER, tin_validation_subflow

RECORDED = json.loads((Path(__file__).parents[1] / 'data' / 'w9_recorded_run.json').read_text())

#: What `load_exempt_payee_codes` reads from the knowledge store — it lists the recorded code.
KNOWLEDGE_STORE = {'knowledge_store': {'results': [{'properties': {'code': '3S'}}], 'next': None}}


def test_the_recorded_document_is_released():
    runner = FlowTestRunner(
        flow=entry_point_workflow(),
        workflow_inputs=RECORDED['workflow_input'],
        block_stubs=RECORDED['block_outputs'],
        # `load_exempt_payee_codes` calls the platform, so script its responses.
        hs_block_instance=ScriptedHsBlockInstance(KNOWLEDGE_STORE),
        # The release path calls the TIN-validation flow; run it too (see subflows, below).
        subflows={TIN_VALIDATION_IDENTIFIER: tin_validation_subflow()},
    )
    runner.run()

    runner.assert_blocks_ran('load_exempt_payee_codes', 'route_for_review', 'mark_released')
    runner.assert_blocks_did_not_run('mark_held')
```

<a id="stub-scenarios"></a>

### Scenarios edit the recording

A test of another path changes what the document **says** and nothing else. Edit the named
fields wherever the recording carries the submission, and every other key a downstream block reads
stays what the platform produced:

```python
import copy
import json
from pathlib import Path

from flows_sdk.testing.flow_test_runner import FlowTestRunner
from flows_sdk.testing.harness import ScriptedHsBlockInstance
from showcase.flows.idp_core.flow import entry_point_workflow

RECORDED = json.loads((Path(__file__).parents[1] / 'data' / 'w9_recorded_run.json').read_text())
KNOWLEDGE_STORE = {'knowledge_store': {'results': [{'properties': {'code': '3S'}}], 'next': None}}


def with_fields(fields):
    """The recorded block outputs, with the named fields' transcriptions replaced."""
    stubs = copy.deepcopy(RECORDED['block_outputs'])
    for output in stubs.values():
        submission = output.get('submission') or output.get('result', {}).get('submission')
        for document in (submission or {}).get('documents') or []:
            for field in document.get('document_fields') or []:
                if field['field_name'] in fields:
                    field['transcription'] = fields[field['field_name']]
    return stubs


def test_an_ambiguous_classification_is_held():
    runner = FlowTestRunner(
        flow=entry_point_workflow(),
        workflow_inputs=RECORDED['workflow_input'],
        # the recorded W-9 has LLC checked; a second box makes it ambiguous
        block_stubs=with_fields({'Tax Classification - Trust': 'True'}),
        hs_block_instance=ScriptedHsBlockInstance(KNOWLEDGE_STORE),
    )
    runner.run()

    runner.assert_blocks_ran('mark_held')
    runner.assert_blocks_did_not_run('mark_released')
```

The showcase’s version also fails when a scenario names a field the document does not have, so a
typo cannot leave the recording unchanged and pass.

Inspect the run with:

- `runner.ccb_result('ref')` — the unwrapped return value of a code block
- `runner.output_of('ref')` — the raw output dict of any block
- `runner.input_of('ref')` — the resolved input a block received (works for
  executed *and* mocked blocks, so you can assert exactly what a mocked block
  was called with)
- `runner.executed_blocks` — reference names in execution order
- `runner.unresolved_references` — references that silently resolved to `None`

### References that resolve to nothing

The wiring tier catches a name that does not exist. A reference that is spelled correctly and
still comes back empty, because its block produced a different shape, shows up only when the flow
runs.

The runner follows the platform’s reference semantics, so a reference that would break a real run
breaks the test. A reference to a block that has not run yet **raises**:

```text
FlowTestRunner.ReferenceResolutionError:
Failed to evaluate '${totals.output.total}' - block 'totals' has not completed. On a real flow
run the engine raises PopulateParametersException here.
Blocks completed so far: machine_transcription, load_exempt_payee_codes.
Common causes: a typo in the reference name, a block declared after the one that consumes it,
or a missing entry in block_stubs.
```

A reference to a *missing key* on a block that **did** complete is different: the platform
walks the output dict key by key and yields `None` when a key is simply absent, so the runner
does too. Two neighbouring cases do **not** yield `None`, and the runner matches the platform
on both:

* If the path runs *through* a value that is not a dict — `${block.output.a.b.c}` where `a.b`
  is a string, a number or `None` — the platform raises, because it cannot subscript it.
* If the reference is embedded in a larger string rather than being the whole value, a `None`
  result is interpolated as the literal text `null`.

The flow’s own `output` is resolved when the run ends, as on the platform. A reference there to
a block this run did not reach — one on a `Routing` branch it did not take — raises, because the
platform fails the whole run.

The `None` case is the one worth guarding, because defensive code absorbs it:
`total = line_item_total or 0.0` turns a broken reference into `0.0` and the test still passes.
So assert on it explicitly:

```python
runner.run()
runner.assert_no_unresolved_references()
```

#### TIP
Make `assert_no_unresolved_references()` a habit in every flow-graph test. A reference that
resolves to `None` is invisible at run time and cheap to assert on here.

### Mocking platform blocks and asserting their inputs

Any non-custom-code block — a **composite** block (`SUBMISSION_BOOTSTRAP`,
`MACHINE_CLASSIFICATION`), an **atomic** block (`FULL_PAGE_OICR`), an output block,
or a **subflow call** — is *mocked* via `block_stubs`.

Assert on the input a mocked block *received*. Its output is something you wrote; its **input**
was assembled by the flow under test — references resolved, upstream outputs combined — so it is
the hand-off worth pinning. A mis-keyed reference produces a plausible dict that a stub accepts
and that fails only on a real run.

```python
import json
from pathlib import Path

from flows_sdk.testing.flow_test_runner import FlowTestRunner
from flows_sdk.testing.harness import ScriptedHsBlockInstance
from showcase.flows.idp_core.flow import entry_point_workflow

RECORDED = json.loads((Path(__file__).parents[1] / 'data' / 'w9_recorded_run.json').read_text())
KNOWLEDGE_STORE = {'knowledge_store': {'results': [{'properties': {'code': '3S'}}], 'next': None}}

runner = FlowTestRunner(
    flow=entry_point_workflow(),
    workflow_inputs=RECORDED['workflow_input'],
    block_stubs={**RECORDED['block_outputs'], 'validate_tins': {'all_valid': True}},
    hs_block_instance=ScriptedHsBlockInstance(KNOWLEDGE_STORE),
)
runner.run()

# assert exactly what the stubbed subflow call was handed — its input is built by this
# project's own upstream blocks, so this is the hand-off worth pinning
assert runner.input_of('validate_tins')['documents'][0]['tin'] == '202267197'
```

### Stubbing options

A stub is normally a static output dict, but it can also be a **callable** that
computes the output from the block’s resolved input — handy when the output
depends on what was passed in:

```python
block_stubs={
    'lookup_rate': lambda resolved_input: {
        'rate': 0.1 if resolved_input['region'] == 'US' else 0.2
    },
}
```

For `Foreach` iterations, key the stub by the **concrete iteration name**. A `Foreach` holds one
block as a template and generates one real block per item, rendering the template’s
`reference_name` for each — `${<foreach_reference_name>.item}` and
`${<foreach_reference_name>.index}` are substituted into it. Each generated name must be unique,
and the platform fails the run if two collide, so the name interpolates something that differs per
item: the index, or a property of the item itself.

```python
from flows_sdk.blocks import Foreach, PythonBlock

Foreach(
    reference_name='identify',
    items=bootstrap.output('segments'),
    template=PythonBlock(
        reference_name='identify_${identify.item.segment_id}',   # unique per segment
        code=identify_segment,
    ),
)
```

That produces one block per segment, named by its id. A template whose name interpolates nothing
gets `_${identify.index}` appended, so its iterations are `identify_0`, `identify_1`, and so on.
The runner renders each name in its iteration’s context, as the engine does, and records each
iteration under it: stub one iteration, hook it, or read it back with `ccb_result` and
`assert_blocks_ran` by that name. A recorded run has no entries for iterations, so take the names
from the template.

For platform blocks that call external services, provide their raw output. Use
`ccb_output(value)` to wrap a value the way the platform wraps a code block’s return — it
follows the `HS_CODE_BLOCK_OUTPUT_WRAPPING_MODE` setting, so under `no_wrapping` it returns
the value unwrapped, matching the blocks around it.
A stub’s output reaches the next block the way a stored output does on the platform, through
its JSON encoding: a `datetime` arrives as an ISO string and a tuple as a list, and a value the
platform cannot store, such as a mock object, fails the run. A literal input written in the flow
arrives as the deployed flow’s JSON holds it, so a dict key `1` reaches the block as `'1'`.
`Fork`, `Routing`, `Foreach` and `Outputs` sections are executed automatically — you never stub
them; you stub the platform blocks *inside* them.

### Settings, secrets and triggers

A flow can read values the platform supplies rather than a block: system settings
(`system_setting('x')`), system secrets (`system_secret('x')`) and its trigger’s payload
(`triggers_output(...)`). Give the runner the first two, and the trigger as a workflow input:

```python
from flows_sdk.blocks import PythonBlock
from flows_sdk.flows import Flow, Manifest, Triggers
from flows_sdk.testing.flow_test_runner import FlowTestRunner
from flows_sdk.utils import system_secret, system_setting, triggers_output


def notify(subject: str, token: str, limit: int) -> dict:
    return {'sent': subject, 'limit': limit}


flow = Flow(
    title='Notify',
    owner_email='flows@example.com',
    manifest=Manifest(identifier='NOTIFY', input=[]),
    triggers=Triggers(title='Triggers', reference_name='triggers', blocks=[]),
    blocks=[
        PythonBlock(
            reference_name='notify',
            code=notify,
            code_input={
                'subject': triggers_output('email', 'subject'),
                'token': system_secret('mail_token'),
                'limit': system_setting('mail.daily_limit'),
            },
        )
    ],
)

runner = FlowTestRunner(
    flow=flow,
    workflow_inputs={'$trigger': {'payload': {'email': {'subject': 'Invoice'}}}},
    system_secrets={'mail_token': 'test-token'},
    system_settings={'mail': {'daily_limit': 100}},
)
runner.run()
assert runner.ccb_result('notify') == {'sent': 'Invoice', 'limit': 100}
```

They behave as on the platform. A missing setting resolves to `None` and is listed in
`unresolved_references`; a missing secret raises, as the platform fails a task whose secret it
cannot find. A secret is substituted only as the whole value of one of a block’s inputs, so one
nested in an object or a list, or placed inside a longer string, raises too: on the platform the
block would receive a placeholder instead of the secret. The same holds after a secret is passed
into a subflow: the subflow’s input holds the placeholder, and a block there gets the secret only
by reading that input as the whole value of one of its own. A reference the platform does not
rewrite, such as `${system.settings}` with no key or a key containing `-`, raises, as it fails on
the engine. The triggers section runs first, as the block the platform puts there.

### Assertion hooks

Most of the time you run the flow and then assert on what it recorded. A hook asserts *during*
the run instead, on one named block, the moment it executes.

Use one when the flow **fails partway**: the test stops at `run()`, but the hook has already
checked the block you care about. Otherwise, assert after `run()`.

`BlockHook` fires for executed and mocked blocks alike.

The keys of `block_hooks` are **block reference names** — the same strings you pass to
`block_stubs` and read back from `runner.executed_blocks` — not hook types. A name the flow does
not declare, such as a typo or a block inside a subflow, raises `ValueError`, because the hook
would never run. The triggers section’s `reference_name` is declared, and its hook runs:

```python
import json
from pathlib import Path

from flows_sdk.testing.flow_test_runner import BlockHook, FlowTestRunner
from flows_sdk.testing.harness import ScriptedHsBlockInstance
from showcase.flows.idp_core.flow import entry_point_workflow
from showcase.flows.tin_validation.flow import TIN_VALIDATION_IDENTIFIER, tin_validation_subflow

RECORDED = json.loads((Path(__file__).parents[1] / 'data' / 'w9_recorded_run.json').read_text())
KNOWLEDGE_STORE = {'knowledge_store': {'results': [{'properties': {'code': '3S'}}], 'next': None}}


def _decision_is_release(out):
    assert out['result']['decision'] == 'release', f'routed to {out["result"]["decision"]!r}'


runner = FlowTestRunner(
    flow=entry_point_workflow(),
    workflow_inputs=RECORDED['workflow_input'],
    block_stubs=RECORDED['block_outputs'],
    hs_block_instance=ScriptedHsBlockInstance(KNOWLEDGE_STORE),
    subflows={TIN_VALIDATION_IDENTIFIER: tin_validation_subflow()},
    block_hooks={
        # 'route_for_review' is the reference_name of a block in the flow under test.
        'route_for_review': BlockHook(assert_output=_decision_is_release),
    },
)
runner.run()
```

#### IMPORTANT
A hook must **raise** to fail the test. Its return value is discarded, so
`assert_output=lambda out: out['x'] == 'y'` asserts nothing — it computes a boolean, throws it
away, and passes for ever. Write `assert` inside the hook, as above; a `lambda` cannot contain
one, which is why this example uses a named function.

### Testing a hierarchy of flows (subflows)

A flow can call another flow as a **subflow** (a `Block` whose identifier matches
the subflow’s manifest identifier). You can either *stub* that call like any other
block, or run the **whole hierarchy** offline by passing the subflow’s `Flow`
object — the runner executes it inline via a nested `FlowTestRunner`, so the
child flow’s own custom code runs for real while only its leaf platform blocks
are mocked:

```python
import json
from pathlib import Path

from flows_sdk.testing.flow_test_runner import FlowTestRunner
from flows_sdk.testing.harness import ScriptedHsBlockInstance
from showcase.flows.idp_core.flow import entry_point_workflow
from showcase.flows.tin_validation.flow import (
    TIN_VALIDATION_IDENTIFIER, tin_validation_subflow,
)

RECORDED = json.loads((Path(__file__).parents[1] / 'data' / 'w9_recorded_run.json').read_text())
KNOWLEDGE_STORE = {'knowledge_store': {'results': [{'properties': {'code': '3S'}}], 'next': None}}

runner = FlowTestRunner(
    flow=entry_point_workflow(),
    workflow_inputs=RECORDED['workflow_input'],
    block_stubs=RECORDED['block_outputs'],
    hs_block_instance=ScriptedHsBlockInstance(KNOWLEDGE_STORE),
    # run the subflow inline instead of stubbing it
    subflows={TIN_VALIDATION_IDENTIFIER: tin_validation_subflow()},
)
runner.run()

# inspect the nested runner for the subflow's own blocks
sub = runner.subflow_runners['validate_tins']
assert sub.ccb_result('summarise_validation')['invalid_count'] == 0
```

To stub a block *inside* the subflow instead of letting it run, use `subflow_stubs`, keyed by
the parent’s reference name for the subflow call and then by the block inside it:

```python
subflow_stubs={'validate_tins': {'extract_line_items': {'line_items': [{'amount': '$20'}]}}},
```

Reference names are unique only within a flow, so keying by the call site lets the parent and
the subflow each have a `parse` block, and two calls to one subflow get different stubs.

Or stub the whole subflow call, by putting `validate_tins` in `block_stubs` and leaving it out
of `subflows` — then `runner.subflow_runners` has no entry for it.

A deeper hierarchy needs nothing more. Every nested runner is handed the same `subflows` mapping,
so a subflow that calls a subflow of its own is resolved by identifier like any other: list every
flow in the hierarchy once, whatever its depth, and reach a grandchild’s runner through
`runner.subflow_runners['call']`’s own `subflow_runners`. `subflow_stubs` applies one level down
only; a block deeper than that runs for real, or is replaced with an emulator (below).

### Running only part of a flow

```python
runner.run(stop_after='route_for_review')
```

Executes the flow up to and including that block, then stops. Useful on a long flow when the
part you are working on is near the front and everything after it needs stubs you have not
written yet.

To skip the front of a flow instead, stub those blocks: the flow still runs end to end, and every
reference through them still resolves.

<a id="block-emulators"></a>

### Emulating a block everywhere

A stub is keyed by **reference name**, so a block that appears ten times needs ten entries. An
emulator is keyed by **block identifier**, so it stands in for every block of that kind at once
and computes its output from whatever input it was given:

```python
from flows_sdk.testing.flow_test_runner import register_block_emulator

def _rest_call(resolved_input):
    """Stand in for every HTTP_REST block in the flow."""
    if resolved_input['uri'].endswith('/rates'):
        return {'response': {'rate': 0.2}}
    return {'response': {}}

register_block_emulator('HTTP_REST', _rest_call)
```

Use it when one block identifier appears throughout a flow — an HTTP call, a knowledge-store read.
A `block_stubs` entry for a specific reference name still wins, so you can emulate the general
case and override one occurrence.

Emulators are registered globally, so unregister in a fixture teardown
(`unregister_block_emulator('HTTP_REST')`) or they leak into the next test.

<a id="e2e-tests"></a>

## End-to-end tests: synthetic data

The first of the two live tiers, and the one most live tests belong in. It runs your flow on a
real instance — the platform’s own validation, its sandbox, its models — with data made up for the
purpose, so it is an ordinary pytest test: it deploys the flow from your checkout, sends it data
from git, and asserts on the result value by value. It runs in CI against a development instance.

Use it for everything about how the flow **behaves**: that it deploys and completes, that its custom
code blocks run in the platform’s sandbox, which way a routing decision goes, what happens after
supervision, how it uses the knowledge store and the systems around it. Keep the
[in-flow tier](#in-flow-tests) for the questions only customer data can answer.

### A test owns its data, and its configuration

Everything the test needs is in your repository:

| Where                   | What                                                                             |
|-------------------------|----------------------------------------------------------------------------------|
| `tests/data/`           | the synthetic input — a document, a submission — and the result expected from it |
| `tests/e2e/test_e2e.py` | the test: deploy the flow, run it, compare                                       |

The same `tests/data/` files can drive the offline tiers too, so one synthetic fixture is checked
against both the local runner and the real platform. A test of a document-processing flow submits a
synthetic document and compares what the flow extracted with the result expected from it:

```python
# flows/<name>/tests/e2e/test_e2e.py
import json
from pathlib import Path

import pytest
from flows_sdk.testing.e2e import HsClient
from flows_sdk.testing.harness import requires_instance

from my_project.flows.invoice.flow import FLOW_IDENTIFIER, entry_point_workflow

DATA = Path(__file__).parents[1] / 'data'

pytestmark = [pytest.mark.e2e, requires_instance()]   # skip where no instance is configured


@pytest.fixture(scope='module')
def client() -> HsClient:
    return HsClient.from_env()


@pytest.fixture(scope='module')
def deployment(client):
    # This checkout's flow, as its own copy, undeployed and archived afterwards.
    with client.deployed_copies(entry_point_workflow) as copies:
        yield copies[FLOW_IDENTIFIER]


def test_the_invoice_is_extracted(client, deployment):
    submission_id = client.create_submission(
        DATA / 'invoice.pdf', flow_identifier=deployment['identifier']
    )
    result = client.wait_submission(submission_id)

    assert result['flow_run']['status'] == 'COMPLETED'
    extracted = {
        field['name']: (field.get('transcription') or {}).get('normalized')
        for document in result['submission']['documents']
        for field in document['document_fields']
    }
    assert extracted == json.loads((DATA / 'invoice.expected.json').read_text())
```

A project from `hs-flows init` starts with a placeholder of the same shape: its flow returns a
fixed value, so the test starts it with `create_flow_run` and compares the run’s `flow_output`.

`deployed_copies()` builds, imports and deploys exactly what
your checkout builds, so a test never runs against whatever happened to be left on the instance.
Each flow is deployed as a *copy*, under a namespace no other run uses, so the test never
overwrites a deployment an operator has configured and two pipelines do not fight over one flow.
Pass it the functions that build the flows, the flows a flow calls first:

```python
with client.deployed_copies(
    idp_core,
    document_processing,
    settings={DOCUMENT_PROCESSING: {'layout_release_uuid': release}},
    exclude=[NOTIFICATION],
) as copies:
    flow_under_test = copies[DOCUMENT_PROCESSING]['identifier']
```

- **`settings`** fills in a flow’s input section — what an operator would otherwise set in Flow
  Studio, such as a layout release or a knowledge-store collection. A test that owns its data owns
  its configuration too. A name the flow does not declare is refused before anything is imported.
- **`exclude`** deploys the named flows as themselves rather than as copies: each run overwrites
  the original, the copies call it under its own name, and it stays deployed afterwards.
- **`cleanup`** undeploys and archives every copy on exit.

A **supporting** flow — an IDP core, a notification flow — is part of the deployment group of the
main flow that calls it, and the platform refuses to deploy one on its own. `deployed_copies`
imports it and lets it go live with its caller.

<a id="flow-copies"></a>

### Flows that call each other

A wrapper calls its IDP core by identifier, and a core calls its subflows by identifier, so a copy
of one has to call the copies of the others. Declare each of your own flows’ identifiers once,
with `flow_identifier()`, and use the constant everywhere:

```python
from flows_sdk.identifiers import flow_identifier, namespaced_flow_identifier
from flows_sdk.implementations.idp_v43.idp_blocks import IDPCoreBlock
from flows_sdk.implementations.idp_v43.idp_values import IDPCoreManifest, get_idp_wf_config

CORE = flow_identifier('INVOICE_CORE')
NOTIFICATION = flow_identifier('INVOICE_NOTIFICATION')


def idp_core():
    manifest = IDPCoreManifest(flow_identifier=CORE)
    ...


def wrapper():
    idp_wf_config = get_idp_wf_config()
    idp_wf_config.notification_workflow_initialization = namespaced_flow_identifier(NOTIFICATION)
    core = IDPCoreBlock(idp_wf_config, identifier=CORE)
    ...
```

`CORE` is the plain string `'INVOICE_CORE'`. When `deployed_copies` builds the flows, the SDK gives
a manifest’s identifier, a block’s and an on-error flow’s the run’s namespace. Anywhere else a flow
identifier goes, such as a `FlowIdentifier` setting, pass it through
`namespaced_flow_identifier()` where the flow is built. Identifiers that
are not your flows’, such as the platform’s defaults, stay as they are.

A reference the namespace would miss reaches the original, so `deployed_copies` refuses it before
importing anything: a copied flow’s plain identifier left in a built flow, a call to a copy that is
not built in the same call, or an excluded flow that calls a copy.

### Documents, submissions and supervision

For a document-processing flow, the input is a document. Submit it from the test process and wait:

```python
submission_id = client.create_submission(DATA / 'w9.png', flow_identifier=flow_under_test)
result = client.wait_submission(submission_id)

result['flow_run']['status']              # 'COMPLETED'
result['flow_run']['flow_output']         # what the flow returned
result['submission']['documents']         # fields and transcriptions, as the UI shows them
```

`wait_submission()` waits on the submission’s **flow run**, so
the blocks after the submission completes have finished too. It returns the submission with its
documents, as the UI shows them.

A supervised submission stops on a task. The test takes the operator’s place:

```python
submission_id = client.create_submission(
    DATA / 'w9.png', flow_identifier=flow_under_test, machine_only=False
)
task = client.await_supervision_task(submission_id)
client.complete_supervision_task(task, values={'Name': 'JANE Q. PUBLIC'})
result = client.wait_submission(submission_id)


def fields_of(submission):
    return {
        field['name']: (field.get('transcription') or {}).get('normalized')
        for document in submission['documents']
        for field in document['document_fields']
    }


assert fields_of(result['submission'])['Name'] == 'JANE Q. PUBLIC'
```

The task is completed with the test’s own credential, so that credential needs permission to
complete supervision tasks.

### The rest of the environment is test data too

Anything the flow reads from the instance is part of what the test depends on — a layout release,
a knowledge-store collection, a configured endpoint. Establish it from the repository rather than
relying on how the instance was left. The showcase’s `tests/e2e/environment.py` does three things
worth copying:

- **imports the layout release** from `tests/data/` when the instance lacks it;
- **deploys its flows as copies** whose settings point at the test’s own knowledge-store
  collection, so nothing it seeds can change how a real deployment routes;
- **seeds the collection for each scenario and empties it afterwards**, so a test sees exactly the
  entries it put there, never what an earlier test or a person left behind:

```python
with exempt_codes(client, IRS_EXEMPT_CODES):          # the document's code is not listed
    submission_id = client.create_submission(DOCUMENT, flow_identifier=flow_under_test)
    held = client.wait_submission(submission_id)

assert held['flow_run']['flow_output']['outcome']['status'] == 'held'
```

That is the same synthetic document released in one test and held in the next, depending only on
data the test controls — a routing decision tested both ways, on the real platform.

<a id="e2e-in-ci"></a>

### Running it in CI

Authenticate with **machine-to-machine credentials**. Create an M2M client in the instance’s admin
UI, in the **System Admin** group: the tests import and deploy flows, which needs the `import_flows`
permission, and on a fresh instance no other group has it. The UI shows the client’s *Client
Secret (JWK)* once; save it to a file and point the environment at it:

```bash
export HS_BASE_URL=https://dev-instance
export HS_M2M_CLIENT_ID=<the client id the UI shows next to the key>
export HS_M2M_CREDS=~/.hyperscience/m2m_creds.json   # the JWK file you saved
pytest -m e2e
```

Without those variables the tier skips, so the rest of the suite stays runnable anywhere.

#### IMPORTANT
**The credential needs whatever the tests do.** Deploying flows, creating submissions and reading
flow runs at minimum; editing the knowledge store, importing a layout release or completing
supervision tasks if a test does those.

#### WARNING
**One run per instance at a time, unless each run owns its state.** Two pipelines deploying the
same identifier race each other’s import and deploy. `deployed_copies` separates the flows, but
anything else a test seeds — a knowledge-store collection, say — has to be per run too, or two runs
will rewrite it under each other.

<a id="in-flow-tests"></a>

## In-flow tests: customer data

The top of the pyramid, and the smallest tier. Put a test here only when synthetic
data cannot answer the question — typically **evaluation**: does extraction stay accurate on the
documents this customer actually receives? Everything about how the flow behaves belongs in the
[end-to-end tier](#e2e-tests), which is faster, runs in CI, and can assert on anything.

A real document carries PII, so it must not reach a laptop or a CI log. So the tests are flows. They are deployed to the customer’s instance, create a submission there,
wait for it, and assert on the result *inside* the environment. Your pytest run learns only whether
the suite’s flow run succeeded, plus a URL where a human can read which case failed and why.

### Two flows, because data and logic have different owners

| File                            | What it is             | Who owns it                                |
|---------------------------------|------------------------|--------------------------------------------|
| `in_flow/suite_core_flow.py`    | the assertions         | git — rebuilt and re-uploaded on every run |
| `in_flow/suite_wrapper_flow.py` | the test data          | the instance — configured once by a human  |
| `in_flow/test_in_flow.py`       | the pytest entry point | git                                        |

The **wrapper** declares the test data as inputs — the document as a `File`, the expected result
as an object. Someone configures those once through Flow Studio, and the values stay on the
instance.

The **core** holds the assertions. Running the tests builds both flows from your repository and
syncs them to the instance first, so editing an assertion and re-running `pytest` is the whole
loop.

**The instance owns the data, git owns the logic:** a test references an expected value; it never
contains one.

### Writing a suite

A suite is **a flow**, built from blocks, deployed to the instance and run there. Each case is a
block in it, so a failed case is a failed block you can open in the flow run.

An in-flow test is an evaluation, and an evaluation is three steps: submit the configured
document, wait for it, compare what came out with what a human approved. Each is an ordinary
custom code block running a function from your own module, calling the public API through
`_hs_block_instance`:

```python
# flows/<name>/tests/in_flow/evaluation.py — runs on the instance, standard library only
import base64
import json
import time

FINISHED = ('COMPLETED', 'FAILED', 'CANCELLED', 'TIMED_OUT')


def submit_and_wait(blob_uuid, flow_identifier, _hs_block_instance):
    """Submit the configured document to the flow under test; wait for its run to finish."""
    flows = _hs_block_instance.hs_get(
        '/api/v5/flows', params={'identifier': flow_identifier, 'limit': 500}
    )
    flow_uuid = next(
        flow['uuid']
        for flow in json.loads(flows.text)['results']
        if flow['identifier'] == flow_identifier
    )
    blob = _hs_block_instance.fetch_blob(blob_uuid)
    created = _hs_block_instance.hs_post(
        '/api/v5/submissions',
        json={
            'flow_uuid': flow_uuid,  # not `identifier`: it is dropped, and the default flow runs
            'machine_only': True,
            'files': [
                {
                    'file_content_base64': base64.b64encode(blob.content).decode('ascii'),
                    'filename': 'invoice.pdf',
                }
            ],
        },
    )
    submission_id = json.loads(created.text)['submission_id']
    while True:  # wait on the flow run, not on the submission's state
        submission = _hs_block_instance.hs_get(
            f'/api/v5/submissions/{submission_id}', params={'debug': 'true'}
        )
        flow_run_id = json.loads(submission.text).get('flow_run_id')  # only with ?debug=true
        if flow_run_id:
            run = _hs_block_instance.hs_get(
                f'/api/v5/flow_runs/{flow_run_id}',
                handled_error_codes=list(range(400, 500)),  # not readable yet: poll again
            )
            if run.status_code < 400 and json.loads(run.text).get('status') in FINISHED:
                return {'submission_id': submission_id}
        time.sleep(10)


def total_matches(submission_id, expected_total, _hs_block_instance):
    """A case: read the submission as the UI does, and compare one field."""
    response = _hs_block_instance.hs_get(f'/api/v5/submissions/{submission_id}?flat=false')
    fields = {
        field['name']: (field.get('transcription') or {}).get('normalized')
        for document in json.loads(response.text).get('documents') or []
        for field in document.get('document_fields') or []
    }
    actual = fields.get('Total')
    return {
        'passed': actual == expected_total,
        'detail': f'expected {expected_total!r}, read {actual!r}',
    }
```

```python
# flows/<name>/tests/in_flow/suite_core_flow.py
from flows_sdk.blocks import PythonBlock
from flows_sdk.flows import Flow, Manifest, Parameter
from flows_sdk.testing.in_flow import collect_results, fail_if_any_failed, in_flow_test_case
from flows_sdk.utils import workflow_input

from . import evaluation

# 1. submit the configured document and wait for the flow under test to finish
submitted = PythonBlock(
    reference_name='submit_document',
    code=evaluation.submit_and_wait,
    code_input={
        'blob_uuid': workflow_input('test_document'),         # configured on the wrapper
        'flow_identifier': workflow_input('flow_under_test'),
    },
    include_module=True,   # the functions call module-level helpers
)

# 2. one block per case. `in_flow_test_case` is what makes it a case.
total = PythonBlock(
    reference_name=in_flow_test_case('total'),
    code=evaluation.total_matches,
    code_input={
        'submission_id': submitted.output('submission_id'),
        'expected_total': workflow_input('expected_total'),   # configured on the wrapper
    },
    include_module=True,
)

# 3. gather the verdicts, and fail the run if any case failed or did not run.
#    Wired to nothing: it finds every `test_case__` block in its own flow run.
report = collect_results(reference_name='report', suite='invoice_accuracy')
verdict = fail_if_any_failed(reference_name='verdict', report=report.output())

core_suite = Flow(
    title='Invoice accuracy assertions',
    owner_email='team@example.com',
    manifest=Manifest(
        identifier='INVOICE_ACCURACY_CORE',
        roles=['test_flow'],
        input=[
            Parameter(name='test_document', type='string', ui={'hidden': True}),
            Parameter(name='expected_total', type='string', ui={'hidden': True}),
            Parameter(name='flow_under_test', type='string', ui={'hidden': True}),
        ],
    ),
    blocks=[submitted, total, report, verdict],
)
```

The showcase’s and the scaffold’s `evaluation.py` add a timeout, error reporting, and a check that
the run completed. When you write your own:

- submit by `flow_uuid`: an `identifier` is ignored, and the instance’s *default* flow runs;
- `?debug=true` adds `flow_run_id` to a submission;
- wait on the **flow run**, not on the submission’s `state`;
- `hs_get`/`hs_post` raise on an error status unless it is listed in `handled_error_codes`, so
  list the ones you check `status_code` for.

The SDK provides only the reporting — `in_flow_test_case`, `collect_results`,
`fail_if_any_failed` — and the wrapper’s call into this flow, `call_test_core`. Everything a suite
*tests* is yours: what counts as a correct submission is specific to your application, so it is
your code, readable end to end.

Read the submission from `GET /api/v5/submissions/{id}?flat=false`, the representation the UI
exports, so it lines up with an expected value exported from the UI. The submission a flow passes
between its blocks is in a different format, so do not compare against it.

### How a block becomes a test case

Wrap its reference name in `in_flow_test_case`:

```python
from flows_sdk.testing.in_flow import in_flow_test_case

reference_name = in_flow_test_case('extraction_matches')   # renders 'test_case__extraction_matches'
```

The name you pass is the **case id**: `collect_results` reports the verdict under it, and the run’s
failure lists failed cases by it.

A case cannot sit inside a `Foreach` template, because its verdicts could not be collected; the
suite rejects one when it is collected. To check every item, make one case whose code loops over
them and returns a single verdict, naming what failed in its `detail`.

`collect_results` takes no wiring: it finds every case block in its own flow run, so adding a case
is one declaration. A case the run never reached, on a branch it did not take, is listed under
`not_run`, and `fail_if_any_failed` fails the run for it: a check that never happened is not a
pass.

### The two rules a case follows

1. **Name it with `in_flow_test_case()`.** The collector fails the report on a block that returns
   a verdict without the prefix, and on a declared case that produced no verdict.
2. **Return `{'passed': bool}`, and do not raise.** A `detail` string is carried into the report and
   the block log. A raising case would hide every later failure; `fail_if_any_failed` runs last and
   fails the flow once, listing all of them.

A step that every case depends on — like `submit_and_wait` — *should* raise when it fails: nothing
after it can run. The run fails at that step, and the suite reports it with the run’s URL.

#### WARNING
**One suite invocation per instance at a time.** Each run re-imports and deploys the suite
flows, so two concurrent `pytest -m in_flow` runs against the same instance race each other’s sync
and fail with 409s during setup. For a shared instance, serialise the runs — or give each one
its own flow identifiers.

<a id="in-flow-running"></a>

### Running it

The pytest module ties the two flows together. `wrapper_suite` is the wrapper flow — the one
that declares the test data as inputs — and `core_suite` is the assertions flow from above:

```python
# flows/<name>/tests/in_flow/test_in_flow.py
from flows_sdk.testing.in_flow_suite import InFlowTestCase, InFlowTestSuite

from .suite_core_flow import core_suite        # the assertions
from .suite_wrapper_flow import wrapper_suite  # the test data


class TestInvoiceAccuracy(InFlowTestSuite):
    suite_test_cases = [InFlowTestCase(wrapper_suite)]  # pytest triggers this flow
    dependency_flows = [core_suite]                     # called by the wrapper as a subflow
```

The suite needs the framework’s pytest plugin, enabled with `-p flows_sdk.testing.plugin` — see
[Installing the test tooling](#installing-test-tooling). Without it, the suite fails with a message naming that option.

Authenticate the same way as the [end-to-end tier](#e2e-tests) — a machine-to-machine credential,
its JWK saved to a file — but against the customer’s instance:

```bash
export HS_BASE_URL=https://my-instance
export HS_M2M_CLIENT_ID=<the client id the UI shows next to the key>
export HS_M2M_CREDS=~/.hyperscience/m2m_creds.json   # the JWK file you saved
pytest -m in_flow
```

#### IMPORTANT
**The credential needs the System Admin group.** Running the suite imports and deploys both
flows, creates submissions and reads flow runs. Importing a flow needs the `import_flows`
permission, and on a fresh instance only System Admin has it.

Running it syncs both flows to the instance, triggers the wrapper, and reports **one pytest test
per flow run**. The test passes when the run completes. Otherwise it fails with the run’s URL,
where you read which case failed and the values it compared:

```text
$ pytest -m in_flow
...
E   Failed: the in-flow suite ended FAILED. Open the flow run to see which cases failed and why:
E   https://my-instance/flows/flow-runs/1c9e2b7a-…/flow-run
...
FAILED flows/invoice/tests/in_flow/test_in_flow.py::TestInvoiceAccuracy::test_the_suite_flow_run_succeeded[INVOICE_ACCURACY_WRAPPER]
```

List every flow a case calls in `dependency_flows`, including the ones its subflows call in turn,
in any order: a flow the platform refuses to deploy because a subflow it calls is not there yet is
retried once the others are. Every listed flow, wrappers included, carries the `test_flow` role —
it marks the flow as the suite’s to overwrite — and a suite that lists one without it fails before
syncing anything.

**The first run creates the flows and fails**, because nothing in your repository can invent a
document. Every test errors during setup with the same explanation:

```text
$ pytest -m in_flow
...
E   flows_sdk.testing.in_flow_suite.WrapperNotConfigured:
E   INVOICE_ACCURACY_WRAPPER could not be synced to the instance, so the suite cannot run.
E   The usual cause is unconfigured test data: a flow whose mandatory inputs have no value
E   cannot be deployed, and the test documents are configured on the instance rather than
E   committed, so nothing here can fill them in. The platform error below names the inputs
E   it is missing.
E   Configure them at: https://my-instance/flows/6f2b…/edit
E   Platform error: 400 ... "test_document": ["This field is required."]
```

Open that link, set the inputs the platform error names, and re-run.

<a id="in-flow-expected-result"></a>

### Where the expected result comes from

The expectation is configured on the wrapper by a human who has checked a real run, not written
by hand or committed.

How much you configure is up to how much you want to assert:

- **A few values.** Run the document through the flow once, read the values off the submission
  details page, and configure them as individual wrapper inputs — `expected_total`,
  `expected_vendor`. Your assertion is then an ordinary comparison against
  `workflow_input('expected_total')`. This is the common case and the easiest to review: each
  input names one thing someone decided mattered.
- **A whole extraction.** Export the submission from the UI for a run you have approved,
  configure it as one object input, and have your assertion block compare every field it
  carries. Broader coverage, at the cost of a golden a human has to re-approve whenever the
  layout legitimately changes. Fetch the actual submission from the same public API the export
  came from, or the two representations will not line up.

Either way the expected values live on the instance beside the document they describe, and the
test in git says only *which* values matter — never what they are.

### Declare the wrapper’s inputs mandatory

No `optional=True`, and no placeholder values in its `input` section. This is what makes an
unconfigured suite fail loudly rather than run against nothing:

* a flow with an unset mandatory input still **imports** — a missing value is only a warning — so
  the wrapper can be uploaded and configured in the UI afterwards;
* it will not **deploy**, and the platform names each input it is missing.

The first run therefore creates the flows, fails on the deploy, and says which inputs to set and
where.

Marking the document `optional=True` defeats this: the wrapper deploys empty, the suite runs, and
every assertion comparing a value fails for a reason that looks like a bug in the flow.

### Mark the assertions flow’s inputs hidden

The other half of the same rule, and the opposite treatment. An assertions flow’s inputs are
**runtime** inputs — the wrapper passes them in on every run, and nobody ever sets them in the
UI — so declare each one `ui={'hidden': True}`:

```python
from flows_sdk.flows import Parameter

Parameter(
    name='test_document',
    type='string',
    title='Test document (blob uuid, from the wrapper)',
    ui={'hidden': True},
)
```

Hidden inputs are exempt from the mandatory-value check, so the flow deploys with nothing
configured. Don’t use empty-string defaults instead: on a wrapper, an unset input is the signal
that nobody has attached the test data.

### One path per suite flow

The in-flow submission and wait blocks **raise**; the assertion blocks record their outcome and
let the flow continue. So a single flow covering two independent paths stops at the first
submission that fails or times out, and the second path never runs — its result is *absent*
rather than failed, which reads as “no problem”. Give each path its own suite flow and wrapper,
then declare one `InFlowTestCase` per path in a single class — each is triggered separately and
carries its own results, and `timeout_seconds` can be set per case so a cheap path does not wait
an expensive one’s ceiling before reporting a hang.

<a id="in-flow-wrapper-protected"></a>

### The wrapper is protected

The wrapper’s configuration — which document, which expected values — is the only record of what
the tests run against, and nothing in git can recreate it. On every run the framework compares
the wrapper built from your code with the one on the instance. If they differ and the deployed one
has configured values, the run **fails and changes nothing**.

You resolve it explicitly:

```bash
pytest -m in_flow --merge-test-flows    # take the new definition, keep the configured data
pytest -m in_flow --force-test-flows    # take the new definition, discard the configured data
```

`--merge-test-flows` is what you normally want. It fails if a configured input is not in the code
any more, rather than drop its value.

### What crosses the boundary

For each suite run the framework reads **one thing: the run’s status**. It never reads a block’s
log, its output or the run’s error message. The suite’s last block fails the run when any case
failed or did not run, so the status is the verdict, and which case failed is read on the
instance, at the run’s URL.

In-flow assertions therefore log freely — expected and actual values, field by field — because
those logs stay on the instance for a human to read. The local tiers have the opposite property
for the opposite reason: pytest output escapes into terminals and CI artifacts, so those tiers run
on synthetic fixtures and never hold a real value to print.

### Supervision

Supervision is flow logic, so test it in the [end-to-end tier](#e2e-tests): there a test
submits a synthetic document with `machine_only=False`, takes the operator’s place with
`HsClient.await_supervision_task` / `complete_supervision_task`, and asserts on what the flow did
next — all from pytest, with its own credential. An in-flow evaluation submits machine-only and
measures what the models read unaided.

<a id="testing-best-practices"></a>

## Best practices

1. **Push logic down the pyramid.** Put transformation logic in pure functions
   and unit-test it exhaustively; keep code blocks thin.
2. **Keep code blocks real, mock the rest.** `FlowTestRunner` runs your code for
   real — only stub platform/IDP blocks and external calls.
3. **Call custom code block functions directly.** Import and call them with the mocks; use
   `invoke_block` only for code that has no importable name.
4. **Snapshot every deployable flow.** The golden holds its contract, so it moves only when
   something a caller can observe changes — which makes every diff worth reading.
5. **Assert no unresolved references.** Call
   `runner.assert_no_unresolved_references()` in flow-graph tests so a broken
   reference cannot hide behind defensive code.
6. **Commit synthetic data; never commit customer data.** Synthetic documents, submissions and
   their expected results belong in `tests/data/`, beside the tests that use them. A real
   document and a real expected result are configured on the customer’s instance, on the in-flow
   wrapper, and only referenced. If a fixture in your repo came from a real submission, treat it
   as customer data.
7. **Give every flow a `FlowStaticChecksSuite` subclass.** Two declarations get you every standard
   check, and a check added in a later SDK release arrives without you editing anything.
8. **Use `assert_blocks_ran` / `assert_blocks_did_not_run`, not `in runner.executed_blocks`.**
   The helpers distinguish “the branch was not taken” from “that block name does not exist”,
   and the negative form fails on a typo instead of passing vacuously forever.
9. **Mark each test with its tier.** A module-level `pytestmark = pytest.mark.contract`, with the
   markers declared in `pyproject.toml` — see [Marking tests with their tier](#marking-tiers). It is your choice, not a
   requirement; but it is what lets CI run the offline tiers on every PR, `e2e` against a
   development instance and `in_flow` where the customer’s data lives. Select the offline run by
   exclusion, `-m "not e2e and not in_flow"`, so a forgotten marker never hides a test.
10. **Make the live tiers opt-in.** `requires_instance()` skips a test when credentials are
    absent, so offline runs stay green.
11. **Default to synthetic data for live tests.** Before writing an in-flow case, ask whether a
    synthetic document could answer the same question. If it could, write an `e2e` test: it runs
    in CI, it can assert on any value, and it owns the environment it runs in.
12. **Know what offline cannot prove.** The platform’s validation rules, the custom-code
    container’s installed package set, how settings reach the flows that read them, retries and
    `on_error` flows are only exercised on a real instance — the `e2e` tier covers them. Accuracy
    on customer documents is measured only by the `in_flow` tier: offline the IDP blocks are
    stubbed, and in the `e2e` tier the document is synthetic.

## Full example project

The **testing showcase** is a complete, runnable project covering every tier above. It is built
on the IDP starter flow, so its layout release and sample document ship with the SDK — the live
tiers have a document that genuinely classifies, and because a Form W-9 sample contains no real
person’s data the same material is safe to commit, stub offline, and send to an instance from the
end-to-end tier.

It holds the three flows described above, their custom code blocks, and a test directory per
tier.

Or start a new project from scratch, which generates the same structure, including a synthetic
end-to-end test and a working in-flow suite:

```bash
hs-flows init my_flows
```

For more information, see:

- [Introduction to Flows SDK](intro.md)
- [Command Line Interface](cli.md)
- [Examples](examples.md)
- [Source Documentation](source-docs.md)
