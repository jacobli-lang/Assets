<a id="testing-sdk-requirements"></a>

# Testing Framework — SDK Requirements

#### NOTE
**Unlisted page.** This tracks SDK and platform work the testing framework still needs, so it
describes gaps rather than features. It is absent from the navigation and from search, and is
reachable only by direct link.

A tracked list of changes the **SDK and platform** need in order for the testing
framework to deliver its full value. These are not testing-framework tasks: each
one is a gap in the SDK that the framework can work around at best, and each unlocks
a check that is otherwise impossible.

**Ordered by priority**, which here means: what is causing harm now and is cheap to fix,
then what a whole capability is blocked on, then friction that already has a workaround,
then the largest change last. Every item states what it unblocks, so the placement can be
argued with.

|   # | Item                                               | Why here                                                                                                         |
|-----|----------------------------------------------------|------------------------------------------------------------------------------------------------------------------|
|   1 | Removal of dangling SDK references                 | A live defect on every v41/v42 IDP flow, fixed by deleting one reference                                         |
|   2 | Block output contracts shipped with the blocks     | Decides how much the most-used check actually verifies. Partial today, and grows one block at a time             |
|   3 | Mocks that satisfy the `HsBlockInstance` interface | A one-line SDK change that removes a `type: ignore` from every typed CCB test in every project                   |
|   4 | A `File` input that accepts more than one file     | Parametrised in-flow testing is blocked on it (the synthetic `e2e` tier is not)                                  |
|   5 | A published CCB constraints file per release       | Makes a currently undetectable failure — an import that resolves locally and not on the instance — detectable    |
|   6 | A public API for Python package management         | Follows from the constraints file: keeps a project’s declared packages in step with the instance’s               |
|   7 | Declared outputs on every flow                     | The framework already checks it; SDK-level enforcement reaches repositories that never adopt a test suite        |
|   8 | A standard no-op / pass-through block              | Small, structural, and turns a per-project test into a lint rule                                                 |
|   9 | Engine scheduler core as an importable package     | The largest win and the largest cost. Nothing is blocked on it, so it goes last despite being the strategic item |
> * [1. Removal of dangling SDK references](#removal-of-dangling-sdk-references)
> * [2. Block contracts shipped with the blocks](#block-contracts-shipped-with-the-blocks)
> * [3. Mocks that satisfy the `HsBlockInstance` interface](#mocks-that-satisfy-the-hsblockinstance-interface)
> * [4. A `File` input that accepts more than one file](#a-file-input-that-accepts-more-than-one-file)
> * [5. A published CCB constraints file per release](#a-published-ccb-constraints-file-per-release)
> * [6. A public API for Python package management](#a-public-api-for-python-package-management)
> * [7. Declared outputs on every flow](#declared-outputs-on-every-flow)
> * [8. A standard no-op / pass-through block](#a-standard-no-op-pass-through-block)
> * [9. Engine scheduler core as an importable package](#engine-scheduler-core-as-an-importable-package)
> * [Also worth noting](#also-worth-noting)
> * [See also](#see-also)

## 1. Removal of dangling SDK references

**Status:** one known instance.

`MachineTranscriptionBlock` in `idp_v41`/`idp_v42` references
`column_transcription_target_accuracies`, which is marked `@deprecated since R40.1`
and no longer declared — so it resolves to `None` on every run of every v41/v42
flow.

The framework reports this as an ordinary `undeclared-input` on every v41/v42 flow, an issue its
author cannot fix. A project waives it with `tolerated_references`, a workaround in the consumer
rather than a fix in the SDK.

**What is needed:** drop the reference from `MachineTranscriptionBlock`.

## 2. Block contracts shipped with the blocks

**Status:** nothing shipped. `flows_sdk.testing.contracts` is a registry with no entries.

Contracts are registered by whoever owns a block, for example with
`register_block_contract_from_manifest`, which takes a block’s existing `Manifest`. Until blocks
register their contracts, path validation and required-input checking do not fire at all.

**What is needed:** each block declares its own contract alongside its definition — the block
builder is the natural owner, and the composite blocks under
`forms/form_extraction/workflows/*/block_definition.py` already declare `Manifest`s in exactly
the vocabulary the registry accepts. `flows_sdk.implementations` also ships 30 typed contract
dataclasses (`Submission`, `Document`, `Page`, …) for `register_contract_type`; what is
missing is the *link* from a block to the type it emits.

**What it unblocks:**

* **Reference-path validation for every block.** Wiring validation can currently
  prove `${bootstrap.output.submission.image_uuid}` names a nonexistent field only
  for the handful of blocks with a contract. Everywhere else it can confirm the
  block exists and nothing more.
* **A contract snapshot that can record what a flow depends on.** The golden records only a
  flow’s own declared interface. Once blocks ship contracts, what a flow reads from each block is
  available *declared* rather than inferred, which is worth recording.
* **Stub validation across the board.** Contract-based validation can only
  check stubs for blocks it has a contract for.

## 3. Mocks that satisfy the `HsBlockInstance` interface

**Status:** friction, with a workaround in every project.

`HsBlockInstance` is an ABC and `MockHsBlockInstance` does not inherit from it, so a
CCB with a typed signature rejects the mock:

```default
error: Argument 3 to "summarise_submission" has incompatible type
"MockHsBlockInstanceV2"; expected "HsBlockInstance"  [arg-type]
```

Every typed CCB test therefore carries `# type: ignore[arg-type]` — one customer
suite has them scattered through its unit tier, and the scaffolded template has to
funnel a `cast` through one helper to stay clean.

**What is needed:** either the mocks inherit from `HsBlockInstance`, or the interface
becomes a `Protocol` so structural typing accepts them.

**What it unblocks:** typed CCB tests with no per-call-site escape hatch — which matters
because `# type: ignore` on an argument suppresses *real* type errors on the same
line, not just this one.

## 4. A `File` input that accepts more than one file

**Status:** missing. It is what blocks parametrised in-flow tests.

A `File` input holds exactly one blob UUID, at every layer of the stack:

* `forms/sdm/validation/validators.py` types it as `{'type': ['string', 'null']}`, and no
  array-of-files type exists anywhere in the registry.
* `SDMBlockFilesViewSet` (`forms/sdm/views.py`) reads `request.FILES.get('file')` — one file
  per POST, returning one UUID.
* the UI widget is `WFBlockFieldFile = JsonSchemaFormField<File, UUID>` — a single UUID, with
  no `multiple` support.

This is the reason an in-flow suite cannot be parametrised the way the monorepo’s e2e tests
are. There, a test is parametrised over `(release, document, expected_output)` tuples drawn
from a manifest of S3 paths. Here the documents cannot leave the instance, so they arrive as
configured wrapper inputs — and a wrapper can hold exactly one. Covering N documents therefore
means N wrapper flows, each hand-configured.

The synthetic `e2e` tier does not have this problem: its documents live in git, so a test
parametrises over them with ordinary `pytest.mark.parametrize`. The limit bites only where the
documents must stay on the instance — customer data, in the in-flow tier.

The available workaround is worse than the problem. Two parallel `array` inputs — one of blob
UUIDs, one of expected results — deploys and runs, because `array` is a valid type. But an
operator would have to upload each document elsewhere to obtain its UUID, paste the UUIDs into
a textarea as JSON, and keep index alignment with a second array by hand. There is no file
picker, no check that a UUID exists, and an off-by-one in either list silently mispairs every
case.

**What is needed:** a `File` input that accepts multiple files (or a `FileList` type),
with a UI picker that returns a list of UUIDs.

**What it unblocks:** two distinct things, worth separating.

1. *Parametrised suites.* One wrapper holding a list of documents, with the suite flow doing a
   `Foreach` over it — so adding a case is attaching a file rather than authoring a flow.
2. *Multi-document submissions as a single input.* A test whose subject is a submission
   containing several files — the case a collation or splitting flow exists to handle — cannot
   be expressed at all today, because the input surface cannot carry more than one document.

Note that (1) also needs framework support for per-run inputs: `InFlowTestSuite.run_suite`
currently triggers with `input={}` and its `suite_results` fixture is class-scoped, so the
wrapper runs once per class. The platform side is ready — run input is merged over the flow’s
own, run input winning (`forms/sdm/utils.py`) — and the client already accepts an `input`
argument.

## 5. A published CCB constraints file per release

**Status:** missing.

Custom code blocks run in the developer’s interpreter offline but in a container
with its own installed package set in production, so a CCB importing a library that
happens to be installed locally passes every offline tier and fails on its first
real run. This is the largest remaining fidelity gap, and it cannot be closed from
outside the platform build.

**What is needed:** each release publishes the wheel-set its CCB sandbox provides.

**What it unblocks:** wiring validation flags a CCB import that will not resolve in
production, moving the failure from a real run to a second of static analysis in the
contract tier.

### Custom Python packages make this worse

A flow’s custom code may also import packages the *customer* uploaded to the instance and made
available to its code blocks. Those are not in the sandbox’s base wheel-set and are not
installed on a developer’s machine either, so a unit test importing one fails locally for a
reason that has nothing to do with the code being tested.

Until the gap below closes, the recommendation is to **stand up a test environment that installs
the same third-party packages the instance provides, and run the unit tier there.** A requirements file checked in beside the flow, applied in CI and locally, keeps the two
in step.

## 6. A public API for Python package management

**Status:** missing. Needed before the framework can be fully realised.

Packages are managed today through endpoints on the internal surface
(`/api/python_packages`, `.../install`, `.../download_requirements`,
`.../supported_python_versions`), gated behind `ViewFlowsPermission | BlockApiUserPermission`
and absent from the public v5 API. There is no supported way for a test harness to ask an
instance which packages its code blocks can import, or to reproduce that set elsewhere.

**What is needed:** a public, documented API to list the packages installed for a given Python
version — and ideally to install them — on the same footing as the rest of the v5 surface.

**What it unblocks:** three things that are all currently manual. A test environment could be
provisioned *from the instance* rather than from a hand-maintained requirements file that drifts.
Wiring validation could resolve a CCB’s imports against base wheel-set **plus** customer
packages, instead of flagging false positives or missing real ones. And an in-flow suite could assert that
the packages a flow depends on are actually present before its blocks fail at run time.

## 7. Declared outputs on every flow

**Status:** supported by the SDK, not enforced.

`Manifest(output=[Parameter(...)])` exists and is typed, but nothing requires it.
A flow can map `output={'submission': ...}` while declaring nothing, leaving
callers to read the source. Of the four flows in one customer use case, three
map outputs they never declare.

**What is needed:** enforcement. `FlowStaticChecksSuite.test_flow_interface` now
checks this, plus the integrity rule that the runtime mapping and the declared
outputs agree, but a check only helps a repository that adopts it.

**What it unblocks:** an SDK-level warning at flow construction, so a flow with an
undocumented return value cannot ship even in a repository that has not adopted the
contract tier.

## 8. A standard no-op / pass-through block

**Status:** missing.

Every `Routing` default branch needs a block that forwards its input unchanged.
Flows hand-roll one, so a repository accumulates several near-identical
`_pass_submission` functions, each of which could quietly start transforming data.
One customer core flow has five call sites of one such helper.

**What is needed:** a `PassThroughBlock` (or equivalent) in the SDK.

**What it unblocks:** a lint rule that rejects a hand-rolled pass-through, which is
better than a test asserting that a project’s five copies still agree — the check
becomes structural rather than per-project.

## 9. Engine scheduler core as an importable package

**Status:** not started. The strategic item.

`FlowTestRunner` is a second implementation of the engine’s semantics, kept honest
only by `tests/test_flow_runner_fidelity.py`. Every mature orchestrator instead
tests by running the *real* engine with stubbed leaf executors — Temporal (stubbed
activities plus `Replayer`), Prefect (`prefect_test_harness()`), Dagster (mocked IO
managers).

**What is needed:** the engine’s scheduler core — rendered JSON in, reference
resolution and control flow out, no server infrastructure — extracted as a
pip-installable executor with block execution behind an interface.

**What it unblocks:** one implementation of flow semantics instead of two, so the offline
tier inherits engine changes rather than chasing them, and graph coverage as free
instrumentation.

Note the usual companion — replaying recorded production runs as a drift detector — is
not available here, because a recorded run of a customer flow is customer data. Drift
against real data is detected on the instance instead, by the in-flow tier.

## Also worth noting

* **`save_response` cannot report its own failure.** Completing a supervision task returns
  `200 {"OK": true}` even when the response was *silently discarded* — a task that does not
  exist, or one already completed (`tasks/api.py` returns `True` on both paths, and
  `views.py` drops the `task_response_id` that would tell them apart). A caller cannot
  distinguish success from a no-op, so the framework re-reads the pending queue to confirm.
  **What is needed:** a distinct status, or the `task_response_id` in the body.
* **Supervision task completion has no public API.** The framework uses the internal
  `/api/tasks/{uuid}/save_response`, and the identity problem below is the reason it needs a
  token at all.
* **Custom code cannot complete supervision tasks as itself.** It runs under an internal
  service identity that holds none of the twelve `complete_*_tasks` permissions, so an in-flow
  test acting as itself is refused with a 403.
  Every in-flow suite that covers a supervision path therefore has to carry a worker’s token as a
  flow input. The synthetic `e2e` tier sidesteps it — the test completes the task from outside,
  as its own credential — which is one reason supervision paths belong there. **What it would
  unblock:** in-flow supervision tests with no credential to distribute or rotate. Whether to grant that permission to all custom code is a platform decision with a
  wide blast radius — noted here as the constraint that shapes the current design, not as a
  recommendation.
* **A supervision task’s fields do not carry their names.** `input_payload.fields[i]` has a
  `template_field_uuid` but no name; the name lives in a sibling `template_fields` list. Any
  caller wanting to set “the Name field” must resolve that join itself, and getting it wrong
  fails *silently* — the machine’s own reading is submitted and the test still passes. **What is
  needed:** the field name alongside the field, or an explicit error for an unmatched uuid.
* **A submission’s flow run is only reachable via an undiscoverable query parameter.**
  `GET /api/v5/submissions/<id>?debug=true` returns `flow_run_id` and `correlation_id`,
  added for exactly this purpose (“@since 37.0.0” on `DebugSubmissionAPISerializer`). Without
  `debug=true` both fields are simply absent rather than documented as conditional, so the link
  looks like it does not exist. The obvious alternative,
  `/api/submissions/<id>/flow_run`, requires `ViewFlowsPermission`, which
  the custom-code identity lacks, so a block gets 403. **What is needed:** surface these fields
  unconditionally, or document the parameter on the non-debug response.
* **The submissions API silently ignores unknown keys.** Creating a submission takes
  `flow_uuid`; there is no `identifier` field. Posting `{'identifier': 'MY_FLOW'}` is
  accepted and runs the instance’s *default* flow, so a test can pass while asserting against a
  completely different flow. **What is needed:** reject unknown fields, or accept an identifier.
* **The flow-runs list is oldest-first.** `/api/v5/flow_runs?limit=N` returns the *oldest* N,
  so on an instance with any history the run just created is never in the first page.
  `sort=-dt_started` is required and easy to omit.
* **There is no “integration” tier.** Tests that hit one real external system
  without a full flow run (the Microsoft Graph email test in one customer use
  case) sit in `e2e`. They use synthetic data against a real system, which is what
  that tier is for, though they need no Hyperscience instance and exercise no
  deployed flow. Revisit if the pattern spreads.
* **A `Foreach` reports as one aggregate block.** The API reports a `Foreach` as a
  single entry with the loop’s combined output, not one entry per concrete iteration
  (`identify_0`, `identify_1`, …) — whereas the offline runner does use those
  concrete names. So a per-block assertion written against offline names will not match
  on a real run, which is why the in-flow helpers match block references by prefix.
* **Contract snapshots cannot see subflow interfaces.** A flow calling a subflow
  records only its identifier, so a breaking change to the subflow’s inputs is
  invisible until run time. Shipping block output contracts fixes this for platform blocks; subflows need
  the same treatment, since they are the same mechanism.

## See also

- [Getting Started with Testing Flows](testing_getting_started.md#testing-getting-started) — how the framework is applied, step by step
