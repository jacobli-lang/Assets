<a id="testing-design"></a>

# Testing Framework — Design & Roadmap

#### NOTE
**Unlisted page.** This is design rationale and roadmap, not a user guide. It is absent from the
navigation and from search, and is reachable only by direct link.

This page covers what each tier can and cannot prove, which tools were adopted or built, and what
is still to come. The key section is [Fidelity: what each tier can actually prove](#fidelity-what-each-tier-can-actually-prove).

#### SEE ALSO
SDK-side gaps this framework depends on are tracked in
[Testing Framework — SDK Requirements](testing_sdk_requirements.md#testing-sdk-requirements) — block output contracts, a standard no-op block,
enforced flow outputs, and a published CCB constraints file.

#### SEE ALSO
For how this is applied step by step — setting up a repository, the tests to write, and what
to run after a given change — see [Getting Started with Testing Flows](testing_getting_started.md#testing-getting-started). For the API reference of each
tier, see [Testing Flows](testing.md#testing-flows).

> * [The shape of the problem](#the-shape-of-the-problem)
> * [The pyramid](#the-pyramid)
> * [Fidelity: what each tier can actually prove](#fidelity-what-each-tier-can-actually-prove)
>   * [Reference resolution](#reference-resolution)
>   * [Known remaining gaps](#known-remaining-gaps)
> * [Snapshots pin the contract, not the definition](#snapshots-pin-the-contract-not-the-definition)
> * [Static wiring validation](#static-wiring-validation)
> * [Block contracts](#block-contracts)
>   * [The SDK ships a registry, not contracts](#the-sdk-ships-a-registry-not-contracts)
> * [Real data without holding real data](#real-data-without-holding-real-data)
> * [Tooling: build vs adopt](#tooling-build-vs-adopt)
>   * [One command for config: `hs-flows update`](#one-command-for-config-hs-flows-update)
> * [Roadmap](#roadmap)
>   * [Where evals must run](#where-evals-must-run)
>   * [The longer-term architecture](#the-longer-term-architecture)
> * [Eval testing (proposal, not built)](#eval-testing-proposal-not-built)
>   * [What is actually being evaluated](#what-is-actually-being-evaluated)
>   * [Dataset and cases](#dataset-and-cases)
>   * [Graders](#graders)
>   * [Thresholds and baselines](#thresholds-and-baselines)
>   * [Non-determinism](#non-determinism)
>   * [Where each eval tier would run](#where-each-eval-tier-would-run)
>   * [What is left](#what-is-left)
> * [See also](#see-also)

## The shape of the problem

A flow is a graph of blocks. Some are **platform blocks** (ML/IDP tasks, integrations)
that only exist server-side; some are **custom code blocks** (CCBs) — your Python,
executed in a sandboxed container. Testing a flow therefore means testing three
different things, and conflating them is the main way flow test suites go wrong:


```mermaid
flowchart LR
    subgraph Y["Yours to test"]
        L["Business logic<br/><i>pure functions</i>"]
        W["Wiring<br/><i>${refs} between blocks</i>"]
    end
    subgraph O["Ours to test"]
        P["Platform block behaviour"]
        M["Model quality"]
    end
    L --> W
    W -.->|"depends on"| P
    P -.->|"depends on"| M

    classDef yours fill:#dcfce7,stroke:#16a34a,color:#14532d
    classDef ours fill:#f1f5f9,stroke:#94a3b8,color:#334155
    class L,W yours
    class P,M ours
```

Your suite should prove the green boxes exhaustively and *assume* the grey ones. The
offline tiers exist to make that separation cheap.

## The pyramid


```mermaid
flowchart TD
    I["<b>in_flow</b> — customer data; tests that <i>are</i> flows, on the customer's instance<br/><i>very few, slow, only what synthetic data cannot answer</i>"]
    E["<b>e2e</b> — synthetic data; pytest driving a live instance through HsClient<br/><i>a few, slow, highest fidelity for behaviour</i>"]
    F["<b>flow-graph</b> — whole graph offline, FlowTestRunner"]
    C["<b>contract</b> — flow contract snapshot"]
    W["<b>wiring</b> — every reference, no stubs<br/><i>FlowStaticChecksSuite</i>"]
    U["<b>unit</b> — pure functions, plain pytest<br/><i>many, fast, deterministic</i>"]

    I --> E --> F --> C --> W --> U

    classDef customer fill:#fee2e2,stroke:#dc2626,color:#7f1d1d
    classDef live fill:#fef3c7,stroke:#d97706,color:#78350f
    classDef offline fill:#dbeafe,stroke:#2563eb,color:#1e3a8a
    classDef fast fill:#dcfce7,stroke:#16a34a,color:#14532d
    class I customer
    class E live
    class F offline
    class C,W,U fast
```

The bottom two tiers are the cheapest and, for wiring bugs, the highest-yield: they
need no stubs at all. Run the fast tiers on every PR, the synthetic `e2e` tier in development CI
against a development instance, and `in_flow` where the customer’s data lives:

```bash
pytest -m "not e2e and not in_flow"                 # offline, every PR
pytest -m e2e                                       # CI, against a development instance
pytest -m in_flow                                   # on the customer's instance, on demand
```

The two live tiers are split by **whose data they use**, and that one distinction decides
everything else about them. A synthetic document belongs to the team: it lives in git, travels to
any instance, and can be asserted on value by value — so an `e2e` test is an ordinary local process
driving the instance over HTTP, with none of the restrictions below. A customer’s document carries
PII, so a test on it cannot be a local process at all: an `in_flow` test is a flow, deployed
alongside the flow it tests, asserting from inside, reporting back only whether it passed.

Most of what a flow does is behaviour — completion, routing, supervision, how it uses the knowledge
store and external systems — and synthetic data exercises all of it. So the pyramid narrows sharply
at the top: `in_flow` is reserved for evaluation, questions like *is extraction accurate on what this
customer actually sends?*, which no made-up document can answer.

<a id="fidelity-what-each-tier-can-actually-prove"></a>

## Fidelity: what each tier can actually prove

`FlowTestRunner` executes flows **offline**, so it is a second implementation of the platform
engine’s semantics. That has a hard consequence:

#### WARNING
An offline tier that is **more permissive** than production is worse than no tier at
all, because it converts “this flow is broken” into a passing test. Every divergence below is
therefore either removed or surfaced.

The runner is pinned against the engine’s real behaviour by
`tests/test_flow_runner_fidelity.py`. Those tests are the contract; treat a change
that requires editing them as a change that needs justifying.

### Reference resolution

Wiring bugs are the single most common flow defect, so this is where fidelity matters
most. The engine distinguishes two cases, and so does the runner:

| Situation                                                             | Platform engine                      | `FlowTestRunner`                  |
|-----------------------------------------------------------------------|--------------------------------------|-----------------------------------|
| Reference to an unknown / not-yet-run block                           | raises `PopulateParametersException` | raises `ReferenceResolutionError` |
| Path walks *through* a scalar (`a.b.c` where `b` is `5`)              | raises                               | raises                            |
| Dotted segment used to index a list (`items.0`)                       | raises                               | raises                            |
| Path into a `None` output (`n.output.x` where the output is `None`)   | raises                               | raises                            |
| Block reference with no `input`/`output` segment (`boot.submission`)  | raises                               | raises                            |
| `Foreach` over items that are not a list (a string, a number, a dict) | fails the task                       | raises `EngineTaskFailure`        |
| `Foreach` whose iterations do not each get a name of their own        | fails the task                       | raises `EngineTaskFailure`        |
| Missing **key** on a block that did run                               | resolves to `None`                   | resolves to `None`, **recorded**  |
| Reference embedded in a longer string                                 | interpolated, `None` → `'null'`      | same                              |

The missing-key row is the subtle one. The platform tolerates a missing key, so the
runner must too — but it is nearly always a typo or a stub that does not match the
real output shape, and a defensively written block swallows it:

```python
def validate(line_item_total, expected_total):
    total = line_item_total or 0.0   # <-- a broken reference becomes 0.0, silently
    ...
```

So the runner records them and lets you assert:

```python
runner.run()
runner.assert_no_unresolved_references()
```

#### TIP
Add `runner.assert_no_unresolved_references()` to every flow-graph test. It is the
cheapest guard against the highest-frequency class of flow bug.

### Known remaining gaps

Being explicit about what the offline tier does **not** model:

| Not modelled                        | Why it matters                                | Cover it with    |
|-------------------------------------|-----------------------------------------------|------------------|
| Retries, timeouts, `on_error` flows | error paths are untested offline              | `e2e`            |
| CCB sandbox wheel-set               | `import pandas` passes locally, fails in prod | `e2e`; see below |
| Block output *shapes*               | a stub can describe a block that cannot exist | contracts, `e2e` |
| Model quality                       | stubs assert nothing about ML accuracy        | evals (proposed) |
| Parallelism / ordering              | Fork branches run sequentially offline        | `e2e`            |

#### CAUTION
CCBs run in your local virtual environment offline, but in production they run in a
container with its own installed package set. A CCB importing a library that happens to be
in your dev environment will pass every offline tier and fail on the first real run. Until the SDK
ships a per-release constraints file, treat third-party imports in CCBs as `e2e`-only
risk.

## Snapshots pin the contract, not the definition

A flow definition is an *implementation*, not an interface document. Titles,
descriptions, literal input values and custom-code bodies all change constantly
and legitimately. A golden that moves on every edit gets refreshed without being read, and a
golden nobody reads is worse than none.

So the snapshot pins only what a **consumer of the flow can observe**:


```mermaid
flowchart LR
    A["Flow.render()"] --> B["extract contract"]
    B --> K1["identifier"]
    B --> K2["roles"]
    B --> K3["declared inputs<br/><i>name, type, optional</i>"]
    B --> K4["declared outputs<br/><i>name, type, optional</i>"]

    X["excluded: everything about blocks,<br/>titles, descriptions, literal values,<br/>code bodies, the flow-level output<br/>mapping, uuid, sdk_version"]

    classDef keep fill:#dcfce7,stroke:#16a34a,color:#14532d
    classDef drop fill:#f1f5f9,stroke:#94a3b8,color:#334155
    class K1,K2,K3,K4 keep
    class X drop
```

The snapshot is four keys — `identifier`, `roles`, `inputs`, `outputs` — and nothing
else. Inputs and outputs are each recorded as `{name, type, optional}`, spelled the
same way in both sections because it is the same `Parameter.optional` field: whether a
consumer reading `${flow.output.x}` can rely on `x` being there is part of the
signature, so flipping an output to optional moves the golden even though every name
and type is unchanged.

Inputs also record `has_default`. A caller may leave out an input that has a default, so
giving an input one, or dropping it, changes what every caller must pass. The default’s
value is not recorded: it is configuration, like a literal block parameter, and recording it
would move the golden whenever a setting is tuned. Whether a changed default changes
behaviour is for the flow-graph and live tiers to assert.

Why each included item is contractual: the **identifier** is how the flow is deployed,
triggered and called as a subflow; **roles** decide where it can be deployed and what it
can be selected in place of (`IDPCoreBlock` filters on `idp_core`, so a core that loses
that role stops being selectable); and **inputs and outputs** are its typed signature,
where a rename invalidates the saved configuration on every deployed instance.

Nothing about the flow’s **blocks** is recorded: that would make the golden a snapshot of the
whole flow definition again. Wiring bugs are caught by `validate_flow_wiring` and the flow tier,
which name the broken reference instead of showing a diff to interpret.

The result behaves the way a contract test should:

| Change                                                    | Snapshot   |
|-----------------------------------------------------------|------------|
| renamed, added or dropped input or output                 | **moves**  |
| an input or output becoming optional                      | **moves**  |
| changed identifier or roles                               | **moves**  |
| renamed block, re-pointed reference, renamed routing case | unchanged  |
| flow title or description                                 | unchanged  |
| literal `code_input` value (`0.2` → `0.9`)                | unchanged  |
| re-plumbing two of the flow’s own blocks                  | unchanged  |
| custom-code body                                          | unchanged  |
| SDK upgrade or interpreter change                         | unchanged  |

Behaviour changes are covered by unit and flow-graph tests, which is where they
belong — a golden file is a poor place to notice that arithmetic changed.

One more property: **a missing golden file fails.** Writing-and-passing would mean
an uncommitted snapshot silently succeeds in a fresh CI checkout.

Refresh deliberately after an intended contract change:

```bash
UPDATE_SNAPSHOTS=1 pytest
```

## Static wiring validation

The flow-graph tier catches wiring bugs, but only once every platform block has a
stub — and across the SDK’s own sample flows there are 43 custom code blocks
against 207 platform blocks, with 40 of 61 flows containing no custom code at all.
For most real flows, writing stubs *is* the work.

So reference validation is also available with no stubs and no execution, by
walking the rendered definition:


```mermaid
flowchart TD
    R["rendered flow JSON"] --> P["collect blocks in<br/>declaration order"]
    P --> V["for every ${...} reference"]
    V --> C1{"block exists?"}
    C1 -->|no| E1["unknown-block"]
    C1 -->|yes| C2{"declared before<br/>the consumer?"}
    C2 -->|no| E2["forward-reference"]
    C2 -->|yes| C3{"contract known<br/>for that block?"}
    C3 -->|no| OK["accept<br/><i>path unverifiable</i>"]
    C3 -->|yes| C4{"path exists<br/>in contract?"}
    C4 -->|no| E3["unknown-output-path"]
    C4 -->|yes| OK

    classDef bad fill:#fee2e2,stroke:#dc2626,color:#7f1d1d
    classDef good fill:#dcfce7,stroke:#16a34a,color:#14532d
    class E1,E2,E3 bad
    class OK good
```

Plus undeclared workflow inputs, references to a `workflow.` scope that does not exist
(the segment must be one of `input`, `variables`, `definition` or `run`), block references
with no `input` or `output` segment, a value holding more than one reference (the engine
resolves one per value), references into a sibling `Fork` branch (the branches run in parallel),
misused `Foreach` loop variables, unused `code_input` keys, and subflow calls missing a required
input. Projects get this by giving each flow a `FlowStaticChecksSuite` subclass, whose
`test_flow_wiring` runs it, so `pytest -m contract` covers CI. The same suite checks that every
`PythonBlock` in a flow runs on one Python version.

Against the SDK’s own samples, 58 of 61 shipped flows pass. The other three share one defect:
`idp_core_flow_v41`/`v42` reference `column_transcription_target_accuracies`, which is deprecated
since R40.1 and not in the manifest, so it resolves to `None` at runtime.

## Block contracts

Every offline tier shares one blind spot: **a stub is an unvalidated assertion
about a block you did not write.** Stub `{'submission': {'image_uuid': 'img-42'}}`
and every test built on it is green — while `Submission` has no `image_uuid` field,
so on a real run that reference resolves to `None`.

The SDK already ships typed dataclasses for the platform’s core objects
(`Submission`, `Document`, `Page`, `Entity`, … — 30 of them under
`flows_sdk.implementations.idp_v43.contracts`). Mapping *block identifiers* to those types
unlocks two checks that are otherwise impossible offline:

1. **Reference paths** — wiring validation can tell that
   `${bootstrap.output.submission.image_uuid}` names a field that does not exist,
   statically.
2. **Stub plausibility** — the wiring check rejects a stub whose
   keys the block cannot emit.

A contract does not make a stub: a stub has to carry data the next block can consume, which type
placeholders do not.

### The SDK ships a registry, not contracts

`flows_sdk.testing.contracts` exposes registration and lookup; it ships no block specs, because
a hand transcription of a block’s outputs fails in three ways:

* a transcription is a copy of the truth, and drifts the moment the block changes;
* it is wrong for anyone on an IDP version other than the one transcribed;
* a *wrong* contract is worse than a missing one — it produces false failures and erodes
  trust in the whole check.

Instead, whoever owns a block registers its contract, expressed as `Parameter` lists — the
same vocabulary the block’s `Manifest` already uses. The platform’s composite blocks in
`forms/form_extraction/workflows/*/block_definition.py` declare their manifests that way
today, so `register_block_contract_from_manifest(manifest)` takes one directly, with no
transcription step to drift.

**Out of the box nothing is registered, so path validation and required-input checking are
inert until a caller registers something.** The gap is safe because of how the checks degrade:

* an **unregistered** identifier is never an error — validation is skipped;
* therefore registering a contract can only ever *find* bugs, never invent them;
* coverage grows one block at a time, with no migration and no flag day.

#### CAUTION
“No wiring issues” must not be read as “all references verified”. For a block with no
registered contract the framework knows the block exists, not what it emits.

The open question this leaves is whether the SDK should ship an opt-in
`register_idp_v43_contracts()` so a v43 project gets coverage without writing the
registrations itself. That is a small addition on top of the registry, not a change to it.

## Real data without holding real data

The constraint: flows process PII-heavy customer documents. We want tests against real
data, but **real data cannot be committed, and must not leave the customer’s trust
boundary — not even into the memory of a developer’s test process.**

That last clause is what shapes the architecture. If a test may not bring the data out,
then the test goes in: the in-flow tier is compiled to flows and deployed, so the
assertions execute where the data already lives.

The constraint is about customer data, and only customer data. Synthetic data — documents and
records made up for the purpose — is bound by none of it, so the tier below, `e2e`, is an ordinary
pytest process that sends synthetic data to a development instance and asserts on the result
directly. That split is what keeps the in-flow tier small: everything that does not genuinely need
a customer’s documents is tested without them.


```mermaid
flowchart TB
    subgraph VC["Version control (PII-free only)"]
        SY["Synthetic fixtures"]
        TL["Test <i>logic</i><br/><i>core test flows — which fields<br/>matter, not what they equal</i>"]
    end
    subgraph CB["Customer trust boundary"]
        WR["Wrapper flow inputs<br/><i>documents + reference results,<br/>configured by a human</i>"]
        RD[("Real runs<br/><i>PII</i>")]
        CT["Core test flow, executing<br/><i>full-detail assertions in block logs</i>"]
        WR --> CT
        CT --> RD
        RD --> CT
    end
    subgraph DC["Central / dev CI"]
        OT["Offline tiers<br/><i>synthetic stubs</i>"]
        E2["e2e tier<br/><i>synthetic data, HsClient,<br/>a development instance</i>"]
        ST["pytest<br/><i>pass/fail + a URL</i>"]
    end
    TL --> OT
    SY --> OT
    SY --> E2
    TL -->|"uploaded as a flow"| CT
    CT -->|"status only"| ST

    classDef pii fill:#fee2e2,stroke:#dc2626,color:#7f1d1d
    classDef safe fill:#dcfce7,stroke:#16a34a,color:#14532d
    classDef ci fill:#dbeafe,stroke:#2563eb,color:#1e3a8a
    class RD,WR,CT pii
    class SY,TL safe
    class OT,E2,ST ci
```

Rules that follow from this:

1. **Committed artifacts are PII-free by construction** — synthetic fixtures, and test
   logic that names fields and references inputs rather than embedding values.
2. **Real data is never materialized outside the instance** — not on disk, not in a
   developer’s process. Test data is configured once as flow inputs by someone who is
   already entitled to see it.
3. **Only pass/fail crosses the boundary.** The assertions themselves may hold anything,
   because their output stays in block logs inside the environment.
4. **No encrypted customer data in git** — it moves the problem to key management. Redaction is a
   local aid, not a commit path: committing requires values to be synthetic, not masked.

The cost: an in-flow test needs a reachable instance and a configured wrapper flow, so it cannot
run from a laptop against a copy of production data. The synthetic `e2e` tier bounds that cost: a
test that can use a made-up document runs in CI, from a laptop, anywhere.

Output is not filtered on the way out instead: no filter over it can be trusted, since transcribed
field values appear as JSON keys and a denylist matches the framework’s own vocabulary. So the data
stays where it may be printed.

## Tooling: build vs adopt

Each decision below was made against two constraints: customers install a **plain
pip wheel**, and tests must run **fully offline**. Dependency weight and license were
checked directly against package metadata rather than reputation.

| Area                | Decision                                  | Rationale                                                                                                                          |
|---------------------|-------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------|
| Snapshots           | **built** — `assert_flow_snapshot`        | ~40 lines of `json` + `difflib`, no dependency: the golden is a four-key contract, not an arbitrary object                         |
| JSON diffing        | adopt `deepdiff` *if needed*              | only mature ignore-subtree differ; no mandatory deps                                                                               |
| Data expectations   | **defer** `pandera`                       | 5 core deps, pandas behind an extra; expectations are configured on the instance, so nothing needs it                              |
| Eval metrics        | **build** on `scikit-learn`  *(proposed)* | field-level F1 / accuracy is not first-class in any eval framework                                                                 |
| Synthetic values    | **adopt** `mimesis`                       | zero runtime deps                                                                                                                  |
| Scaffolding         | **build** `hs-flows init`                 | Copier/cruft `update` requires a reachable template repo                                                                           |
| Config distribution | **build** `hs-flows update`               | one command for all three tools; see below                                                                                         |
| Graph coverage      | **not built**                             | line coverage over the functions package does the job — see [5. See what your tests cover](testing_getting_started.md#gs-coverage) |

Rejected:

| Rejected                       | Reason                                                                                                  |
|--------------------------------|---------------------------------------------------------------------------------------------------------|
| Great Expectations             | 22 core deps (pandas, numpy, altair, cryptography, mistune). Unshippable in a customer-installed SDK.   |
| Soda Core                      | Actively released, but PyPI declares the license **Proprietary**.                                       |
| SDV                            | **BUSL-1.1**; the Additional Use Grant restricts synthetic-data-service use.                            |
| promptfoo                      | Node/npm CLI — incompatible with a pip-only story.                                                      |
| Langfuse (self-host)           | Requires Postgres + ClickHouse + Redis + blob storage.                                                  |
| Inspect AI (as a customer dep) | Well-governed and MIT, but 40 core deps incl. `boto3`, `fastapi`, `uvicorn`. Fine internally.           |
| whylogs                        | Conceptually ideal for PII-free profiles, but last released 2024-12 and depends on a vendor API client. |
| Copier / cruft                 | `update` clones the template repo; customers cannot reach our git host.                                 |

### One command for config: `hs-flows update`

Three tools, three different mechanisms, but a single command:

| Tool   | Mechanism                                                                        | Why                                                                                                                              |
|--------|----------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------|
| pytest | `-p flows_sdk.testing.plugin` in the project’s `addopts`, written by `init`      | an entry point would load the plugin into every pytest run of anyone with the SDK installed                                      |
| ruff   | `extend = ".flows-sdk/ruff.toml"` — a copy in the project, referenced relatively | `extend` takes only a path; a relative one needs nothing exported, so a fresh clone lints                                        |
| mypy   | settings written inline into `[tool.mypy]`                                       | mypy refuses config inheritance *and* silently ignores a `config_file` key inside a config file, so there is nothing to point at |

`hs-flows update` overwrites the SDK-owned files from the versions bundled in the
wheel. No merge engine, no git, no network — the SDK version *is* the rules
version. Everything is reachable through one command, so upgrading is
`pip install -U flows_sdk && hs-flows update`.

On a freshly scaffolded project `ruff check .`, `ruff format --check .`, `mypy .` and `pytest`
all pass with no exported variables and no extra flags; the SDK’s own suite runs them to check.
The copy at `.flows-sdk/mypy.ini` stays the canonical reference for mypy’s inline block, and a test
asserts the two agree.

There are no `hs-flows lint`, `format` or `typecheck` commands: projects run `ruff`, `mypy` and
`pytest` directly.

#### NOTE
Synthetic document generation is good for **coverage and regression**, not for
absolute accuracy gates: current approaches under-model OCR noise and layout
degradation, which is exactly what moves extraction scores. Accuracy numbers must come
from a real holdout that never leaves the customer network.

## Roadmap


```mermaid
flowchart LR
    P0["<b>Offline tiers</b><br/>wiring validation, contract snapshots,<br/>engine-fidelity runner, block contracts"]
    P1["<b>Tooling + structure</b><br/>hs-flows init / update<br/>canonical lint/type/test config"]
    P2["<b>PII-safe test data</b><br/>synthetic e2e + in-flow tests"]
    P3["<b>Eval testing</b><br/>graders, thresholds,<br/>baselines"]
    P0 --> P1 --> P2 --> P3

    CC["<b>Contract coverage</b><br/>declare outputs alongside blocks<br/><i>SDK-side, parallel track</i>"]
    SC["<b>Extract the scheduler core</b><br/>one implementation of flow semantics<br/><i>platform-side, see below</i>"]

    classDef done fill:#dcfce7,stroke:#16a34a,color:#14532d
    classDef next fill:#fef9c3,stroke:#ca8a04,color:#713f12
    classDef side fill:#e0e7ff,stroke:#4f46e5,color:#312e81
    class P0,P1,P2 done
    class P3 next
    class CC,SC side
```

PII-safe test data came before evals, because evals need somewhere for their data to live before
they need graders. **Eval testing is the only remaining phase, and it is still a proposal** — worth
confirming there is demand for it before building graders and baselines.

Two items sit to one side because neither is this framework’s work.

**Contract coverage** needs block authors to declare outputs alongside the block
definition (see [Testing Framework — SDK Requirements](testing_sdk_requirements.md#testing-sdk-requirements)). **Extracting the scheduler core** is the
platform change that would remove the offline runner’s second implementation of flow semantics;
see below.

### Where evals must run

#### IMPORTANT
The offline tier **stubs the block being evaluated**, so its accuracy is whatever the
stub says. Offline evals validate graders and wiring — never model quality. Model
quality is measurable only against real inference, and ground truth is customer data, so
by the same argument as the in-flow tier an eval should run **as a flow on the
instance** with its dataset configured as a wrapper input. An eval over a *synthetic* dataset
is just an `e2e` test, and has none of these constraints.

### The longer-term architecture

Mature orchestrators agree on how to test workflows offline:

| Orchestrator   | How it tests workflows offline                                                |
|----------------|-------------------------------------------------------------------------------|
| Temporal       | real engine, **stubbed activities**; `Replayer` against recorded history      |
| Prefect        | `prefect_test_harness()` — real ephemeral API                                 |
| Dagster        | real execution, mocked IO managers                                            |
| Airflow        | `dag.test()` runs tasks locally without an executor — the weakest of the four |

All of them run the *real* engine with stubbed leaf executors. None reimplements
engine semantics in a test harness. The strategic direction is therefore to extract
the engine’s **scheduler core** — rendered JSON in, reference resolution and
control-flow semantics out, no server infrastructure — as a pip-installable executor,
with block execution as a pluggable interface. Then there is **one** implementation of
flow semantics instead of two, and the offline tier inherits engine changes rather than
chasing them.

Note that the usual companion to this — Temporal’s `Replayer`, replaying recorded
production histories as a drift detector — is **not** available here, because a recorded
history of a customer flow run is customer data. Drift against real data is detected on
the instance by the in-flow tier instead.

Until the scheduler core lands, `tests/test_flow_runner_fidelity.py` is what keeps the
two implementations honest.

## Eval testing (proposal, not built)

Nothing in this part is built. It is a specification: the containment problem it depends on is
solved, so it is buildable.

### What is actually being evaluated

Two different things, routinely conflated:

1. **Deterministic extraction quality** — did the flow pull the right field values?
   Measured with precision / recall / F1 per field, and classification accuracy for
   layout assignment. This is the bulk of the need.
2. **Non-deterministic model output** — ORCA, and flows calling external LLMs (Gemini).
   Same run, different answer. Needs sampling and tolerances.

#### IMPORTANT
The offline tier **stubs the block being evaluated**, so its accuracy is whatever the
stub says. Offline evals can validate graders and wiring; they cannot measure model
quality. Evals therefore live next to `HsClient`, not `FlowTestRunner` — and that is a
structural fact, not a preference.

### Dataset and cases

```python
@dataclass
class EvalCase:
    case_id: str                  # stable, opaque
    flow_input: dict              # what to submit
    expected: dict                # ground truth: {field_name: value}
    tags: set[str]                # 'us', 'emea', 'multi_page', ...
```

Ground truth **is** customer data — a real invoice’s true total — so a dataset cannot be
committed, and by part 1’s logic it should not be fetched to a laptop either. The natural home
is therefore the one the in-flow tests already use: **a dataset is configured on a wrapper flow
as a `File` input**, and the eval runs on the instance like any other in-flow test. The
`EvalCase` shape above is what that file contains, not what a repository holds.

This is the part of the proposal most likely to need rework, because it puts the grader math
inside a CCB rather than in the pytest process — and the graders are where the third-party
dependency below wants to live.

### Graders

```python
class Grader(Protocol):
    def __call__(self, expected: Any, actual: Any) -> GradeResult: ...
```

| Grader                        | For                                                        |
|-------------------------------|------------------------------------------------------------|
| `exact_match`                 | codes, identifiers                                         |
| `numeric_tolerance(rel, abs)` | amounts — `1234.50` vs `1234.5` must pass                  |
| `normalized_string`           | case, whitespace, punctuation differences                  |
| `field_level_f1`              | the headline IDP metric: per-field P/R/F1 across a dataset |
| `classification_accuracy`     | layout assignment                                          |
| `llm_judge(backend)`          | only where nothing deterministic applies                   |

**Build on `scikit-learn` for the metric math** (`precision_recall_fscore_support`) and
hand-roll the harness. Every eval framework surveyed is LLM-judge-shaped, telemetry-on-by-default,
or dependency-heavy — `DeepEval`,
`Ragas`, `promptfoo` (npm), `Langfuse` (needs Postgres + ClickHouse + Redis),
`Inspect AI` (40 core deps). None ships field-level extraction F1 as a first-class
metric, so adopting one means subclassing its metric base anyway.

#### NOTE
`scikit-learn` is a heavy dependency and would go in an `evals` extra, never the base
install. If that proves unpalatable, the metric math is genuinely ~50 lines.

### Thresholds and baselines

```python
def test_us_invoice_extraction_quality(eval_runner):
    report = eval_runner.run(dataset='us_invoices_2026_q3')
    report.assert_thresholds(
        field_f1={'Total Amount of Invoice': 0.95, 'Vendor Name': 0.90},
        overall_f1=0.92,
    )
    report.assert_no_regression(baseline='baselines/us_invoices.json', tolerance=0.02)
```

A committed baseline holds **aggregate scores only** — no per-record data — so it is
PII-free by construction and safe to diff in review.

Two failure modes worth distinguishing: *below threshold* (absolute quality bar) and
*regressed against baseline* (relative). A model can be above the bar and still have
got materially worse.

### Non-determinism

For ORCA and LLM-backed flows: run N samples per case, report mean ± stdev, and gate on
the mean with an explicit variance ceiling. A flow whose output is unstable run-to-run
is a finding in itself, so the variance is reported rather than averaged away.

### Where each eval tier would run

| Tier                | Where                               | What it proves                   |
|---------------------|-------------------------------------|----------------------------------|
| grader unit tests   | anywhere, committed synthetic data  | the graders are correct          |
| offline eval wiring | anywhere                            | the harness assembles and scores |
| **real eval**       | as an in-flow test, on the instance | actual model quality             |

Only aggregate scores leave the customer network — the same boundary part 1 establishes, which
is why the mechanism can be shared. Marked `@pytest.mark.eval` and run on a schedule, not per
PR: they cost real inference.

---

### What is left

Part 1 is done. For part 2, in order:

1. **Graders, with unit tests over synthetic data.** Independently useful and the only piece that
   can be verified without an instance. Settle the `scikit-learn`-versus-50-lines question here,
   because a CCB dependency is a heavier commitment than a test-time one.
2. **The dataset-as-wrapper-input mechanism.** Reuses what part 1 built; mostly a question of
   whether JSONL in a `File` input is ergonomic enough for a human to maintain.
3. **Baselines and thresholds.** Only meaningful once real scores exist to compare against.

**Part 2 is large and speculative.** Confirm there is demand for eval testing before building
graders and baselines: the offline, synthetic e2e and in-flow tiers cover the failure modes seen
so far. Part 1 is finished on its own, not a foundation waiting on part 2.

## See also

- [Testing Flows](testing.md#testing-flows) — the practical guide
- [Command Line Interface](cli.md)
- [Introduction to Flows SDK](intro.md)
