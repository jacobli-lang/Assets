<!-- flows_sdk documentation master file, created by
sphinx-quickstart on Thu Oct 14 13:12:50 2021.
You can adapt this file completely to your liking, but it should at least
contain the root `toctree` directive. -->

# Hyperscience Flows SDK

The `flows_sdk` is a Python library for programmatically building flows: sequences of business steps managed and executed by the Hyperscience Platform. These solutions are written in code, but are then manageable on the Hyperscience Platform.

![image](media/images/tutorial/idp-starter-flow-studio.png)

Our documentation consists of the following sections:

* [Introduction to Flows SDK](pages/intro.md#introduction-to-flows-sdk): Explanations of system architecture, flows_sdk library structure, and basic concepts.
* [Getting Started](pages/tutorial.md#getting-started): A quickstart guide to deploying your first flow to the Hyperscience Platform.
* [Command Line Interface](pages/cli.md#command-line-interface): A tutorial for hs-flows - the Flows SDK CLI tool.
* [Examples](pages/examples.md#examples): A library of fully executable flow examples. These can be used as templates for developing your own flows.
* [Getting Started with Testing Flows](pages/testing_getting_started.md#getting-started-with-testing-flows): A step-by-step introduction to testing flows — setting up a repository, the tests to write for each flow, what to run after a change, and testing on a live instance with synthetic and customer data.
* [Testing Flows](pages/testing.md#testing-flows): A comprehensive guide to testing flows across the whole pyramid — unit and component tests with mock objects, stub-free wiring validation, contract snapshots, offline flow-graph tests with `FlowTestRunner`, end-to-end tests on a live instance with synthetic data, and in-flow evaluations on customer data that run inside the instance.
* [Custom Supervision](pages/custom_supervision.md#custom-supervision): A guide to configuring Custom Supervision templates.
* [Salesforce Integration Flow](pages/salesforce_integration_flow.md#salesforce-integration-flow): A runnable example of writing extracted data to Salesforce from a flow of your own, driven by the updated Salesforce Notifier output block.
* [Managing Third-Party Python Packages](pages/python_packages.md#managing-third-party-python-packages): A guide to installing/uninstalling third-party Python packages for custom Python Code blocks.
* [Secure Handling of Secrets](pages/secrets.md#secure-handling-of-secrets): A guide to securely working with secrets like passwords and tokens in your flows. In summary, make sure you never include them directly in your flows or custom code, never commit them in a repository, and never log them. Use fields that have the `"secret": true` property instead.
* [FAQ](pages/faq.md#faq): Answers to frequently asked questions.
* [Source Documentation](pages/source-docs.md#source-documentation) & [IDP Library](pages/idp.md#idp-library): Definitions for all classes and functions in the flows_sdk library.

If you’re using the Flows SDK for the first time, we encourage you to complete the [Getting Started](pages/tutorial.md#getting-started) tutorial to learn the basics of working with flows.
