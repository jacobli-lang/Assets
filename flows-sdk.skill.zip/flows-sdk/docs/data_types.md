# Data Types

> ##### Table of Content
> 
> * [Overview](#overview)
>   * [“type”](#type)
>   * [“type_spec”](#type-spec)
>   * [“schema”](#schema)
>   * [“ui”](#ui)
>   * [Relation between “type”, “type_spec”, “schema”, “ui”](#relation-between-type-type-spec-schema-ui)
>   * [Extending, future evolution](#extending-future-evolution)
> * [Types supported in “type”](#types-supported-in-type)
>   * [Type “json”](#type-json)
>   * [Primitive Types](#primitive-types)
>     * [boolean](#boolean)
>     * [integer](#integer)
>     * [number](#number)
>     * [string](#string)
>     * [object](#object)
>     * [array](#array)
>   * [Alias types](#alias-types)
>     * [Raw](#raw)
>     * [UUID](#uuid)
>     * [ReleaseUUID](#releaseuuid)
>     * [LayoutUUID](#layoutuuid)
>     * [TaskRestrictions](#taskrestrictions)
>     * [GoalTimeRule](#goaltimerule)
>     * [FlowIdentifier](#flowidentifier)
>     * [Path](#path)
>     * [Password](#password)
>     * [MultilineText](#multilinetext)
>     * [DateTime](#datetime)
>     * [Percentage](#percentage)
>     * [ApiVersion](#apiversion)
>     * [ExportType](#exporttype)
>     * [File](#file)
>   * [Alias types (Backend-only)](#alias-types-backend-only)
>   * [Unknown Types](#unknown-types)
> * [UI-supported JSON-schema constructs](#ui-supported-json-schema-constructs)
>   * [Collections of Primitive Types](#collections-of-primitive-types)
>   * [Enumerated values](#enumerated-values)
>   * [Minimum/Maximum values](#minimum-maximum-values)

## Overview

Our datatypes framework in Block and Workflow manifests is based
on [JSON Schema](https://json-schema.org/understanding-json-schema/index.html). It serves
validation (both static and runtime, both format-based and business-level) and presentation aspects
of fields.

Let’s start with a sample field:

```json
{
  "name": "person",
  "type": "object",
  "type_spec": {},
  "schema": {
    "type": "object",
    "properties": {
      "name": {
        "type": "string"
      },
      "age": {
        "type": "integer"
      }
    }
  },
  "ui": {
    "hidden": true
  },
  "description": "Person with their age",
  "title": "Person",
  "optional": false
}
```

There are four fields that play a role as far as data types, validation and UI presentation are
concerned:

- type
- type_spec
- schema
- ui

### “type”

`type` is a required string property for every field.

It can be either `json`, or one of the primitive JSON schema types, or it can be a CamelCase-d alias
type.

The primitive types are: `string`, `integer`, `number`, `boolean`, `array`, `object`.

Alias types are things like `UUID`, `ReleaseUUID`, `GoalTimeRule`, etc. Each of these serves as a
shortcut for defining all three properties (`type`, `schema`, `ui`)
using some hardcoded values, without having to include them every time.

Additionally, apart from the json-schema-based validation, such alias types can also imply some
business-level validation by any of the deployed Django apps.

Also, alias types may be rendered/edited using some dedicated special-built widget in the UI.

In R30, the alias types we support will be hardcoded in our UI and their JSON-Schema validation will
be handled yb SDM, while their business-level validation (e.g. ReleaseUUID) will be validated using
a signals-based BE-side framework, by the respective apps that “understand” them.

In future releases, we may start defining in the specific Django app that “undestands” them, or even
as part of the block that they serve.

Example: `ReleaseUUID`

`"type": "ReleaseUUID"` is a “shortcut” that translates to these field properties:

```json
{
  "type": "string",
  "schema": {
    "type": "string",
    "format": "uuid"
  },
  "ui": {
    "trim": true,
    "multiline": false
  }
}
```

But additionally, `"type": "ReleaseUUID"` also comes with business-level validation, declared in the
`form_extraction` app that would check that the specified UUID is that of an actual Layout Release.

Also, `"type": "ReleaseUUID"` is rendered as a layout release selector widget in the UI.

### “type_spec”

`type_spec` is an optional object property that further specifies (or “specializes”) the type, in
ways that cannot be achieved via the `schema` property. Its exact format is specific to the specific
type used. See the FlowIdentifier `type_spec` below for an example.

### “schema”

`schema` is an optional property, and if specified, it must be a valid
[JSON Schema](https://json-schema.org/understanding-json-schema/index.html) field.

It is validated using third-party validator libraries by the Flow Studio UI (when a worfklow is
being edited), by the BE-side validation framework (when a workflow is imported or saved) and in the
future we might also use it at runtime to validate block inputs and outputs as the workflow is being
executed.

We are using latest validator libraries as of the time this document was created, so we support JSON
Schema draft 7.

Apart from validation, the `schema` field may determine the UI widget being used for a field. UI
knows about specific JSON schema constructs and “tweaks” the widgets used for editing when it sees
them. For example see the #enumerated-values section below, or the case for numeric minimum/maximum
values (https://json-schema.org/understanding-json-schema/reference/numeric.html#range).

If the UI does not fully support the given schema, it will revert to the “default” rendering for the
given type.

All the specific `schema` constructs that our UI supports will be listed and kept up-to-date in this
document.

For R30, we intend to support the following things with dedicated UI:

- Enums defined as `oneOf: [{const, title}]`, see below
- Numeric ranges (`minimum`, `maximum`).

### “ui”

The `"ui"` field includes UI-side presentation-related tweaks for the field. These are not coming
from the JSON Schema specification, these are HS-specific things. Since `schema` serves
predominantly validation-related aspects, `ui` also serves as the placeholder for anything that is
related to the presentation, but is not related to the validation.

Here are the properties we intend to support for R30:

`"trim": <true or false>` - Default: `true`. Whether string values should have their leading and
trailing whitespace trimmed when saving the workflow.

`"multiline": <true of false>` - Default: `false`. Whether a multiline text area should be used for
editing the field.

`"hidden": <true or false>` - Default: `false`. Instructs the UI to not render a widget for this
field, even if its value is specified in a “static” way, and not as a `${...}` expression.

### Relation between “type”, “type_spec”, “schema”, “ui”

`type` is required.<br />
\\\\
`type_spec` is optional, and if specified must conform to whatever is the `type_spec` format
specific to the chosen `type`.<br />
\\\\
`schema` is optional, but if specified, it must be a valid JSON Schema. This means that sometimes
the same primitive `type` may be duplicated both inside `type` and inside `schema.type`. Some JSON
Schema constructs might imply a type, e.g. `oneOf`.

If `type` is an alias type that implies a schema, the `schema` field can still be specified and will
take precedence over the default schema. Same goes for the `ui` field. Example:

```json
{
  "type": "DateTime",
  "schema": {
    "type": "string",
    "pattern": "<regex pattern for 2020 dates"
  }
}
```

### Extending, future evolution

For R30 we datatypes are defined only inline within the fileds in the block/WF manifests, and we
have a list of supported “hardcoded” aliased types (e.g. ReleaseUUID), but we have no support for
defining reusable datatypes. This might evolve in future versions, where we might have a way to have
Django apps and individual blocks define reusable datatypes. JSON Schema has support for
references (https://json-schema.org/understanding-json-schema/structuring.html#reuse)
that we may utilize.

## Types supported in “type”

### Type “json”

`"type": "json"` is a shortcut for:

```json
{
  "type": "json",
  "schema": {}
}
```

The empty `schema` means that any value is valid here - be it scalar or composite.

Rendered as a generic text editor in UI, but validates that the value is JSON-parseable. The data is
persisted as the parsed value, not the string value that was entered. The parsed value could be a
primitive scalar, or an array, or a key:value mapping.

### Primitive Types

These are the “primitive” types we support. All of these are more or less shortcuts for:

```json
{
  "type": "X",
  "schema": {
    "type": "X"
  },
  "ui": {
    "trim": true
  }
}
```

#### boolean

Rendered as a checkbox.

#### integer

#### number

The equivalent of Python’s `float`

#### string

Whitespace-trimmed string. Implies `"ui": {"trim": true}`.

#### object

Rendered as a generic text editor in UI, but validates that the value is JSON-parseable, and is a
mapping between string keys and arbitrary values. The data is persisted as the parsed value, not the
string value that was entered.

#### array

Rendered as a multi-choice input field for arrays of enums (enums can be strings or integers)
with the exact construct below. In any other cases it will be rendered as a generic text editor in
the UI. The data is persisted as a parsed list, not as the json-containing string that was entered.

```json
{
  "type": "array",
  "schema": {
    "type": "array",
    "values": {
      "oneOf": [
        {
          "const": "To",
          "title": "To"
        },
        {
          "const": "From",
          "title": "From"
        }
      ]
    }
  }
}
```

### Alias types

These represent business-level or domain-level concepts.

Each of these serves as a shortcut for defining all three properties (`type`, `schema`, `ui`)
using some hardcoded values, without having to include them every time.

Additionally, such alias types may imply some business-level validation, and may be rendered/edited
using some dedicated special-built widget in the UI.

#### Raw

String that is kept as-is, no whitespace trimming. Translates to

```json
{
  "type": "string",
  "schema": {
    "type": "string"
  },
  "ui": {
    "trim": false
  }
}
```

#### UUID

Translates to:

```json
{
  "type": "string",
  "schema": {
    "type": "string",
    "format": "uuid"
  },
  "ui": {
    "trim": true,
    "multiline": false
  }
}
```

#### ReleaseUUID

Like `UUID`, but has business-level validation defined in `form_extraction`, and uses a dedicated
user-friendly UI.

#### LayoutUUID

Like `UUID`, but has business-level validation defined in `form_extraction`, and uses a dedicated
user-friendly UI. Note: User-friendly UI is a stretch goal for R30

#### TaskRestrictions

```json
{
  "type": "array",
  "schema": {
    "type": "array",
    "items": {
      "type": "string"
    }
  }
}
```

And comes with business-level validation and a dedicated UI for selecting Task restrictions.

#### GoalTimeRule

Same as`object`, but uses the current specific UI we have for editing goal time rules. Defining a
particular GTR-specific schema is a nice-to-have for R30.

#### FlowIdentifier

References a flow identifier, such as IDP_SUBMISSION_NOTIFY_V35. Such parameters are used when a
block in one flow is calling another flow as a sub-flow, and the exact flow it calls needs to be
user-configurable.

The `type_spec` for FlowIdentifier is optional and allows filtering the flows that we be available
for the user to select. If used, it can contain the following properties:

- `filter_schema` - optional, all matching flows need to match this json schema
- `filter_roles` - optional, all matching flows must have at least one of these roles
- `label` - optional, used for showing a label for the connection in the UI

`filter_roles` is a “utility shortcut” for a common type of flow filter to save specifying a complex
schema.

Both `filter_schema` and `filter_roles` are optional. If both are used, a flow would need to match
them both in order to be listed.

Specifying an empty `type_spec` means no filtering happens, all user-facing flows will be listed.

Here is an example for matching all “notifications” flows, any of the two properties on its own
would achieve the same:

```json
{
  "filter_roles": ["notifications"],
  "filter_schema": {
    "type": "object",
    "properties": {
      "manifest": {
        "type": "object",
        "properties": {
          "roles": {
            "type": "array",
            "minItems": 1,
            "contains": {
              "type": "string",
              "const": "notifications"
            }
          }
        }
      }
    }
  }
}
```

#### Path

Like `string`, may come with some dedicated UI-side support or BE-side validation.

#### Password

Like `Raw` (string that does not get auto-trimmed), with special rendering and BE-side handling.

#### MultilineText

String that is kept as-is, no whitespace trimming, rendered as a multi-line text area. Translates to

```json
{
  "type": "string",
  "schema": {
    "type": "string"
  },
  "ui": {
    "trim": false,
    "multiline": true
  }
}
```

#### DateTime

```json
{
  "type": "string",
  "schema": {
    "type": "string",
    "format": "date-time"
  }
}
```

Produces trimmed string values, iso-formatted. UI might render a date/time selector. Optional for
R30.

#### Percentage

Like `number` - edited as a percentage, but rendered into the DSL as a number after dividing the
percentage by 100.
**Note**: No range restrictions on this one

#### ApiVersion

Enum for the values `v3`, `v4`, `v5`, `transformed`. See [Enumerated values](#Enumerated values)
below.

```json
{
  "type": "string",
  "schema": {
    "type": "string",
    "oneOf": [
      {
        "title": "V3",
        "const": "v3"
      },
      {
        "title": "V4",
        "const": "v4"
      },
      {
        "title": "V5",
        "const": "v5"
      },
      {
        "title": "Transformed",
        "const": "transformed"
      }
    ]
  }
}
```

#### ExportType

Enum for the values `SUBMISSION`, `FLAT_SUBMISSION`, `DOCUMENTS`, `DOCUMENTS_AND_UNMATCHED`.
See [Enumerated values](#Enumerated values) below.

```json
{
  "type": "string",
  "schema": {
    "type": "string",
    "oneOf": [
      {
        "title": "Full submission object",
        "const": "SUBMISSION"
      },
      {
        "title": "Flat submission object",
        "const": "FLAT_SUBMISSION"
      },
      {
        "title": "Full individual documents",
        "const": "DOCUMENTS"
      },
      {
        "title": "Full and Unmatched",
        "const": "DOCUMENTS_AND_UNMATCHED"
      }
    ]
  }
}
```

#### File

A string reference to a file in the system.

UI representation depends on the current string value:

| value                                                             | description                                                                                                                     |
|-------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------|
| `null`                                                            | an `Import File` button                                                                                                         |
| valid reference to an existing file                               | metainformation about the file (filename, uploaded date, uploaded by) and an actions menu supporting Download / Upload / Remove |
| invalid file reference (e.g. malformed reference or missing file) | validation error                                                                                                                |

Requires `IMPORT_FLOWS` permission to import new files / visualize the actions menu.

From `R31` until `R35`, this field was only used on `CUSTOM_CODE` blocks, and there was a “hard-coded” FE
restriction for `.py` files.

In `R36+` you can add `type_spec` to `File` parameters where you can define the `allowed_extensions` property
to allow importing different types of files. For example to define a flow input that allows for uploading CSV
files you could define the flow parameter as:

```default
{
  "name": "csv_file",
  "title": "CSV File"
  "type": "File",
  "type_spec": {
    "allowed_extensions": ".csv"
  }
}
```

### Alias types (Backend-only)

Our backend may support a number of additional business-level or domain-level hardcoded types, which
from the UI’s standpoint are treated as an “Unknown Type” (see below). Fields that use these types
will almost always be defined as `${...}` values, so the UI will not have to render them.

- `Submission`
- `Document`
- `DocumentPage`
- … anything else from https://docs.hyperscience.ai/

### Unknown Types

If UI or BE encounter an unknown type, e.g. `"type": "BlockSpecificType"`, in any block’s manifest,
they should not break, but should treat it as a generic `json` field. We accept that the “core”
support for datatypes may lag behind the specific types that appear in new blocks developed for
individual customers.

Normally such datatypes wll only appear for “runtime” values, and would be specified
via `${prev_block.output.xxxx}` references, so the UI will never have to display them. But even if
this is not the case, the generic “json” editor should be good-enough for now.

## UI-supported JSON-schema constructs

### Collections of Primitive Types

See https://json-schema.org/understanding-json-schema/reference/array.html#items

For R30 we don’t exect to have dedicated support for these - UI will render a generic JSON editor,
and the schema validation will ensure that whatver the user entered is of the valid type.

Still such stricter type info should be preferred over generic `array` types within the manifests.

### Enumerated values

JSON Schema has a couple of possible ways for defining enums. The specific construct below is
supported by our UI and rendered as a combobox. Other constructs might be OK for successfully
validating enums, but won’t result in a “nice” UI.

```json
{
  "type": "integer",
  "schema": {
    "type": "integer",
    "oneOf": [
      {
        "title": "One",
        "const": 1
      },
      {
        "title": "Two",
        "const": 2
      }
    ]
  }
}
```

The `type` above should match the type of the consts. Titles should be strings.

This is based on the following concepts from JSON Schema:<br />
\\\\
[oneOf](https://json-schema.org/understanding-json-schema/reference/combining.html#oneof)<br />
\\\\
[Enumerated values](https://json-schema.org/understanding-json-schema/reference/generic.html#enumerated-values)<br />
\\\\
[Const](https://json-schema.org/understanding-json-schema/reference/generic.html#constant-values)

### Minimum/Maximum values

We support specifying minimum/maxiumum schema properties for integer/number/Percentage data types.
The syntax is the following:

```json
{
  "type": "integer",
  "schema": {
    "type": "integer",
    "minimum": 0,
    "maximum": 100
  }
}
```

Note that in R30 we don’t support the `exclusiveMinimum`, `exclusiveMaximum` properties in the UI.

https://json-schema.org/understanding-json-schema/reference/numeric.html#range
