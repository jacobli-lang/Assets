# Command Line Interface

`hs-flows` is the Flows SDK command-line tool. It has three subcommands: `bundle`,
`init` and `update`.

## Bundling Flows

The CLI tool allows bundling one or multiple flows into a single zip file, which simplifies the process of
importing into a Hyperscience instance.
It can also extract the functions of code blocks into separate python files during the bundling process.
The tool is installed alongside Flows SDK when you install the Flows SDK wheel, and is accessible as `hs-flows`.

## Syntax

```default
hs-flows bundle INPUT [INPUT ...] [-o OUTPUT] [-e ENTRY_POINT] [-c CODE_POLICY] [-h]
```

where:

* `INPUT`: Specifies the input of the bundle operation.
  Either a Python file (`.py` extension) that contains a flow definition, or a directory containing multiple `.py`
  flow definition files.
  Multiple input arguments are supported, allowing for an arbitrary number of flows to be bundled.
* `OUTPUT`: Specifies the output of the bundle operation. Either a zip filename,
  or a directory inside which the tool will auto-generate a zip. Optional, defaults to current directory.
  CAUTION: this will overwrite the zip file if it already exists.
* `ENTRY_POINT`: Specifies the name of the flow entry-point function inside the processed flow files.
  The entry-point function is the one that returns the final constructed `Flow` object.
  Optional, defaults to `entry_point_flow`.
* `CODE_POLICY`: Policy for handling code blocks’ code, `inline` or `files`. Optional, defaults to `inline`.
  - `inline`: Leave code inline in the json.
  - `files`: Extract code into separate python files in the zip.
    This allows working with (downloading and uploading) those files directly from the UI for code blocks,
    without having to reimport the flow that uses them. This may help for quicker iterations during flows’ development.
    However, the recommended mode of work in production scenarios is to keep these inline in the json
    and to always treat your Python-based flow definition as the source of truth.
* `-h`/`--help`: Display a detailed help message and exit.

## Examples

Print help message and exit:

```default
hs-flows bundle --help
```

Bundle `some_flow.py` into `example.zip` with code inline in the json:

```default
hs-flows bundle some_flow.py -o example.zip -c inline
```

Bundle all flows found in `directory/flows` into a default zip (`flows-<timestamp>.zip`) with code extracted into files:

```default
hs-flows bundle directory/flows -c files
```

Bundle `hello_flow.py` and `fork_flow.py` into `two_flows.zip` with code inline in the json:

```default
hs-flows bundle hello_flow.py fork_flow.py -o two_flows.zip
```

## init

Scaffold a new flows project from the template bundled in the SDK. Works offline.

### init Syntax

```default
hs-flows init PROJECT_NAME [-f FLOW_NAME] [--owner-email EMAIL] [-o OUTPUT] [--force]
```

| Argument            | Description                                                                                                                              |
|---------------------|------------------------------------------------------------------------------------------------------------------------------------------|
| `PROJECT_NAME`      | Package name in snake_case, not a Python keyword or the name of a module already importable, such as `email`; also the directory created |
| `-f`, `--flow-name` | Name of the first flow’s package, in snake_case and not a Python keyword (default: `main`)                                               |
| `--owner-email`     | `owner_email` on the generated flow                                                                                                      |
| `-o`, `--output`    | Directory to create the project in (default: `.`)                                                                                        |
| `--force`           | Overwrite files that already exist                                                                                                       |

### init Examples

```default
hs-flows init invoice_processing --flow-name invoice
```

`ruff check .`, `ruff format --check .`, `mypy .` and the generated tests all pass in the
directory `init` creates.

It is one package per deployable flow, with the custom-code functions and the tests
beside the flow they cover:

```default
invoice_processing/
├── pyproject.toml                    extends .flows-sdk/ruff.toml; mypy rules, tier markers and pytest plugin inline
├── conftest.py                       puts the project on sys.path for pytest
├── .flows-sdk/                       SDK-owned config (managed by `hs-flows update`)
└── invoice_processing/flows/invoice/
    ├── flow.py                       entry_point_workflow() -> Flow
    ├── functions.py                  the CCBs — plain, importable, testable
    └── tests/{unit,flow,contract,e2e,in_flow,data}/
```

`init` also generates the flow’s contract golden, so its contract test passes from the start.

## update

Refresh the configuration files the SDK owns, so lint and type rules stay in step
across every flows repository.

### update Syntax

```default
hs-flows update [-o OUTPUT]
```

| Argument         | Description                               |
|------------------|-------------------------------------------|
| `-o`, `--output` | Project root (default: current directory) |

### update Examples

```default
pip install -U "flows_sdk[testing]"
hs-flows update      # refresh SDK-owned config
```

The configuration ships inside the wheel, so this works offline. Each tool is configured its own
way:

| Tool     | Mechanism                                                                                                                                  |
|----------|--------------------------------------------------------------------------------------------------------------------------------------------|
| `pytest` | `[tool.pytest.ini_options]` in your own `pyproject.toml` — the tier markers and `-p flows_sdk.testing.plugin` are yours; nothing is copied |
| `ruff`   | your `pyproject.toml` sets `extend = ".flows-sdk/ruff.toml"` — a path relative to the project root                                         |
| `mypy`   | settings written inline into `[tool.mypy]`; `.flows-sdk/mypy.ini` is the canonical copy `update` refreshes                                 |

mypy cannot extend another configuration file, so `init` writes its settings into your
`pyproject.toml` directly.

#### CAUTION
`update` **overwrites** everything under `.flows-sdk/`. Put project-specific
overrides in your own `pyproject.toml`, which extends the SDK config and
therefore wins on any key it sets — never edit the SDK-owned files directly.

`samples/testing_showcase` has the same shape.

Two limits:

- **`mypy` must be run from inside the project.** It searches for configuration upward from
  the *current directory*, unlike `ruff`, which searches upward from each file it checks.
  Run it from an outer directory and it finds nothing, falls back to its own defaults, and
  reports spurious missing-import errors.
- **`update` cannot refresh the inline `[tool.mypy]` block.** It rewrites
  `.flows-sdk/mypy.ini`, which mypy does not read, and then lists every setting in it that
  the inline block lacks or sets differently. Copy those across.

#### NOTE
**A monorepo does not need `.flows-sdk/` per project.** `init` is for a standalone repository. A
monorepo that already distributes `ruff` and `mypy` configuration its own way should keep doing
so.
