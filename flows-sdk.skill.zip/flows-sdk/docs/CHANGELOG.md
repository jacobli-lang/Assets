# CHANGELOG

## 2.12.0

- **[improvement] The SDK no longer prints Pydantic deprecation warnings (`PydanticDeprecatedSince20`) when it is imported or a flow is exported**
  - It uses only Pydantic V2 APIs now, so it keeps working once Pydantic V3 removes the deprecated ones
- [breaking change] The SDK now requires Pydantic 2.1 or later (`pydantic>=2.1,<3.0`); Pydantic 1.10 is no longer supported
- [breaking change] Exported flow JSON serializes values that are not plain JSON (e.g. a `UUID`, `date` or `Enum` in a block’s input, the flow’s input or its variables) with Pydantic’s serializer
  - `UUID`, `date`, naive `datetime` and `Enum` values export as before
  - A UTC `datetime` ends in `Z` instead of `+00:00`, a `timedelta` is an ISO 8601 duration instead of seconds, and a `Decimal` is a string instead of a number
  - A value Pydantic cannot serialize raises `pydantic_core.PydanticSerializationError` (a `ValueError`) instead of `TypeError`

## 2.11.3

- **[feature] V44: `max_tokens_per_image` on the ORCA Extraction and General Prompting blocks**
  - The per-image token budget now follows the selected model’s own vision grid; leaving it unset lets the model choose
  - `max_image_tokens` is deprecated (to be removed in v47.0) and now defaults to unset rather than 1280
- **[feature] V43: `target_outputs` on the ORCA General Prompting block, to score given completions instead of generating them (Hyperscience Platform 43.2.3+)**
- **[feature] V43 and V44: `disable_log_redaction` (debug only) on the ORCA Extraction and General Prompting blocks (43.2.3+ and 44.0.1+; older platforms ignore it)**
- **[feature] V43 and V44: the ORCA General Prompting block takes optional `title` and `description`, so each block can have its own name in Flow Studio**
- **[improvement] Documented `scoring_error` on General Prompting results whose target completion cannot be scored (V44)**
- **[bugfix] The V42 and V43 ORCA starter flows now pass the ORCA QA sample rate to the QA flow; it was sent under the wrong key, so QA ran on every document instead of the configured 5%**
- **[improvement] V43 and V44 block docstrings list their parameters in signature order**
- **[improvement] Supported-languages links in the V44 blocks now point at the v44 help docs**

## 2.11.2

- **[bugfix] The V43 `AddressParserBlock` from 2.9.1 is now included in the 2.11 line**
  - It is available under the [V43 additional blocks](idp/README.md#module-flows_sdk.implementations.idp_v43.additional_blocks)

## 2.11.1

- **[bugfix] Fixed broken imports in some of the flows in the `idp_flow_v44.zip` starter examples**

## 2.11.0

- **[feature] Hyperscience Platform V44 has been released!**
  - [updated blocks](idp/README.md#v44)
  - [starter examples](examples.md#v44)
- **[feature] Added an example integration flow for the updated Salesforce Notifier output block (V44+), which runs a flow of yours for every submission payload**
  - [Salesforce Integration Flow](salesforce_integration_flow.md#salesforce-integration-flow) walks through adding the output block to your document processing flow and running the [sample](examples.md#code-snippets) against the Form W-9 from the Document Processing Starter
  - For platforms before v44, where the output block does not exist, the same page ships a second sample: a document processing flow that calls a Salesforce writer subflow directly
- **[bugfix] `hs-flows bundle` no longer fails with `Invalid cross-device link` when the output directory is on its own mount**
  - The bundle is staged in a temporary directory beside the output rather than in the system temp dir, so the final rename never crosses a filesystem boundary
- **[bugfix] Fixed unstable ordering of roles in IDP version V43**

## 2.10.0

- **[improvement] Added support for the Python 3.14 `PythonBlock`**
- \*\*[bugfix] Fix absolute package path imports failing on `hs-flows bundle` \*\*

## 2.9.1

- **[feature] Made the address parsing block available**
  - The `AddressParserBlock` is now available under the [V43 additional blocks](idp/README.md#module-flows_sdk.implementations.idp_v43.additional_blocks)

## 2.9.0

- **[feature] Hyperscience Platform V43.2 has been released!**
  - [updated blocks](idp/README.md#v43)
  - [starter examples](examples.md#v43)
- **[feature] In V43.2+ address parsing support has been added to the IDP flow**
  - Configure it through the new `AddressParserSettings` (API provider, API key, and API options)
- **[feature] The Images to Printable File block can now generate searchable PDFs**
  - Documents are now described as a list of `pages`, where each page may optionally reference a `searchable_words_blob_uuid` to emit an invisible searchable text layer
- **[improvement] Output wrapping mode is now respected by IDP blocks that alias code blocks (e.g. HTTP REST)**
  - Uses the same `HS_CODE_BLOCK_OUTPUT_WRAPPING_MODE` configuration introduced in 2.8.2
- **[bugfix] Multi-line lambdas passed as `code=` now serialize parenthesized so they stay a parseable expression the platform can translate to a LAMBDA_PYTHON task; an unparseable lambda extraction now fails at build time instead of at flow runtime.**

## 2.8.2

- **[improvement] Introduced support for output wrapping mode for PythonCode, Foreach and Routing blocks**
  - Use environment variables `HS_CODE_BLOCK_OUTPUT_WRAPPING_MODE` and `HS_PLATFORM_TARGET_VERSION` to configure it, defaults to the existing behavior of wrapping the block output in “result”.
  - [Official documentation on Output Wrapping Mode](tutorial.md#output-wrapping-mode)
- **[bugfix] Fixed an issue in `CodeBlock` with `include_module=True` where using `import datetime` was resulting in an error.**

## 2.8.1

- **[improvement] Updated TypeAlias references to display the concrete type alias.**

## 2.8.0

- **[feature] Hyperscience Platform V43 has been released!**
  - [updated blocks](idp/README.md#v43)
  - [starter examples](examples.md#v43)
- **[bugfix] Fixed issue where `Parameter.json_schema` was not being properly exported to json**

## 2.7.2

- **[bugfix] Fix issue where module based CCBs with code inputs would be missing an import**

## 2.7.1

- **[bugfix] No longer allow a block with both a `code` and a `script_ref` input, as this can result in confusing behavior**
- **[improvement] `Block.output()` and `workflow_input()` return types adjusted to allow smoother typechecking experience for block definitions**

## 2.7.0

- **[feature] Hyperscience Platform V43 has been released!**
  - [updated blocks](idp/README.md#v43)
  - [starter examples](examples.md#v43)
- **[improvement] Generated flow JSON now includes an `sdk_version` field in the metadata section**
- **[improvement] `MockHsBlockInstance.log()` now correctly reflects the difference in logging behaviour between Python versions — see [HsBlockInstance.log](source-docs.md#flows_sdk.types.HsBlockInstance.log) and [Unit Testing Custom Code Blocks](testing.md#unit-testing-ccbs) for more details**
  - In `PythonBlock` with Python version <= 3.12, logging arguments via `HsBlockInstance.log()` is not supported
  - In `PythonBlock` with Python version >= 3.13, logging arguments is supported
- **[deprecated] `FOLDER_TRIGGER` has been deprecated across multiple IDP versions in favor of the Universal Folder Listener**
- **[bugfix] Fixed `BundleExporter` hardcoding Python code block identifiers, which prevented correct export of flows using newer `PythonBlock` versions**
- **[bugfix] Fixed unstable ordering of roles across IDP versions V38–V42**

## 2.6.0

- **[feature] Hyperscience Platform V42.3 has been released!**
  - [updated blocks](idp/README.md#v42)
  - [starter examples](examples.md#v42)
- **[feature] In V42.3+ a new Document Processing with ORCA Subflow has been added for Advanced and Premium license**
  - **IDP ORCA Flow** - a read-only subflow similar to **IDP Core Flow** but ORCA is used for field identification
  - **ORCA QA Flow** - Quality assurance for ORCA flow. Meant to be used together with IDP ORCA Flow to spawn QA tasks for human review

## 2.5.1

- **[bugfix] Fix MockHsBlockInstance.log function having an outdated signature**

## 2.5.0

- **[feature] Hyperscience Platform V42.2 has been released!**
  - [updated blocks](idp/README.md#v42)
  - [starter examples](examples.md#v42)

## 2.4.2

- **[bugfix] Allow Code Blocks to use static methods and class methods**

## 2.4.1

- **[feature] Added support for using entire modules as code in Code Blocks.**
  - Module-backed CCBs enable better code organization, maintainability, and testability
  - For further details see the [`PythonBlock`](source-docs.md#flows_sdk.blocks.PythonBlock) documentation
- **[feature] Comprehensive unit testing support for Custom Code Blocks**
  - Added `MockHsBlockInstance` and `MockHsTask` classes in `flows_sdk.mocks` for testing CCBs locally
  - Mock objects simulate blob storage, logging, HTTP requests, and measurements
  - See the new [Unit Testing Custom Code Blocks](testing.md#unit-testing-ccbs) guide for more details and examples
- **[improvement] Added comprehensive documentation for several flow utilities**
  - Added docstrings with code examples for `workflow_input()`, `FlowDefinitionReferences`, and `FlowRunReferences`

## 2.4.0

- **[feature] Hyperscience Platform V42.1 has been released!**
  - [updated blocks](idp/README.md#v42)
  - [starter examples](examples.md#v42)
- **[improvement] The On-Error flows have been split in two parts:**
  - The On-Error flow that is configured on the main flow, which is responsible for handling the error and calling the On-Error subflow
  - The On-Error subflow, which is responsible for generating the error message to be sent to the output blocks
  - Similarly to the Document processing flows, this allows for better separation of concerns and updating the on-error logic without losing any configure output blocks.

## 2.3.0

- **[improvement] Added support for the Python 3.13 `PythonBlock`**

## 2.1.0

- **[feature] Hyperscience Platform V42 has been released!**
  - [updated blocks](idp/README.md#v42)
  - [starter examples](examples.md#v42)

## 2.0.0

- [breaking change] Upgrade to Python 3.12 - using blocks from V41 now requires a 3.12 venv
- [feature] [Updated blocks for V41.2](idp/README.md#v41)

## 1.11.3

- **[feature] Backport to [V40 IDP Library](idp/README.md#v40) the support for forcing normalization errors and blank or missing fields to supervision**

## 1.11.2

- **[improvement] Added support for empty branches in `Routing` and `Fork` blocks:**
  - Allow empty branches (branches without any blocks)
  - Allow branches to define an output from an external block, without requiring any blocks to run.\*\*

## 1.11.1

- **[improvement] Updated documentation for chat component for LLM Document Q&A in [Custom Supervision](custom_supervision.md)**

## 1.11.0

- **[feature] Hyperscience Platform V41 has been released!**
  - [updated blocks](idp/README.md#v41)
  - [starter examples](examples.md#v41)

## 1.10.5

- **[feature] Refer to the business metric measurement occurrence time via `time`, a datetime object. This datetime must be timezone-aware**

## 1.10.4

- **[feature] Added `FileFilterBlock` to [V40 IDP Library](idp/README.md#v40)**

## 1.10.3

- **[feature] Added publish measurements method to HsBlockInstance that allows code in PythonBlock
  or CodeBlock to tracks business metrics (available since V41)**

## 1.10.2

- **[improvement] Added support for the Python 3.12 `PythonBlock`**

## 1.10.1

- **[feature] Added utility methods to HsBlockInstance for making authenticated requests to the
  Hyperscience instance from inside the code in PythonBlock or CodeBlock (available since R40.2)**

## 1.10.0

- **[feature] Hyperscience Platform V40 has been released!**
  - [updated blocks](idp/README.md#v40)
  - [starter examples](examples.md#v40)
- **[bugfix] Removed default Submission Aware On Error flow from V38 examples because it might not
  exist in a V38 system.**

## 1.9.1

- **[bugfix] Updated default inputs for `ReprocessingBlock` in versions 39 and 39.1, so that additional inputs in custom IDP_CORE flows would get relayed for reprocessing runs**

## 1.9.0

- **[feature] Hyperscience Platform V39.1 has been released!**
  - [updated blocks](idp/README.md#v39-1)
  - [starter examples](examples.md#v39-1)
- **[improvement] Roles are exposed as an argument to the IDP Core Block**
- **[improvement] Easier to see where to modify Notification, On Error flows in the
  Document Processing example flow**
- **[improvement] Default Notification flow, On Error flow, and IDP Core block in the example flow
  point to the out-of-the-box flows in the platform**

## 1.8.3

- **[bugfix] Reverted the change introduced in Flows SDK version 1.8.2 where the default value for
  `PythonBlock#python_version` is set to Python 3.11, which caused breaking behaviour.**
- **[improvement] Added support for an environment variable `HS_PYTHON_CODE_BLOCK_PYTHON_VERSION`
  that allows overriding the default behaviour *without* having to make code changes to
  existing flows.**
  - To understand how to control Python versions for `PythonBlocks`, Please refer to the
    [PythonBlock documentation](source-docs.md#flows_sdk.blocks.PythonBlock)

## 1.8.2

- **[bugfix] Default version of PythonBlock is now Python 3.11, instead of 3.9**

## 1.8.1

- **[improvement] Ported quality of life features introduced in the V39 samples to V38 samples**
  - Roles are exposed as an argument to the IDP Core Block
  - Easier to see where to modify Notification, On Error flows in the
    Document Processing example flow for V38
  - Default Notification flow, On Error flow, and IDP Core block in the example V38 flow
    point to the out-of-the-box flows in the platform for that version
- **[improvement] Moved IDPWrapperManifest out of the example Document Processing flow samples for
  both V38 and V39**
- **[improvement] Added parameter that controls which Python version a `PythonBlock` works with**

## 1.8.0

- **[feature] Hyperscience Platform V39 has been released!**
  - [updated blocks](idp/README.md#v39)
  - [starter examples](examples.md#v39)
- **[improvement] Roles are exposed as an argument to the IDP Core Block**
- **[improvement] Easier to see where to modify Notification, On Error flows in the
  Document Processing example flow**
- **[improvement] Default Notification flow, On Error flow, and IDP Core block in the example flow
  point to the out-of-the-box flows in the platform**

## 1.7.2

- Bump asttokens to 2.4.1

## 1.7.1

- **[bugfix] Default CustomSupervision’s notification_workflow to None**
- **[improvement] Add release.zip to the idp v38 starter flow**
- **[improvement] Properly identify settings as Classification settings**

## 1.7.0

- **[feature] Hyperscience Platform V38 has been released!**
  - [updated blocks](idp/README.md#v38)
  - [starter examples](examples.md#v38)

## 1.6.4

- **[feature] Add support for `on_error_flow` construct in error handling.**
  - Can be used only in the flow level error handling section
  - Available in Hyperscience Platform V38 and above.

## 1.6.3

- **[feature] Add support for `compatibility_spec` construct in blocks.**
  - Available in Hyperscience Platform V38 and above.

## 1.6.2

- **[bugfix] Remove extra parameter http_config from SubmissionBootstrap block for R32.**

## 1.6.1

- **[improvement] Setting a range for pydantic between `1.10.11` inclusive and `2.0` non-inclusive .**

## 1.6.0

- **[feature] Hyperscience Platform V37 has been released!**
  - [updated blocks](idp/README.md#v37)
  - [starter examples](examples.md#v37)

## 1.5.2

- **[improvement] Updated pydantic version to `1.10.8`.**

## 1.5.1

- **[bugfix] Added missing `http_config` parameter to `SubmissionBootstrapBlock`.**
- **[improvement] Updated documentation for I/O blocks.**

## 1.5.0

- **[feature] Hyperscience Platform V36 has been released!**
  - [updated blocks](idp/README.md#v36)
  - [starter examples](examples.md#v36)

## 1.4.1

- **[feature] Decision dependencies for Custom Supervision is available!**
- **[feature] Mandatory decisions for Custom Supervision is also available!**

You can find explanations of both features and examples of the JSON configuration in the
[Decision components section](custom_supervision.md#json-configuration) of Custom Supervision.

## 1.4.0

- **[feature] Hyperscience Platform V35 has been released!**
  - [updated blocks](idp/README.md#v35)
  - [starter examples](examples.md#v35)
  - Check out some of the new features v35 features, released in recent flows-sdk versions:
    - PythonBlock, how to store and load binary data, use 3rd party libraries and more [in 1.1.0](#id56)
    - How to use structured logging, also visible in the UI [in 1.3.0](#id53)
- **[feature] A new system block has been introduced - Foreach!**
  - This block enables dynamic parallelization of tasks - [check out the docs to learn more](source-docs.md#flows_sdk.blocks.Foreach)

## 1.3.0

- **[improvement] Added a `log` method to `HsBlockInstance`**

This is done in preparation for an upcoming V35 feature that will expose better logging functionality
for flow developers, making it available for both `CodeBlock` and `PythonBlock`.

[`flows_sdk.types.HsBlockInstance`](source-docs.md#flows_sdk.types.HsBlockInstance)

## 1.2.1

- **[improvement] A reference to the code function passed to `CodeBlock` and `PythonBlock` is now available on the block object under `block.code_fn`**

## 1.2.0

- **[feature] Hyperscience Platform V34 has been released!**

You can find the [updated blocks](idp/README.md#v34) in the usual `implementations.idp_v34.idp_blocks`
package as well as the new [starter examples](examples.md#v34).

- **[feature] New block - HyperscienceRestApiBlock available for V32, V33, and V34**

This block allows you to make API requests against the Hyperscience Platform APIs.
Check out the docs to learn more!

[`flows_sdk.implementations.idp_v34.idp_blocks.HyperscienceRestApiBlock`](idp/README.md#flows_sdk.implementations.idp_v34.idp_blocks.HyperscienceRestApiBlock)

- **[deprecated] Removed the Kofax Folder Listener IOBlock**

If you are using this block, we recommend migrating to the [Universal Folder Listener](idp/README.md#v34-universal-folder-listener) IOBlock.

## 1.1.0

- **[feature] Added a new block - PythonBlock**

> This requires a Hyperscience platform version `34.0.0+`

[`flows_sdk.blocks.PythonBlock`](source-docs.md#flows_sdk.blocks.PythonBlock)

PythonBlock is a special type of block that can execute custom python code on
the Hyperscience platform. Similarly to CodeBlock, the code can utilize packages that
are part of the Python Standard Library, but it also allows developers to utilize third-party python packages.

Check out [the docs](python_packages.md) to learn how.

- **[feature] Introduces HsTask and HsBlockInstance system arguments for code blocks**

> This requires a Hyperscience platform version `35.0.0+`

The `HsTask` class can be used to access flow run metadata - most prominently the `correlation_id` which corresponds
to the submission UUID. `HsBlockInstance` allows users to store binary data to the platform and retrieve it later as
a mechanism to transfer such data between blocks.

Please refer to the examples under [code snippets](examples.md#code-snippets) for more information
on how to access these classes in code block functions.

## 1.0.1

- **[improvement] new properties for v32 `CaseCollationBlock` and v33 `MachineCollationBlock`**

Both now have the `dedupe_files` property, with the v33 `MachineCollationBlock` also adding `remove_from_cases`.

Check out the docs to learn more:
`flows_sdk.implementations.idp_v32.idp_blocks.CaseCollationBlock`, `flows_sdk.implementations.idp_v33.idp_blocks.MachineCollationBlock`

- **[examples] Added a new example for custom supervision using v33 blocks**
- **[examples] IDP starter examples for Hyperscience v32 have been updated**

[The examples](examples.md) `IDP Starter V32.0.9+` and  `IDP Starter V32.0.0 to V32.0.8` were
packing an outdated flow definition, which is now updated.

`IDP w/ Code Block` could result in a halted submission. It should now properly execute end-to-end on the Hyperscience Platform.

## 1.0.0

- **[improvement] `reference_name` is now an optional property for all blocks.**

> This requires a Hyperscience platform version `32.0.11+` or `33.1.1+`

It’s still a good idea to provide meaningful reference names when instantiating blocks,
but if the property `reference_name` is not set, a unique one will be generated.

before:

```python
from flows_sdk.implementations.idp_v43.idp_blocks import SubmissionBootstrapBlock

submission_bootstrap = SubmissionBootstrapBlock(reference_name='submission_bootstrap')
# renders as {"reference_name": "submission_bootstrap"}
```

after:

```python
from flows_sdk.implementations.idp_v43.idp_blocks import SubmissionBootstrapBlock

submission_bootstrap = SubmissionBootstrapBlock()
# renders as {"reference_name": "auto_submission_bootstrap__1"}
```

- **[bugfix] Fixed a bug where IDP Starter V32 would not work on Hyperscience platforms after 32.0.9.**
  There are now two separate examples - one for 32.0.0 to 32.0.8 and another one for 32.0.9+

## 0.8.0

- **[feature] Introduces the `implementation.idp_v33` package that contains block definitions used by
  v33 of the Hyperscience platform**
- **[improvement] Added an IDP Starter Example that uses v33 blocks**
