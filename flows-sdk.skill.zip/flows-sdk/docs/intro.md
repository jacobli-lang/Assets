# Introduction to Flows SDK

`flows_sdk` is a Python library for programmatically building Flows.
Flows are sequences of business steps managed and executed by the Hyperscience Platform.

A Flow definition is like a blueprint: it configures and connects multiple Blocks that define the business workflow. The Hyperscience Platform uses this blueprint to execute, scale, and manage the lifecycle of these Blocks at runtime.

## System Architecture

The `flows_sdk` enables you build flows using a Python library in any environment/IDE you prefer. The resulting `.py` definition of the flow must be “translated” into a JSON representation, which is imported into the Hyperscience Platform.

#### NOTE
You manage the source code for the flows that you write, for example in a separate git repository within your organization. You import the produced JSON artifacts in the Hyperscience Platform to run the flows.

Once uploaded to the Hyperscience Platform, this JSON artifact is kept in sync with any changes made in the Flow Studio. The Flow Studio provides a GUI for business users to manage the flow’s settings over time.

![](media/images/architecture.jpg)

The only requirements to use the `flows_sdk` are:

- **Development:** The only local requirement for development is `python 3.7+` and
  a link to this library, provided by your CX representative. Additional dependencies will later be pulled via `pip`.
- **Deployment:** In order to deploy flows built using the `flows_sdk`, you need:
  - A running instance of the Hyperscience Platform (`v32` and above)
  - A user account with permissions to edit and import flows

## Library Structure

The `flows_sdk` library contains everything you need to build on the Hyperscience Platform. As illustrated below, it contains the following top-level sublibraries: `flows`, `blocks`, and `implementations`. Documentation is split into [Source Documentation](source-docs.md) and the [IDP Library](idp/README.md).

```default
├── flows_sdk
│   ├── blocks.py                  \  Source
│   ├── flows.py                   /  Documentation
│   ├── implementations            - IDP Library
│   │     ├── idp_v34 
│   │     ├── idp_v35
│   │     ├── ...

```

[Source Documentation](source-docs.md) includes all of the underlying classes necessary for a flow to execute, such as `Flow`, `Block`, and `CodeBlock`. These classes are agnostic to the version of the Hyperscience Platform you are running.

The [IDP Library](idp/README.md) includes the latest performant blocks for **intelligent document processing**.

## Basic Concepts

### Flow

A flow is a sequence of business steps managed and executed by the Hyperscience Platform. Flows are composed of Blocks, such as IDP blocks (e.g., Classification), Routing, Fork, Triggers, as well as other helper components.

Once uploaded to the Hyperscience Platform, flows are rendered and managed within the Flow Studio:

![](media/images/tutorial/idp-starter-flow-studio.png)

#### Split Flows: Main / Core

Since R38, flows are typically split into “main” and “core” flows to separate extraction configuration from processing logic. The main flow defines the release along with the extraction settings, and the core flow defines the logical steps of extraction. This allows swapping out various core flows to test new features and upgraded core logic while retaining the same extraction settings.

### Block

A block is a single step in a flow. Using the `flows_sdk`, blocks can be defined and ordered, and their inputs can be customized and passed statically (e.g., during flow definition or via UI-exposed settings) or dynamically (e.g., the output of a previously executed block).

### Python Block

[Python Blocks](source-docs.md#flows_sdk.blocks.PythonBlock) are a special type of block that can execute custom
Python code on the Hyperscience Platform.

Starting with **V34.0.1**, third-party packages can be installed in the Hyperscience Platform and utilized from the code in Python Blocks.

Prior to **V34.0.1**, [Code Block](source-docs.md#flows_sdk.blocks.CodeBlock) is used instead, without the ability to install external packages.

### Routing

A system block that routes execution to one of its branches based on a condition (similar to a `switch..case` statement). Routing is viewable within the Flow Studio as a branching of logic:

![](media/images/routing.png)

A full definition is in the [Source Documentation](source-docs.md#flows_sdk.blocks.Routing).

### Fork

A system block that schedules other blocks for parallel execution. A full definition is in the [Source Documentation](source-docs.md#flows_sdk.blocks.Fork).

### Foreach

A system block that performs a task for each item in a dynamic collection. The task is represented by a block that accesses the corresponding item in the collection using special syntax. The items are processed in parallel. A full definition is in the [Source Documentation](source-docs.md#flows_sdk.blocks.Foreach).

### Triggers & Outputs

Trigger Blocks initiate the execution of a flow. Some examples are: watching a folder for new files, checking an inbox, listening to a message queue, etc.

Output Blocks send information to external systems. Some of these blocks are generic (e.g., `HTTP_EXPORT`) while others are integrations into specific systems (e.g., `EXPORT_UIPATH`).

Full definitions are in the Block Library for [Trigger Blocks](idp/README.md) and [Output Blocks](idp/README.md).

### Error handling

To facilitate the implementation of common error handling patterns the Hyperscience platform provides some error handling tools out of the box. Currently, we support:

- **Automatic block error retries**. If a block error retry policy is defined either on the block or on the flow that contains the block in case of failure it will get retried according to said policy. The block error retry policy can be defined on both the flow and block levels.

For more details check the error handling [source documentation](source-docs.md#module-flows_sdk.error_handling).

### Submission Object

Many block subclasses available within the [Block Library](idp/README.md) use a Submission object, which is a dictionary of extracted document information with the following basic structure:

```default
   {
      "submission": {
         "id": "12345",
         "documents": [
            {
                "id": "1",
                "pages": [...] // list of pages
                "document_fields": [...] // list of document fields
            },
            ...
         ]
         "cases": [],
      }
   }
```

As most blocks in the [Block Library](idp/README.md) require a Submission object for input, this paradigm enables you to easily pass the output of one block as the input to the next block:

```default
    # This example shows the output of MachineTranscriptionBlock (i.e. machine_transcription)
    # being used as the input to a ManualTranscriptionBlock   
    
    machine_transcription = MachineTranscriptionBlock(
        reference_name='machine_transcription',
        submission=previous_block.output('submission'))
   
    manual_transcription = ManualTranscriptionBlock(
        reference_name='manual_transcription',
        submission=machine_transcription.output('submission'),
     ...
    )
```

The exact state of the Submission object will depend on which processing blocks have been executed. Most blocks will also wrap the Submission object within additional flow-level metadata.

Read our [Testing & Debugging](faq.md#testing-debugging) guide for how to inspect the current state of the Submission object in your flow. Or, download a full example here - this is the output of `ManualTranscriptionV2Block` from our [Tutorial](tutorial.md)).
