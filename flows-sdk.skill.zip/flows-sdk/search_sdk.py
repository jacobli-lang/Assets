#!/usr/bin/env python3
"""Search the offline Flows SDK docs + samples bundled with this skill.

Every whitespace-separated term must match (case-insensitive) somewhere in a
file's path or body (AND semantics). Hits are ranked by match count and printed
with the file path, the nearest preceding heading, and a snippet.

No third-party dependencies; runs on any Python 3.
"""
import argparse
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def nearest_heading(lines, idx):
    for i in range(idx, -1, -1):
        if lines[i].startswith("#") and not lines[i].startswith("#!"):
            return lines[i].lstrip("#").strip()
    return ""


def main() -> int:
    ap = argparse.ArgumentParser(description="Search the offline Flows SDK docs.")
    ap.add_argument("terms", nargs="+", help="Keywords; all must match (AND).")
    ap.add_argument("--version", help="Restrict IDP Library to a platform version, e.g. 43 or 39_1.")
    ap.add_argument("--samples", action="store_true", help="Search sample flow code only.")
    ap.add_argument("--docs", action="store_true", help="Search docs only (no samples).")
    ap.add_argument("--limit", type=int, default=15, help="Max results (default 15).")
    ap.add_argument("--json", action="store_true", help="Machine-readable output.")
    args = ap.parse_args()

    term_res = [re.compile(re.escape(t), re.IGNORECASE) for t in args.terms]
    files = []
    if not args.samples:
        for p in sorted((ROOT / "docs").rglob("*.md")):
            if args.version and p.parent.name == "idp" and p.stem != f"idp_v{args.version.lstrip('vV').replace('.', '_')}":
                continue
            files.append(p)
    if not args.docs:
        files += sorted(p for p in (ROOT / "samples").rglob("*") if p.is_file())

    results = []
    for p in files:
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        rel = str(p.relative_to(ROOT))
        hay = rel + "\n" + text
        if not all(tr.search(hay) for tr in term_res):
            continue
        score = sum(len(tr.findall(text)) for tr in term_res)
        lines = text.split("\n")
        # locate the line where the most terms co-occur, falling back to the first match
        best, best_n = 0, -1
        for i, line in enumerate(lines):
            n = sum(1 for tr in term_res if tr.search(line))
            if n > best_n:
                best, best_n = i, n
                if n == len(term_res):
                    break
        snip = " ".join(l.strip() for l in lines[max(0, best - 1): best + 2])[:240]
        results.append({"path": rel, "line": best + 1, "score": score,
                        "section": nearest_heading(lines, best), "snippet": snip})

    results.sort(key=lambda r: -r["score"])
    results = results[: args.limit]
    if args.json:
        print(json.dumps(results, indent=2))
        return 0
    if not results:
        print("No matches. Try fewer/broader terms, or drop --version.")
        return 1
    for r in results:
        print(f"{r['path']}:{r['line']}  (score {r['score']})")
        if r["section"]:
            print(f"  § {r['section']}")
        print(f"  {r['snippet']}\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
