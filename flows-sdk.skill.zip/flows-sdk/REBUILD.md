# Rebuilding this export

Requires GitHub access to the internal `hyperscience/flows-sdk` repo.

```bash
gh repo clone hyperscience/flows-sdk -- --depth 1
python3.12 -m venv docvenv && . docvenv/bin/activate
pip install "sphinx<9,>=8.2.3" "sphinx-autodoc-typehints>=3.2.0" "autodoc-pydantic>=2.2.0" \
  "myst-parser>=4.0.1" sphinx_rtd_theme "sphinx-toolbox>=3.2.0" sphinxcontrib-mermaid sphinx-markdown-builder
pip install -e flows-sdk
mkdir -p flows-sdk/docs/mdconf && cp rebuild/mdconf.py flows-sdk/docs/mdconf/conf.py
cd flows-sdk/docs/source && sphinx-build -a -b markdown -c ../mdconf . ../../../mdbuild
```

`mdconf.py` wraps the site's own `conf.py` and only adds Markdown renderers for
collapsible blocks and Mermaid diagrams. Then split `mdbuild/pages/idp.md` on
its `## V44` / `### V39.1` headings into `docs/idp/idp_vXX.md`, copy the other
pages into `docs/`, and copy `samples/**/*.{py,json,toml,txt,md}`.
