import os
_src = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'source'))
exec(open(os.path.join(_src, 'conf.py')).read())
sys.path.append(os.path.join(_src, '_ext'))
html_static_path = []
html_favicon = None

def _passthrough(self, node):
    pass

def setup(app):
    from sphinx_toolbox.collapse import CollapseNode
    from docutils import nodes
    def _visit(self, node):
        summary = node.get('label', '')
        if summary:
            self.add(f'\n**{summary}**\n')
    def _depart(self, node):
        pass
    app.add_node(CollapseNode, override=True, markdown=(_visit, _depart))

_orig_setup = setup
def setup(app):
    _orig_setup(app)
    from sphinxcontrib.mermaid import mermaid
    from docutils import nodes as _n
    from sphinx_toolbox.collapse import CollapseSummaryNode  # noqa
    def _mv(self, node):
        self.add('\n```mermaid\n' + node['code'] + '\n```\n')
        raise _n.SkipNode
    app.add_node(mermaid, override=True, markdown=(_mv, None))
    try:
        from sphinx_toolbox.collapse import CollapseSummaryNode as _CS
        def _sv(self, node):
            raise _n.SkipNode
        app.add_node(_CS, override=True, markdown=(_sv, None))
    except ImportError:
        pass
