---
name: flows-sdk
description: Offline copy of the Hyperscience Flows SDK documentation (the flows-sdk.hyperscience.ai site) plus the official sample flows. Use whenever writing, reviewing, or debugging a Hyperscience flow in Python with flows_sdk, e.g. Flow/Block/CodeBlock/PythonBlock/Foreach/Routing classes, IDP Library blocks for a specific platform version (idp_v34 to idp_v44), output() wiring, error handling and on-error flows, secrets, python packages, custom supervision JSON, the hs-flows CLI, flow testing, or the changelog between SDK versions. Also use when someone can't reach flows-sdk.hyperscience.ai or asks "what does the SDK say about X". No network needed.
---

# Flows SDK docs (offline)

A Markdown export of the Flows SDK documentation site, built with the site's own
Sphinx config from the `hyperscience/flows-sdk` repo, plus the repo's `samples/`
flow code. See `VERSION` in this folder for the SDK version and commit it was
built from.

## Layout

| Path | What it is |
|---|---|
| `docs/intro.md`, `docs/tutorial.md` | Concepts and the getting-started tutorial |
| `docs/source-docs.md` | API reference for `flows_sdk.blocks`, `flows`, `utils`, `types`, `mocks`, `error_handling`, etc. (autodoc) |
| `docs/idp/idp_vXX.md` | IDP Library for one platform version (`flows_sdk.implementations.idp_vXX`); `docs/idp/README.md` lists them |
| `docs/custom_supervision.md` | Custom Supervision JSON spec (v34+); `custom_supervision_v33.md` for older |
| `docs/cli.md` | `hs-flows` CLI (bundle, etc.) |
| `docs/secrets.md`, `docs/python_packages.md` | Secrets and third-party Python packages in code blocks |
| `docs/testing*.md` | Flow testing framework |
| `docs/examples.md` | Index of the example flows; the code itself is in `samples/` |
| `docs/CHANGELOG.md` | Per-version SDK changes |
| `docs/faq.md`, `docs/data_types.md`, `docs/salesforce_integration_flow.md` | Misc pages |
| `samples/<name>/` | Example flows (`.py`, `.json`); e.g. `idp_flow_v43`, `fork`, `foreach`, `routing`, `secrets`, `on_error_flow_v39_1` |

## Steps

1. Search, quoting the user's keywords (all terms must match):
   ```bash
   python3 "$HOME/.claude/skills/flows-sdk/search_sdk.py" "<keywords>"
   ```
   Flags: `--version 43` limits the IDP Library to that platform version;
   `--samples` searches only sample code; `--docs` skips samples; `--json`.
2. Read the hit at the printed `path:line` (paths are relative to this skill
   folder) before answering. The snippet is a locator, not the answer.
3. Match the platform version. If the target instance runs v42, read
   `docs/idp/idp_v42.md` and the `idp_flow_v42` sample, not v44. Check
   `docs/CHANGELOG.md` if the project pins an older `flows_sdk` than `VERSION`.
4. Cite the doc path(s) you used. Don't invent classes, parameters, or CLI flags
   that aren't in these files.

## Notes

- Release/sample-document binaries (PDFs, zips, images) from `samples/` are not
  included, only code and JSON.
- Links inside the docs are relative (`source-docs.md#flows_sdk.blocks.Block`);
  open the target file and search for the anchor's last segment.
- To refresh, see `REBUILD.md`.
