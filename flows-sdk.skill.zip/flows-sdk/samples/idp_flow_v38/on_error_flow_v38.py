from uuid import UUID

from flows_sdk.flows import Flow, Manifest, Parameter
from flows_sdk.implementations.idp_v38.additional_blocks import (
    HyperscienceRestApiBlock,
    JSONOutputsBlock,
)
from flows_sdk.package_utils import export_flow
from flows_sdk.utils import workflow_input

ON_ERROR_FLOW_UUID = '46ad83ad-5a9c-46c5-a322-e2aa8e40bdce'
ON_ERROR_FLOW_TASK_NAME = 'ON_ERROR_V38_EXAMPLE'
ON_ERROR_DESCRIPTION = """Flow designed to be used as an "on-error" handler for other flows.
\n\n
With the on-error flow configured, when the original flow fails for any reason, and all
    the configured auto-retries have been exhausted, the on-error flow will be triggered.
\n\n
The input it receives is the ID of the failed flow run, which can be used to query
    additional information about the failure.
\n\n
In this on-error flow implementation,
    we fetch the full metadata of the failed flow run and then send it
    to a user-configured output.
    The data format of the output conforms to
    the schema documented here: https://docs.hyperscience.ai/#flows-runs.
\n\n
If you need more complex logic in this flow
    please consult the documentation of Flows SDK (https://flows-sdk.hyperscience.ai)
    and the available public APIs (https://docs.hyperscience.ai)
"""


class OnErrorFlowInputKeys:
    failed_run_uuid: str = 'failed_run_uuid'


class OnErrorManifest(Manifest):
    def __init__(self, flow_identifier: str):
        super().__init__(
            identifier=flow_identifier,
            roles=['on_error', 'supporting'],
            input=[
                Parameter(
                    name=OnErrorFlowInputKeys.failed_run_uuid,
                    type='string',
                    title='Failed Flow Run UUID',
                    description='UUID of the failed flow run that triggered this on_error flow',
                    optional=False,
                    ui={'hidden': True},
                ),
            ],
        )


def on_error_flow() -> Flow:

    flow_run_rest_api_block = HyperscienceRestApiBlock(
        reference_name='flow_run_rest_api_block',
        method='GET',
        app_endpoint=f'/api/v5/flow_runs/{workflow_input(OnErrorFlowInputKeys.failed_run_uuid)}',
    )

    json_outputs_block = JSONOutputsBlock(
        inputs={'payload': flow_run_rest_api_block.output('result.data')}
    )

    return Flow(
        uuid=UUID(ON_ERROR_FLOW_UUID),
        owner_email='flows.sdk@hyperscience.com',
        title='On-Error V38 - flows-sdk',
        description=ON_ERROR_DESCRIPTION,
        manifest=OnErrorManifest(ON_ERROR_FLOW_TASK_NAME),
        output={},
        input={},
        blocks=[
            flow_run_rest_api_block,
            json_outputs_block,
        ],
    )


def entry_point_workflow() -> Flow:
    return on_error_flow()


if __name__ == '__main__':
    export_flow(entry_point_workflow())
