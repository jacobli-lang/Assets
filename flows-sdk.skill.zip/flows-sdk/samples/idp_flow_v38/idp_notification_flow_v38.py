import os

from flows_sdk.blocks import Outputs
from flows_sdk.flows import Flow, Manifest
from flows_sdk.package_utils import export_flow
from flows_sdk.utils import icon_path_to_base64, workflow_input

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

IDP_SUBMISSION_NOTIFY_IDENTIFIER = 'IDP_SUBMISSION_NOTIFY_V38_EXAMPLE'
IDP_SUBMISSION_NOTIFY_UUID = 'cf22dd1e-d013-4d09-b598-40696fa9a322'
IDP_SUBMISSION_NOTIFY_TITLE = 'Submission State Notifications V38 - flows-sdk example'

IDP_OUTPUT_ROLE = 'idp_output'


def idp_submission_notify_workflow() -> Flow:
    return Flow(
        title='Submission State Notifications V38',
        owner_email='flows.sdk@hyperscience.com',
        description=(
            'Send notifications to external systems when a submission has been '
            'created or is waiting for supervision. \n'
            f'If the "Document Processing" flow is live, this flow '
            'must also be live, but it can be empty.'
        ),
        is_user_facing=True,
        blocks=[
            Outputs(
                reference_name='outputs',
                title='Outputs',
                description=(
                    'Send submission data to external systems when a submission '
                    'has been created or is waiting for supervision'
                ),
                role_filter=[IDP_OUTPUT_ROLE],
                input_template={
                    'submission': {'id': workflow_input('submission.id')},
                    'enabled': True,
                },
                blocks=[],
            )
        ],
        uuid=IDP_SUBMISSION_NOTIFY_UUID,
        input={},
        output={},
        manifest=Manifest(
            identifier=IDP_SUBMISSION_NOTIFY_IDENTIFIER,
            input=[
                {
                    'name': 'submission',
                    'type': 'Submission',
                    'title': 'Submission Object',
                    'ui': {'hidden': True},
                }
            ],
            output=[],
            roles=['notifications', 'supporting'],
            ui={
                'hidden': True,
                'icon': icon_path_to_base64(os.path.join(BASE_DIR, 'notification_flow_icon.png')),
            },
        ),
    )


def entry_point_workflow() -> Flow:
    return idp_submission_notify_workflow()


if __name__ == '__main__':
    export_flow(entry_point_workflow())
