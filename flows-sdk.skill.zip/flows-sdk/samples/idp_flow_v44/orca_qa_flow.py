from uuid import UUID

from flows_sdk.blocks import Block
from flows_sdk.flows import Flow, Manifest, Parameter
from flows_sdk.package_utils import export_flow
from flows_sdk.utils import str_to_deterministic_uuid_4, workflow_input

ORCA_QA_FLOW_IDENTIFIER = 'ORCA_QA_FLOW_EXAMPLE'
ORCA_QA_FLOW_UUID = str(str_to_deterministic_uuid_4(ORCA_QA_FLOW_IDENTIFIER))
ORCA_QA_FLOW_TITLE = 'ORCA Quality Assurance Flow - flows-sdk example'
ORCA_QA_FLOW_DESCRIPTION = 'Optical Reasoning Cognition Agent Quality Assurance flow.'


class FlowInputs:
    Submission = 'submission'
    TaskRestrictions = 'task_restrictions'
    OrcaQASampleRate = 'orca_qa_sample_rate'

    @classmethod
    def get_manifest_inputs(cls) -> list[Parameter]:
        return [
            Parameter(
                name=cls.Submission,
                type='Submission',
                title='Submission Object',
                ui={'hidden': True},
            ),
            Parameter(
                name=cls.TaskRestrictions,
                type='TaskRestrictions',
                title='Task Restrictions',
                description=(
                    'Defines what users can access Supervision tasks created by this flow.'
                ),
                optional=True,
                ui={'hidden': True},
            ),
            Parameter(
                name=cls.OrcaQASampleRate,
                type='Percentage',
                schema={'type': 'number', 'minimum': 0, 'maximum': 1},
                title='ORCA QA Sample Rate',
                description='Defines the percentage of documents sampled for QA.',
                value=1,
                ui={'hidden': True},
            ),
        ]


def entry_point_workflow() -> Flow:
    return orca_qa_flow()


def orca_qa_flow() -> Flow:
    submission_ref = workflow_input(FlowInputs.Submission)
    task_restrictions_ref = workflow_input(FlowInputs.TaskRestrictions)
    orca_qa_sample_rate_ref = workflow_input(FlowInputs.OrcaQASampleRate)

    orca_qa_block = Block(
        identifier='VISION_LANGUAGE_MODEL_QA_2',
        reference_name='orca_qa',
        input={
            'submission': submission_ref,
            'sample_rate': orca_qa_sample_rate_ref,
            'task_restrictions': task_restrictions_ref,
        },
        title='ORCA Quality Assurance',
        description='Quality assurance for ORCA document processing',
    )

    return Flow(
        uuid=UUID(ORCA_QA_FLOW_UUID),
        owner_email='flows.sdk@hyperscience.com',
        title=ORCA_QA_FLOW_TITLE,
        manifest=Manifest(
            identifier=ORCA_QA_FLOW_IDENTIFIER,
            input=FlowInputs.get_manifest_inputs(),
            roles=['supporting', 'quality_assurance', 'read_only'],
            enable_overrides=True,
        ),
        blocks=[orca_qa_block],
        description=ORCA_QA_FLOW_DESCRIPTION,
    )


if __name__ == '__main__':
    export_flow(flow=entry_point_workflow())
