# Testing showcase

A complete, runnable flows project with tests in every tier of the flows testing framework. What
each tier is for, and how to write one, is in the
[testing guide](https://flows-sdk.hyperscience.ai/pages/testing.html); this README covers only
this project.

The flow is the IDP starter flow from `samples/idp_flow_v43`, whose layout release and Form W-9
sample ship with the SDK. The W-9 sample holds no real person's data, so it is safe to commit,
stub and send to an instance. The starter flow has no custom code, so this project adds some:
derive the tax classification and TIN, validate the TIN in a subflow, and route on the result.

## Layout

```
showcase/flows/
├── document_processing/  the WRAPPER — configuration only
│   ├── flow.py           settings an operator edits; calls the core by identifier
│   └── tests/
│       ├── contract/     FlowStaticChecksSuite for this flow
│       ├── e2e/          pytest against a live instance, with synthetic data
│       ├── in_flow/      tests that run as flows, on customer data
│       └── data/         the synthetic W-9, its approved extraction, its layout release
├── idp_core/             the CUSTOM CORE — the pipeline, and this project's logic
│   ├── flow.py           the standard IDP chain with custom blocks spliced in
│   ├── functions.py      the custom code
│   └── tests/
│       ├── unit/         the functions, called directly or through invoke_block
│       └── flow/         the whole graph offline via FlowTestRunner
└── tin_validation/       a SUBFLOW, called by the core
    ├── flow.py
    ├── functions.py
    └── tests/unit/
```

The custom blocks are in the core rather than the wrapper because they read extracted field
values, which exist only inside the IDP chain. So the wrapper's offline tests are the contract
tier, and the unit and flow tiers live beside the core.

QA sampling is switched off in `document_processing/flow.py` for both live tiers: nothing in a
test answers a QA task, so each run would leave one in the supervision queue. The comment there
explains why that takes two steps.

## Running the offline tiers

```bash
pip install -e '.[dev]'
pytest -m "not e2e and not in_flow"

ruff check .
ruff format .
mypy showcase
```

`flows_sdk` is not on public PyPI, so `pip install` resolves it from wherever your environment
points for the SDK: an internal index, or `pip install -e` against a local checkout.

The flow tier stubs the core's platform blocks with what they emitted for the synthetic W-9,
recorded from a run on an instance into `showcase/flows/idp_core/tests/data/`. Re-record it when
an SDK or platform upgrade changes the IDP blocks, with the credentials below, and read the diff:

```bash
python -m showcase.flows.idp_core.tests.flow.record_platform_outputs
```

See [stubs come from a real run](https://flows-sdk.hyperscience.ai/pages/testing.html#recorded-stubs).

This project has the shape `hs-flows init` generates, and a test in the SDK's suite holds the two
together. The ruff and mypy rules in `.flows-sdk/` are the SDK's; `hs-flows update` replaces
them, so don't edit them here.

## Running the live tiers

```bash
export HS_BASE_URL=https://dev-instance
export HS_M2M_CREDS=~/.hyperscience/m2m_creds.json
export HS_M2M_CLIENT_ID=<client id>
pytest -m e2e        # synthetic data, against a development instance
pytest -m in_flow    # customer data, on the customer's instance
```

The `e2e` tests deploy their own namespaced copies of the flows, so a run never changes the ones
an operator configured. They import the layout release if the instance lacks it, set the
knowledge-store collection the routing reads per scenario, and complete a supervision task. The
credential therefore needs to deploy flows, create submissions, edit the knowledge store and
complete supervision tasks. See
[end-to-end tests](https://flows-sdk.hyperscience.ai/pages/testing.html#e2e-tests).

The `in_flow` tests are flows, in `document_processing/tests/in_flow/`:

```
evaluation.py              the steps, as plain code: submit, wait, compare
suite_eval_flow.py         the evaluation flow running them, rebuilt every run
suite_eval_wrapper_flow.py the document and its approved result, configured on the instance
test_in_flow.py            the pytest entry point
```

The first run creates the flows and fails, asking for the test data to be configured on the
instance. See [running in-flow tests](https://flows-sdk.hyperscience.ai/pages/testing.html#in-flow-running).
