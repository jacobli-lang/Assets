"""The document-processing **wrapper** — configuration, and a call to the custom core.

This is the flow from ``samples/idp_flow_v43`` (the IDP starter showcase), whose layout release
and sample document **ship with the SDK** (``release.zip`` and ``form-w9-sample.png``), so the
end-to-end tier has a real document that classifies. A Form W-9 holds no real person's data, so
it is safe to commit, stub and pass around.

A wrapper is **configuration**. It declares the settings an operator edits in Flow Studio — the
layout release, the notification flows, the switches this project adds — and calls an IDP core
by identifier. It holds no business logic.

The one line that makes this a *customised* IDP project is::

    IDPCoreBlock(idp_wf_config, identifier=IDP_CORE_IDENTIFIER)

pointing at ``showcase/flows/idp_core/flow.py`` rather than the SDK's default core. This
project's blocks live there because they read extracted field values and so have to run inside
the pipeline, after transcription.

So the unit and flow tiers have nothing to test in this file. Its tests are the contract tier
(does it declare the interface its callers depend on?) and the wiring tier (does every
reference resolve?). The logic tests live beside the core.
"""

from pathlib import Path
from uuid import UUID

from flows_sdk.error_handling import ErrorHandling
from flows_sdk.flows import Flow, Parameter
from flows_sdk.identifiers import flow_identifier
from flows_sdk.implementations.idp_v43 import idp_blocks, idp_values
from flows_sdk.implementations.idp_v43.idp_blocks import IDPCoreBlock
from flows_sdk.implementations.idp_v43.idp_blocks.submission_complete import (
    SubmissionCompleteSettings,
)
from flows_sdk.implementations.idp_v43.idp_values import (
    DEFAULT_IDP_SUBMISSION_NOTIFY_IDENTIFIER,
    IdpWorkflowConfig,
    IDPWrapperManifest,
    Settings,
    StructuredSamplingRates,
    TranscriptionQaConfigData,
    get_idp_wf_config,
)
from flows_sdk.package_utils import export_flow
from flows_sdk.utils import workflow_input

from showcase.flows.idp_core.flow import (
    EXEMPT_CODE_COLLECTION,
    IDP_CORE_IDENTIFIER,
    REQUIRE_VALID_TIN,
)

FLOW_UUID = 'c4e81b27-5f39-4a6d-8b12-7e0a3d9c5f68'
FLOW_IDENTIFIER = flow_identifier('SHOWCASE_DOCUMENT_PROCESSING')
FLOW_TITLE = 'Showcase — Document Processing'


def idp_workflow(idp_wf_config: IdpWorkflowConfig) -> Flow:
    """Build the wrapper: notification settings, the custom core, and the outputs block."""
    idp_wf_config.notification_workflow_initialization = DEFAULT_IDP_SUBMISSION_NOTIFY_IDENTIFIER
    idp_wf_config.notification_workflow_classification = DEFAULT_IDP_SUBMISSION_NOTIFY_IDENTIFIER
    idp_wf_config.notification_workflow_identification = DEFAULT_IDP_SUBMISSION_NOTIFY_IDENTIFIER
    idp_wf_config.notification_workflow_transcription = DEFAULT_IDP_SUBMISSION_NOTIFY_IDENTIFIER
    idp_wf_config.notification_workflow_flexible_extraction = (
        DEFAULT_IDP_SUBMISSION_NOTIFY_IDENTIFIER
    )

    # QA off. `get_idp_wf_config()` enables every QA flavour at a 5% sampling rate, which suits
    # production but not a flow under test: QA raises a task on a sampled document that nothing
    # in the flow answers, so each run leaves a task in the supervision queue. The submission
    # completes regardless (QA samples, it does not gate), so the tests still pass.
    #
    # Two halves: the sampling rates here, the enable flags via `additional_inputs` below.
    # `transcription_qa = None` clears `field_transcr_qa_enabled` but renders the four sampling
    # rates as null, which the platform rejects at import ("None is not of type 'number'"; they
    # are typed `Percentage`). A config object with zero rates keeps the rates valid but turns
    # the flag back *on*, since the flag is `transcription_qa is not None`.
    idp_wf_config.qa_config.field_id_qa_sampling_ratio = 0
    idp_wf_config.qa_config.nlc_qa_sampling_ratio = 0
    idp_wf_config.qa_config.table_id_qa_sampling_ratio = 0
    idp_wf_config.qa_config.table_cell_transcription_qa_sample_rate = 0
    idp_wf_config.qa_config.transcription_qa = TranscriptionQaConfigData(
        auto_qa_sampling_rate_enabled=False,
        structured_sampling_rates=StructuredSamplingRates.single_sampling_rate(0),
        semi_structured_sampling_rate=0,
        exclude_auto_transcribe_fields_from_qa=True,
    )

    # The custom core, not `DEFAULT_IDP_CORE_IDENTIFIER`: this argument puts this project's
    # blocks in the pipeline.
    idp_flow = IDPCoreBlock(
        idp_wf_config,
        identifier=IDP_CORE_IDENTIFIER,
        # The four enable flags, forced off. `additional_inputs` is the sanctioned override;
        # the config alone cannot do it: `qa` is derived as `transcription_qa is not None`, and
        # the other three are hardcoded to `True` when the settings are assembled.
        additional_inputs={
            SubmissionCompleteSettings.TranscriptionQaEnabled: False,
            SubmissionCompleteSettings.FieldIdQaEnabled: False,
            SubmissionCompleteSettings.TableIdQaEnabled: False,
            SubmissionCompleteSettings.TableCellTranscriptionQaEnabled: False,
            # This project's own settings, passed to the core explicitly. A subflow's input is
            # only what its caller passes: declaring a setting on both flows does not connect
            # them, and the core would run on its own defaults.
            REQUIRE_VALID_TIN: workflow_input(REQUIRE_VALID_TIN),
            EXEMPT_CODE_COLLECTION: workflow_input(EXEMPT_CODE_COLLECTION),
        },
    )

    outputs = idp_blocks.IDPOutputsBlock(inputs={'submission': idp_flow.output('submission')})

    # This project's settings are declared alongside the standard IDP ones, or the platform
    # refuses to deploy: a flow-level `input` value with no matching manifest Parameter is a
    # validation error, not a default. An operator sets them here and the core reads them, so
    # both flows declare them and the core call above passes them on.
    manifest = IDPWrapperManifest(FLOW_IDENTIFIER)
    # `IDPWrapperManifest` declares no outputs; declared here so a caller can learn the return
    # shape without reading the source.
    manifest.output = [
        Parameter(name='submission', type='object', title='The processed submission'),
        Parameter(name='outcome', type='object', title='Release/hold decision and its reasons'),
    ]
    manifest.input.extend(
        [
            Parameter(
                name=REQUIRE_VALID_TIN,
                type='boolean',
                title='Require a valid taxpayer number',
                description=(
                    'When on, a document whose TIN is not nine digits is held for review. '
                    'Turn off to release documents with an illegible TIN.'
                ),
                value=True,
            ),
            Parameter(
                name=EXEMPT_CODE_COLLECTION,
                type='string',
                title='Exempt payee code collection',
                description='Knowledge-store collection holding the valid exempt payee codes.',
                value='W9_EXEMPT_PAYEE_CODES',
            ),
        ]
    )

    return Flow(
        uuid=UUID(FLOW_UUID),
        owner_email='flows-sdk@hyperscience.ai',
        title=FLOW_TITLE,
        description=(
            'The IDP starter wrapper, pointed at a custom IDP core — used to demonstrate '
            'every tier of the flows testing framework.'
        ),
        manifest=manifest,
        output={
            'submission': idp_flow.output('submission'),
            'outcome': idp_flow.output('outcome'),
        },
        triggers=idp_values.IDPTriggers(),
        input={
            Settings.LayoutReleaseUuid: None,
            # Default on: a document whose TIN did not transcribe cleanly should be reviewed.
            REQUIRE_VALID_TIN: True,
            EXEMPT_CODE_COLLECTION: 'W9_EXEMPT_PAYEE_CODES',
        },
        blocks=[idp_flow, outputs],
        error_handling=ErrorHandling(on_error_flow=None),
    )


def entry_point_workflow() -> Flow:
    return idp_workflow(get_idp_wf_config())


if __name__ == '__main__':
    dist = Path(__file__).parents[3] / 'dist'
    dist.mkdir(exist_ok=True)
    export_flow(
        entry_point_workflow(),
        filename='showcase_document_processing',
        location=str(dist),
    )
