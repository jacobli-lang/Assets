"""The in-flow evaluation's steps, as plain custom code over the public API.

Submit the configured document, wait for it, and compare what came out with what a human
approved. The SDK supplies only the reporting — naming a block as a case, collecting the
verdicts, failing the run. These functions run on the instance, through ``_hs_block_instance``,
and import only the standard library, so the test flow needs nothing installed.

Each block that uses them passes ``include_module=True``: the functions call module-level helpers,
and without it only the entrypoint's own source would reach the platform.

A case returns ``{'passed': bool}`` and, ideally, a ``detail`` string. ``collect_results``
reads the case name from the block's reference name.

The comparisons read the submission from the **public API**, the endpoint the UI reads, so the
reference a human saves from the UI and the compared value share one representation. The
in-flow submission does not: on a machine-only run it keeps low-confidence fields as the
machine's raw guesses, while the API nulls them.
"""

from __future__ import annotations

import json
from typing import Any

#: Flow-run states that mean "finished". `PAUSED` is not one: a supervised run waits there.
_FINISHED = ('COMPLETED', 'FAILED', 'CANCELLED', 'TIMED_OUT')

#: Passed as ``handled_error_codes``. Without it ``hs_get``/``hs_post`` raise on any error status
#: with a message that leaves out the response body, so the ``status_code`` checks below never run.
_CLIENT_ERRORS = list(range(400, 500))


def submit_and_wait(
    blob_uuid: str,
    filename: str,
    flow_identifier: str,
    timeout_seconds: int,
    poll_seconds: int,
    _hs_block_instance: Any,
) -> dict[str, Any]:
    """Submit the configured document to the flow under test, and wait for its run to finish.

    Three things the API imposes:

    * submit by ``flow_uuid``. The serializer has no ``identifier`` field and drops unknown keys
      silently, so posting an identifier runs the instance's *default* flow;
    * ``?debug=true`` is what adds ``flow_run_id`` to a submission;
    * wait on the **flow run**, not the submission's state. Completing the submission is one step
      inside the run, so ``state == 'complete'`` says nothing about the blocks after it.

    Raises rather than recording a verdict: nothing after it can run without a finished
    submission. The suite reports the failure with the run's URL.
    """
    import base64  # noqa: PLC0415
    import time  # noqa: PLC0415

    flow_uuid = _flow_uuid(flow_identifier, _hs_block_instance)
    blob = _hs_block_instance.fetch_blob(blob_uuid)
    response = _hs_block_instance.hs_post(
        '/api/v5/submissions',
        json={
            'flow_uuid': flow_uuid,
            'machine_only': True,
            'files': [
                {
                    'file_content_base64': base64.b64encode(blob.content).decode('ascii'),
                    'filename': filename,
                }
            ],
        },
        handled_error_codes=_CLIENT_ERRORS,
    )
    if response.status_code >= 400:  # noqa: PLR2004
        raise AssertionError(
            f'could not submit {filename!r} to {flow_identifier!r}: '
            f'HTTP {response.status_code} {response.text[:300]}'
        )
    submission_id = int(json.loads(response.text)['submission_id'])

    deadline = time.monotonic() + timeout_seconds
    flow_run_id: str | None = None
    status: str | None = None
    while True:
        if flow_run_id is None:
            debug = _hs_block_instance.hs_get(
                f'/api/v5/submissions/{submission_id}',
                params={'debug': 'true'},
                handled_error_codes=_CLIENT_ERRORS,
            )
            if debug.status_code < 400:  # noqa: PLR2004
                flow_run_id = json.loads(debug.text).get('flow_run_id')
        if flow_run_id is not None:
            run = _hs_block_instance.hs_get(
                f'/api/v5/flow_runs/{flow_run_id}', handled_error_codes=_CLIENT_ERRORS
            )
            # The run id exists before the run is readable; until then, keep polling.
            if run.status_code < 400:  # noqa: PLR2004
                status = json.loads(run.text).get('status')
                if status in _FINISHED:
                    break
        if time.monotonic() >= deadline:
            raise AssertionError(
                f'submission {submission_id} did not finish within {timeout_seconds}s '
                f'(flow run {flow_run_id}, last status {status!r})'
            )
        time.sleep(poll_seconds)

    if status != 'COMPLETED':
        raise AssertionError(
            f'flow run {flow_run_id} for submission {submission_id} ended {status}'
        )
    _hs_block_instance.log(f'submission {submission_id} finished; flow run {flow_run_id}')
    return {'submission_id': submission_id}


def _flow_uuid(flow_identifier: str, _hs_block_instance: Any) -> str:
    response = _hs_block_instance.hs_get(
        '/api/v5/flows',
        params={'identifier': flow_identifier, 'limit': 500},
        handled_error_codes=_CLIENT_ERRORS,
    )
    if response.status_code >= 400:  # noqa: PLR2004
        raise AssertionError(
            f'could not look up flow {flow_identifier!r}: HTTP {response.status_code}'
        )
    found = [
        flow
        for flow in json.loads(response.text).get('results', [])
        if flow.get('identifier') == flow_identifier
    ]
    for flow in found:
        if flow.get('is_live'):
            return str(flow['uuid'])
    if found:
        # The submissions API refuses a flow that is not live with a bare 400.
        raise AssertionError(
            f'flow {flow_identifier!r} is on this instance but not live, so a submission to it '
            f'is refused. Deploy it first.'
        )
    raise AssertionError(
        f'no flow {flow_identifier!r} is deployed here, so nothing to submit to. Deploy the '
        f'flow under test on this instance first.'
    )


def _fetch_submission(submission_id: Any, _hs_block_instance: Any) -> dict[str, Any]:
    """The submission as the public API renders it.

    ``flat=false`` is required: without it the payload has no ``documents``, so every field
    lookup below would come back empty and every case would pass vacuously.
    """
    response = _hs_block_instance.hs_get(
        f'/api/v5/submissions/{int(submission_id)}?flat=false', handled_error_codes=_CLIENT_ERRORS
    )
    # An error body has no documents, so every expected field would read as a wrong extraction
    # and hide the real cause, such as the block's permissions.
    if response.status_code >= 400:  # noqa: PLR2004
        raise AssertionError(
            f'could not read submission {submission_id}: '
            f'HTTP {response.status_code} {response.text[:300]}'
        )
    return dict(json.loads(response.text))


def _fields(submission: dict[str, Any], match: str = 'normalized') -> dict[str, Any]:
    """``{field name: transcribed value}`` across every document in the submission.

    The endpoint's shape:

    * the field list is ``documents[].document_fields[]``; there is no ``fields`` key;
    * ``transcription`` is a ``{'raw': ..., 'normalized': ...}`` dict, and *match* picks
      the half to compare.

    A field the platform left untranscribed (below the confidence threshold, with no
    supervision on a machine-only run) carries ``None``; it is kept, so an expectation about
    it fails visibly instead of vacuously.
    """
    found: dict[str, Any] = {}
    for document in submission.get('documents') or []:
        for field in document.get('document_fields') or []:
            name = field.get('name')
            if not name or name in found:
                continue
            transcription = field.get('transcription')
            found[name] = (
                transcription.get(match) if isinstance(transcription, dict) else transcription
            )
    return found


def matches_reference(
    submission_id: Any, reference_submission: Any, _hs_block_instance: Any
) -> dict[str, Any]:
    """Compare every transcribed field against the approved reference submission.

    ``reference_submission`` is configured on the wrapper by a human who exported it from
    the UI, so nothing here is written down in version control.
    """
    actual = _fields(_fetch_submission(submission_id, _hs_block_instance))
    expected = _fields(reference_submission or {})

    differing = sorted(name for name in expected if actual.get(name) != expected.get(name))
    missing = sorted(name for name in expected if name not in actual)

    if not expected:
        detail = 'the reference submission has no fields — is it configured on the wrapper?'
        passed = False
    elif differing:
        detail = f'{len(differing)} field(s) differ from the reference: {differing}'
        passed = False
    else:
        detail = f'all {len(expected)} reference field(s) match'
        passed = True

    _hs_block_instance.log(detail)
    return {'passed': passed, 'detail': detail, 'missing': missing}


def field_equals(
    submission_id: Any, field_name: str, expected: Any, _hs_block_instance: Any
) -> dict[str, Any]:
    """Compare one named field, so a failure names the field rather than the submission."""
    actual = _fields(_fetch_submission(submission_id, _hs_block_instance)).get(field_name)
    passed = actual == expected
    detail = f'{field_name}: expected {expected!r}, read {actual!r}'
    _hs_block_instance.log(detail)
    return {'passed': passed, 'detail': detail}
