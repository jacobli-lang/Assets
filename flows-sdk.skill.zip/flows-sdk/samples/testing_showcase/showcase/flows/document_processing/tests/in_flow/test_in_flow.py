"""In-flow tier — extraction accuracy on customer data, measured inside the instance.

The smallest tier. It answers the one question synthetic data cannot: does the flow read the
right values off the documents a customer actually receives? The flow's *logic* — completion,
the custom blocks, routing, supervision — is tested in ``tests/e2e/`` against a synthetic W-9.

The tests are the flows beside this file: ``suite_eval_flow.py`` holds the assertions and
``suite_eval_wrapper_flow.py`` the data they run against. Inheriting ``InFlowTestSuite`` and
naming them is the whole integration — pytest syncs them, triggers the wrapper, and reports its
flow run as one test, which fails with a link to the run when a case failed.

The tests are flows because customer documents must not leave the environment — not to a
developer's machine, not into CI logs, not into a test process's memory. So the assertions run
inside the instance, and this side learns only whether the suite's flow run succeeded, plus a
URL where a human can read which case failed and why.

Running it::

    export HS_BASE_URL=https://my-instance
    export HS_M2M_CREDS=~/.hyperscience/m2m_creds.json
    export HS_M2M_CLIENT_ID=<client id>
    pytest -m in_flow

The suite skips without credentials. If the wrapper's test data has not been configured yet the
platform refuses to deploy it, and the failure says so with a link to its settings page.

    pytest -m in_flow --merge-test-flows    # wrapper definition changed; keep its data
    pytest -m in_flow --force-test-flows    # rebuild the wrapper, discarding its data
"""

import pytest
from flows_sdk.testing.harness import requires_instance
from flows_sdk.testing.in_flow_suite import InFlowTestCase, InFlowTestSuite

from showcase.flows.document_processing.tests.in_flow.suite_eval_flow import (
    entry_point_workflow as accuracy_suite,
)
from showcase.flows.document_processing.tests.in_flow.suite_eval_wrapper_flow import (
    entry_point_workflow as accuracy_wrapper,
)

pytestmark = [pytest.mark.in_flow, requires_instance()]


class TestDocumentProcessingAccuracy(InFlowTestSuite):
    """What the models extract from the configured document, checked on the instance."""

    #: The wrapper pytest triggers — the flow holding the configured document and its approved
    #: result, which calls the assertions as a subflow. Named so the pytest id reads
    #: `test_the_suite_flow_run_succeeded[accuracy]`.
    suite_test_cases = [InFlowTestCase(accuracy_wrapper, name='accuracy')]

    #: The assertions flow. Deployed but never triggered directly: rebuilt from this checkout
    #: every run, and needed because the platform will not deploy a wrapper whose subflow does
    #: not exist yet.
    dependency_flows = [accuracy_suite]

    # A real document runs classification, identification and transcription. The in-flow wait
    # blocks carry their own, shorter budgets.
    timeout_seconds = 2400
    poll_seconds = 20
