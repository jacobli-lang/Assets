"""End-to-end tier — the document-processing flow on a live instance, with synthetic data.

Everything these tests need is in the repository: the flows are deployed from this checkout,
the document is the synthetic W-9 in ``tests/data/``, its approved extraction is the JSON beside
it, and the layout release it classifies against ships there too. None of it is customer data,
so these are ordinary pytest tests. They drive the instance through its public API, read the
submission back, and assert on exact values — and they run in CI against a development
instance::

    export HS_BASE_URL=https://dev-instance
    export HS_M2M_CREDS=~/.hyperscience/m2m_creds.json
    export HS_M2M_CLIENT_ID=<client id>
    pytest -m e2e

What this tier covers is the flow's **logic**, end to end, on the real platform:

* the flow completes and its custom blocks run inside the custom core;
* it extracts the expected fields from a known document;
* the routing decision, both ways — the tests own the knowledge-store collection the routing
  reads, so the same document can be made to release or to hold;
* the supervised path, with the test taking the operator's place on the task.

Extraction *accuracy on customer documents* is the question this tier cannot answer, and it is
what ``tests/in_flow/`` is for.

Each scenario is one submission, run by a module-scoped fixture, with several small tests
reading it — so a failure names what broke, and the instance processes each document once.
"""

from __future__ import annotations

import json
from collections.abc import Iterator
from typing import Any

import pytest
from flows_sdk.testing.e2e import HsClient, assert_blocks_completed, block_run
from flows_sdk.testing.harness import requires_instance

from showcase.flows.document_processing.tests.e2e.environment import (
    DATA,
    deployed_flow_under_test,
    ensure_layout_release,
    exempt_codes,
)

pytestmark = [pytest.mark.e2e, requires_instance()]

DOCUMENT = DATA / 'form-w9-sample.png'

#: The document's approved extraction — synthetic, so its values can sit in git and be
#: compared directly.
EXPECTED_FIELDS: dict[str, str] = json.loads(
    (DATA / 'form-w9-sample.expected.json').read_text(encoding='utf-8')
)['fields']

#: The exempt payee code the document carries.
DOCUMENT_EXEMPT_CODE = EXPECTED_FIELDS['Exempt Payee Code']

#: A realistic collection: the IRS exempt payee codes, 1 to 13. The document's code is not one.
IRS_EXEMPT_CODES = [str(code) for code in range(1, 14)]

#: What the test types into the supervision task — synthetic like everything else.
CORRECTED_NAME = 'JANE Q. PUBLIC'


@pytest.fixture(scope='module')
def client() -> HsClient:
    return HsClient.from_env()


@pytest.fixture(scope='module')
def flow_under_test(client: HsClient) -> Iterator[str]:
    with deployed_flow_under_test(client, ensure_layout_release(client)) as identifier:
        yield identifier


def fields_of(submission: dict[str, Any]) -> dict[str, Any]:
    """``{field name: normalized value}`` across the submission's documents."""
    return {
        field['name']: (field.get('transcription') or {}).get('normalized')
        for document in submission.get('documents') or []
        for field in document.get('document_fields') or []
    }


# -- released: the document's code is in the collection -----------------------------------


@pytest.fixture(scope='module')
def released(client: HsClient, flow_under_test: str) -> dict[str, Any]:
    """One machine-only run, with the document's exempt code listed so routing releases it."""
    with exempt_codes(client, [*IRS_EXEMPT_CODES, DOCUMENT_EXEMPT_CODE]):
        submission_id = client.create_submission(DOCUMENT, flow_identifier=flow_under_test)
        return client.wait_submission(submission_id)


def test_the_flow_completes(released: dict[str, Any]) -> None:
    assert released['flow_run']['status'] == 'COMPLETED'


def test_the_custom_blocks_run_inside_the_core(client: HsClient, released: dict[str, Any]) -> None:
    """A flow run lists only its own blocks; this project's live in the core it calls."""
    core_call = block_run(released['flow_run'], '__idp_core__')
    assert core_call is not None, 'the flow never called its core'
    core_run = client.get_flow_run(core_call['subflow_run_id'])
    assert_blocks_completed(core_run, 'load_exempt_payee_codes', 'route_for_review')


def test_the_expected_fields_are_extracted(released: dict[str, Any]) -> None:
    actual = fields_of(released['submission'])
    differing = {
        name: {'expected': expected, 'read': actual.get(name)}
        for name, expected in EXPECTED_FIELDS.items()
        if actual.get(name) != expected
    }
    assert not differing, f'fields differ from the approved extraction: {differing}'


def test_a_listed_exempt_code_is_released(released: dict[str, Any]) -> None:
    assert released['flow_run']['flow_output']['outcome'] == {
        'status': 'released',
        'document_count': 1,
        'validated_count': 1,
    }


# -- held: the same document, with its code missing from the collection -------------------


@pytest.fixture(scope='module')
def held(client: HsClient, flow_under_test: str) -> dict[str, Any]:
    """The same document, but the collection lacks its code — so routing must hold it."""
    with exempt_codes(client, IRS_EXEMPT_CODES):
        submission_id = client.create_submission(DOCUMENT, flow_identifier=flow_under_test)
        return client.wait_submission(submission_id)


def test_an_unlisted_exempt_code_holds_the_document(held: dict[str, Any]) -> None:
    outcome = held['flow_run']['flow_output']['outcome']
    assert outcome['status'] == 'held', outcome
    assert any(
        f'exempt payee code {DOCUMENT_EXEMPT_CODE!r} is not in the knowledge store' in reason
        for reason in outcome['reasons']
    ), outcome['reasons']


# -- supervised: the test takes the operator's place ---------------------------------------


@pytest.fixture(scope='module')
def supervised(client: HsClient, flow_under_test: str) -> dict[str, Any]:
    """A run that stops on a transcription task, which the test completes with a correction.

    This client's own credential completes the task, so it needs a role holding one of the
    ``complete_*_tasks`` permissions.
    """
    with exempt_codes(client, [*IRS_EXEMPT_CODES, DOCUMENT_EXEMPT_CODE]):
        submission_id = client.create_submission(
            DOCUMENT, flow_identifier=flow_under_test, machine_only=False
        )
        task = client.await_supervision_task(submission_id)
        client.complete_supervision_task(task, values={'Name': CORRECTED_NAME})
        return client.wait_submission(submission_id)


def test_the_flow_resumes_after_supervision(supervised: dict[str, Any]) -> None:
    assert supervised['flow_run']['status'] == 'COMPLETED'


def test_the_operators_correction_is_what_the_flow_outputs(supervised: dict[str, Any]) -> None:
    """Proves the rest of the flow sees the operator's value, not the machine's reading."""
    assert fields_of(supervised['submission'])['Name'] == CORRECTED_NAME
