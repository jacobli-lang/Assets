"""Contract tier for the document-processing wrapper.

Nothing but the declaration: the checks are inherited from
:class:`flows_sdk.testing.suites.FlowStaticChecksSuite`. The wrapper declares settings and
calls a core, so it has no logic of its own to pin — only that it calls the right core, and
calls it correctly.

Refresh the golden after an intended change:

    UPDATE_SNAPSHOTS=1 pytest -m contract
"""

from pathlib import Path

import pytest
from flows_sdk.testing.suites import FlowStaticChecksSuite

from showcase.flows.document_processing.flow import entry_point_workflow
from showcase.flows.idp_core.flow import entry_point_workflow as idp_core_workflow

pytestmark = pytest.mark.contract


class TestDocumentProcessingContract(FlowStaticChecksSuite):
    """The wrapper: what a caller submitting a document can depend on."""

    flow = entry_point_workflow
    snapshot_path = Path(__file__).parent / 'snapshots' / 'document_processing.json'

    # The custom core. Declaring it checks that the call site supplies what the core requires,
    # and fails if the wrapper calls a different core: `IDPCoreBlock` defaults to the SDK's own,
    # which would deploy and run perfectly while skipping every block this project added.
    subflows = (idp_core_workflow,)
