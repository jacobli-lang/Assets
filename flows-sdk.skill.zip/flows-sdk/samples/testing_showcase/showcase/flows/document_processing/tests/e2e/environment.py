"""The instance state the synthetic e2e tests need, established from this repository.

Nothing here assumes the instance was prepared by hand: the layout release is imported when
missing, the flows are deployed from this checkout, and the knowledge-store collection the
routing reads is set to exactly what a test needs and emptied afterwards.

Plain functions and context managers rather than fixtures, so the test module shows what it
depends on and in which order.
"""

from __future__ import annotations

import time
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from flows_sdk.implementations.idp_v43.idp_values import Settings
from flows_sdk.testing.e2e import HsClient

from showcase.flows.document_processing.flow import FLOW_IDENTIFIER
from showcase.flows.document_processing.flow import entry_point_workflow as document_processing
from showcase.flows.idp_core.flow import EXEMPT_CODE_COLLECTION
from showcase.flows.idp_core.flow import entry_point_workflow as idp_core
from showcase.flows.tin_validation.flow import tin_validation_subflow

#: Synthetic test data — the document, its approved extraction, and the layout it classifies
#: against. Committed, because none of it belongs to anyone.
DATA = Path(__file__).parents[1] / 'data'

#: The W-9 layout release shipped in `DATA`, as its uuid.
LAYOUT_RELEASE_UUID = '43a2dcb9-7dd0-4759-8819-c3fb1822c2e6'

#: The knowledge-store collection the test copy of the flow reads exempt payee codes from.
#: Owned by these tests and distinct from the one an operator configures, so seeding it cannot
#: change how any real deployment routes.
EXEMPT_CODES_COLLECTION = 'SHOWCASE_E2E_EXEMPT_PAYEE_CODES'


def ensure_layout_release(client: HsClient, *, timeout: float = 300.0) -> str:
    """Import the W-9 layout release unless the instance already has it; return its uuid.

    The import endpoint only enqueues the work — it answers ``JOB_ENQUEUED`` and the funcall
    worker does the rest — so this polls until the release is listed.
    """
    if _release_is_listed(client):
        return LAYOUT_RELEASE_UUID
    with (DATA / 'w9-layout-release.zip').open('rb') as release:
        # `template_releases`, not `layout_releases`: the latter route exists but refuses POST.
        client.request(
            'POST',
            '/api/template_releases/import_release',
            files={'template_release_file': ('w9-layout-release.zip', release, 'application/zip')},
        )
    deadline = time.time() + timeout
    while not _release_is_listed(client):
        if time.time() >= deadline:
            raise TimeoutError(
                f'layout release {LAYOUT_RELEASE_UUID} was not listed within {timeout:.0f}s of '
                f'importing it. The import runs on the funcall worker — is it running?'
            )
        time.sleep(5)
    return LAYOUT_RELEASE_UUID


def _release_is_listed(client: HsClient) -> bool:
    page: str | None = '/api/template_releases'
    while page is not None:
        body = client.get_json(page)
        if any(release.get('uuid') == LAYOUT_RELEASE_UUID for release in body.get('results', [])):
            return True
        page = body.get('next')
    return False


@contextmanager
def deployed_flow_under_test(client: HsClient, layout_release: str) -> Iterator[str]:
    """Deploy this checkout's flows as copies; yield the identifier of the one to submit to.

    All three flows are copied under one namespace of their own. The wrapper calls the core and
    the core calls TIN validation *by identifier*, declared with ``flow_identifier``, so the
    copies call each other rather than the originals. Nothing an operator configured changes,
    and concurrent runs never share a deployment. The wrapper's copy carries the test's settings
    — this layout release, this collection — and every copy is undeployed and archived on exit.
    """
    with client.deployed_copies(
        tin_validation_subflow,
        idp_core,
        document_processing,
        settings={
            FLOW_IDENTIFIER: {
                Settings.LayoutReleaseUuid: layout_release,
                EXEMPT_CODE_COLLECTION: EXEMPT_CODES_COLLECTION,
            }
        },
    ) as copies:
        yield copies[FLOW_IDENTIFIER]['identifier']


@contextmanager
def exempt_codes(client: HsClient, codes: list[str]) -> Iterator[None]:
    """Hold the test's collection at exactly *codes* for the duration of the block.

    Emptied first and afterwards, so a test never inherits what an earlier one — or an
    interrupted run — left behind.
    """
    _empty_collection(client)
    for code in codes:
        client.post_json(
            '/api/v5/knowledge_store/items',
            json={'collection': EXEMPT_CODES_COLLECTION, 'properties': {'code': code}},
        )
    try:
        yield
    finally:
        _empty_collection(client)


def _empty_collection(client: HsClient) -> None:
    items: list[dict[str, Any]] = []
    page: str | None = '/api/v5/knowledge_store/items'
    params: dict[str, str] | None = {'collection': EXEMPT_CODES_COLLECTION}
    while page is not None:
        body = client.get_json(page, params=params)
        items.extend(body.get('results') or [])
        page, params = body.get('next'), None
    for item in items:
        client.request('DELETE', f'/api/v5/knowledge_store/items/{item["id"]}')
