"""In-flow evaluation of the document-processing flow — extraction accuracy on customer data.

This is a **flow**, not a pytest module. It runs on the instance, so the document it submits and
the submission it inspects never leave the environment. ``suite_eval_wrapper_flow.py`` declares
the test *data* as inputs a human configures once: data belongs to the instance, the evaluation
to git.

It holds only what synthetic data cannot answer: whether the flow reads the right values off a
*customer's* document. The flow's logic — completion, the custom blocks, routing, supervision —
is tested in ``tests/e2e/`` with a synthetic W-9. The showcase has no customer data, so its
wrapper is configured with that same W-9; in a real project it is a real document that never
enters git.

Each step is a custom code block running a function from ``evaluation.py``: submit, wait, compare.
The SDK contributes only the reporting — ``in_flow_test_case`` to name a case, ``collect_results``
and ``fail_if_any_failed`` to gather the verdicts. Add a case by adding a block whose reference
name is wrapped in ``in_flow_test_case()``; the collector finds it.
"""

from pathlib import Path

from flows_sdk.blocks import PythonBlock
from flows_sdk.flows import Flow, Manifest, Parameter
from flows_sdk.package_utils import export_flow
from flows_sdk.testing.in_flow import (
    ROLE_TEST_FLOW,
    collect_results,
    fail_if_any_failed,
    in_flow_test_case,
)
from flows_sdk.utils import workflow_input

from . import evaluation

EVAL_SUITE_IDENTIFIER = 'SHOWCASE_EVAL_SUITE'


def entry_point_workflow() -> Flow:
    """Build the suite: submit the configured document and evaluate what the models extracted.

    The submission is machine-only, so supervision is skipped and this measures what the
    pipeline reads unaided.
    """
    submitted = PythonBlock(
        reference_name='submit_w9',
        code=evaluation.submit_and_wait,
        code_input={
            'blob_uuid': workflow_input('test_document'),
            'filename': 'form-w9-sample.png',
            'flow_identifier': workflow_input('flow_under_test'),
            'timeout_seconds': 1800,
            'poll_seconds': 10,
        },
        # The functions in `evaluation.py` call module-level helpers, so the whole module ships
        # with the block; otherwise it fails at run time on the first helper call.
        include_module=True,
    )

    # The reference submission is a run somebody inspected and approved, exported from the
    # submission details page and configured on the wrapper, so no transcription of a real
    # document enters version control.
    matches_reference = PythonBlock(
        reference_name=in_flow_test_case('extraction_matches'),
        code=evaluation.matches_reference,
        code_input={
            'submission_id': submitted.output('submission_id'),
            'reference_submission': workflow_input('reference_submission'),
        },
        include_module=True,
    )

    # Individual values worth their own case, so a failure names the field rather than
    # "something in the submission differs". Again referenced, never inlined.
    taxpayer_name = PythonBlock(
        reference_name=in_flow_test_case('name_extracted'),
        code=evaluation.field_equals,
        code_input={
            'submission_id': submitted.output('submission_id'),
            'field_name': 'Name',
            'expected': workflow_input('expected_name'),
        },
        include_module=True,
    )

    business_name = PythonBlock(
        reference_name=in_flow_test_case('business_name_extracted'),
        code=evaluation.field_equals,
        code_input={
            'submission_id': submitted.output('submission_id'),
            'field_name': 'Business Name',
            'expected': workflow_input('expected_business_name'),
        },
        include_module=True,
    )

    report = collect_results(
        reference_name='report',
        suite='document_processing_eval',
    )

    verdict = fail_if_any_failed(
        reference_name='verdict',
        report=report.output(),
    )

    return Flow(
        title='Showcase — Evaluation Suite',
        description='In-flow evaluation of the document-processing flow, on customer documents.',
        owner_email='flows-sdk@hyperscience.ai',
        manifest=Manifest(
            identifier=EVAL_SUITE_IDENTIFIER,
            # `test_flow` marks this as test code: rebuilt and re-uploaded on every run.
            roles=[ROLE_TEST_FLOW],
            # Every input arrives from the wrapper at run time, so all are `ui={'hidden': True}`:
            # the platform skips hidden inputs when it validates that mandatory inputs have
            # values, so this flow deploys on its own with nothing configured.
            input=[
                Parameter(
                    name='test_document',
                    type='string',
                    title='Test document (blob uuid, from the wrapper)',
                    ui={'hidden': True},
                ),
                Parameter(
                    name='reference_submission',
                    type='object',
                    title='Approved submission output (from the wrapper)',
                    ui={'hidden': True},
                ),
                Parameter(
                    name='expected_name',
                    type='string',
                    title='Expected Name field',
                    ui={'hidden': True},
                ),
                Parameter(
                    name='expected_business_name',
                    type='string',
                    title='Expected Business Name field',
                    ui={'hidden': True},
                ),
                Parameter(
                    name='flow_under_test',
                    type='string',
                    title='Identifier of the flow to test',
                    value='SHOWCASE_DOCUMENT_PROCESSING',
                    ui={'hidden': True},
                ),
            ],
            output=[Parameter(name='report', type='object', title='Suite result')],
        ),
        blocks=[
            submitted,
            matches_reference,
            taxpayer_name,
            business_name,
            report,
            verdict,
        ],
        # Nothing to configure here: the values arrive from the wrapper on each run.
        input={},
        output={'report': report.output()},
    )


if __name__ == '__main__':
    dist = Path(__file__).parents[5] / 'dist'
    dist.mkdir(exist_ok=True)
    export_flow(
        entry_point_workflow(),
        filename='showcase_eval_suite',
        location=str(dist),
    )
