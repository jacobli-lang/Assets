"""In-flow test suite wrapper — the test data.

This flow holds what the suite runs against: the **document**, and the **result expected from
it**. Both are configured once by a human through Flow Studio and live on the instance; the
platform stores the document as a blob UUID and the expected result as JSON.

A real document and its correct transcription are equally sensitive, so neither belongs in
version control, but the *assertions* about them do: the instance owns the data, git owns the
logic, and this flow's parameter surface is the boundary.

The configuration cannot be regenerated from this repository, so the framework protects it:
``pytest`` creates this flow when absent and updates it while unconfigured, but once data is
attached it refuses to overwrite the definition and fails rather than test a stale input surface.

    pytest -m in_flow --merge-test-flows    # update the definition, keep the data
    pytest -m in_flow --force-test-flows    # overwrite it, discarding the data

**Generate once, configure, then leave alone.** The evaluation lives in ``suite_eval_flow.py``
and is rebuilt every run.

How to obtain the values to configure here: "Where the expected result comes from" in the
testing guide, https://flows-sdk.hyperscience.ai/pages/testing.html#in-flow-expected-result.
"""

from pathlib import Path

from flows_sdk.flows import Flow, Manifest, Parameter
from flows_sdk.package_utils import export_flow
from flows_sdk.testing.in_flow import (
    ROLE_TEST_FLOW,
    ROLE_TEST_WRAPPER,
    TEST_DOCUMENT_TYPE_SPEC,
    call_test_core,
)
from flows_sdk.utils import workflow_input

from showcase.flows.document_processing.flow import FLOW_IDENTIFIER
from showcase.flows.document_processing.tests.in_flow.suite_eval_flow import EVAL_SUITE_IDENTIFIER

EVAL_WRAPPER_IDENTIFIER = 'SHOWCASE_EVAL_SUITE_WRAPPER'


def entry_point_workflow() -> Flow:
    """Build the wrapper: declare the test data, hand it to the assertions."""
    run_core = call_test_core(
        reference_name='run_test_suite',
        core_identifier=EVAL_SUITE_IDENTIFIER,
        inputs={
            'test_document': workflow_input('test_document'),
            'reference_submission': workflow_input('reference_submission'),
            'expected_name': workflow_input('expected_name'),
            'expected_business_name': workflow_input('expected_business_name'),
            'flow_under_test': workflow_input('flow_under_test'),
        },
    )

    return Flow(
        title='Showcase — Evaluation Suite (data)',
        description=(
            'Holds the document and expected results the test suite runs against. Configure '
            'these inputs here; the assertions live in the suite flow.'
        ),
        owner_email='flows-sdk@hyperscience.ai',
        manifest=Manifest(
            identifier=EVAL_WRAPPER_IDENTIFIER,
            # `test_wrapper` marks this as holding configuration the framework protects.
            roles=[ROLE_TEST_FLOW, ROLE_TEST_WRAPPER],
            input=[
                # Required inputs must be declared required: the platform then refuses to
                # deploy the flow until they are configured, which is how the suite fails
                # instead of running against missing test data.
                Parameter(
                    name='test_document',
                    type='File',
                    title='Test document',
                    # Without this the UI offers no uploadable type at all.
                    type_spec=TEST_DOCUMENT_TYPE_SPEC,
                    description=(
                        'The customer document to measure — the showcase uses '
                        'tests/data/form-w9-sample.png. It must classify against the W-9 '
                        'layout release assigned to the flow under test.'
                    ),
                ),
                Parameter(
                    name='reference_submission',
                    type='object',
                    title='Approved submission output',
                    description=(
                        'The submission output JSON from a run you have inspected and accepted. '
                        'Every field it carries is compared.'
                    ),
                ),
                Parameter(
                    name='expected_name',
                    type='string',
                    title='Expected "Name" field',
                    description='The value the Name field should transcribe to.',
                ),
                Parameter(
                    name='expected_business_name',
                    type='string',
                    title='Expected "Business Name" field',
                    description='The value the Business Name field should transcribe to.',
                ),
                Parameter(
                    name='flow_under_test',
                    type='string',
                    title='Flow under test',
                    value=FLOW_IDENTIFIER,
                ),
            ],
            ui={
                'groups': [
                    {
                        'title': 'Test data',
                        'description': (
                            'The document and the results expected from it. These stay on this '
                            'instance and are not part of the flow definition in git.'
                        ),
                        'fields': [
                            'test_document',
                            'reference_submission',
                            'expected_name',
                            'expected_business_name',
                        ],
                    },
                    {'title': 'Target', 'fields': ['flow_under_test']},
                ]
            },
            output=[Parameter(name='report', type='object', title='Suite result')],
        ),
        blocks=[run_core],
        # Empty on purpose: a human fills this in on the instance. A placeholder here would
        # look configured and deploy, so the suite would run against test data nobody set.
        input={},
        output={'report': run_core.output('report')},
    )


if __name__ == '__main__':
    dist = Path(__file__).parents[5] / 'dist'
    dist.mkdir(exist_ok=True)
    export_flow(
        entry_point_workflow(),
        filename='showcase_eval_suite_wrapper',
        location=str(dist),
    )
