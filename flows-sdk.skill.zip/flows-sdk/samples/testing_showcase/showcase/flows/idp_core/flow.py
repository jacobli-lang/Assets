"""A **custom IDP core** flow — the standard document-processing chain plus this project's
own logic.

An IDP project has two flows:

* This one, the **core** (``roles=['read_only', 'supporting', 'idp_core']``), is the pipeline:
  filter, bootstrap, classify, identify, transcribe, render, complete. Customising IDP means
  copying this flow, changing the identifier, and adding your own blocks to the chain.
* The **wrapper** (``document_processing/flow.py``) is configuration: the settings an operator
  edits in Flow Studio, and a call to this core by identifier. It holds no business logic.

The custom blocks read *extracted field values*, which exist only after transcription, so they
are spliced in after ``document_rendering`` and before ``complete_submission``. In the wrapper
they would run after the core has finalised the submission, too late to affect routing or what
the core reports.

The chain is the one from ``samples/idp_flow_v43/idp_core_flow_v43.py``, written out in full so
it can be diffed against the starter.

Offline, every standard IDP block is stubbed and the three custom blocks are the testable
surface. Extraction accuracy needs real models, which is the end-to-end tier's job.
"""

from pathlib import Path
from uuid import UUID

from flows_sdk.blocks import Block, PythonBlock, Routing
from flows_sdk.flows import Flow, Parameter
from flows_sdk.identifiers import flow_identifier
from flows_sdk.implementations.idp_v43 import additional_blocks, idp_blocks
from flows_sdk.implementations.idp_v43.idp_values import IDPCoreManifest
from flows_sdk.package_utils import export_flow
from flows_sdk.utils import str_to_deterministic_uuid_4, workflow_input

from showcase.flows.idp_core import functions
from showcase.flows.tin_validation.flow import TIN_VALIDATION_IDENTIFIER

#: A custom core needs its own identifier and UUID — the wrapper points `IDPCoreBlock` at this
#: identifier instead of the SDK's default core.
IDP_CORE_IDENTIFIER = flow_identifier('SHOWCASE_IDP_CORE')
IDP_CORE_UUID = str(str_to_deterministic_uuid_4(IDP_CORE_IDENTIFIER))
IDP_CORE_TITLE = 'Showcase — Custom IDP Core'

#: Set on the flow so a test can turn the TIN requirement off and exercise both branches.
REQUIRE_VALID_TIN = 'require_valid_tin'

#: Knowledge-store collection holding the valid exempt payee codes.
EXEMPT_CODE_COLLECTION = 'exempt_code_collection'

NO_LABEL = 'No'
YES_LABEL = 'Yes'


def _mark_released(documents: list, validation: list) -> dict:
    """Record that the documents may go downstream.

    Module-private, so a unit test reaches it through the flow with `invoke_block`.
    """
    validated = [result for result in validation or [] if result.get('valid')]
    return {
        'status': 'released',
        'document_count': len(documents or []),
        'validated_count': len(validated),
    }


def _mark_held(reasons: list) -> dict:
    """Record that the submission needs a human, and why."""
    return {'status': 'held', 'reasons': list(reasons or [])}


def idp_workflow() -> Flow:
    """Build the custom core: the standard IDP chain with this project's logic spliced in."""
    file_filter = additional_blocks.FileFilterBlock(reference_name='file_filter')

    bootstrap_submission = idp_blocks.SubmissionBootstrapBlock(
        trigger=file_filter.output('result.filtered_trigger'),
        reference_name='submission_bootstrap',
    )

    case_collation_task = idp_blocks.MachineCollationBlock(
        reference_name='machine_collation',
        submission=bootstrap_submission.output('submission'),
        cases=bootstrap_submission.output('api_params.cases'),
    )

    machine_classification = idp_blocks.MachineClassificationBlock(
        reference_name='machine_classification',
        submission=case_collation_task.output('submission'),
        api_params=bootstrap_submission.output('api_params'),
    )

    manual_classification = idp_blocks.ManualClassificationBlock(
        reference_name='manual_classification',
        submission=machine_classification.output('submission'),
        api_params=bootstrap_submission.output('api_params'),
        nlc_metadata=machine_classification.output('nlc_metadata'),
    )

    manual_classification_routing = Routing(
        reference_name='manual_classification_routing',
        decision=machine_classification.output('needs_manual_classification'),
        title='Is Manual Classification needed?',
        branches=[
            Routing.Branch(
                case='false', label=NO_LABEL, blocks=[], output='machine_classification'
            ),
        ],
        default_branch=Routing.DefaultBranch(label=YES_LABEL, blocks=[manual_classification]),
    )

    machine_identification = idp_blocks.MachineIdentificationBlock(
        reference_name='machine_identification',
        submission=manual_classification_routing.output('submission'),
        api_params=bootstrap_submission.output('api_params'),
    )

    manual_identification = idp_blocks.ManualIdentificationBlock(
        reference_name='manual_identification',
        submission=machine_identification.output('submission'),
        api_params=bootstrap_submission.output('api_params'),
    )

    manual_identification_routing = Routing(
        reference_name='manual_identification_routing',
        decision=machine_identification.output('needs_manual_identification'),
        title='Is Manual Identification needed?',
        branches=[
            Routing.Branch('false', blocks=[], label=NO_LABEL, output='machine_identification'),
        ],
        default_branch=Routing.DefaultBranch(blocks=[manual_identification], label=YES_LABEL),
    )

    machine_transcription = idp_blocks.MachineTranscriptionBlock(
        reference_name='machine_transcription',
        submission=manual_identification_routing.output('submission'),
        api_params=bootstrap_submission.output('api_params'),
    )

    manual_transcription = idp_blocks.ManualTranscriptionBlock(
        reference_name='manual_transcription',
        submission=machine_transcription.output('submission'),
        api_params=bootstrap_submission.output('api_params'),
    )

    manual_transcription_routing = Routing(
        reference_name='manual_transcription_routing',
        decision=machine_transcription.output('needs_manual_transcription'),
        title='Is Manual Transcription needed?',
        branches=[
            Routing.Branch('false', blocks=[], label=NO_LABEL, output='machine_transcription'),
        ],
        default_branch=Routing.DefaultBranch(blocks=[manual_transcription], label=YES_LABEL),
    )

    flexible_extraction = idp_blocks.FlexibleExtractionBlock(
        reference_name='flexible_extraction',
        submission=manual_transcription_routing.output('submission'),
        api_params=bootstrap_submission.output('api_params'),
    )

    flexible_extraction_routing = Routing(
        reference_name='flexible_extraction_routing',
        decision=machine_transcription.output('needs_flexible_extraction'),
        title='Is Flexible Extraction needed?',
        branches=[
            Routing.Branch(
                'false', blocks=[], label=NO_LABEL, output='manual_transcription_routing'
            ),
        ],
        default_branch=Routing.DefaultBranch(blocks=[flexible_extraction], label=YES_LABEL),
    )

    reprocessing = idp_blocks.ReprocessingBlock(
        reference_name='reprocessing',
        submission=flexible_extraction_routing.output('submission'),
    )

    document_rendering = idp_blocks.DocumentRendererBlock(
        reference_name='document_rendering',
        submission=reprocessing.output('submission'),
        is_reprocessing=reprocessing.output('is_reprocessing'),
    )

    # -- this project's own logic -------------------------------------------------
    #
    # After rendering and before completion, because these blocks read extracted field values.
    # Offline, every block above is stubbed and these run for real.

    # The one block that talks to the platform. Offline it needs `ScriptedHsBlockInstance`
    # rather than the default mock, since it calls `.json()` on the response.
    exempt_codes = PythonBlock(
        reference_name='load_exempt_payee_codes',
        code=functions.load_exempt_payee_codes,
        code_input={'collection': workflow_input(EXEMPT_CODE_COLLECTION)},
        title='Load exempt payee codes',
        # The function reads a module-level constant (MAX_KNOWLEDGE_STORE_PAGES). Without
        # `include_module=True` only the entrypoint's source is serialised, so the block fails
        # on the instance with `NameError` while every offline tier passes.
        include_module=True,
    )

    route = PythonBlock(
        reference_name='route_for_review',
        code=functions.route_for_review,
        code_input={
            'submission': document_rendering.output('submission'),
            'require_valid_tin': workflow_input(REQUIRE_VALID_TIN),
            'valid_exempt_codes': exempt_codes.output('codes'),
        },
        title='Derive classification and route',
        # Also module-scoped: reads TIN_DIGITS and calls the `_fields_by_name` helper.
        include_module=True,
    )

    # A subflow: TIN validation is reusable, and the flow tier shows both stubbing it and
    # running it inline.
    validate_tins = Block(
        identifier=TIN_VALIDATION_IDENTIFIER,
        reference_name='validate_tins',
        input={'documents': route.output('documents')},
        title='Validate TINs (subflow)',
    )

    release = PythonBlock(
        reference_name='mark_released',
        code=_mark_released,
        code_input={
            'documents': route.output('documents'),
            'validation': validate_tins.output('results'),
        },
        title='Mark released',
    )

    hold = PythonBlock(
        reference_name='mark_held',
        code=_mark_held,
        code_input={'reasons': route.output('reasons')},
        title='Mark held for review',
    )

    decision = Routing(
        reference_name='review_decision',
        decision=route.output('decision'),
        branches=[Routing.Branch(case='release', blocks=[validate_tins, release], label='Release')],
        default_branch=Routing.DefaultBranch(blocks=[hold], label='Hold for review'),
    )

    submission_complete = idp_blocks.SubmissionCompleteBlock(
        reference_name='complete_submission',
        submission=document_rendering.output('submission'),
        is_reprocessing=reprocessing.output('is_reprocessing'),
    )

    manifest = IDPCoreManifest(
        flow_identifier=IDP_CORE_IDENTIFIER,
        roles=['read_only', 'supporting', 'idp_core'],
    )
    # The settings this project adds to the standard IDP ones. The platform refuses to deploy a
    # flow-level `input` value with no matching manifest Parameter.
    manifest.input.extend(
        [
            Parameter(
                name=REQUIRE_VALID_TIN,
                type='boolean',
                title='Require a valid taxpayer number',
                description=(
                    'When on, a document whose TIN is not nine digits is held for review. '
                    'Turn off to release documents with an illegible TIN.'
                ),
                value=True,
            ),
            Parameter(
                name=EXEMPT_CODE_COLLECTION,
                type='string',
                title='Exempt payee code collection',
                description='Knowledge-store collection holding the valid exempt payee codes.',
                value='W9_EXEMPT_PAYEE_CODES',
            ),
        ]
    )
    # Declared so a caller can learn the return shape without reading the source.
    manifest.output = [
        Parameter(name='submission', type='object', title='The processed submission'),
        Parameter(name='outcome', type='object', title='Release/hold decision and its reasons'),
    ]

    return Flow(
        uuid=UUID(IDP_CORE_UUID),
        owner_email='flows-sdk@hyperscience.ai',
        title=IDP_CORE_TITLE,
        description=(
            "A custom IDP core: the standard document-processing chain plus this project's "
            'own classification, TIN validation and routing logic.'
        ),
        manifest=manifest,
        output={
            'submission': submission_complete.output('submission'),
            'outcome': decision.output('result'),
        },
        blocks=[
            file_filter,
            bootstrap_submission,
            case_collation_task,
            machine_classification,
            manual_classification_routing,
            machine_identification,
            manual_identification_routing,
            machine_transcription,
            manual_transcription_routing,
            flexible_extraction_routing,
            reprocessing,
            document_rendering,
            exempt_codes,
            route,
            decision,
            submission_complete,
        ],
    )


def entry_point_workflow() -> Flow:
    return idp_workflow()


if __name__ == '__main__':
    dist = Path(__file__).parents[3] / 'dist'
    dist.mkdir(exist_ok=True)
    export_flow(
        entry_point_workflow(),
        filename='showcase_idp_core',
        location=str(dist),
    )
