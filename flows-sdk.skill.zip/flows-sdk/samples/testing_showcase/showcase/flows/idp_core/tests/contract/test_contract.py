"""Contract tier for the custom IDP core.

The standard checks are inherited from :class:`flows_sdk.testing.suites.FlowStaticChecksSuite`.

Refresh the golden after an intended change:

    UPDATE_SNAPSHOTS=1 pytest -m contract
"""

from pathlib import Path

import pytest
from flows_sdk.testing.suites import FlowStaticChecksSuite

from showcase.flows.idp_core.flow import entry_point_workflow
from showcase.flows.tin_validation.flow import tin_validation_subflow

pytestmark = pytest.mark.contract


class TestIdpCoreContract(FlowStaticChecksSuite):
    """The core, checked on its own. It is called by the wrapper, so its interface is an API."""

    flow = entry_point_workflow
    snapshot_path = Path(__file__).parent / 'snapshots' / 'idp_core.json'

    # The TIN-validation flow `validate_tins` calls, so that call site is checked too.
    subflows = (tin_validation_subflow,)
