"""Unit tier — the CCB functions called directly, no flow and no platform.

Where most assertions belong. The functions are plain Python, so testing them needs nothing
from the framework: import, call, assert. Pin every edge case that does not involve the
platform here rather than in a slower tier.

Extraction accuracy is not tested here: offline, a transcription is whatever the stub says.
That belongs in the end-to-end tier, against a real document.
"""

import pytest
from flows_sdk.mocks import MockHsBlockInstance

from showcase.flows.idp_core.functions import (
    TIN_DIGITS,
    classify_tax_entity,
    load_exempt_payee_codes,
    normalise_tin,
    route_for_review,
)

pytestmark = pytest.mark.unit


def _document(fields: dict[str, str], document_id: int = 1) -> dict:
    """A document carrying the given field transcriptions."""
    return {
        'id': document_id,
        'document_fields': [
            {'field_name': name, 'transcription': value} for name, value in fields.items()
        ],
    }


class TestNormaliseTin:
    """A handwritten TIN arrives with whatever separators the writer used."""

    @pytest.mark.parametrize(
        ('raw', 'digits'),
        [
            ('202-26-7197', '202267197'),
            ('202 26 7197', '202267197'),
            ('202267197', '202267197'),
            ('  202-26-7197  ', '202267197'),
        ],
    )
    def test_separators_and_whitespace_are_stripped(self, raw: str, digits: str) -> None:
        assert normalise_tin(raw)['digits'] == digits

    def test_nine_digits_is_valid(self) -> None:
        assert normalise_tin('202-26-7197')['valid'] is True

    @pytest.mark.parametrize('raw', ['202-26', '20226719712', '', 'not a number'])
    def test_anything_but_nine_digits_is_invalid(self, raw: str) -> None:
        result = normalise_tin(raw)
        assert result['valid'] is False
        assert len(result['digits']) != TIN_DIGITS

    def test_an_ssn_is_recognised_by_its_3_2_4_grouping(self) -> None:
        assert normalise_tin('202-26-7197')['looks_like'] == 'ssn'

    def test_an_ein_is_recognised_by_its_2_7_grouping(self) -> None:
        assert normalise_tin('12-0719651')['looks_like'] == 'ein'

    def test_an_unseparated_number_is_not_guessed_at(self) -> None:
        """An SSN and an EIN are both nine digits, so there is nothing to infer from."""
        assert normalise_tin('202267197')['looks_like'] == 'unknown'


class TestClassifyTaxEntity:
    """The W-9's seven checkboxes are mutually exclusive; real documents disagree."""

    def test_one_checked_box_gives_that_classification(self) -> None:
        result = classify_tax_entity(_document({'Tax Classification - LLC': 'X'}))
        assert result == {'classification': 'LLC', 'checked': ['LLC'], 'ambiguous': False}

    @pytest.mark.parametrize('marker', ['X', 'x', 'true', 'checked', 'Yes'])
    def test_the_marker_a_checkbox_transcribes_as_varies(self, marker: str) -> None:
        """IDP emits a marker rather than a boolean, and which marker is not guaranteed."""
        result = classify_tax_entity(_document({'Tax Classification - Trust': marker}))
        assert result['classification'] == 'Trust'

    def test_nothing_checked_is_ambiguous_not_a_default(self) -> None:
        """The writer missed the box. Guessing a default would be worse than flagging it."""
        result = classify_tax_entity(_document({'Name': 'A Person'}))
        assert result['classification'] == 'unknown'
        assert result['ambiguous'] is True

    def test_several_checked_is_ambiguous_and_reports_all_of_them(self) -> None:
        """Resolving to the first match would silently pick one of two stated answers."""
        result = classify_tax_entity(
            _document({'Tax Classification - LLC': 'X', 'Tax Classification - Trust': 'X'})
        )
        assert result['classification'] == 'unknown'
        assert sorted(result['checked']) == ['LLC', 'Trust']

    def test_an_empty_transcription_is_not_a_checked_box(self) -> None:
        result = classify_tax_entity(_document({'Tax Classification - LLC': ''}))
        assert result['checked'] == []


class TestLoadExemptPayeeCodes:
    """The one function that calls the platform — hence the scripted mock in other tiers."""

    def test_reads_codes_from_a_single_page(self) -> None:
        from flows_sdk.testing.harness import ScriptedHsBlockInstance

        platform = ScriptedHsBlockInstance(
            {
                'knowledge_store': {
                    'results': [{'properties': {'code': '5'}}, {'properties': {'code': '13'}}],
                    'next': None,
                }
            }
        )
        result = load_exempt_payee_codes('W9_CODES', platform)
        assert result == {'codes': ['5', '13'], 'pages_read': 1}

    def test_follows_pagination(self) -> None:
        """The loop is the substance here, and it is invisible to any test that stubs the block."""

        class _Paged:
            """Answers with two pages, then stops."""

            LogLevel = MockHsBlockInstance().LogLevel

            def __init__(self) -> None:
                self.calls: list[str] = []

            def hs_get(self, path: str, **_: object) -> object:
                self.calls.append(path)
                first = len(self.calls) == 1
                payload = {
                    'results': [{'properties': {'code': '5' if first else '13'}}],
                    'next': '/api/v5/knowledge_store/items?cursor=2' if first else None,
                }

                class _Response:
                    @staticmethod
                    def json() -> dict:
                        return payload

                return _Response()

            def log(self, *_args: object, **_kwargs: object) -> None:
                pass

        platform = _Paged()
        result = load_exempt_payee_codes('W9_CODES', platform)

        assert result == {'codes': ['5', '13'], 'pages_read': 2}
        # The second request used the URL the platform supplied, not one we built.
        assert platform.calls[1] == '/api/v5/knowledge_store/items?cursor=2'

    def test_an_empty_collection_yields_no_codes(self) -> None:
        from flows_sdk.testing.harness import ScriptedHsBlockInstance

        platform = ScriptedHsBlockInstance({'knowledge_store': {'results': [], 'next': None}})
        assert load_exempt_payee_codes('W9_CODES', platform)['codes'] == []


class TestRouteForReview:
    """The decision the flow branches on, plus the reasons behind it."""

    @staticmethod
    def _submission(*documents: dict) -> dict:
        return {'documents': list(documents)}

    def test_a_clean_document_is_released(self) -> None:
        submission = self._submission(
            _document(
                {
                    'Tax Classification - LLC': 'X',
                    'Social Security Number': '202-26-7197',
                }
            )
        )
        result = route_for_review(submission, True, [], MockHsBlockInstance())
        assert result['decision'] == 'release'
        assert result['reasons'] == []

    def test_an_ambiguous_classification_sends_it_to_review(self) -> None:
        submission = self._submission(_document({'Social Security Number': '202-26-7197'}))
        result = route_for_review(submission, True, [], MockHsBlockInstance())
        assert result['decision'] == 'review'
        assert 'ambiguous' in result['reasons'][0]

    def test_an_invalid_tin_sends_it_to_review(self) -> None:
        submission = self._submission(
            _document({'Tax Classification - LLC': 'X', 'Social Security Number': '202-26'})
        )
        result = route_for_review(submission, True, [], MockHsBlockInstance())
        assert result['decision'] == 'review'
        assert 'TIN has 5 digits' in result['reasons'][0]

    def test_the_tin_requirement_can_be_turned_off(self) -> None:
        """Some documents legitimately have an illegible TIN and should still flow through."""
        submission = self._submission(
            _document({'Tax Classification - LLC': 'X', 'Social Security Number': '202-26'})
        )
        result = route_for_review(submission, False, [], MockHsBlockInstance())
        assert result['decision'] == 'release'

    def test_an_exempt_code_outside_the_knowledge_store_sends_it_to_review(self) -> None:
        submission = self._submission(
            _document(
                {
                    'Tax Classification - LLC': 'X',
                    'Social Security Number': '202-26-7197',
                    'Exempt Payee Code': '99',
                }
            )
        )
        result = route_for_review(submission, True, ['5', '13'], MockHsBlockInstance())
        assert result['decision'] == 'review'
        assert "'99' is not in the knowledge store" in result['reasons'][0]

    def test_an_empty_code_list_disables_the_check(self) -> None:
        """A missing knowledge store must not hold every document — that is a config gap."""
        submission = self._submission(
            _document(
                {
                    'Tax Classification - LLC': 'X',
                    'Social Security Number': '202-26-7197',
                    'Exempt Payee Code': '99',
                }
            )
        )
        result = route_for_review(submission, True, [], MockHsBlockInstance())
        assert result['decision'] == 'release'

    def test_every_reason_is_reported_not_just_the_first(self) -> None:
        """A reviewer needs the whole picture, not one problem at a time."""
        submission = self._submission(
            _document(
                {
                    'Tax Classification - LLC': 'X',
                    'Tax Classification - Trust': 'X',
                    'Social Security Number': '202-26',
                    'Exempt Payee Code': '99',
                }
            )
        )
        result = route_for_review(submission, True, ['5'], MockHsBlockInstance())
        assert len(result['reasons']) == 3

    def test_the_summary_carries_the_derived_values(self) -> None:
        submission = self._submission(
            _document(
                {'Tax Classification - LLC': 'X', 'Social Security Number': '202-26-7197'},
                document_id=42,
            )
        )
        result = route_for_review(submission, True, [], MockHsBlockInstance())
        assert result['documents'] == [
            {
                'document_id': 42,
                'classification': 'LLC',
                'tin': '202267197',
                'tin_kind': 'ssn',
            }
        ]

    def test_the_decision_is_logged(self) -> None:
        """A routing block that cannot explain itself is unreadable in a flow run."""
        mock = MockHsBlockInstance()
        route_for_review(self._submission(_document({})), True, [], mock)
        assert any('review' in str(entry) for entry in mock.log_data)
