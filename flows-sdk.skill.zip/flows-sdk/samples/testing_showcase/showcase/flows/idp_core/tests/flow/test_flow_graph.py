"""Flow tier — the whole graph offline, with the showcase's own code running for real.

``FlowTestRunner`` executes the core's blocks in order: the custom code blocks run for real and
the platform's blocks are stubbed. The unit tier proves each function works; this proves they
are *wired together*, so a mis-keyed reference or a mis-shaped hand-off fails here rather than
on a real submission.

The stubs are **recorded**: ``record_platform_outputs.py`` ran the synthetic W-9 through the
core on an instance and saved each platform block's output and the core's workflow input. A
hand-written stub that misses a key of that large shape hands the next block ``None``. A
scenario changes what the document *says* by editing named fields; everything else is what the
platform produced.

Extraction accuracy is not tested here: with the platform blocks stubbed, a transcription is
whatever the recording or the scenario says. That belongs to the live tiers.
"""

import copy
import json
from pathlib import Path
from typing import Any

import pytest
from flows_sdk.testing.flow_test_runner import BlockHook, FlowTestRunner
from flows_sdk.testing.harness import ScriptedHsBlockInstance

from showcase.flows.idp_core.flow import entry_point_workflow
from showcase.flows.tin_validation.flow import (
    TIN_VALIDATION_IDENTIFIER,
    tin_validation_subflow,
)

pytestmark = pytest.mark.flow

#: A real run of the synthetic W-9: the core's workflow input and its platform blocks' outputs.
RECORDED = json.loads(
    (Path(__file__).parents[1] / 'data' / 'w9_recorded_run.json').read_text(encoding='utf-8')
)

#: The recorded document's id, which every per-document result carries.
DOCUMENT_ID = RECORDED['block_outputs']['document_rendering']['submission']['documents'][0]['id']

#: The knowledge store the flow reads its valid exempt codes from. It lists `3S`, the exempt payee
#: code the recorded W-9 carries, so the recording as it stands takes the release path.
KNOWLEDGE_STORE = {
    'knowledge_store': {
        'results': [{'properties': {'code': '3S'}}, {'properties': {'code': '13'}}],
        'next': None,
    }
}


def recorded_stubs(fields: dict[str, str] | None = None) -> dict[str, Any]:
    """The recorded platform outputs, with the named fields' transcriptions replaced.

    Fields are named as on the layout — ``'Social Security Number'`` — and changed in every
    submission the recording carries, so the blocks agree on what the document says. A name the
    document does not have fails rather than changing nothing.
    """
    fields = fields or {}
    stubs = copy.deepcopy(RECORDED['block_outputs'])
    seen: set[str] = set()
    for output in stubs.values():
        submission = output.get('submission') or (output.get('result') or {}).get('submission')
        for document in (submission or {}).get('documents') or []:
            # Blocks before identification hand on documents with no fields yet.
            for field in document.get('document_fields') or []:
                if field['field_name'] in fields:
                    field['transcription'] = fields[field['field_name']]
                    seen.add(field['field_name'])
    unknown = set(fields) - seen
    assert not unknown, f'the recorded W-9 has no field(s) {sorted(unknown)}'
    return stubs


def run_flow(
    *,
    fields: dict[str, str] | None = None,
    knowledge_store: dict[str, Any] | None = None,
    run_subflow: bool = True,
    **inputs: Any,
) -> FlowTestRunner:
    """Execute the core offline and hand back the runner for inspection.

    Args:
        fields: Field transcriptions to change from the recording — the scenario.
        knowledge_store: Scripted platform routes. Defaults to a store listing `3S` and `13`.
        run_subflow: When true the TIN-validation subflow executes inline through a nested
            runner; when false it is stubbed.
        **inputs: Workflow input overrides.
    """
    stubs = recorded_stubs(fields)
    if not run_subflow:
        stubs['validate_tins'] = {
            'all_valid': True,
            'results': [{'document_id': DOCUMENT_ID, 'valid': True, 'problems': []}],
            'invalid_count': 0,
        }

    runner = FlowTestRunner(
        flow=entry_point_workflow(),
        # What the wrapper really passed the core, with this project's settings pinned.
        workflow_inputs={
            **RECORDED['workflow_input'],
            'require_valid_tin': True,
            'exempt_code_collection': 'W9_EXEMPT_PAYEE_CODES',
            **inputs,
        },
        block_stubs=stubs,
        subflows=({TIN_VALIDATION_IDENTIFIER: tin_validation_subflow()} if run_subflow else None),
        hs_block_instance=ScriptedHsBlockInstance(knowledge_store or KNOWLEDGE_STORE),
    )
    runner.run()
    return runner


class TestTheHappyPath:
    def test_the_recorded_document_runs_through_to_release(self) -> None:
        runner = run_flow()

        runner.assert_blocks_ran(
            'load_exempt_payee_codes',
            'route_for_review',
            'validate_tins',
            'mark_released',
        )
        assert runner.ccb_result('mark_released')['status'] == 'released'

    def test_no_reference_resolves_to_none(self) -> None:
        """The check that catches a typo'd or mis-keyed reference.

        The platform hands a block ``None`` for a reference that does not resolve, so this bug
        is silent in production and in a test that only asserts the flow completed. Every
        reference must resolve here, platform blocks included: the stubs are what those blocks
        really emitted.

        The exception is a setting the recorded run did not carry either, such as storage
        credentials an instance leaves unset: the platform resolves those to ``None`` too.
        """
        unresolved = set(run_flow().unresolved_references)
        unset_on_the_real_run = {
            reference
            for reference in unresolved
            if reference.startswith('workflow.input.')
            and reference.split('.')[2] not in RECORDED['workflow_input']
        }
        unexpected = unresolved - unset_on_the_real_run
        assert not unexpected, f'references that resolved to None: {sorted(unexpected)}'

    def test_the_derived_values_reach_the_release_block(self) -> None:
        """The hand-off between two custom blocks, which is what this tier is for."""
        runner = run_flow()
        assert runner.ccb_result('route_for_review')['documents'] == [
            {
                'document_id': DOCUMENT_ID,
                'classification': 'LLC',
                'tin': '202267197',
                'tin_kind': 'ssn',
            }
        ]
        assert runner.ccb_result('mark_released')['validated_count'] == 1


class TestBranching:
    """The flow has one Routing block; both sides need a test or half of it is untested."""

    def test_an_ambiguous_classification_takes_the_review_branch(self) -> None:
        # The recorded W-9 already has LLC checked; a second box makes it ambiguous.
        runner = run_flow(fields={'Tax Classification - Trust': 'True'})

        runner.assert_blocks_ran('mark_held')
        # The subflow is inside the release branch, so it must not have run.
        runner.assert_blocks_did_not_run('validate_tins', 'mark_released')
        assert 'ambiguous' in runner.ccb_result('mark_held')['reasons'][0]

    def test_turning_the_tin_requirement_off_releases_a_document_with_a_bad_tin(self) -> None:
        short_tin = {'Social Security Number': '123-45'}
        assert run_flow(fields=short_tin).ccb_result('mark_held')['status'] == 'held'
        released = run_flow(fields=short_tin, require_valid_tin=False)
        assert released.ccb_result('mark_released')['status'] == 'released'

    def test_an_unlisted_exempt_code_takes_the_review_branch(self) -> None:
        """Ties the knowledge-store read to the routing decision — two blocks, one behaviour."""
        runner = run_flow(fields={'Exempt Payee Code': '99'})
        runner.assert_blocks_ran('mark_held')
        assert 'not in the knowledge store' in runner.ccb_result('mark_held')['reasons'][0]


class TestTheSubflow:
    """A subflow can be stubbed or executed inline; both are useful and both are shown."""

    def test_the_subflow_receives_the_documents_the_parent_derived(self) -> None:
        """`input_of` asserts what a block was *called with*, not just what it returned."""
        passed_down = run_flow().input_of('validate_tins')['documents']
        assert passed_down[0]['tin'] == '202267197'
        assert passed_down[0]['classification'] == 'LLC'

    def test_the_subflow_can_be_stubbed_instead(self) -> None:
        """Faster, and the right choice when the subflow is not what a test is about."""
        runner = run_flow(run_subflow=False)
        runner.assert_blocks_ran('validate_tins', 'mark_released')
        assert 'validate_tins' not in runner.subflow_runners

    def test_the_subflow_reports_an_invalid_tin(self) -> None:
        """A structurally impossible TIN — area number 666 is never issued."""
        runner = run_flow(fields={'Social Security Number': '666-45-6789'})

        result = runner.subflow_runners['validate_tins'].ccb_result('summarise_validation')
        assert result['invalid_count'] == 1
        assert 'never issued' in result['results'][0]['problems'][0]


class TestThePlatformCall:
    def test_the_knowledge_store_is_read_once_per_run(self) -> None:
        platform = ScriptedHsBlockInstance(KNOWLEDGE_STORE)
        runner = FlowTestRunner(
            flow=entry_point_workflow(),
            workflow_inputs={
                **RECORDED['workflow_input'],
                'exempt_code_collection': 'W9_EXEMPT_PAYEE_CODES',
            },
            block_stubs=recorded_stubs(),
            subflows={TIN_VALIDATION_IDENTIFIER: tin_validation_subflow()},
            hs_block_instance=platform,
        )
        runner.run()

        assert platform.requested_paths == [
            '/api/v5/knowledge_store/items?collection=W9_EXEMPT_PAYEE_CODES'
        ]

    def test_an_empty_knowledge_store_does_not_hold_every_document(self) -> None:
        """A missing configuration is a config gap, not a reason to review every document."""
        runner = run_flow(
            knowledge_store={'knowledge_store': {'results': [], 'next': None}},
            fields={'Exempt Payee Code': '99'},
        )
        assert runner.ccb_result('mark_released')['status'] == 'released'


class TestInspectingStubbedBlocks:
    def test_a_stubbed_platform_block_still_records_its_input(self) -> None:
        """`input_of` works for stubbed blocks too, so a mocked block's input is assertable.

        `submission_bootstrap` takes the trigger `file_filter` hands on, so its recorded input is
        what proves the trigger reached the pipeline at all.
        """
        trigger = run_flow().input_of('submission_bootstrap')['$trigger']
        assert trigger == RECORDED['block_outputs']['file_filter']['result']['filtered_trigger']

    def test_a_block_hook_checks_a_block_before_a_later_failure(self) -> None:
        """A hook asserts on a block as it runs, so a flow that fails after it still reports it."""
        seen: list[dict[str, Any]] = []
        stubs = recorded_stubs()
        del stubs['complete_submission']  # the run now fails at the last block
        runner = FlowTestRunner(
            flow=entry_point_workflow(),
            workflow_inputs={
                **RECORDED['workflow_input'],
                'exempt_code_collection': 'W9_EXEMPT_PAYEE_CODES',
            },
            block_stubs=stubs,
            subflows={TIN_VALIDATION_IDENTIFIER: tin_validation_subflow()},
            hs_block_instance=ScriptedHsBlockInstance(KNOWLEDGE_STORE),
            # Keyed by *block reference name*; the value carries separate `assert_input` and
            # `assert_output` callbacks.
            block_hooks={'route_for_review': BlockHook(assert_output=seen.append)},
        )
        with pytest.raises(FlowTestRunner.MissingBlockImplementation):
            runner.run()
        assert seen and seen[0]['result']['decision'] == 'release'


def test_stop_after_runs_only_a_prefix_of_the_flow() -> None:
    """Handy when debugging: stop once the block under investigation has run."""
    runner = FlowTestRunner(
        flow=entry_point_workflow(),
        workflow_inputs={
            **RECORDED['workflow_input'],
            'exempt_code_collection': 'W9_EXEMPT_PAYEE_CODES',
        },
        block_stubs=recorded_stubs(),
        hs_block_instance=ScriptedHsBlockInstance(KNOWLEDGE_STORE),
    )
    runner.run(stop_after='route_for_review')

    runner.assert_blocks_ran('route_for_review')
    runner.assert_blocks_did_not_run('mark_released', 'mark_held')


@pytest.mark.parametrize('code', ['3S', '13'])
def test_every_configured_exempt_code_is_accepted(code: str) -> None:
    runner = run_flow(fields={'Exempt Payee Code': code})
    assert runner.ccb_result('mark_released')['status'] == 'released'


def test_a_scenario_naming_a_field_the_document_lacks_fails() -> None:
    """Otherwise a typo in a field name would leave the recording unchanged, and pass."""
    with pytest.raises(AssertionError, match='no field'):
        recorded_stubs({'Social Securty Number': '123-45-6789'})
