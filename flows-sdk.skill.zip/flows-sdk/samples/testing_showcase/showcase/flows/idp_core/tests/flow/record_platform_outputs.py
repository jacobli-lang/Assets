"""Record what the core's platform blocks emit for the synthetic W-9 — the flow tier's stubs.

::

    export HS_BASE_URL=https://dev-instance
    export HS_M2M_CLIENT_ID=<client id>
    export HS_M2M_CREDS=~/.hyperscience/m2m_creds.json
    python -m showcase.flows.idp_core.tests.flow.record_platform_outputs

Deploys this checkout's flows the way the end-to-end tier does, submits the synthetic W-9, and
writes the core run's workflow input and each platform block's output to
``tests/data/w9_recorded_run.json``, which the flow tier stubs from. Re-record after an SDK or
platform upgrade changes the IDP blocks, and read the diff.

**Synthetic data only.** A recording copies a run's data to this machine and into git, which
must never happen to a customer's document.
"""

from __future__ import annotations

import json
from pathlib import Path

from flows_sdk.testing.e2e import HsClient

from showcase.flows.document_processing.tests.e2e.environment import (
    DATA,
    deployed_flow_under_test,
    ensure_layout_release,
)

#: The core's platform blocks on the machine path — every block the flow tier stubs. This
#: project's own blocks are not here: they run for real offline.
PLATFORM_BLOCKS = (
    'file_filter',
    'submission_bootstrap',
    'machine_collation',
    'machine_classification',
    'machine_identification',
    'machine_transcription',
    'reprocessing',
    'document_rendering',
    'complete_submission',
)

RECORDING = Path(__file__).parents[1] / 'data' / 'w9_recorded_run.json'


def main() -> None:
    client = HsClient.from_env()
    layout_release = ensure_layout_release(client)
    with deployed_flow_under_test(client, layout_release) as flow_under_test:
        submission_id = client.create_submission(
            DATA / 'form-w9-sample.png', flow_identifier=flow_under_test
        )
        result = client.wait_submission(submission_id)
    recorded = client.recorded_flow_run(result['flow_run_id'], subflow='__idp_core__')

    missing = [block for block in PLATFORM_BLOCKS if block not in recorded['block_outputs']]
    if missing:
        raise SystemExit(
            f'the recorded run has no output for {missing}; did it take the machine path?'
        )
    recording = {
        'workflow_input': recorded['workflow_input'],
        'block_outputs': {block: recorded['block_outputs'][block] for block in PLATFORM_BLOCKS},
    }
    RECORDING.parent.mkdir(exist_ok=True)
    RECORDING.write_text(json.dumps(recording, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print(f'recorded flow run {result["flow_run_id"]} to {RECORDING}')


if __name__ == '__main__':
    main()
