"""Unit tests for block code that no test can import.

``invoke_block`` looks a block up in the real flow by reference name and calls its code. Use it
only when there is no importable function: the blocks below wrap module-private helpers.
Everything with a public name is called directly in ``test_functions.py``.

Wiring is not tested here: the flow-graph tier runs these blocks by reference name in the real
flow, so a rename or a mis-keyed input fails there.
"""

import pytest
from flows_sdk.flows import Flow
from flows_sdk.testing.flow_test_runner import invoke_block

from showcase.flows.idp_core.flow import entry_point_workflow

pytestmark = pytest.mark.unit


@pytest.fixture
def flow() -> Flow:
    """The real flow, so blocks are looked up in the definition that ships."""
    return entry_point_workflow()


def test_mark_released_block(flow: Flow) -> None:
    """`mark_released` is a module-private helper with no importable name.

    The case `invoke_block` is for: code the flow references but a test cannot import.
    """
    output = invoke_block(
        flow,
        'mark_released',
        {
            'documents': [{'document_id': 1}, {'document_id': 2}],
            'validation': [{'document_id': 1, 'valid': True}],
        },
    )
    assert output == {'status': 'released', 'document_count': 2, 'validated_count': 1}


def test_mark_held_block(flow: Flow) -> None:
    output = invoke_block(flow, 'mark_held', {'reasons': ['a reason']})
    assert output == {'status': 'held', 'reasons': ['a reason']}
