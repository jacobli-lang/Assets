"""Custom code for the document-processing flow — plain functions, directly testable.

Kept out of ``flow.py`` so they can be imported and called without building a flow, which
makes the unit tier trivial and keeps the flow definition readable.

The domain is Form W-9. The IDP chain classifies and transcribes the form; everything here
runs *after* that and decides what to do with the result:

* :func:`normalise_tin` cleans up a taxpayer identification number.
* :func:`classify_tax_entity` collapses the form's seven mutually-exclusive tax-classification
  checkboxes into one value.
* :func:`load_exempt_payee_codes` reads the instance's knowledge store.
* :func:`route_for_review` decides whether a document can be released downstream.

Nothing here imports anything outside the standard library, so it all runs inside the
platform's restricted wheel-set.
"""

from __future__ import annotations

from typing import Any

#: The W-9 checkbox fields, in the order the form presents them. Exactly one should be
#: checked; the flow has to cope when zero or several are.
TAX_CLASSIFICATION_FIELDS = (
    'Tax Classification - Individual',
    'Tax Classification - C Corp',
    'Tax Classification - S Corp',
    'Tax Classification - Partnership',
    'Tax Classification - Trust',
    'Tax Classification - LLC',
)

#: What a checked box transcribes as. IDP emits a marker rather than a boolean.
CHECKED_VALUES = frozenset({'X', 'x', 'true', 'True', 'checked', 'yes', 'Yes'})

#: A TIN is 9 digits, as either an SSN (3-2-4) or an EIN (2-7).
TIN_DIGITS = 9


def _fields_by_name(document: dict[str, Any]) -> dict[str, str]:
    """Flatten a document's fields into ``{field_name: transcription}``.

    Reads ``field_name`` and ``transcription``, the shape a flow sees. The public submissions
    API uses ``name`` and a nested ``transcription.raw`` instead.
    """
    flattened: dict[str, str] = {}
    for field in document.get('document_fields') or []:
        name = field.get('field_name') or field.get('output_name')
        if name and name not in flattened:
            flattened[str(name)] = str(field.get('transcription') or '').strip()
    return flattened


def normalise_tin(raw: str) -> dict[str, Any]:
    """Normalise a taxpayer identification number to digits, and say which kind it is.

    A handwritten TIN arrives with whatever separators the writer used, so the digits are
    the only reliable part. An SSN and an EIN are both nine digits, so the *kind* is read
    from the formatting only, and the decision is left to the caller.

    Args:
        raw: The transcription, e.g. ``'202-26-7197'`` or ``'12 0719651'``.

    Returns:
        ``{'digits': str, 'valid': bool, 'looks_like': 'ssn' | 'ein' | 'unknown'}``.
        ``valid`` is false for anything that is not exactly nine digits, which is the only
        check that can be made without an external service.
    """
    digits = ''.join(character for character in str(raw or '') if character.isdigit())
    valid = len(digits) == TIN_DIGITS

    looks_like = 'unknown'
    if valid:
        # SSNs are written 3-2-4 and EINs 2-7; a TIN without separators stays 'unknown'.
        compact = str(raw or '').strip()
        if compact.count('-') == 2 and compact.split('-')[0].isdigit():  # noqa: PLR2004
            looks_like = 'ssn' if len(compact.split('-')[0]) == 3 else 'ein'  # noqa: PLR2004
        elif compact.count('-') == 1:
            looks_like = 'ein'

    return {'digits': digits, 'valid': valid, 'looks_like': looks_like}


def classify_tax_entity(document: dict[str, Any]) -> dict[str, Any]:
    """Collapse the W-9's tax-classification checkboxes into a single value.

    The form has seven mutually-exclusive boxes and exactly one should be checked. Real
    documents break that rule in both directions — nothing checked (the writer missed it) or
    several (they changed their mind) — and both need to be visible rather than silently
    resolved to the first match.

    Returns:
        ``{'classification': str, 'checked': list[str], 'ambiguous': bool}``.
        ``classification`` is ``'unknown'`` when nothing or more than one box is checked.
    """
    fields = _fields_by_name(document)
    checked = [
        name.replace('Tax Classification - ', '')
        for name in TAX_CLASSIFICATION_FIELDS
        if fields.get(name, '') in CHECKED_VALUES
    ]

    if len(checked) == 1:
        return {'classification': checked[0], 'checked': checked, 'ambiguous': False}
    return {'classification': 'unknown', 'checked': checked, 'ambiguous': True}


#: How many knowledge-store pages to follow before giving up. A runaway `next` chain would
#: otherwise spin forever inside a block that has no execution timeout.
MAX_KNOWLEDGE_STORE_PAGES = 50


def load_exempt_payee_codes(
    collection: str,
    _hs_block_instance: Any,
) -> dict[str, Any]:
    """Load the valid exempt-payee codes from the instance's knowledge store.

    A W-9's exempt payee code is only meaningful against a list the customer maintains in a
    knowledge store, so the flow reads that configuration from the platform at run time.

    The only block here that calls the platform, so its tests need ``ScriptedHsBlockInstance``:
    ``MockHsBlockInstance.hs_get`` returns a ``Mock``, and ``.json()`` on that is another
    ``Mock`` rather than data.

    The knowledge store pages as ``{'results': [...], 'next': url}``. That loop is what is
    worth testing, and a test that stubs this block never runs it.

    Args:
        collection: Knowledge-store collection holding the codes.
        _hs_block_instance: Injected by the platform.

    Returns:
        ``{'codes': list[str], 'pages_read': int}``.
    """
    codes: list[str] = []
    path: str | None = f'/api/v5/knowledge_store/items?collection={collection}'
    pages_read = 0

    while path and pages_read < MAX_KNOWLEDGE_STORE_PAGES:
        payload = _hs_block_instance.hs_get(path).json() or {}
        pages_read += 1

        for item in payload.get('results') or []:
            code = (item.get('properties') or {}).get('code')
            if code:
                codes.append(str(code).strip())

        # `next` is an absolute URL the platform supplies; follow it rather than build one.
        path = payload.get('next')

    _hs_block_instance.log(
        f'loaded {len(codes)} exempt payee code(s) from {collection} over {pages_read} page(s)'
    )
    return {'codes': codes, 'pages_read': pages_read}


def route_for_review(
    submission: dict[str, Any],
    require_valid_tin: bool,
    valid_exempt_codes: list[str],
    _hs_block_instance: Any,
) -> dict[str, Any]:
    """Decide whether the submission can be released downstream, and why.

    The block the flow branches on. It returns a *decision plus its reasons* rather than a
    bare boolean, so a test and a reader of the flow run can see why.

    Args:
        submission: The submission as the IDP core flow left it.
        require_valid_tin: When true, a TIN that is not nine digits sends the document to
            review. Turn it off to release documents whose TIN is illegible.
        valid_exempt_codes: Codes from the knowledge store. An empty list disables the check,
            so an unpopulated collection does not hold every document.
        _hs_block_instance: Injected by the platform; used for logging.

    Returns:
        ``{'decision': 'release' | 'review', 'reasons': list[str], 'documents': list}``,
        where each entry in ``documents`` carries the derived classification and TIN for the
        corresponding document.
    """
    reasons: list[str] = []
    summaries: list[dict[str, Any]] = []

    for document in submission.get('documents') or []:
        fields = _fields_by_name(document)
        entity = classify_tax_entity(document)
        tin = normalise_tin(
            fields.get('Social Security Number')
            or fields.get('Employer Identification Number')
            or ''
        )

        document_id = document.get('id')
        if entity['ambiguous']:
            reasons.append(
                f'document {document_id}: tax classification is ambiguous '
                f'(checked: {entity["checked"] or "nothing"})'
            )
        if require_valid_tin and not tin['valid']:
            reasons.append(
                f'document {document_id}: TIN has {len(tin["digits"])} digits, expected '
                f'{TIN_DIGITS}'
            )

        exempt_code = fields.get('Exempt Payee Code', '')
        if exempt_code and valid_exempt_codes and exempt_code not in valid_exempt_codes:
            reasons.append(
                f'document {document_id}: exempt payee code {exempt_code!r} is not in the '
                f'knowledge store'
            )

        summaries.append(
            {
                'document_id': document_id,
                'classification': entity['classification'],
                'tin': tin['digits'],
                'tin_kind': tin['looks_like'],
            }
        )

    decision = 'review' if reasons else 'release'
    _hs_block_instance.log(
        f'routing {len(summaries)} document(s) to {decision}'
        + (f'; reasons: {"; ".join(reasons)}' if reasons else '')
    )
    return {'decision': decision, 'reasons': reasons, 'documents': summaries}
