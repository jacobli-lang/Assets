"""Unit tests for the TIN-validation subflow's pure functions.

The cheapest tier, and the one that should carry the most cases: `validate_tin_digits` is a
pure function over a string, so every rule can be pinned without a flow, a runner or an
instance.

Each SSN rule catches a specific transcription error — a typed placeholder, or two swapped
digits — so each has its own test.
"""

from __future__ import annotations

import pytest

from showcase.flows.tin_validation.functions import summarise_validation, validate_tin_digits

pytestmark = pytest.mark.unit


class TestValidateTinDigits:
    """The structural rules, one test per reason a TIN can be rejected."""

    def test_a_plausible_ssn_passes(self) -> None:
        assert validate_tin_digits('123456789', 'ssn') == {'valid': True, 'problems': []}

    @pytest.mark.parametrize('area', ['000', '666'])
    def test_an_area_number_the_irs_never_issues_is_rejected(self, area: str) -> None:
        """`000` and `666` are not issued, so seeing one means the digits are wrong."""
        outcome = validate_tin_digits(f'{area}456789', 'ssn')
        assert not outcome['valid']
        assert outcome['problems'] == [f'area number {area} is never issued']

    def test_a_reserved_area_number_is_rejected(self) -> None:
        """900 and above are reserved (ITINs and unassigned ranges)."""
        outcome = validate_tin_digits('900456789', 'ssn')
        assert not outcome['valid']
        assert 'reserved' in outcome['problems'][0]

    def test_the_boundary_below_the_reserved_range_is_accepted(self) -> None:
        """899 is issuable; 900 is not. Off-by-one here would reject valid numbers."""
        assert validate_tin_digits('899456789', 'ssn')['valid']
        assert not validate_tin_digits('900456789', 'ssn')['valid']

    def test_a_zero_group_number_is_rejected(self) -> None:
        outcome = validate_tin_digits('123006789', 'ssn')
        assert not outcome['valid']
        assert outcome['problems'] == ['group number cannot be 00']

    def test_a_zero_serial_number_is_rejected(self) -> None:
        outcome = validate_tin_digits('123450000', 'ssn')
        assert not outcome['valid']
        assert outcome['problems'] == ['serial number cannot be 0000']

    def test_every_broken_rule_is_reported_not_just_the_first(self) -> None:
        """A partial report sends someone to fix one digit at a time."""
        outcome = validate_tin_digits('123000000', 'ssn')
        assert not outcome['valid']
        assert len(outcome['problems']) == 2  # noqa: PLR2004

    def test_an_ein_skips_the_ssn_rules(self) -> None:
        """EIN ranges differ, so applying SSN rules to one would reject valid numbers."""
        assert validate_tin_digits('000456789', 'ein') == {'valid': True, 'problems': []}

    def test_an_unknown_kind_is_held_to_the_stricter_rules(self) -> None:
        """When the kind was not identified, failing closed is the safer default."""
        assert not validate_tin_digits('000456789', 'unknown')['valid']

    @pytest.mark.parametrize(
        ('digits', 'expected'),
        [
            ('', 'expected 9 digits, got 0'),
            ('12345678', 'expected 9 digits, got 8'),
            ('1234567890', 'expected 9 digits, got 10'),
        ],
    )
    def test_the_wrong_length_is_reported_with_the_length(self, digits: str, expected: str) -> None:
        outcome = validate_tin_digits(digits, 'ssn')
        assert not outcome['valid']
        assert outcome['problems'] == [expected]

    def test_non_digits_are_rejected_before_the_rules_run(self) -> None:
        """`int(area)` would raise on letters, so the guard has to come first."""
        outcome = validate_tin_digits('12345678x', 'ssn')
        assert not outcome['valid']
        assert outcome['problems'] == ['contains non-digit characters']


class TestSummariseValidation:
    """The block entrypoint: aggregates per document and reports for the parent flow."""

    def test_all_valid_when_every_document_passes(self, platform: object) -> None:
        result = summarise_validation(
            [{'document_id': 1, 'tin': '123456789', 'tin_kind': 'ssn'}],
            _hs_block_instance=platform,
        )
        assert result == {
            'all_valid': True,
            'invalid_count': 0,
            'results': [{'document_id': 1, 'valid': True, 'problems': []}],
        }

    def test_one_bad_document_does_not_hide_the_good_ones(self, platform: object) -> None:
        """The parent flow routes per document, so it needs the whole picture."""
        result = summarise_validation(
            [
                {'document_id': 1, 'tin': '123456789', 'tin_kind': 'ssn'},
                {'document_id': 2, 'tin': '000456789', 'tin_kind': 'ssn'},
            ],
            _hs_block_instance=platform,
        )
        assert result['all_valid'] is False
        assert result['invalid_count'] == 1
        assert [r['valid'] for r in result['results']] == [True, False]

    def test_no_documents_is_valid_rather_than_an_error(self, platform: object) -> None:
        """An empty submission has nothing invalid in it; failing here would block release."""
        assert summarise_validation([], _hs_block_instance=platform) == {
            'all_valid': True,
            'results': [],
            'invalid_count': 0,
        }

    def test_a_missing_tin_is_reported_rather_than_crashing(self, platform: object) -> None:
        """An illegible TIN arrives as None, which must not raise."""
        result = summarise_validation(
            [{'document_id': 1, 'tin': None, 'tin_kind': None}], _hs_block_instance=platform
        )
        assert result['invalid_count'] == 1
        assert result['results'][0]['problems'] == ['expected 9 digits, got 0']

    def test_the_outcome_is_logged_with_the_reasons(self, platform: object) -> None:
        """The log is where an operator reads *why* a document was held."""
        summarise_validation(
            [{'document_id': 7, 'tin': '000456789', 'tin_kind': 'ssn'}],
            _hs_block_instance=platform,
        )
        logged = ' '.join(str(entry) for entry in platform.log_data)  # type: ignore[attr-defined]
        assert '1 invalid' in logged
        assert 'never issued' in logged
