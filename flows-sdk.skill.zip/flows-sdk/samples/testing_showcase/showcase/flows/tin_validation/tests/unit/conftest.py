"""Fixtures for the TIN-validation unit tests."""

from __future__ import annotations

import pytest
from flows_sdk.mocks import MockHsBlockInstance


@pytest.fixture
def platform() -> MockHsBlockInstance:
    """The platform object the block is handed at run time.

    `summarise_validation` logs through it, and the mock makes what it logged assertable.
    """
    return MockHsBlockInstance()
