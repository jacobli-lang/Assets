"""Contract tier for the TIN-validation subflow.

The four standard checks come from ``FlowStaticChecksSuite``: every reference resolves, no block
reads a field its upstream cannot emit, the interface is complete, and the flow's contract
matches a committed golden. Only assertions specific to *this* flow are written out below.

A subflow's interface is a real API — the core calls it and reads named outputs off it — so
this tier is what stops a rename or a dropped output breaking the caller silently.

Refresh the golden after an intended change:

    UPDATE_SNAPSHOTS=1 pytest -m contract
"""

from pathlib import Path

import pytest
from flows_sdk.testing.suites import FlowStaticChecksSuite

from showcase.flows.tin_validation.flow import (
    TIN_VALIDATION_IDENTIFIER,
    tin_validation_subflow,
)

pytestmark = pytest.mark.contract


class TestTinValidationContract(FlowStaticChecksSuite):
    """The subflow, checked on its own."""

    flow = tin_validation_subflow
    snapshot_path = Path(__file__).parent / 'snapshots' / 'tin_validation.json'

    def test_every_mandatory_input_has_a_default(self) -> None:
        """A subflow is deployed independently of its caller, so it must stand alone.

        Its caller supplies the real value at run time, but deploy validation comes first and
        refuses a mandatory input with no value (import succeeds either way).
        """
        rendered = tin_validation_subflow().render()
        configured = rendered.get('input') or {}

        for param in rendered['manifest']['input']:
            has_manifest_default = param.get('value') not in (None, '')
            assert has_manifest_default or param['name'] in configured, (
                f'{param["name"]} has no default and no value in the input section, so '
                f'{TIN_VALIDATION_IDENTIFIER} cannot be deployed on its own'
            )
