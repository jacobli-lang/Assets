"""Custom code for the TIN-validation subflow.

TIN validation is a step several flows want, and a subflow is how a flows project shares logic
across flows without copying blocks. It also shows that ``FlowTestRunner`` can stub a subflow
wholesale or execute it inline through a nested runner.
"""

from __future__ import annotations

from typing import Any

#: Prefixes the IRS does not issue for SSNs. A cheap check that catches transposition and
#: placeholder values without calling out to anything.
INVALID_SSN_AREA_NUMBERS = frozenset({'000', '666'})

#: SSN area numbers from 900 up are reserved (ITINs and unassigned ranges).
RESERVED_SSN_AREA_FLOOR = 900

SSN_AREA_LENGTH = 3
SSN_GROUP_LENGTH = 2


def validate_tin_digits(digits: str, kind: str) -> dict[str, Any]:
    """Check a nine-digit TIN against the structural rules for its kind.

    Structural only — it proves the number *could* exist, not that it does (that needs the
    IRS). It catches the common transcription errors: placeholders and transposed digits.

    Args:
        digits: Exactly nine digits, as :func:`normalise_tin` produces.
        kind: ``'ssn'``, ``'ein'`` or ``'unknown'``. An unknown kind is checked against the
            SSN rules, which are the stricter of the two.

    Returns:
        ``{'valid': bool, 'problems': list[str]}``.
    """
    problems: list[str] = []

    if len(digits) != 9:  # noqa: PLR2004
        return {'valid': False, 'problems': [f'expected 9 digits, got {len(digits)}']}
    if not digits.isdigit():
        return {'valid': False, 'problems': ['contains non-digit characters']}

    if kind in ('ssn', 'unknown'):
        area = digits[:SSN_AREA_LENGTH]
        group = digits[SSN_AREA_LENGTH : SSN_AREA_LENGTH + SSN_GROUP_LENGTH]
        serial = digits[SSN_AREA_LENGTH + SSN_GROUP_LENGTH :]

        if area in INVALID_SSN_AREA_NUMBERS:
            problems.append(f'area number {area} is never issued')
        elif int(area) >= RESERVED_SSN_AREA_FLOOR:
            problems.append(f'area number {area} is reserved')
        if group == '00':
            problems.append('group number cannot be 00')
        if serial == '0000':
            problems.append('serial number cannot be 0000')

    return {'valid': not problems, 'problems': problems}


def summarise_validation(
    documents: list[dict[str, Any]],
    _hs_block_instance: Any,
) -> dict[str, Any]:
    """Validate every document's TIN and summarise the result for the parent flow.

    Args:
        documents: The per-document summaries from ``route_for_review``.
        _hs_block_instance: Injected by the platform; used for logging.

    Returns:
        ``{'all_valid': bool, 'results': list, 'invalid_count': int}``.
    """
    results = []
    for document in documents or []:
        outcome = validate_tin_digits(
            str(document.get('tin') or ''), str(document.get('tin_kind') or 'unknown')
        )
        results.append(
            {
                'document_id': document.get('document_id'),
                'valid': outcome['valid'],
                'problems': outcome['problems'],
            }
        )

    invalid = [result for result in results if not result['valid']]
    summary = '; '.join(
        '{}: {}'.format(result['document_id'], ', '.join(result['problems'])) for result in invalid
    )
    _hs_block_instance.log(
        f'validated {len(results)} TIN(s); {len(invalid)} invalid'
        + (f' — {summary}' if invalid else '')
    )
    return {'all_valid': not invalid, 'results': results, 'invalid_count': len(invalid)}
