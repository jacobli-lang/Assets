"""The TIN-validation subflow.

Called by the custom IDP core. TIN validation is reusable across flows, and a subflow is how a
flows project shares logic without copying blocks. ``FlowTestRunner`` can test a subflow two
ways: stubbed wholesale, or executed inline through a nested runner.
"""

from pathlib import Path
from uuid import UUID

from flows_sdk.blocks import PythonBlock
from flows_sdk.flows import Flow, Manifest, Parameter
from flows_sdk.identifiers import flow_identifier
from flows_sdk.package_utils import export_flow
from flows_sdk.utils import workflow_input

from showcase.flows.tin_validation import functions

TIN_VALIDATION_IDENTIFIER = flow_identifier('SHOWCASE_TIN_VALIDATION')
TIN_VALIDATION_UUID = '3f7c1a84-9e52-4d16-b0a3-5c8e2f4b7d91'


def tin_validation_subflow() -> Flow:
    """Build the subflow: validate each document's TIN, summarise the outcome."""
    summarise = PythonBlock(
        reference_name='summarise_validation',
        code=functions.summarise_validation,
        code_input={'documents': workflow_input('documents')},
        title='Validate TINs',
        # `summarise_validation` calls `validate_tin_digits`, and a PythonBlock serialises only
        # the entrypoint by default, so on an instance the helper is undefined (`NameError`).
        # `include_module=True` ships the whole module.
        include_module=True,
    )

    return Flow(
        uuid=UUID(TIN_VALIDATION_UUID),
        title='Showcase — TIN Validation',
        description='Structurally validates taxpayer identification numbers.',
        owner_email='flows-sdk@hyperscience.ai',
        manifest=Manifest(
            identifier=TIN_VALIDATION_IDENTIFIER,
            input=[
                Parameter(
                    name='documents',
                    type='array',
                    title='Per-document summaries to validate',
                )
            ],
            # Declared so a caller can discover the return shape without reading the source.
            # The contract suite asserts these match what the flow actually maps.
            output=[
                Parameter(name='all_valid', type='boolean', title='Every TIN is valid'),
                Parameter(name='results', type='array', title='Per-document results'),
                Parameter(name='invalid_count', type='number', title='How many failed'),
            ],
        ),
        blocks=[summarise],
        # A default so the subflow deploys on its own: deploy requires every mandatory manifest
        # input to have a value, and the caller supplies the real one only at run time.
        input={'documents': []},
        output={
            'all_valid': summarise.output('all_valid'),
            'results': summarise.output('results'),
            'invalid_count': summarise.output('invalid_count'),
        },
    )


if __name__ == '__main__':
    dist = Path(__file__).parents[3] / 'dist'
    dist.mkdir(exist_ok=True)
    export_flow(
        tin_validation_subflow(),
        filename='showcase_tin_validation',
        location=str(dist),
    )
