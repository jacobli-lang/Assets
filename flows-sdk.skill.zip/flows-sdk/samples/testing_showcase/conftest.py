"""Pytest configuration for the showcase: make the project importable so tests can
``from showcase.flows.document_processing.flow import ...``.

Tier markers are not applied here. Each test module declares its own tier with
``pytestmark = pytest.mark.<tier>``, and ``pyproject.toml`` lists the markers. The
``tests/<tier>/`` folders are organisation, not configuration.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
