from uuid import UUID

from flows_sdk.flows import Flow, Manifest, Parameter
from flows_sdk.implementations.idp_v42.additional_blocks import (
    HyperscienceRestApiBlock,
)
from flows_sdk.package_utils import export_flow
from flows_sdk.utils import str_to_deterministic_uuid_4, workflow_input

ON_ERROR_CORE_FLOW_IDENTIFIER = 'ON_ERROR_CORE_EXAMPLE'
ON_ERROR_CORE_FLOW_UUID = str(str_to_deterministic_uuid_4(ON_ERROR_CORE_FLOW_IDENTIFIER))
ON_ERROR_CORE_TITLE = 'Retrieve error information - flows-sdk example'
ON_ERROR_CORE_DESCRIPTION = (
    'Core logic of the on-error flow. Compiles the data, relevant to the error. This includes '
    'metadata for the failed flow run, without any inputs, outputs or logs, which get excluded '
    'for performance reasons - their size is unpredictable.'
    '\n\n'
    'Any custom error handling logic should be added here. The main on-error flow should only be '
    'used for configuring the outputs in the Outputs block, i.e. where the compiled on-error data '
    'should be sent to.'
)


class OnErrorFlowInputKeys:
    failed_run_uuid: str = 'failed_run_uuid'

FAILED_FLOW_RUN_UUID_PARAMETER = Parameter(
    name=OnErrorFlowInputKeys.failed_run_uuid,
    type='string',
    title='Failed Flow Run UUID',
    description='UUID of the failed flow run that triggered this on_error flow',
    optional=False,
    ui={'hidden': True},
)

def on_error_core_flow() -> Flow:
    flow_run_uuid = workflow_input(OnErrorFlowInputKeys.failed_run_uuid)
    flow_run_rest_api_block = HyperscienceRestApiBlock(
        reference_name='flow_run_rest_api_block',
        method='GET',
        app_endpoint=f'/api/v5/flow_runs/{flow_run_uuid}/summary',
    )

    return Flow(
        uuid=UUID(ON_ERROR_CORE_FLOW_UUID),
        owner_email='flows-sdk@hyperscience.ai',
        title=ON_ERROR_CORE_TITLE,
        description=ON_ERROR_CORE_DESCRIPTION,
        manifest=Manifest(
            identifier=ON_ERROR_CORE_FLOW_IDENTIFIER,
            roles=['on_error_core', 'supporting', 'read_only'],
            input=[FAILED_FLOW_RUN_UUID_PARAMETER],
        ),
        output={'flow_run': flow_run_rest_api_block.output('result.data')},
        input={},
        blocks=[flow_run_rest_api_block],
    )


def entry_point_workflow() -> Flow:
    return on_error_core_flow()


if __name__ == '__main__':
    export_flow(entry_point_workflow())
