from uuid import UUID

from flows_sdk.blocks import Routing
from flows_sdk.flows import Flow
from flows_sdk.implementations.idp_v42 import additional_blocks, idp_blocks
from flows_sdk.implementations.idp_v42.additional_blocks import QASchedulerBlock
from flows_sdk.implementations.idp_v42.flows_version import FLOWS_VERSION, FLOWS_VERSION_DOTTED
from flows_sdk.implementations.idp_v42.idp_values import IDPCoreManifest, Settings
from flows_sdk.package_utils import export_flow
from flows_sdk.utils import str_to_deterministic_uuid_4, workflow_input

# If you are creating a custom version of this flow, choose a different UUID and identifier
# here and pass the correct identifier into ORCACoreBlock(identifier=...) within your flow.
IDP_ORCA_IDENTIFIER = f'IDP_ORCA_{FLOWS_VERSION}_EXAMPLE'
IDP_ORCA_UUID = str(str_to_deterministic_uuid_4(IDP_ORCA_IDENTIFIER))
IDP_ORCA_TITLE = f'Document Processing with ORCA Subflow {FLOWS_VERSION_DOTTED} - flows-sdk example'
NO_LABEL = 'No'
YES_LABEL = 'Yes'


def idp_orca_workflow() -> Flow:
    file_filter = additional_blocks.FileFilterBlock(reference_name='file_filter')

    bootstrap_submission = idp_blocks.SubmissionBootstrapBlock(
        trigger=file_filter.output('result.filtered_trigger'),
        reference_name='submission_bootstrap',
    )

    case_collation_task = idp_blocks.MachineCollationBlock(
        reference_name='machine_collation',
        submission=bootstrap_submission.output('submission'),
        cases=bootstrap_submission.output('api_params.cases'),
    )

    machine_classification = idp_blocks.MachineClassificationBlock(
        reference_name='machine_classification',
        submission=case_collation_task.output('submission'),
        api_params=bootstrap_submission.output('api_params'),
    )

    manual_classification = idp_blocks.ManualClassificationBlock(
        reference_name='manual_classification',
        submission=machine_classification.output('submission'),
        api_params=bootstrap_submission.output('api_params'),
    )

    manual_classification_routing = Routing(
        reference_name='manual_classification_routing',
        decision=machine_classification.output('needs_manual_classification'),
        title='Is Manual Classification needed?',
        branches=[
            Routing.Branch(
                case='false', label=NO_LABEL, blocks=[], output='machine_classification'
            ),
        ],
        default_branch=Routing.DefaultBranch(label=YES_LABEL, blocks=[manual_classification]),
    )

    orca_extraction = idp_blocks.OpticalReasoningCognitionAgentBlock(
        reference_name='orca_extraction',
        submission=manual_classification_routing.output('submission'),
        api_params=bootstrap_submission.output('api_params'),
    )

    flexible_extraction = idp_blocks.FlexibleExtractionBlock(
        reference_name='flexible_extraction',
        submission=orca_extraction.output('submission'),
        api_params=bootstrap_submission.output('api_params'),
    )

    flexible_extraction_routing = Routing(
        reference_name='flexible_extraction_routing',
        decision=orca_extraction.output('needs_flexible_extraction'),
        title='Is Flexible Extraction needed?',
        branches=[
            Routing.Branch('false', blocks=[], label=NO_LABEL, output='orca_extraction'),
        ],
        default_branch=Routing.DefaultBranch(blocks=[flexible_extraction], label=YES_LABEL),
    )

    reprocessing = idp_blocks.ReprocessingBlock(
        reference_name='reprocessing',
        submission=flexible_extraction_routing.output('submission'),
    )

    document_rendering = idp_blocks.DocumentRendererBlock(
        reference_name='document_rendering',
        submission=reprocessing.output('submission'),
        is_reprocessing=reprocessing.output('is_reprocessing'),
    )

    schedule_orca_qa = QASchedulerBlock(
        reference_name='schedule_orca_qa',
        flow_identifier=workflow_input(Settings.OrcaQaFlowIdentifier),
        submission=document_rendering.output('submission'),
        # The keys are the input names of the ORCA QA flow (FlowInputs in orca_qa_flow.py).
        qa_config={
            'task_restrictions': workflow_input(Settings.OrcaQaTaskRestrictions),
            'orca_qa_sample_rate': workflow_input(Settings.OrcaQaSampleRate),
        },
        is_reprocessing=reprocessing.output('is_reprocessing'),
    )
    schedule_orca_qa_routing = Routing(
        reference_name='schedule_orca_qa_routing',
        decision=workflow_input(Settings.OrcaQaFlowIdentifier),
        branches=[
            Routing.Branch(case='null', label='Skip QA', blocks=[], output='document_rendering')
        ],
        default_branch=Routing.DefaultBranch(label='Schedule QA', blocks=[schedule_orca_qa]),
        title='Should schedule QA?',
    )

    submission_complete = idp_blocks.SubmissionCompleteBlock(
        reference_name='complete_submission',
        submission=document_rendering.output('submission'),
        is_reprocessing=reprocessing.output('is_reprocessing'),
    )

    manifest = IDPCoreManifest(
        flow_identifier=IDP_ORCA_IDENTIFIER, roles=['read_only', 'supporting', 'idp_core', 'orca']
    )
    # Enable ORCA and ORCA only extraction for this flow.
    # (Shows ORCA Extraction parameters and hides Identification blocks related parameters from
    # IDPCoreManifest)
    for p in manifest.input:
        if p.name in [Settings.OrcaEnabled, Settings.OrcaOnlyExtraction]:
            p.value = True

    return Flow(
        uuid=UUID(IDP_ORCA_UUID),
        owner_email='flows-sdk@hyperscience.ai',
        title=IDP_ORCA_TITLE,
        description='A read-only subflow containing steps to process documents into '
        'machine-readable output using ORCA (Optical Reasoning & Cognition Agent).',
        manifest=manifest,
        output={'submission': submission_complete.output('submission')},
        blocks=[
            file_filter,
            bootstrap_submission,
            case_collation_task,
            machine_classification,
            manual_classification_routing,
            orca_extraction,
            flexible_extraction_routing,
            reprocessing,
            document_rendering,
            schedule_orca_qa_routing,
            submission_complete,
        ],
    )


def entry_point_workflow() -> Flow:
    return idp_orca_workflow()


if __name__ == '__main__':
    export_flow(entry_point_workflow())
