import sys
from uuid import UUID

from flows_sdk import utils
from flows_sdk.blocks import CodeBlock
from flows_sdk.flows import Flow, Manifest, Parameter
from flows_sdk.package_utils import export_flow
from flows_sdk.types import HsBlockInstance, HsTask

SYSTEM_ARGS_FLOW_IDENTIFIER = 'SYSTEM_ARGS_FLOW'
SYSTEM_ARGS_FLOW_UUID = UUID('83bf180b-3f20-49ff-bd6f-63a1a5f78e0c')


def entry_point_flow() -> Flow:
    return sample_flow_using_system_args()


class FlowInputs:
    TEST_INPUT = 'test'


def sample_flow_using_system_args() -> Flow:
    # system arguments can be combined with regular arguments
    def use_hs_task_fn(test: str, _hs_task: HsTask) -> str:
        return f'{test}_{_hs_task.correlation_id}'

    use_hs_task = CodeBlock(
        reference_name='use_hs_task',
        code=use_hs_task_fn,
        code_input={'test': utils.workflow_input(FlowInputs.TEST_INPUT)},
    )

    # a function can also have only system arguments
    def store_blob_fn(_hs_block_instance: HsBlockInstance) -> str:
        from flows_sdk.types import StoreBlobRequest

        store_blob_response = _hs_block_instance.store_blob(
            StoreBlobRequest(name='test-blob', content=b'{"data":"store-this-as-a-blob"}')
        )

        return store_blob_response.uuid

    store_blob = CodeBlock(reference_name='store_blob', code=store_blob_fn, code_input={})

    # you can also use both system arguments in the same function
    def fetch_blob_fn(blob_ref: str, _hs_task: HsTask, _hs_block_instance: HsBlockInstance) -> str:
        import json

        blob = _hs_block_instance.fetch_blob(blob_ref)
        data_from_previous_block = json.loads(str(blob.content, 'utf-8'))

        return f"{data_from_previous_block['data']}_{_hs_task.flow_run_id}"

    fetch_blob = CodeBlock(
        reference_name='fetch_blob',
        code=fetch_blob_fn,
        code_input={'blob_ref': store_blob.output()},
    )

    return Flow(
        title='System Arguments Flow',
        description='A simple Flow showcasing how to use system arguments',
        blocks=[use_hs_task, store_blob, fetch_blob],
        owner_email='flows.sdk@hyperscience.com',
        manifest=Manifest(
            identifier=SYSTEM_ARGS_FLOW_IDENTIFIER,
            input=[
                (
                    Parameter(
                        name=FlowInputs.TEST_INPUT,
                        title='Test input',
                        type='string',
                        optional=False,
                    )
                )
            ],
        ),
        uuid=SYSTEM_ARGS_FLOW_UUID,
        input={FlowInputs.TEST_INPUT: 'test-1234'},
    )


if __name__ == '__main__':
    export_filename = None
    if len(sys.argv) > 1:
        export_filename = sys.argv[1]

    export_flow(flow=entry_point_flow(), filename=export_filename)
