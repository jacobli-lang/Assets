from uuid import UUID

from flows_sdk.flows import Flow
from flows_sdk.implementations.idp_v36 import idp_blocks, idp_values
from flows_sdk.implementations.idp_v36.idp_values import (
    IdpWorkflowConfig,
    get_idp_wf_config,
    get_idp_wf_inputs,
)
from flows_sdk.package_utils import export_flow

IDP_UUID = '2667344c-ffef-4021-86c1-108fd54b6654'
IDP_TASK_NAME = 'IDP_V36_EXAMPLE'


def idp_workflow(idp_wf_config: IdpWorkflowConfig) -> Flow:

    bootstrap_submission = idp_blocks.SubmissionBootstrapBlock(
        reference_name='submission_bootstrap',
    )

    case_collation_task = idp_blocks.MachineCollationBlock(
        reference_name='machine_collation',
        submission=bootstrap_submission.output('submission'),
        cases=bootstrap_submission.output('api_params.cases'),
    )

    machine_classification = idp_blocks.MachineClassificationBlock(
        reference_name='machine_classification',
        submission=case_collation_task.output('submission'),
        api_params=bootstrap_submission.output('api_params'),
        rotation_correction_enabled=idp_wf_config.rotation_correction_enabled,
        mobile_processing_enabled=False,
    )

    manual_classification = idp_blocks.ManualClassificationBlock(
        reference_name='manual_classification',
        submission=machine_classification.output('submission'),
        api_params=bootstrap_submission.output('api_params'),
    )

    machine_identification = idp_blocks.MachineIdentificationBlock(
        reference_name='machine_identification',
        submission=manual_classification.output('submission'),
        api_params=bootstrap_submission.output('api_params'),
    )

    manual_identification = idp_blocks.ManualIdentificationBlock(
        reference_name='manual_identification',
        submission=machine_identification.output('submission'),
        api_params=bootstrap_submission.output('api_params'),
    )

    machine_transcription = idp_blocks.MachineTranscriptionBlock(
        reference_name='machine_transcription',
        submission=manual_identification.output('submission'),
        api_params=bootstrap_submission.output('api_params'),
    )

    manual_transcription = idp_blocks.ManualTranscriptionBlock(
        reference_name='manual_transcription',
        submission=machine_transcription.output('submission'),
        api_params=bootstrap_submission.output('api_params'),
        table_output_manual_review=(
            idp_wf_config.manual_transcription_config.table_output_manual_review
        ),
        supervision_transcription_masking=(
            idp_wf_config.manual_transcription_config.supervision_transcription_masking
        ),
        task_restrictions=idp_wf_config.manual_transcription_config.task_restrictions,
    )

    flexible_extraction = idp_blocks.FlexibleExtractionBlock(
        reference_name='flexible_extraction',
        submission=manual_transcription.output('submission'),
        api_params=bootstrap_submission.output('api_params'),
        task_restrictions=idp_wf_config.flexible_extraction_config.task_restrictions,
        supervision_transcription_masking=(
            idp_wf_config.flexible_extraction_config.supervision_transcription_masking
        ),
    )

    submission_complete = idp_blocks.SubmissionCompleteBlock(
        reference_name='complete_submission', submission=flexible_extraction.output('submission')
    )

    outputs = idp_blocks.IDPOutputsBlock(
        inputs={'submission': bootstrap_submission.output('submission')}
    )

    inputs = get_idp_wf_inputs(idp_wf_config)

    return Flow(
        uuid=UUID(IDP_UUID),
        owner_email='flows.sdk@hyperscience.com',
        title='Document Processing V36 - flows-sdk example',
        description='Document Processing V36 - flows-sdk example',
        manifest=idp_values.IDPManifest(flow_identifier=IDP_TASK_NAME),
        output={'submission': submission_complete.output()},
        triggers=idp_values.IDPTriggers(),
        input=inputs,
        blocks=[
            bootstrap_submission,
            case_collation_task,
            machine_classification,
            manual_classification,
            machine_identification,
            manual_identification,
            machine_transcription,
            manual_transcription,
            flexible_extraction,
            submission_complete,
            outputs,
        ],
    )


def entry_point_workflow() -> Flow:
    idp_wf_config = get_idp_wf_config()
    return idp_workflow(idp_wf_config)


if __name__ == '__main__':
    export_flow(flow=entry_point_workflow())
