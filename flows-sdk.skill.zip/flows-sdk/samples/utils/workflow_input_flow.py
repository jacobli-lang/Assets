from uuid import UUID

from flows_sdk.blocks import CodeBlock
from flows_sdk.flows import Flow, Manifest, Parameter
from flows_sdk.utils import workflow_input


def entry_point_flow() -> Flow:
    return workflow_input_example_flow()


def workflow_input_example_flow() -> Flow:
    """Example showing how to use workflow_input to access simple and nested input parameters."""

    # Simple parameter access - single argument
    def process_text(text: str) -> str:
        return text.upper()

    simple_block = CodeBlock(
        reference_name='process_text',
        code=process_text,
        code_input={'text': workflow_input('text_to_process')},
    )

    # Nested parameter access - multiple arguments joined with dots
    def extract_submission_id(submission_id: str) -> str:
        return f'Processing submission: {submission_id}'

    nested_block = CodeBlock(
        reference_name='extract_id',
        code=extract_submission_id,
        code_input={'submission_id': workflow_input('submission', 'id')},
    )

    return Flow(
        title='Workflow Input Example',
        description='Demonstrates using workflow_input() with simple and nested parameters',
        blocks=[simple_block, nested_block],
        owner_email='flows.sdk@hyperscience.com',
        manifest=Manifest(
            identifier='WORKFLOW_INPUT_EXAMPLE',
            input=[
                Parameter(name='text_to_process', type='string'),
                Parameter(name='submission', type='object'),
            ],
        ),
        uuid=UUID('c2d3e4f5-a6b7-8c9d-0e1f-2a3b4c5d6e7f'),
        input={
            'text_to_process': 'hello world',
            'submission': {'id': 'sub_12345', 'status': 'pending'},
        },
    )

