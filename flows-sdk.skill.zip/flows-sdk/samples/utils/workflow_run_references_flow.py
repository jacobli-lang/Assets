import sys
from uuid import UUID

from flows_sdk.blocks import PythonBlock
from flows_sdk.flows import Flow, Manifest
from flows_sdk.package_utils import export_flow
from flows_sdk.types import HsBlockInstance
from flows_sdk.utils import FlowRunReferences


def entry_point_flow() -> Flow:
    return workflow_run_references_example_flow()


def workflow_run_references_example_flow() -> Flow:
    """Example showing how to use WorkflowRunReferences to track flow execution."""

    def log_execution(
        run_uuid: str,
        correlation_id: str,
        _hs_block_instance: HsBlockInstance,
    ) -> None:
        _hs_block_instance.log(f'Run UUID: {run_uuid}')
        _hs_block_instance.log(f'Correlation ID: {correlation_id}')

    log_block = PythonBlock(
        reference_name='log_execution',
        code=log_execution,
        code_input={
            'run_uuid': FlowRunReferences.UUID,
            'correlation_id': FlowRunReferences.CORRELATION_ID,
        },
    )

    return Flow(
        title='Workflow Run References Example',
        description='Demonstrates using WorkflowRunReferences for tracking execution',
        blocks=[log_block],
        owner_email='flows.sdk@hyperscience.com',
        manifest=Manifest(identifier='WORKFLOW_RUN_REF_EXAMPLE', input=[]),
        uuid=UUID('e4f5a6b7-c8d9-0e1f-2a3b-4c5d6e7f8a9b'),
        input={},
    )


if __name__ == '__main__':
    export_filename = None
    if len(sys.argv) > 1:
        export_filename = sys.argv[1]

    export_flow(flow=entry_point_flow(), filename=export_filename)

