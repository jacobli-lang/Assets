from uuid import UUID

from flows_sdk.blocks import PythonBlock
from flows_sdk.flows import Flow, Manifest
from flows_sdk.types import HsBlockInstance
from flows_sdk.utils import FlowDefinitionReferences


def entry_point_flow() -> Flow:
    return workflow_definition_references_example_flow()


def workflow_definition_references_example_flow() -> Flow:
    """Example showing how to use WorkflowDefinitionReferences to access flow metadata."""

    def log_flow_info(flow_identifier: str, _hs_block_instance: HsBlockInstance) -> None:
        _hs_block_instance.log(f'Running flow: {flow_identifier}')

    log_block = PythonBlock(
        reference_name='log_flow',
        code=log_flow_info,
        code_input={'flow_identifier': FlowDefinitionReferences.IDENTIFIER},
    )

    return Flow(
        title='Workflow Definition References Example',
        description='Demonstrates using WorkflowDefinitionReferences.IDENTIFIER',
        blocks=[log_block],
        owner_email='flows.sdk@hyperscience.com',
        manifest=Manifest(identifier='WORKFLOW_DEF_REF_EXAMPLE', input=[]),
        uuid=UUID('d3e4f5a6-b7c8-9d0e-1f2a-3b4c5d6e7f8a'),
        input={},
    )
