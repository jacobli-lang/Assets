from typing import Any, List
from uuid import UUID

from flows_sdk.blocks import CodeBlock, Routing
from flows_sdk.flows import Flow
from flows_sdk.implementations.idp_v34.idp_blocks import (
    IdpCustomSupervisionBlock,
    IDPOutputsBlock,
    MachineClassificationBlock,
    MachineCollationBlock,
    MachineIdentificationBlock,
    MachineTranscriptionBlock,
    ManualClassificationBlock,
    ManualIdentificationBlock,
    ManualTranscriptionBlock,
    SubmissionBootstrapBlock,
    SubmissionCompleteBlock,
)
from flows_sdk.implementations.idp_v34.idp_values import (
    IDPManifest,
    IDPTriggers,
    get_idp_wf_config,
    get_idp_wf_inputs,
)
from flows_sdk.package_utils import export_flow


def entry_point_flow() -> Flow:
    return idp_workflow()


def _collate_classified_documents(manual_transcription: Any) -> List:
    """
    Helper method responsible for an optional flow that executes the following logic:
    - If any documents in the submission already have a case ID, then no operation is necessary
    - If none of the documents in the submission are assigned to a case,
        then create a new case containing all the CLASSIFIED documents in the submission.
        Unassigned pages should not receive case IDs
    """

    # Check the submission object's case field to see if a case has been created
    # thus far in the flow. If not, we should collate all the classified documents
    # in the submission. Otherwise, we can skip this operation.
    should_add_docs_to_case = CodeBlock(
        reference_name='should_add_docs_to_case',
        title='Should Add Classified Documents to a Case',
        description='If there are no cases assigned in the submission, group all classified '
        'documents into a newly created case for Custom Supervision',
        code=lambda cases: {'add_docs': 'true' if not cases else 'false'},
        code_input={'cases': manual_transcription.output('submission.cases')},
    )

    # Here we define the custom method used to grab all documents in the submission.
    def _grab_classified_doc_ids_fn(submission: Any) -> Any:
        doc_list = []
        for doc in submission.get('documents', []):
            doc_list.append(doc['id'])

        return doc_list

    # Custom Code Block to parse the submission object to find all documents. Classified
    # Documents automatically get categorized in this field.
    get_classified_doc_ids = CodeBlock(
        reference_name='get_classified_doc_ids',
        code=_grab_classified_doc_ids_fn,
        code_input={'submission': manual_transcription.output('submission')},
        title='Get All Document IDs',
        description='Grab all the Document IDs present in this submission '
        'to collate into a new case for Custom Supervision',
    )

    # We create and format the appropriate payload for our Machine Collation block to ingest.
    # Note that we are passing a null value for our external_case_id so that we can
    # automatically generate a new case ID.
    format_case_input = CodeBlock(
        reference_name='format_case_input',
        title='Format Classified Documents for Machine Collation',
        description='Creates the payload for Machine Collation',
        code=lambda docs: [{'external_case_id': None, 'documents': docs}],
        code_input={'docs': get_classified_doc_ids.output()},
    )

    # The Machine Collation Block creates the case and collates the classified documents
    # into the newly created case.
    group_into_cases = MachineCollationBlock(
        reference_name='pre_custom_sv_case_collation',
        submission=manual_transcription.output('submission'),
        cases=format_case_input.output(),
    )

    # The Routing block that is responsible for conditionally executing this flow.
    # Subsequent blocks are not reliant on the output of this Routing block.
    group_classified_doc_to_case = Routing(
        reference_name='group_classified_doc_to_case',
        decision=should_add_docs_to_case.output('add_docs'),
        branches=[
            Routing.Branch(
                case='true',
                blocks=[get_classified_doc_ids, format_case_input, group_into_cases],
                label='Collate Classified Documents',
            )
        ],
        default_branch=Routing.DefaultBranch(
            blocks=[
                CodeBlock(
                    reference_name='no_op_case_collation',
                    title='No Operation',
                    description='Pass the existing submission along without any changes',
                    code=lambda submission: {'submission': submission},
                    code_input={'submission': manual_transcription.output('submission')},
                )
            ]
        ),
    )

    return [should_add_docs_to_case, group_classified_doc_to_case]


def idp_workflow() -> Flow:
    idp_wf_config = get_idp_wf_config()

    # The idp flow basically processes, modifies and propagates the submission object from
    # block to block
    # Each block's processing result is usually included in the submission object

    # Submission bootstrap block initializes the submission object and prepares external images
    # or other submission data if needed
    submission_bootstrap = SubmissionBootstrapBlock(reference_name='submission_bootstrap')

    # Case collation block groups files, documents and pages (from the submission) into cases
    # In this example, case collation block receives the submission object and the cases
    # information from submission bootstrap block
    machine_collation = MachineCollationBlock(
        reference_name='machine_collation',
        submission=submission_bootstrap.output('submission'),
        cases=submission_bootstrap.output('api_params.cases'),
    )

    # Machine classification block automatically matches documents to structured, semi-structured
    # or additional layouts
    # In this example, machine classification block receives the submission object from
    # case collation block
    machine_classification = MachineClassificationBlock(
        reference_name='machine_classification',
        submission=machine_collation.output('submission'),
        api_params=submission_bootstrap.output('api_params'),
        rotation_correction_enabled=idp_wf_config.rotation_correction_enabled,
    )

    # Manual classification block allows keyers to manually match submissions to their layouts.
    # Keyers may perform manual classification if machine classification cannot automatically
    # match a submission to a layout with high confidence
    # In this example, manual classification block receives the submission object from machine
    # classification block
    manual_classification = ManualClassificationBlock(
        reference_name='manual_classification',
        submission=machine_classification.output('submission'),
        api_params=submission_bootstrap.output('api_params'),
    )

    # Machine identification automatically identify fields and tables in the submission
    # In this example, machine identification block receives the submission object from manual
    # classification
    machine_identification = MachineIdentificationBlock(
        reference_name='machine_identification',
        submission=manual_classification.output('submission'),
        api_params=submission_bootstrap.output('api_params'),
    )

    # Manual identification allows keyers to complete field identification or table identification
    # tasks, where they draw bounding boxes around the contents of certain fields, table columns
    # or table rows. This identification process ensures that the system will be able to
    # transcribe the correct content in the upcoming transcription process
    # In this example, manual identification block receives the submission object from machine
    # identification
    manual_identification = ManualIdentificationBlock(
        reference_name='manual_identification',
        submission=machine_identification.output('submission'),
        api_params=submission_bootstrap.output('api_params'),
        task_restrictions=idp_wf_config.manual_identification_config.task_restrictions,
    )

    # Machine transcription automatically transcribes the content of your submission
    # In this example, machine identification block receives the submission object from manual
    # identification
    machine_transcription = MachineTranscriptionBlock(
        reference_name='machine_transcription',
        submission=manual_identification.output('submission'),
        api_params=submission_bootstrap.output('api_params'),
    )

    # Manual transcription lets your keyers manually enter the text found in fields or tables
    # that could not be automatically transcribed
    # In this example, manual transcription block receives the submission object from machine
    # transcription block
    manual_transcription = ManualTranscriptionBlock(
        reference_name='manual_transcription',
        submission=machine_transcription.output('submission'),
        api_params=submission_bootstrap.output('api_params'),
        supervision_transcription_masking=(
            idp_wf_config.manual_transcription_config.supervision_transcription_masking
        ),
        table_output_manual_review=(
            idp_wf_config.manual_transcription_config.table_output_manual_review
        ),
        task_restrictions=idp_wf_config.manual_transcription_config.task_restrictions,
    )

    # Here we define a function for a custom code block that gets all fields and tables from a
    # submission to display them in custom supervision. It makes sure they appear only when an
    # appropriate layout has been selected by using the dependencies settings.
    # We also create a decision for the first cell in each table.
    def _get_transcriptions_for_custom_sv_fn(submission: Any) -> Any:
        transcription_entities = []
        table_cell_decisions = []
        visited = set()
        for doc in submission.get('documents', []):
            fields = sorted(doc.get('document_fields', []), key=lambda f: f['id'])
            for field in fields:
                if field['layout_field_uuid'] in visited:
                    continue
                visited.add(field['layout_field_uuid'])
                transcription_entities.append(
                    {
                        'name': f"{field['field_name']}_{field['layout_field_uuid']}",
                        'type': 'transcription',
                        'data_identifier': field['layout_field_uuid'],
                        'ui': {'hidden': True},
                        'dependencies': [
                            {
                                'condition': {
                                    'properties': {'layoutId': {'const': doc['layout_uuid']}}
                                },
                                'override': {'ui': {'hidden': False}},
                            }
                        ],
                    }
                )
            for table in doc.get('tables', []):
                if table['layout_table_uuid'] in visited:
                    continue
                visited.add(table['layout_table_uuid'])
                transcription_entities.append(
                    {
                        'name': table['layout_table_uuid'],
                        'type': 'table_transcription',
                        'data_identifier': table['layout_table_uuid'],
                        'ui': {'hidden': True},
                        'dependencies': [
                            {
                                'condition': {
                                    'properties': {'layoutId': {'const': doc['layout_uuid']}}
                                },
                                'override': {'ui': {'hidden': False}},
                            }
                        ],
                    },
                )
                try:
                    table_cell_decisions.append(
                        {
                            'name': f'table_cell_decision_{table["layout_table_uuid"]}',
                            'type': 'decision',
                            'title': 'Table Cell Decision',
                            'ui': {'hidden': True},
                            'relation': {
                                'type': 'table_cell',
                                'match': table['columns'][0]['cells'][0]['uuid'],
                            },
                            'dependencies': [
                                {
                                    'condition': {
                                        'properties': {'layoutId': {'const': doc['layout_uuid']}}
                                    },
                                    'override': {'ui': {'hidden': False}},
                                }
                            ],
                            'schema': {
                                'oneOf': [
                                    {'const': 'accept', 'title': 'Accept Table Cell'},
                                    {'const': 'reject', 'title': 'Reject Table Cell'},
                                ]
                            },
                        },
                    )
                except (IndexError, KeyError):
                    pass
        return transcription_entities, table_cell_decisions

    # Create our Custom Code block using our function from above.
    get_transcriptions_for_custom_sv = CodeBlock(
        reference_name='get_transcriptions_for_custom_sv',
        code=_get_transcriptions_for_custom_sv_fn,
        code_input={'submission': manual_transcription.output('submission')},
        title='Get All Transcriptions',
        description='Find all transcriptions in this submission to include in Custom Supervision',
    )

    # Using the output of our Custom Code block, we can construct our three column template
    # to define our Custom Supervision task.
    format_sv_template = CodeBlock(
        title='Format Custom Supervision Template',
        description='Creates the supervision template to define our Custom Supervision task',
        reference_name='format_sv_template',
        code=lambda transcriptions: [
            {
                'name': 'three_column_template',
                'version': '1.0',
                'thumbnail': {'group_by_document': True, 'group_by_case': True},
                'action': [
                    {
                        'name': 'Transcriptions',
                        'display': 'All Identified Fields and Tables',
                        'input': transcriptions[0],
                    },
                    {
                        'name': 'Decision and Case',
                        'display': 'Make Decision - Add Case',
                        'input': [
                            *transcriptions[1],
                            {
                                'name': 'document_decision',
                                'type': 'decision',
                                'title': 'Document Decision',
                                'relation': {'type': 'document'},
                                'schema': {
                                    'oneOf': [
                                        {'const': 'accept', 'title': 'Accept Document'},
                                        {'const': 'reject', 'title': 'Reject Document'},
                                    ]
                                },
                            },
                            {'name': 'assign_to_case', 'type': 'case_dropdown', 'title': ''},
                        ],
                    },
                ],
            }
        ],
        code_input={
            'transcriptions': get_transcriptions_for_custom_sv.output(),
        },
    )

    # Create our Custom Supervision task using the template we constructed via Custom Code blocks.
    # This task will have all fields from the submission so that the user can edit them, as well
    # as a document level decision ("accept" or "reject" the document). It will also have the
    # option to add a document to a case.
    idp_custom_supervision = IdpCustomSupervisionBlock(
        reference_name='idp_custom_supervision',
        submission=manual_transcription.output('submission'),
        task_purpose='example_custom_supervision',
        supervision_template=format_sv_template.output(),
    )

    # Case collation block groups files, documents and pages (from the submission) into cases
    # In this example, case collation block receives the submission object and the cases
    # information from the custom supervision block. This block is required after Custom
    # Supervision in order to propagate case ID changes to the IDP database.
    custom_supervision_collation = MachineCollationBlock(
        reference_name='custom_supervision_collation',
        submission=idp_custom_supervision.output('submission'),
        cases=idp_custom_supervision.output('cases'),
        remove_from_cases=idp_custom_supervision.output('remove_from_cases'),
    )

    # Submission complete block finalizes submission processing and updates reporting data
    # Every flow needs a complete block because it initiates Quality Assurance tasks and
    # changes the submission's status to "Complete"
    # In this example, submission complete block receives the submission object from
    # marked_as_complete custom code block
    submission_complete = SubmissionCompleteBlock(
        reference_name='complete_submission',
        submission=custom_supervision_collation.output('submission'),
    )

    # Output block allows users to send data extracted by this idp flow to other systems
    # for downstream processing
    # In this example, this is an empty output block that does not do anything by default
    outputs = IDPOutputsBlock(inputs={'submission': submission_bootstrap.output('submission')})

    return Flow(
        # Flows should have a deterministic UUID ensuring cross-system consistency
        uuid=UUID('4cc70d7f-43c1-43ff-a7c7-708b43610558'),
        owner_email='flows.sdk@hyperscience.com',
        title='IDP Custom Supervision Block Flow Example (V34)',
        # Flow identifiers are globally unique
        manifest=IDPManifest(flow_identifier='IDP_CUSTOM_SUPERVISION_V34_EXAMPLE'),
        # It is important to include all blocks that are instantiated here in the blocks
        # field and make sure they follow the order of the flow. For example, if machine
        # classification depends on the output of case collation, then machine_collation must
        # come before machine_classification in this blocks array
        blocks=[
            submission_bootstrap,
            machine_collation,
            machine_classification,
            manual_classification,
            machine_identification,
            manual_identification,
            machine_transcription,
            manual_transcription,
            *_collate_classified_documents(manual_transcription),
            get_transcriptions_for_custom_sv,
            format_sv_template,
            idp_custom_supervision,
            custom_supervision_collation,
            submission_complete,
            outputs,
        ],
        input=get_idp_wf_inputs(idp_wf_config),
        description='IDP Custom Supervision - All Fields (V34)',
        triggers=IDPTriggers(),
        output={'submission': submission_complete.output()},
    )


if __name__ == '__main__':
    export_flow(flow=entry_point_flow())
