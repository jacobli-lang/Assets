from uuid import UUID

from flows_sdk.blocks import CodeBlock
from flows_sdk.error_handling import (
    ErrorHandling,
    NoRetryErrorRetryPolicy,
    RetryMethod,
    SimpleErrorRetryPolicy,
)
from flows_sdk.flows import Flow, Manifest, Parameter
from flows_sdk.package_utils import export_flow
from flows_sdk.utils import workflow_input

BLOCK_RETRIES_FLOW_IDENTIFIER = 'BLOCK_RETRIES_SHOWCASE'

BLOCK_RETRIES_FLOW_UUID = UUID('59ebf286-686c-4df0-9b5f-f949607780ad')


class FlowInputs:
    N_SECONDS = 'n_seconds'


def entry_point_flow() -> Flow:
    return block_error_retries_showcase_flow()


def block_error_retries_showcase_flow() -> Flow:
    def _create_start_date() -> str:
        from datetime import datetime

        return datetime.now().isoformat()

    create_start_date = CodeBlock(
        reference_name='create_start_date',
        code=_create_start_date,
        code_input={},
    ).with_error_handling(
        ErrorHandling(
            # overrides the flow level retry policy for this block with NO_RETRY
            block_error_retry_policy=NoRetryErrorRetryPolicy()
        )
    )

    def _fail_until_n_seconds_later(start_date: str, n_seconds: int) -> None:
        from datetime import datetime, timedelta

        if datetime.now() < datetime.fromisoformat(start_date) + timedelta(seconds=n_seconds):
            raise Exception('Too early to complete!')

    fail_until_n_seconds_later = CodeBlock(
        reference_name='fail_until_n_seconds_later',
        code=_fail_until_n_seconds_later,
        code_input={
            'start_date': create_start_date.output(),
            'n_seconds': workflow_input(FlowInputs.N_SECONDS),
        },
    )

    return Flow(
        title='Block retries sample flow',
        description='Sample flow with a retry policy',
        blocks=[create_start_date, fail_until_n_seconds_later],
        owner_email='flows.sdk@hyperscience.com',
        manifest=Manifest(
            identifier=BLOCK_RETRIES_FLOW_IDENTIFIER,
            input=[
                Parameter(
                    name=FlowInputs.N_SECONDS,
                    title='Fail for this may seconds',
                    type='integer',
                    optional=False,
                )
            ],
        ),
        uuid=BLOCK_RETRIES_FLOW_UUID,
        input={FlowInputs.N_SECONDS: 30},
        error_handling=ErrorHandling(
            # retry up to 20 times with 5 seconds between attempts
            # will be applied to all blocks in the flow
            block_error_retry_policy=SimpleErrorRetryPolicy(
                method=RetryMethod.FIXED, retry_count=20, retry_interval_seconds=5
            )
        ),
    )


if __name__ == '__main__':
    export_flow(flow=entry_point_flow())
