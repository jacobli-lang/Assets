from uuid import UUID

from flows_sdk.blocks import CodeBlock
from flows_sdk.flows import Flow, Manifest, Parameter
from flows_sdk.package_utils import export_flow
from flows_sdk.types import HsBlockInstance
from flows_sdk.utils import workflow_input

FILE_INPUT_FLOW_IDENTIFIER = 'FILE_INPUT_SHOWCASE'

FILE_INPUT_FLOW_UUID = UUID('2869449d-db9e-485b-b285-f954346793c6')


class FlowInputs:
    FILE = 'file'


def entry_point_flow() -> Flow:
    return file_input_showcase_flow()


def file_input_showcase_flow() -> Flow:
    def _read_and_log_file(file_uuid: str, _hs_block_instance: HsBlockInstance) -> str:
        if not file_uuid:
            _hs_block_instance.log('No file configured')
            return ''
        blob = _hs_block_instance.fetch_blob(file_uuid)
        file_text = blob.content.decode(encoding='utf-8')
        _hs_block_instance.log(file_text)
        return file_text

    read_and_log_file = CodeBlock(
        reference_name='read_and_log_file',
        code=_read_and_log_file,
        code_input={'file_uuid': workflow_input(FlowInputs.FILE)},
    )

    return Flow(
        title='Flow with a file input',
        description='Accepts a text file as an input and logs and outputs its contents',
        blocks=[read_and_log_file],
        owner_email='flows.sdk@hyperscience.com',
        manifest=Manifest(
            identifier=FILE_INPUT_FLOW_IDENTIFIER,
            input=[
                Parameter(
                    name=FlowInputs.FILE,
                    title='File to read',
                    type='File',
                    # restricts the type of file that can be selected
                    type_spec={'allowed_extensions': '.txt'},
                    optional=True,
                )
            ],
        ),
        uuid=FILE_INPUT_FLOW_UUID,
        input={FlowInputs.FILE: 'some_text.txt'},
    )


if __name__ == '__main__':
    export_flow(flow=entry_point_flow())
