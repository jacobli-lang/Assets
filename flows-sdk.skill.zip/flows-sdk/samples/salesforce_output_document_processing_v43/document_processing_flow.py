"""Document processing flow that writes to Salesforce, for platforms before v44.

Runs IDP Core and then calls the Salesforce Writer subflow (`salesforce_writer_flow.py`), handing
it the processed submission, the trigger (which carries the submission metadata) and the Salesforce
credentials.

The credentials are configured HERE, once. You iterate on the Salesforce logic in the subflow and
re-import only that, so this flow - and the credentials on it - stay untouched.

Written for Hyperscience v43. For an older release, change the `idp_v43` imports below to the
matching `idp_vXX` package so the flow references the IDP Core subflow that release installs, and
build in a venv whose Python matches the code block that release ships.

Import the writer subflow FIRST (this flow references it by identifier), then this one::

    HS_PYTHON_CODE_BLOCK_PYTHON_VERSION=3.13 hs-flows bundle document_processing_flow.py \
        -o document_processing_flow.zip

See `Salesforce Integration Flow <../pages/salesforce_integration_flow.html>`_, section "Before v44", for the
full walkthrough. On v44 and later, add the updated Salesforce Notifier output block to a
processing flow you already run instead, as `samples/salesforce_integration_flow` shows.
"""

from uuid import UUID

from flows_sdk.blocks import Block
from flows_sdk.flows import Flow, Parameter
from flows_sdk.implementations.idp_v43.idp_blocks import IDPCoreBlock
from flows_sdk.implementations.idp_v43.idp_values import (
    IDPTriggers,
    IDPWrapperManifest,
    Settings,
    get_idp_wf_config,
)
from flows_sdk.package_utils import export_flow
from flows_sdk.utils import workflow_input

# `WRITER_IDENTIFIER` of `salesforce_writer_flow.py`, declared here too so neither file has to
# import the other: a downloaded sample then runs from any directory. Keep the two in sync.
WRITER_IDENTIFIER = 'SALESFORCE_WRITER_EXAMPLE'

IDENTIFIER = 'SALESFORCE_DOCUMENT_PROCESSING_EXAMPLE'
FLOW_UUID = str(UUID('654a59c7-d04f-4e16-9abd-3a02962ec22a'))


class Inputs:
    # Salesforce connected app credentials (JWT bearer flow), configured on THIS flow, once.
    # Iterating on the subflow never re-imports them.
    Username = 'username'
    ConsumerKey = 'consumer_key'
    PrivateKey = 'private_key'
    SandboxEnvironment = 'sandbox_environment'


def workflow() -> Flow:
    # Standard IDP Core document processing (classification / identification / transcription).
    idp_core = IDPCoreBlock(get_idp_wf_config())

    # Call the Salesforce Writer subflow. A block whose identifier is another flow's identifier is
    # executed as a sub-workflow: the platform runs SALESFORCE_WRITER_EXAMPLE and waits for it.
    # We pass the processed submission, the trigger (carries the metadata), and the credentials.
    write_to_salesforce = Block(
        identifier=WRITER_IDENTIFIER,
        reference_name='salesforce_writer',
        input={
            'submission': idp_core.output('submission'),
            'trigger': workflow_input('$trigger'),
            'username': workflow_input(Inputs.Username),
            'consumer_key': workflow_input(Inputs.ConsumerKey),
            'private_key': workflow_input(Inputs.PrivateKey),
            'sandbox_environment': workflow_input(Inputs.SandboxEnvironment),
        },
        title='Write to Salesforce',
        description='Calls the Salesforce Writer subflow with the processed submission and '
        'credentials.',
    )

    # Start from the standard IDP wrapper manifest (exposes Layout Release and the other IDP flow
    # settings), then add the Salesforce credential inputs.
    manifest = IDPWrapperManifest(IDENTIFIER)
    manifest.input = list(manifest.input) + [
        Parameter(
            name=Inputs.Username,
            type='string',
            title='Associated Username',
            description='Username associated with the Salesforce Connected App',
            value='',
        ),
        Parameter(
            name=Inputs.ConsumerKey,
            type='Password',
            title='Consumer Key',
            description='Consumer key used for authentication with Salesforce. Paired with the '
            'Salesforce instance from which it was issued.',
            secret=True,
            value='',
        ),
        Parameter(
            name=Inputs.PrivateKey,
            type='Password',
            title='Private Key',
            description='Private key used for authentication with Salesforce',
            secret=True,
            value='',
        ),
        Parameter(
            name=Inputs.SandboxEnvironment,
            type='boolean',
            title='Sandbox Environment',
            description='Enable if the Salesforce environment is a sandbox',
            value=False,
        ),
    ]

    return Flow(
        uuid=UUID(FLOW_UUID),
        owner_email='flows-sdk@hyperscience.com',
        title='Salesforce Document Processing - flows-sdk example',
        description='Document processing flow that runs IDP Core and then calls the Salesforce '
        'Writer subflow to write submission data to Salesforce.',
        manifest=manifest,
        input={Settings.LayoutReleaseUuid: None},
        triggers=IDPTriggers(),
        blocks=[idp_core, write_to_salesforce],
        output={'submission': idp_core.output('submission')},
    )


def entry_point_workflow() -> Flow:
    return workflow()


if __name__ == '__main__':
    export_flow(entry_point_workflow())
