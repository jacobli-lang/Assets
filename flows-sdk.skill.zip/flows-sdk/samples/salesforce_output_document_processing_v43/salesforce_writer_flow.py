"""Salesforce Writer subflow: the half of this example that does the Salesforce work.

The document processing flow (`document_processing_flow.py`) calls this flow as a subflow, passing
the processed submission, the trigger (which carries the submission metadata) and the Salesforce
credentials. Keeping the two apart is what lets you iterate: the credentials are configured on the
document processing flow, so re-importing this subflow never clears them.

This subflow owns the settings you tune most often - the target Salesforce object and the two field
mappings - and the Python that writes the record.

Import this subflow FIRST; the document processing flow references it by identifier.

    HS_PYTHON_CODE_BLOCK_PYTHON_VERSION=3.13 hs-flows bundle salesforce_writer_flow.py \
        -o salesforce_writer_flow.zip

See `Salesforce Integration Flow <../pages/salesforce_integration_flow.html>`_, section "Before v44", for the
full walkthrough. On v44 and later, prefer the updated Salesforce Notifier output block and
integration flow in `samples/salesforce_integration_flow`.
"""

from uuid import UUID

from flows_sdk.blocks import PythonBlock
from flows_sdk.flows import Flow, Manifest, Parameter
from flows_sdk.package_utils import export_flow
from flows_sdk.types import HsBlockInstance, HsTask
from flows_sdk.utils import workflow_input

# The document processing flow calls this subflow by identifier. It declares the same string
# itself, so the two files stay independent: keep them in sync.
WRITER_IDENTIFIER = 'SALESFORCE_WRITER_EXAMPLE'
WRITER_FLOW_UUID = str(UUID('7c1d3e58-9b2a-4c6e-8f0d-1a2b3c4d5e6f'))


class Inputs:
    # Passed in by the parent flow (not configured here).
    Submission = 'submission'
    Trigger = 'trigger'
    Username = 'username'
    ConsumerKey = 'consumer_key'
    PrivateKey = 'private_key'
    SandboxEnvironment = 'sandbox_environment'
    # Configured on THIS subflow (non-secret; safe to reset on re-import, and have defaults).
    SfObject = 'sf_object'
    # Mappings of source name -> Salesforce field API name, as JSON objects:
    # {"SOURCE_NAME": "SF_FIELD_API_NAME"}.
    MetadataFieldsMapping = 'metadata_fields_mapping'
    DocumentFieldsMapping = 'document_fields_mapping'
    DryRun = 'dry_run'


def _write_metadata_to_salesforce(
    trigger: dict,
    submission: dict,
    username: str,
    consumer_key: str,
    private_key: str,
    sandbox_environment: bool,
    sf_object: str,
    metadata_fields_mapping: dict,
    document_fields_mapping: dict,
    dry_run: bool,
    _hs_block_instance: HsBlockInstance,
    _hs_task: HsTask,
) -> dict:
    # `simple-salesforce` and its dependencies must be installed on the platform for this
    # interpreter, under Flows -> Python Packages. The import lives inside the function because it
    # runs on the block, not at flow-compile time.
    from simple_salesforce import Salesforce  # type: ignore[import-not-found] # pants: no-infer-dep

    # Build the Salesforce record from the two mappings, source name -> Salesforce field.
    record: dict = {}

    # 1. Extract fields for the Submission metadata.
    #    Metadata rides on the trigger at $trigger.payload.api_params.metadata;
    #    the parent passes that trigger in as `trigger`.
    #    metadata_fields_mapping: {"metadata_key": "SF_FIELD_API_NAME"}
    metadata = trigger.get('payload', {}).get('api_params', {}).get('metadata', {}) or {}
    for metadata_key, sf_field in (metadata_fields_mapping or {}).items():
        if metadata_key not in metadata:
            raise ValueError(
                f'Submission metadata has no key {metadata_key!r}. '
                f'Available keys: {sorted(metadata)}'
            )
        record[sf_field] = metadata[metadata_key]

    # 2. Extract document fields from the processed submission. The `submission` object is the
    #    output of IDP Core and carries the documents/pages/fields. Each extracted field looks like:
    #      { "field_name": "document_field", "output_name": "...",
    #        "transcription": "Acme Corporation", "transcription_normalized": "ACME CORPORATION" }
    #    NB: the Python Code block only ships THIS function's source, so any helper must be defined
    #    inside it (a module-level helper would raise NameError at runtime).
    def get_extracted_field(field_name: str) -> str | None:
        for document in submission.get('documents', []):
            for field in document.get('document_fields', []) or []:
                if field_name in (field.get('field_name'), field.get('output_name')):
                    # Prefer the normalized value; fall back to the raw transcription.
                    return field.get('transcription_normalized') or field.get('transcription')
        return None

    for document_field_name, sf_field in (document_fields_mapping or {}).items():
        value = get_extracted_field(document_field_name)
        if value is None:
            raise ValueError(
                f'No extracted value for document field {document_field_name!r} in the submission.'
            )
        record[sf_field] = value

    if not sf_object:
        raise ValueError('sf_object is required (e.g. "Account").')

    if not record:
        raise ValueError(
            'Nothing to write: both metadata_fields_mapping and document_fields_mapping are empty.'
        )

    # JWT bearer auth with the connected app credentials the document processing flow passes in:
    #   username -> JWT subject, consumer_key -> JWT issuer, private_key -> RS256 signing key.
    # A PEM pasted into a form field can arrive with literal "\n", so normalize it first.
    private_key = private_key.replace('\\n', '\n')
    domain = 'test' if sandbox_environment else 'login'
    salesforce = Salesforce(
        username=username,
        consumer_key=consumer_key,
        privatekey=private_key,
        domain=domain,
    )

    # Look up existing records on the chosen object using the mapped fields as WHERE criteria
    # (AND'd together). If none match, create the record; otherwise skip creation to avoid a
    # duplicate. SOQL string literals are single-quoted, so escape backslashes and single quotes.
    def soql_literal(value: object) -> str:
        escaped = str(value).replace('\\', '\\\\').replace("'", "\\'")
        return f"'{escaped}'"

    # `log()` formats the message with `{}` style, so values that contain braces (a dict, a SOQL
    # string) are passed as ARGS rather than interpolated into `msg`: args are substituted, not
    # re-parsed. `level` is keyword-only; passed positionally it would be taken for an arg.
    def log_info(msg: str, *args: object) -> None:
        _hs_block_instance.log(msg, *args, level=HsBlockInstance.LogLevel.INFO)

    where = ' AND '.join(f'{sf_field} = {soql_literal(v)}' for sf_field, v in record.items())
    query = f'SELECT Id FROM {sf_object} WHERE {where}'
    # Log the query BEFORE running it, so it is visible even if the query itself errors.
    log_info('Salesforce lookup query: {}', query)
    result = salesforce.query_all(query)
    count = result.get('totalSize', len(result.get('records', [])))
    log_info('Salesforce lookup on {} with {} -> {} record(s).', sf_object, record, count)

    created_id = None
    if dry_run:
        # The lookup above still ran, so a dry run proves the credentials and the mapping without
        # touching the org. Turn Dry Run off to write for real.
        log_info(
            'Dry run: not creating a {} record. Would have written {}.', sf_object, record
        )
    elif count == 0:
        # No existing match - create the record.
        created = getattr(salesforce, sf_object).create(record)
        created_id = created.get('id')
        log_info(
            'No existing {}; created record {} with {}.', sf_object, created_id, record
        )
    else:
        log_info('{} existing {} record(s) matched; skipping create.', count, sf_object)

    return {
        'result_count': count,
        'lookup_fields': record,
        'query': query,
        'dry_run': dry_run,
        'created': created_id is not None,
        'salesforce_id': created_id,
    }


def workflow() -> Flow:
    write_to_salesforce = PythonBlock(
        reference_name='write_metadata_to_salesforce',
        code=_write_metadata_to_salesforce,
        # No `python_version` here: the block compiles to the Python version of the venv this
        # is built in, or to `HS_PYTHON_CODE_BLOCK_PYTHON_VERSION` if that is set. Pick the one
        # your platform runs, as described in the walkthrough.
        code_input={
            'trigger': workflow_input(Inputs.Trigger),
            'submission': workflow_input(Inputs.Submission),
            'username': workflow_input(Inputs.Username),
            'consumer_key': workflow_input(Inputs.ConsumerKey),
            'private_key': workflow_input(Inputs.PrivateKey),
            'sandbox_environment': workflow_input(Inputs.SandboxEnvironment),
            'sf_object': workflow_input(Inputs.SfObject),
            'metadata_fields_mapping': workflow_input(Inputs.MetadataFieldsMapping),
            'document_fields_mapping': workflow_input(Inputs.DocumentFieldsMapping),
            'dry_run': workflow_input(Inputs.DryRun),
        },
        title='Write metadata to Salesforce',
        description='Maps submission metadata and extracted document fields to Salesforce field '
        'API names and writes them to a Salesforce record using simple-salesforce.',
    )

    return Flow(
        uuid=UUID(WRITER_FLOW_UUID),
        owner_email='flows-sdk@hyperscience.com',
        title='Salesforce Writer (Example Subflow)',
        description='Writes submission data to Salesforce. Called as a subflow by the Salesforce '
        'document processing example, which passes the Salesforce credentials in.',
        manifest=Manifest(
            # 'supporting' marks this as a subflow: the validator does not require values for its
            # mandatory inputs (submission/trigger/credentials) because the parent passes them in.
            identifier=WRITER_IDENTIFIER,
            roles=['supporting'],
            input=[
                # Passed in by the parent (hidden - not user-configured on this subflow).
                Parameter(
                    name=Inputs.Submission, type='object', title='Submission', ui={'hidden': True}
                ),
                Parameter(name=Inputs.Trigger, type='object', title='Trigger', ui={'hidden': True}),
                Parameter(
                    name=Inputs.Username,
                    type='string',
                    title='Associated Username',
                    ui={'hidden': True},
                ),
                Parameter(
                    name=Inputs.ConsumerKey,
                    type='Password',
                    title='Consumer Key',
                    secret=True,
                    ui={'hidden': True},
                ),
                Parameter(
                    name=Inputs.PrivateKey,
                    type='Password',
                    title='Private Key',
                    secret=True,
                    ui={'hidden': True},
                ),
                Parameter(
                    name=Inputs.SandboxEnvironment,
                    type='boolean',
                    title='Sandbox Environment',
                    value=False,
                    ui={'hidden': True},
                ),
                # Configured on this subflow (non-secret, with defaults).
                Parameter(
                    name=Inputs.SfObject,
                    type='string',
                    title='Salesforce Object',
                    description='API name of the Salesforce object to create, e.g. Account.',
                    value='',
                ),
                Parameter(
                    name=Inputs.MetadataFieldsMapping,
                    type='json',
                    title='Metadata Field Mappings',
                    description='Map submission metadata keys to Salesforce field API names, e.g. '
                    '{"sf_account_name": "Name"}.',
                    value={},
                ),
                Parameter(
                    name=Inputs.DocumentFieldsMapping,
                    type='json',
                    title='Document Field Mappings',
                    description='Map extracted document field names to Salesforce field API names, '
                    'e.g. {"OWNER_NAME": "AccountNumber"}. Leave empty to write metadata only.',
                    value={},
                    optional=True,
                ),
                Parameter(
                    name=Inputs.DryRun,
                    type='boolean',
                    title='Dry Run',
                    description='Run the Salesforce lookup and log what would be written, but do '
                    'not create the record. Turn this off to write for real.',
                    value=True,
                ),
            ],
        ),
        blocks=[write_to_salesforce],
        output={'result': write_to_salesforce.output()},
    )


def entry_point_workflow() -> Flow:
    return workflow()


if __name__ == '__main__':
    export_flow(entry_point_workflow())
