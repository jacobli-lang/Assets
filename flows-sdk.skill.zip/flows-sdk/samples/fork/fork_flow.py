from typing import Any
from uuid import UUID

from flows_sdk.blocks import CodeBlock, Fork
from flows_sdk.flows import Flow, Manifest
from flows_sdk.package_utils import export_flow


def entry_point_flow() -> Flow:
    return example_flow_with_fork()


def example_flow_with_fork() -> Flow:
    ccb_before_fork = CodeBlock(
        reference_name='ccb_before_fork',
        code=lambda _: {'pre_fork': 'response CCB before fork'},
        code_input={'_': None},
    )

    ccb_A_1 = CodeBlock(
        reference_name='ccb_A_1', code=lambda _: {'a': 'response from A 1'}, code_input={'_': None}
    )

    ccb_A_2 = CodeBlock(
        reference_name='ccb_A_2', code=lambda _: {'a': 'response from A 2'}, code_input={'_': None}
    )

    # Note that both ccb_A_1 and ccb_A_2 will be executed in this branch sequentially,
    # but because of output=ccb_A_1._reference_name, only it will "ccb_A_1" will have its output
    # as a key under "fork_output" (check sample output in the comment below)
    branch_A = Fork.Branch(blocks=[ccb_A_1, ccb_A_2], label='first', output=ccb_A_1._reference_name)

    ccb_B = CodeBlock(
        reference_name='ccb_B', code=lambda _: {'b': 'response from B'}, code_input={'_': None}
    )
    branch_B = Fork.Branch(blocks=[ccb_B], label='second', output=ccb_B._reference_name)

    branch_C = Fork.Branch(blocks=[], label='third', output=ccb_before_fork._reference_name)

    fork = Fork(reference_name='a_fork', branches=[branch_A, branch_B, branch_C])

    def print_function(fork_output: Any) -> None:
        print(fork_output)
        return

    #  {
    #     "ccb_A_1": {
    #        "result": {
    #           "a": "response from A 1"
    #        }
    #     },
    #     "ccb_B": {
    #        "result": {
    #           "b": "response from B"
    #        }
    #     }
    #     "ccb_before_fork": {
    #        "result": {
    #           "pre_fork": "response CCB before fork"
    #        }
    #     }
    #  }
    print_ccb = CodeBlock(
        reference_name='print_ccb', code=print_function, code_input={'fork_output': fork.output()}
    )

    return Flow(
        title='Fork sample flow',
        description='A simple Flow showcasing how a Fork is used',
        blocks=[ccb_before_fork, fork, print_ccb],
        owner_email='flows.sdk@hyperscience.com',
        manifest=Manifest(identifier='fork_example', input=[]),
        uuid=UUID('3e3ab564-fcf5-41fb-a573-4bc2fd153b6d'),
        input={},
    )


if __name__ == '__main__':
    export_flow(flow=entry_point_flow())
