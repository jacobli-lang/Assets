import sys
from uuid import UUID

from flows_sdk.blocks import CodeBlock, PythonBlock
from flows_sdk.flows import Flow, Manifest, Parameter
from flows_sdk.package_utils import export_flow
from flows_sdk.types import HsBlockInstance
from flows_sdk.utils import workflow_input

LOGGING_FLOW_IDENTIFIER = 'LOGGING_FLOW'
LOGGING_FLOW_UUID = UUID('cee432a8-30a3-4d07-a924-e6d87c923325')


def entry_point_flow() -> Flow:
    return sample_logging_flow()


class FlowInputs:
    TEXT_TO_LOG = 'text'


def sample_logging_flow() -> Flow:
    # we need a _hs_block_instance to call the logging methods
    def log_text(text: str, _hs_block_instance: HsBlockInstance) -> None:
        _hs_block_instance.log(f'DEBUG level: {text}', HsBlockInstance.LogLevel.DEBUG)
        _hs_block_instance.log(f'INFO level: {text}', HsBlockInstance.LogLevel.INFO)
        _hs_block_instance.log(f'WARNING level: {text}', HsBlockInstance.LogLevel.WARN)
        _hs_block_instance.log(f'ERROR level: {text}', HsBlockInstance.LogLevel.ERROR)
        # raise Exception('something went wrong')  # this will log an exception if uncommented

    log_task_ccb = CodeBlock(
        reference_name='log_task_ccb',
        code=log_text,
        code_input={FlowInputs.TEXT_TO_LOG: workflow_input(FlowInputs.TEXT_TO_LOG)},
    )
    log_task_python = PythonBlock(
        reference_name='log_task_python',
        code=log_text,
        code_input={FlowInputs.TEXT_TO_LOG: workflow_input(FlowInputs.TEXT_TO_LOG)},
    )

    return Flow(
        title='Logging sample flow',
        description='A simple Flow showcasing how to log in code blocks',
        blocks=[log_task_ccb, log_task_python],
        owner_email='flows.sdk@hyperscience.com',
        manifest=Manifest(
            identifier=LOGGING_FLOW_IDENTIFIER,
            input=[
                (
                    Parameter(
                        name=FlowInputs.TEXT_TO_LOG,
                        title='Text to log',
                        type='string',
                        optional=False,
                    )
                )
            ],
        ),
        uuid=LOGGING_FLOW_UUID,
        input={FlowInputs.TEXT_TO_LOG: 'default-text'},
    )


if __name__ == '__main__':
    export_filename = None
    if len(sys.argv) > 1:
        export_filename = sys.argv[1]

    export_flow(flow=entry_point_flow(), filename=export_filename)
