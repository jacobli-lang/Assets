from typing import Any
from uuid import UUID

from flows_sdk.blocks import PythonBlock
from flows_sdk.flows import Flow
from flows_sdk.implementations.idp_v41 import additional_blocks, idp_blocks
from flows_sdk.implementations.idp_v41.idp_values import IDPCoreManifest, Inputs
from flows_sdk.mocks import MockHsBlockInstance
from flows_sdk.package_utils import export_flow
from flows_sdk.types import HsBlockInstance, StoreBlobRequest
from flows_sdk.utils import str_to_deterministic_uuid_4, workflow_input

CUSTOM_EMAIL_PARSING_IDENTIFIER = 'CUSTOM_EMAIL_PARSING_V41'
IDP_CORE_IDENTIFIER = CUSTOM_EMAIL_PARSING_IDENTIFIER
IDP_CORE_UUID = str(str_to_deterministic_uuid_4(CUSTOM_EMAIL_PARSING_IDENTIFIER))
IDP_CORE_TITLE = 'Custom Email Parsing Subflow V41'


def parse_emails_func(  # noqa: PLR0915
    trigger: dict[str, Any],
    _hs_block_instance: HsBlockInstance,
) -> dict[str, Any]:
    import base64
    import hashlib
    import itertools
    import os
    import tempfile
    from email.message import Message

    import magic  # type: ignore[import-not-found]  # pants: no-infer-dep
    import mailparser  # type: ignore[import-not-found]  # pants: no-infer-dep

    from flows_sdk.types import HsBlockInstance, StoreBlobRequest, StoreBlobResponse

    MSG_MIME_TYPE = 'application/vnd.ms-outlook'
    EMAIL_MIME_TYPES = frozenset({'message/rfc822', MSG_MIME_TYPE})

    # ---------------------------------------------------------------------------
    # Helpers
    # ---------------------------------------------------------------------------

    def detect_mime_type(content: bytes) -> str:
        return magic.Magic(mime=True).from_buffer(content)

    def is_email_content(content: bytes) -> bool:
        return detect_mime_type(content) in EMAIL_MIME_TYPES

    def is_msg_content(content: bytes) -> bool:
        return detect_mime_type(content) == MSG_MIME_TYPE

    def get_disposition_filename(content_disposition: str) -> str | None:
        """Extract the filename parameter from a Content-Disposition header, or None if absent."""
        m = Message()
        m['content-disposition'] = content_disposition
        param = m.get_param('filename', header='content-disposition')
        if isinstance(param, tuple):
            return param[2]
        return param

    def attachment_as_bytes(attachment: dict) -> bytes:
        """Decode a mailparser attachment payload to raw bytes."""
        payload = attachment.get('payload', '')
        if attachment.get('binary', False):
            return base64.b64decode(payload)
        if isinstance(payload, str):
            return payload.encode('utf-8')
        return bytes(payload)

    def parse_bytes(content: bytes) -> Any:
        """Parse raw email bytes into a mailparser object, detecting type via libmagic."""
        if is_msg_content(content):
            # extract-msg (used by mailparser for MSG) requires a file path
            tmp_fd, tmp_path = tempfile.mkstemp(suffix='.msg')
            try:
                with os.fdopen(tmp_fd, 'wb') as f:
                    f.write(content)
                return mailparser.parse_from_file_msg(tmp_path)
            finally:
                os.remove(tmp_path)
        return mailparser.parse_from_bytes(content)

    def parse_email(  # noqa: PLR0915
            raw_email: bytes,
            blobs: list[StoreBlobResponse],
            _hs_block_instance: HsBlockInstance,
            prefix: str = '',
            _untitled_counter: itertools.count | None = None,
            _processed_email_payloads: set[str] | None = None,
    ) -> set[str]:
        """
        Parse raw email bytes, recursing into any nested emails.
        All stored blob names are prefixed with the chain of containing email filenames,
        e.g. "outer.msg:inner.eml:$email_body".
        """
        if _untitled_counter is None:
            _untitled_counter = itertools.count()
        if _processed_email_payloads is None:
            _processed_email_payloads = set()

        # Avoid re-processing the same nested email payload when parent parsers
        # expose flattened descendants in addition to direct children.
        email_payload_digest = hashlib.sha256(raw_email).hexdigest()
        if email_payload_digest in _processed_email_payloads:
            return set()
        _processed_email_payloads.add(email_payload_digest)

        parsed = parse_bytes(raw_email)

        # --- body ---
        # Build the body blob by stripping only attachment parts from the original email,
        # preserving all headers, the HTML body (with formatting), plain text body,
        # and inline images unchanged.
        #
        # compat32 policy preserves original header folding and encoding byte-for-byte.
        import email as _stdlib_email
        import io as _io
        from email import policy as _email_policy
        from email.generator import BytesGenerator as _BytesGenerator

        _orig_msg = _stdlib_email.message_from_bytes(raw_email, policy=_email_policy.compat32)

        def _is_strippable(part: Any) -> bool:
            """Return True if this MIME part should be excluded from the body blob."""
            # Explicit file attachments (PDFs, ZIPs, etc.)
            if part.get_content_disposition() == 'attachment':
                return True
            # Nested email parts (message/rfc822, message/vnd.ms-outlook, etc.)
            # These are recursed into separately and produce their own $email_body blobs.
            # Note: also catches unnamed message/* parts that might lack a Content-Disposition.
            if part.get_content_maintype() == 'message':
                return True
            # Inline non-text parts that carry a filename — these are CID-referenced media
            # (e.g. Outlook signature images embedded inside multipart/related via cid: URLs).
            # They must not be left inside every level's body blob, because the downstream
            # body-parsing logic would pick them up as separate documents and show 3 copies.
            # They are handled exactly once via the standalone-attachment deduplication path.
            if (
                part.get_content_maintype() not in ('text', 'multipart')
                and part.get_filename()
            ):
                return True
            return False

        def _strip_inplace(part: Any) -> None:
            """Recursively remove strippable subparts from a multipart message in-place."""
            if not part.is_multipart():
                return
            kept = [sp for sp in part.get_payload() if not _is_strippable(sp)]
            for sp in kept:
                _strip_inplace(sp)
            part.set_payload(kept)

        _strip_inplace(_orig_msg)

        # Only emit a body blob when there is at least one text leaf remaining.
        _has_text = any(
            lp.get_content_maintype() == 'text'
            for lp in _orig_msg.walk()
            if not lp.is_multipart()
        )
        if _has_text:
            _buf = _io.BytesIO()
            _BytesGenerator(_buf, mangle_from_=False, maxheaderlen=998).flatten(_orig_msg)
            blob = StoreBlobRequest(name=f'{prefix}$email_body', content=_buf.getvalue())
            blobs.append(_hs_block_instance.store_blob(blob))

        # --- attachments ---
        # Pre-compute per-attachment info so we can inspect the full list before acting.
        attachments_info = [
            (
                get_disposition_filename(a.get('content-disposition', '')),
                attachment_as_bytes(a),
                a.get('mail_content_type', '').lower(),
            )
            for a in parsed.attachments
        ]
        has_named_email = any(
            fname and (is_email_content(data) or ctype in EMAIL_MIME_TYPES)
            for fname, data, ctype in attachments_info
        )
        # Note: nested emails from Outlook often arrive as message/rfc822 with
        # Content-Disposition: attachment but NO filename= parameter, so fname is None/''
        # and has_named_email stays False.  That is intentional: we recurse into ALL
        # unnamed email parts via the `not has_named_email` branch below.  Unnamed email
        # parts that appear alongside a *named* email attachment are treated as body
        # artifacts (inline-forwarded content) and stored as raw bytes instead.

        nested_emails: list[tuple[str, bytes]] = []
        regular_attachments: list[tuple[str, bytes]] = []

        for disposition_filename, attachment_bytes, content_type_header in attachments_info:
            is_email = is_email_content(attachment_bytes) or content_type_header in EMAIL_MIME_TYPES
            # Recurse into named emails always; recurse into unnamed emails only when no
            # named email sibling exists (otherwise the unnamed part is a body artifact).
            if is_email and (disposition_filename or not has_named_email):
                filename = disposition_filename or f'untitled_attachment_{next(_untitled_counter)}'
                nested_emails.append((filename, attachment_bytes))
            else:
                filename = disposition_filename or f'untitled_attachment_{next(_untitled_counter)}'
                regular_attachments.append((filename, attachment_bytes))

        descendant_leaf_hashes: set[str] = set()
        for filename, attachment_bytes in nested_emails:
            descendant_leaf_hashes.update(
                parse_email(
                    attachment_bytes,
                    blobs,
                    _hs_block_instance,
                    prefix=f'{prefix}{filename}:',
                    _untitled_counter=_untitled_counter,
                    _processed_email_payloads=_processed_email_payloads,
                )
            )

        emitted_leaf_hashes: set[str] = set()
        for filename, attachment_bytes in regular_attachments:
            attachment_digest = hashlib.sha256(attachment_bytes).hexdigest()
            if attachment_digest in descendant_leaf_hashes:
                continue
            blob = StoreBlobRequest(name=f'{prefix}{filename}', content=attachment_bytes)
            blobs.append(_hs_block_instance.store_blob(blob))
            emitted_leaf_hashes.add(attachment_digest)

        return descendant_leaf_hashes | emitted_leaf_hashes

    # ---------------------------------------------------------------------------
    # Entry point
    # ---------------------------------------------------------------------------

    def parse_email_entrypoint(
        trigger: dict[str, Any],
        _hs_block_instance: HsBlockInstance,
    ) -> dict[str, Any]:
        """
        Parse a raw email file and extract its body and attachments to disk.

        Args:
            trigger:  Input from the email listener.
            _hs_block_instance:  HsBlockInstance object.

        Returns:
            Output with new.
        """
        email_file_uuid = trigger.get('payload', {}).get('raw_email').get('uuid')
        if not email_file_uuid:
            _hs_block_instance.log(
                'No raw_email found in trigger payload',
                level=HsBlockInstance.LogLevel.ERROR,
            )
            return {}
        raw_email_blob = _hs_block_instance.fetch_blob(email_file_uuid)
        blobs: list[StoreBlobResponse] = []
        parse_email(raw_email_blob.content, blobs, _hs_block_instance)
        trigger['payload']['blob_storage_files'] = blobs
        return {'parsed_trigger': trigger}

    return parse_email_entrypoint(trigger, _hs_block_instance=_hs_block_instance)


def idp_workflow() -> Flow:

    parse_emails = PythonBlock(
        reference_name='parse_emails',
        code=parse_emails_func,
        code_input={'trigger': workflow_input(Inputs.Trigger)},
    )

    file_filter = additional_blocks.FileFilterBlock(
        trigger=parse_emails.output('parsed_trigger'),
        reference_name='file_filter'
    )

    bootstrap_submission = idp_blocks.SubmissionBootstrapBlock(
        trigger=file_filter.output('result.filtered_trigger'),
        reference_name='submission_bootstrap',
    )

    case_collation_task = idp_blocks.MachineCollationBlock(
        reference_name='machine_collation',
        submission=bootstrap_submission.output('submission'),
        cases=bootstrap_submission.output('api_params.cases'),
    )

    machine_classification = idp_blocks.MachineClassificationBlock(
        reference_name='machine_classification',
        submission=case_collation_task.output('submission'),
        api_params=bootstrap_submission.output('api_params'),
    )

    manual_classification = idp_blocks.ManualClassificationBlock(
        reference_name='manual_classification',
        submission=machine_classification.output('submission'),
        api_params=bootstrap_submission.output('api_params'),
    )

    machine_identification = idp_blocks.MachineIdentificationBlock(
        reference_name='machine_identification',
        submission=manual_classification.output('submission'),
        api_params=bootstrap_submission.output('api_params'),
    )

    manual_identification = idp_blocks.ManualIdentificationBlock(
        reference_name='manual_identification',
        submission=machine_identification.output('submission'),
        api_params=bootstrap_submission.output('api_params'),
    )

    machine_transcription = idp_blocks.MachineTranscriptionBlock(
        reference_name='machine_transcription',
        submission=manual_identification.output('submission'),
        api_params=bootstrap_submission.output('api_params'),
    )

    manual_transcription = idp_blocks.ManualTranscriptionBlock(
        reference_name='manual_transcription',
        submission=machine_transcription.output('submission'),
        api_params=bootstrap_submission.output('api_params'),
    )

    flexible_extraction = idp_blocks.FlexibleExtractionBlock(
        reference_name='flexible_extraction',
        submission=manual_transcription.output('submission'),
        api_params=bootstrap_submission.output('api_params'),
    )

    reprocessing = idp_blocks.ReprocessingBlock(
        reference_name='reprocessing',
        submission=flexible_extraction.output('submission'),
    )

    document_rendering = idp_blocks.DocumentRendererBlock(
        reference_name='document_rendering',
        submission=reprocessing.output('submission'),
        is_reprocessing=reprocessing.output('is_reprocessing'),
    )

    submission_complete = idp_blocks.SubmissionCompleteBlock(
        reference_name='complete_submission',
        submission=document_rendering.output('submission'),
        is_reprocessing=reprocessing.output('is_reprocessing'),
    )

    return Flow(
        uuid=UUID(IDP_CORE_UUID),
        owner_email='flows-sdk@hyperscience.com',
        title=IDP_CORE_TITLE,
        description='A read-only subflow containing steps to process documents into '
        'machine-readable output.',
        manifest=IDPCoreManifest(
            flow_identifier=IDP_CORE_IDENTIFIER, roles=['read_only', 'supporting', 'idp_core']
        ),
        output={'submission': submission_complete.output('submission')},
        blocks=[
            parse_emails,
            file_filter,
            bootstrap_submission,
            case_collation_task,
            machine_classification,
            manual_classification,
            machine_identification,
            manual_identification,
            machine_transcription,
            manual_transcription,
            flexible_extraction,
            reprocessing,
            document_rendering,
            submission_complete,
        ],
    )


def entry_point_workflow() -> Flow:
    return idp_workflow()


# ============================================================================
# Test Infrastructure
# ============================================================================

def _run_parse_emails_real_libs(email_bytes: bytes) -> list[StoreBlobRequest]:
    """Run parse_emails_func with REAL libraries (magic, mailparser) on given bytes."""
    mock = MockHsBlockInstance()
    mock.blobs['root'] = email_bytes
    trigger = {'payload': {'raw_email': {'uuid': 'root'}}}
    parsed_trigger = parse_emails_func(trigger, mock)  # type: ignore[arg-type]
    blob_responses = parsed_trigger['parsed_trigger']['payload']['blob_storage_files']
    # StoreBlobResponse carries uuid+name but not content; reconstruct as StoreBlobRequest
    # (which has both name and content) for use in test assertions.
    return [StoreBlobRequest(name=r.name, content=mock.blobs[r.uuid]) for r in blob_responses]



def _load_example_1st_layer() -> bytes:
    """Load example 1st layer email."""
    from pathlib import Path
    fixtures_dir = Path(__file__).parent / 'idp_core_flow_v41_test_data'
    return (fixtures_dir / 'original' / '1st layer email with a pdf 1.eml').read_bytes()


def _load_example_2nd_layer() -> bytes:
    """Load example 2nd layer email."""
    from pathlib import Path
    fixtures_dir = Path(__file__).parent / 'idp_core_flow_v41_test_data'
    return (fixtures_dir / 'original' / 'Fw 2nd layer email with a pdf 2.eml').read_bytes()


def _load_example_3rd_layer() -> bytes:
    """Load example 3rd layer email."""
    from pathlib import Path
    fixtures_dir = Path(__file__).parent / 'idp_core_flow_v41_test_data'
    return (fixtures_dir / 'original' / '3rd layer email with a pdf 3.eml').read_bytes()


# ============================================================================
# Tests using data from idp_core_flow_v41_test_data/original/
# ============================================================================

def test_parse_emails_example_1st_layer_no_nested_duplication() -> None:
    """Test example 1st layer email doesn't duplicate nested attachments.

    The 1st layer email contains:
    - pdf1.pdf (direct attachment)
    - pdf2.pdf (nested in 2nd layer email)
    - pdf3.pdf (nested in 3rd layer email)

    With the fix, each PDF should appear exactly once despite mailparser
    potentially exposing them in a flattened list.
    """
    email_bytes = _load_example_1st_layer()
    blobs = _run_parse_emails_real_libs(email_bytes)
    names = [b.name for b in blobs]

    # The 1st layer should have pdf1 + nested pdf2/3
    # With the fix, pdf2 and pdf3 should appear only once despite flattening
    pdf1_count = sum('pdf_1' in name for name in names)
    pdf2_count = sum('pdf_2' in name for name in names)
    pdf3_count = sum('pdf_3' in name for name in names)

    # Each PDF should appear exactly once
    assert pdf1_count == 1, \
        f'Example 1st layer: expected pdf1 1x, got {pdf1_count}. Names: {names}'
    assert pdf2_count == 1, \
        f'Example 1st layer: expected pdf2 1x, got {pdf2_count}. Names: {names}'
    assert pdf3_count == 1, \
        f'Example 1st layer: expected pdf3 1x, got {pdf3_count}. Names: {names}'


def test_parse_emails_example_1st_layer_has_headers() -> None:
    """Test example 1st layer email body includes From/Subject headers."""
    email_bytes = _load_example_1st_layer()
    blobs = _run_parse_emails_real_libs(email_bytes)

    # Find the top-level email body (not nested under file paths)
    top_bodies = [b for b in blobs if b.name == '$email_body']
    assert len(top_bodies) >= 1, f'Expected at least 1 top-level email body, got {len(top_bodies)}'

    top_body = top_bodies[0].content.decode('utf-8')

    # Should contain from/subject/date headers
    has_from = 'From:' in top_body
    has_subject = 'Subject:' in top_body

    assert has_from or has_subject, \
        f'Example 1st layer body should have headers, got: {top_body[:400]}'


def test_parse_emails_example_2nd_layer_single_pdf() -> None:
    """Test example 2nd layer email (which only has pdf2+3 as nested).

    The 2nd layer (Fw 2nd layer email with a pdf 2) contains:
    - pdf2.pdf (direct attachment)
    - pdf3.pdf (nested in 3rd layer email)

    Each should appear exactly once.
    """
    email_bytes = _load_example_2nd_layer()
    blobs = _run_parse_emails_real_libs(email_bytes)
    names = [b.name for b in blobs]

    # 2nd layer should have pdf2 at top + nested pdf3
    pdf2_count = sum('pdf_2' in name for name in names)
    pdf3_count = sum('pdf_3' in name for name in names)

    assert pdf2_count == 1, \
        f'Example 2nd layer: expected pdf2 1x, got {pdf2_count}. Names: {names}'
    assert pdf3_count == 1, \
        f'Example 2nd layer: expected pdf3 1x, got {pdf3_count}. Names: {names}'


def test_parse_emails_example_3rd_layer_single_pdf() -> None:
    """Test example 3rd layer email (which only has pdf3 as attachment).

    The 3rd layer (3rd layer email with a pdf 3) contains only:
    - pdf3.pdf (direct attachment, no further nesting)
    """
    email_bytes = _load_example_3rd_layer()
    blobs = _run_parse_emails_real_libs(email_bytes)
    names = [b.name for b in blobs]

    # 3rd layer should only have pdf3
    pdf3_count = sum('pdf_3' in name for name in names)

    assert pdf3_count == 1, \
        f'Example 3rd layer: expected pdf3 1x, got {pdf3_count}. Names: {names}'


def _make_cyrillic_simple_eml() -> bytes:
    """Build an in-memory RFC2822 email with Cyrillic subject and body."""
    from email.message import EmailMessage
    msg = EmailMessage()
    msg['From'] = 'sender@example.com'
    msg['To'] = 'recipient@example.com'
    msg['Subject'] = 'Събджект на кирилица'
    msg['Date'] = 'Tue, 5 May 2026 09:41:59 +0000'
    msg.set_content('Боди на кирилица 1', charset='utf-8')
    return bytes(msg)


def _make_cyrillic_with_attachment_eml() -> bytes:
    """Build an in-memory multipart RFC2822 email with Cyrillic body and a PDF attachment."""
    from email import encoders
    from email.mime.base import MIMEBase
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    outer = MIMEMultipart('mixed')
    outer['From'] = 'sender@example.com'
    outer['To'] = 'recipient@example.com'
    outer['Subject'] = 'Събджект с прикачен файл'
    outer['Date'] = 'Tue, 5 May 2026 10:00:00 +0000'
    outer.attach(MIMEText('Тяло с кирилица и прикачен файл', 'plain', 'utf-8'))
    att = MIMEBase('application', 'pdf')
    att.set_payload(b'%PDF-1.4\nCYRILLIC_ATTACH_FIXTURE')
    encoders.encode_base64(att)
    att.add_header('Content-Disposition', 'attachment', filename='cyrillic_doc.pdf')
    outer.attach(att)
    return outer.as_bytes()


def _make_cyrillic_with_html_eml() -> bytes:
    """Build an in-memory multipart/alternative email with HTML + plain bodies, Cyrillic content."""
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    outer = MIMEMultipart('alternative')
    outer['From'] = 'sender@example.com'
    outer['To'] = 'recipient@example.com'
    outer['Subject'] = 'Събджект на кирилица'
    outer['Date'] = 'Tue, 5 May 2026 09:41:59 +0000'
    outer.attach(MIMEText('Боди на кирилица 1', 'plain', 'utf-8'))
    outer.attach(MIMEText(
        '<html><body><b>Боди</b> на <i>кирилица</i> 1</body></html>',
        'html', 'utf-8',
    ))
    return outer.as_bytes()


def _make_cyrillic_with_html_and_attachment_eml() -> bytes:
    """Multipart/mixed email: HTML+plain body AND a PDF attachment."""
    from email import encoders
    from email.mime.base import MIMEBase
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    outer = MIMEMultipart('mixed')
    outer['From'] = 'sender@example.com'
    outer['To'] = 'recipient@example.com'
    outer['Subject'] = 'Събджект с HTML и прикачен файл'
    outer['Date'] = 'Tue, 5 May 2026 10:00:00 +0000'
    alt = MIMEMultipart('alternative')
    alt.attach(MIMEText('Боди на кирилица (plain)', 'plain', 'utf-8'))
    alt.attach(MIMEText(
        '<html><body><b>Боди</b> на <i>кирилица</i> (html)</body></html>',
        'html', 'utf-8',
    ))
    outer.attach(alt)
    att = MIMEBase('application', 'pdf')
    att.set_payload(b'%PDF-1.4\nHTML_ATTACH_FIXTURE')
    encoders.encode_base64(att)
    att.add_header('Content-Disposition', 'attachment', filename='doc.pdf')
    outer.attach(att)
    return outer.as_bytes()


def _decode_email_body_blob(blob: StoreBlobRequest) -> tuple[dict[str, str], str]:
    """
    Parse a $email_body blob as RFC2822 and return (headers_dict, plain_body_text).
    """
    import email as _email
    from email.header import decode_header as _decode_header

    msg = _email.message_from_bytes(blob.content)

    def _decode_hdr(raw: str | None) -> str:
        if not raw:
            return ''
        parts = []
        for chunk, charset in _decode_header(raw):
            if isinstance(chunk, bytes):
                parts.append(chunk.decode(charset or 'utf-8'))
            else:
                parts.append(chunk)
        return ''.join(parts)

    headers = {
        'From': _decode_hdr(msg.get('From')),
        'To': _decode_hdr(msg.get('To')),
        'Subject': _decode_hdr(msg.get('Subject')),
        'Date': _decode_hdr(msg.get('Date')),
        'Content-Type': msg.get('Content-Type', ''),
    }

    body = ''
    if msg.is_multipart():
        for part in msg.walk():
            if part.get_content_type() == 'text/plain':
                charset = part.get_content_charset() or 'utf-8'
                raw_payload = part.get_payload(decode=True)
                if isinstance(raw_payload, bytes):
                    body = raw_payload.decode(charset)
                break
    else:
        charset = msg.get_content_charset() or 'utf-8'
        payload = msg.get_payload(decode=True)
        if payload is not None and isinstance(payload, bytes):
            body = payload.decode(charset)

    return headers, body


# ============================================================================
# Encoding & formatting integrity tests (inline fixtures, no external files)
# ============================================================================

def test_email_body_blob_is_valid_rfc2822() -> None:
    """$email_body blob must be parseable RFC2822."""
    import email as _email
    raw = _make_cyrillic_simple_eml()
    blobs = _run_parse_emails_real_libs(raw)
    body_blobs = [b for b in blobs if b.name == '$email_body']
    assert len(body_blobs) == 1, 'Expected exactly one $email_body blob'
    msg = _email.message_from_bytes(body_blobs[0].content)
    assert msg.get_content_maintype() in ('text', 'multipart'), \
        f'Unexpected top-level Content-Type: {msg.get_content_type()}'


def test_email_body_blob_cyrillic_subject_decoded_correctly() -> None:
    """Subject containing Cyrillic must survive the round-trip without corruption."""
    raw = _make_cyrillic_simple_eml()
    blobs = _run_parse_emails_real_libs(raw)
    body_blobs = [b for b in blobs if b.name == '$email_body']
    assert body_blobs, 'Expected $email_body blob'
    headers, _ = _decode_email_body_blob(body_blobs[0])
    assert 'Събджект' in headers['Subject'] and 'кирилица' in headers['Subject'], \
        f"Cyrillic subject corrupted: {headers['Subject']!r}"


def test_email_body_blob_cyrillic_body_decoded_correctly() -> None:
    """Body text containing Cyrillic must survive the round-trip without corruption."""
    raw = _make_cyrillic_simple_eml()
    blobs = _run_parse_emails_real_libs(raw)
    body_blobs = [b for b in blobs if b.name == '$email_body']
    assert body_blobs, 'Expected $email_body blob'
    _, body = _decode_email_body_blob(body_blobs[0])
    assert 'Боди' in body and 'кирилица' in body, \
        f'Cyrillic body text corrupted: {body!r}'


def test_email_body_blob_cyrillic_addresses_are_valid_rfc5322() -> None:
    """From/To addresses must be valid RFC5322, not Python tuple repr."""
    raw = _make_cyrillic_simple_eml()
    blobs = _run_parse_emails_real_libs(raw)
    body_blobs = [b for b in blobs if b.name == '$email_body']
    assert body_blobs, 'Expected $email_body blob'
    headers, _ = _decode_email_body_blob(body_blobs[0])
    for field in ('From', 'To'):
        value = headers[field]
        assert '(' not in value and "'" not in value, \
            f'{field} looks like a Python tuple repr: {value!r}'
    assert 'sender@example.com' in headers['From'], \
        f"From address not found: {headers['From']!r}"


def test_email_body_blob_html_body_preserved() -> None:
    """HTML body part must be preserved in the $email_body blob unchanged.

    The original approach reconstructed a plain-text-only email, discarding the HTML
    part entirely. This caused bold/italic formatting and proper line breaks to disappear
    in downstream rendering. With the strip-attachments approach the HTML part is kept.
    """
    import email as _email
    raw = _make_cyrillic_with_html_eml()
    blobs = _run_parse_emails_real_libs(raw)
    body_blobs = [b for b in blobs if b.name == '$email_body']
    assert body_blobs, 'Expected $email_body blob'
    msg = _email.message_from_bytes(body_blobs[0].content)
    html_parts = [p for p in msg.walk() if p.get_content_type() == 'text/html']
    assert html_parts, 'HTML part must be preserved in $email_body blob'
    html_raw = html_parts[0].get_payload(decode=True)
    html_content = html_raw.decode(
        html_parts[0].get_content_charset() or 'utf-8'
    ) if isinstance(html_raw, bytes) else ''
    assert '<b>' in html_content or '<strong>' in html_content, \
        f'Bold HTML tag not found in preserved HTML body: {html_content!r}'
    assert 'Боди' in html_content and 'кирилица' in html_content, \
        f'Cyrillic missing from HTML body: {html_content!r}'


def test_email_body_blob_attachment_stripped_html_preserved() -> None:
    """Attachment must be stripped but HTML body must remain in the $email_body blob."""
    import email as _email
    raw = _make_cyrillic_with_html_and_attachment_eml()
    blobs = _run_parse_emails_real_libs(raw)
    body_blobs = [b for b in blobs if b.name == '$email_body']
    attachment_blobs = [b for b in blobs if b.name != '$email_body']
    assert len(body_blobs) == 1, f'Expected 1 $email_body, got {len(body_blobs)}'
    assert len(attachment_blobs) >= 1, 'Expected at least 1 attachment blob'
    # HTML must be preserved
    msg = _email.message_from_bytes(body_blobs[0].content)
    html_parts = [p for p in msg.walk() if p.get_content_type() == 'text/html']
    assert html_parts, 'HTML part must survive attachment stripping'
    # Attachment payload must NOT be in body blob
    assert b'HTML_ATTACH_FIXTURE' not in body_blobs[0].content, \
        'Attachment payload leaked into the body blob'
    # No Content-Disposition: attachment part must remain
    att_parts = [
        p for p in msg.walk()
        if p.get_content_disposition() == 'attachment'
    ]
    assert not att_parts, (
        f'Attachment MIME parts found in body blob: {[p.get_filename() for p in att_parts]}'
    )


def test_email_body_blob_with_attachment_body_only() -> None:
    """Plain-text body email with attachment: body preserved, attachment stripped."""
    raw = _make_cyrillic_with_attachment_eml()
    blobs = _run_parse_emails_real_libs(raw)
    body_blobs = [b for b in blobs if b.name == '$email_body']
    attachment_blobs = [b for b in blobs if b.name != '$email_body']
    assert len(body_blobs) == 1, f'Expected 1 $email_body, got {len(body_blobs)}'
    assert len(attachment_blobs) >= 1, 'Expected at least 1 attachment blob'
    _, body = _decode_email_body_blob(body_blobs[0])
    assert 'Тяло' in body and 'кирилица' in body, \
        f'Cyrillic body not found in body blob: {body!r}'
    assert 'CYRILLIC_ATTACH_FIXTURE' not in body, \
        'Attachment payload leaked into the body blob'



def _make_multiline_plain_eml() -> bytes:
    """Build a plain-text email whose body contains multiple distinct lines.
    Used to verify that line breaks are preserved in the $email_body blob.
    """
    from email.mime.text import MIMEText
    msg = MIMEText(
        'Line one\nРед две на кирилица\nLine three\nЧетвърти ред на кирилица',
        'plain',
        'utf-8',
    )
    msg['From'] = 'sender@example.com'
    msg['To'] = 'recipient@example.com'
    msg['Subject'] = 'Multiline test'
    msg['Date'] = 'Tue, 5 May 2026 09:41:59 +0000'
    return msg.as_bytes()


def test_email_body_blob_plain_text_line_breaks_preserved() -> None:
    """Line breaks in the plain-text body must be preserved in the $email_body blob.

    The 'no_html' regression showed all lines merged into one paragraph.  With the
    strip-attachments approach the original body bytes are kept verbatim, so newlines
    must survive the round-trip.
    """
    raw = _make_multiline_plain_eml()
    blobs = _run_parse_emails_real_libs(raw)
    body_blobs = [b for b in blobs if b.name == '$email_body']
    assert body_blobs, 'Expected $email_body blob'
    _, body = _decode_email_body_blob(body_blobs[0])
    lines = [line for line in body.splitlines() if line.strip()]
    assert len(lines) >= 4, (  # noqa: PLR2004
        f'Expected >=4 non-empty lines, got {len(lines)}. Body: {body!r}'
    )
    assert 'Line one' in lines[0], f'First line wrong: {lines[0]!r}'
    assert 'Ред две' in lines[1] and 'кирилица' in lines[1], \
        f'Second Cyrillic line corrupted: {lines[1]!r}'
    assert 'Line three' in lines[2], f'Third line wrong: {lines[2]!r}'
    assert 'Четвърти' in lines[3], f'Fourth Cyrillic line corrupted: {lines[3]!r}'


def test_email_body_blob_preserves_original_charset_and_cte() -> None:
    """The body blob must preserve the original email's charset and Content-Transfer-Encoding.

    The strip-attachments approach should never re-encode or transcode the body.
    Whatever charset/CTE was set in the original email must appear unchanged in the blob,
    so that downstream renderers receive exactly the same encoding signal.
    """
    import email as _email
    raw = _make_cyrillic_with_html_eml()
    # Parse original to capture its charset and CTE
    orig_msg = _email.message_from_bytes(raw)
    # Find the text/html part's CTE in the original
    orig_html_cte = None
    for part in orig_msg.walk():
        if part.get_content_type() == 'text/html':
            orig_html_cte = (part.get('Content-Transfer-Encoding') or '').lower()
            break

    blobs = _run_parse_emails_real_libs(raw)
    body_blobs = [b for b in blobs if b.name == '$email_body']
    assert body_blobs, 'Expected $email_body blob'
    blob_msg = _email.message_from_bytes(body_blobs[0].content)

    # The HTML part's CTE in the body blob must match what was in the original
    blob_html_cte = None
    for part in blob_msg.walk():
        if part.get_content_type() == 'text/html':
            blob_html_cte = (part.get('Content-Transfer-Encoding') or '').lower()
            break

    assert blob_html_cte is not None, 'HTML part missing from body blob'
    assert blob_html_cte == orig_html_cte, (
        f'HTML part CTE changed: original={orig_html_cte!r}, blob={blob_html_cte!r}. '
        'Body blob must not re-encode the original email.'
    )


def test_email_body_blob_example_emails_have_html() -> None:
    """Emails must have their HTML body preserved.
    """
    import email as _email
    for label, loader in [
        ('1st layer', _load_example_1st_layer),
        ('2nd layer', _load_example_2nd_layer),
        ('3rd layer', _load_example_3rd_layer),
    ]:
        blobs = _run_parse_emails_real_libs(loader())
        body_blobs = [b for b in blobs if b.name == '$email_body']
        assert body_blobs, f'{label}: expected at least one $email_body blob'
        top_body_msg = _email.message_from_bytes(body_blobs[0].content)
        html_parts = [p for p in top_body_msg.walk() if p.get_content_type() == 'text/html']
        assert html_parts, (
            f'{label}: $email_body blob has no text/html part. '
            'Outlook emails always include HTML; stripping must preserve it.'
        )


def _make_email_with_inline_signature_image_eml() -> bytes:
    """
    Build a multipart/related email that has:
    - text/plain body
    - text/html body referencing an inline image via cid:
    - image/png with Content-Disposition: inline; filename="logo.png"  (the signature)
    This mimics a real Outlook email with a company signature.
    """
    from email.mime.image import MIMEImage
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText

    outer = MIMEMultipart('related')
    outer['From'] = 'sender@example.com'
    outer['To'] = 'recipient@example.com'
    outer['Subject'] = 'Email with inline signature image'
    outer['Date'] = 'Tue, 5 May 2026 09:41:59 +0000'

    alt = MIMEMultipart('alternative')
    alt.attach(MIMEText('Body text plain', 'plain', 'utf-8'))
    alt.attach(MIMEText(
        '<html><body>Body text <b>html</b><img src="cid:sig_img"></body></html>',
        'html', 'utf-8',
    ))
    outer.attach(alt)

    # Inline signature image (same bytes in all levels — this is what was duplicating)
    img_bytes = b'\x89PNG_SIGNATURE_FIXTURE_BYTES'
    sig_img = MIMEImage(img_bytes, 'png')
    sig_img.add_header('Content-Disposition', 'inline', filename='logo.png')
    sig_img.add_header('Content-ID', '<sig_img>')
    outer.attach(sig_img)

    return outer.as_bytes()


def test_email_body_blob_inline_images_stripped() -> None:
    """Inline images with filenames must NOT appear inside the $email_body blob.
    """
    import email as _email
    raw = _make_email_with_inline_signature_image_eml()
    blobs = _run_parse_emails_real_libs(raw)
    body_blobs = [b for b in blobs if b.name == '$email_body']
    assert body_blobs, 'Expected $email_body blob'
    msg = _email.message_from_bytes(body_blobs[0].content)
    image_parts = [p for p in msg.walk() if p.get_content_maintype() == 'image']
    assert not image_parts, (
        f'Body blob must not contain image parts, found: '
        f'{[(p.get_filename(), p.get_content_type()) for p in image_parts]}'
    )


def test_email_body_blob_inline_image_emitted_as_standalone_blob() -> None:
    """The inline signature image must appear exactly once as a standalone attachment blob."""
    raw = _make_email_with_inline_signature_image_eml()
    blobs = _run_parse_emails_real_libs(raw)
    non_body_blobs = [b for b in blobs if b.name != '$email_body']
    img_blobs = [b for b in non_body_blobs if b'PNG_SIGNATURE_FIXTURE_BYTES' in b.content]
    assert len(img_blobs) == 1, (
        f'Inline signature image must appear exactly once as a standalone blob, '
        f'got {len(img_blobs)}. All blob names: {[b.name for b in blobs]}'
    )


def test_email_body_blob_example_inline_png_not_in_body_blobs() -> None:
    """In the example 1st-layer email, the signature PNG must not appear in body blobs.
    """
    import email as _email
    blobs = _run_parse_emails_real_libs(_load_example_1st_layer())
    body_blobs = [b for b in blobs if b.name == '$email_body']
    for bb in body_blobs:
        msg = _email.message_from_bytes(bb.content)
        image_parts_with_filename = [
            p for p in msg.walk()
            if p.get_content_maintype() == 'image' and p.get_filename()
        ]
        assert not image_parts_with_filename, (
            f"Body blob '{bb.name}' must not contain inline image parts with filenames, "
            f"found: {[(p.get_filename(), p.get_content_type()) for p in image_parts_with_filename]}"  # noqa: E501
        )


if __name__ == '__main__':
    export_flow(entry_point_workflow())
