from uuid import UUID

from flows_sdk.flows import Flow, Manifest
from flows_sdk.implementations.idp_v35.idp_blocks import (
    IDPFullPageTranscriptionBlock,
    IDPImageCorrectionBlock,
    IDPOutputsBlock,
    SubmissionBootstrapBlock,
    SubmissionCompleteBlock,
)
from flows_sdk.implementations.idp_v35.idp_values import IDPTriggers
from flows_sdk.package_utils import export_flow

IDENTIFIER = 'IDP_FULL_PAGE_TRANSCRIPTION_V35'
FLOW_UUID = '9f27b706-e063-473e-8eea-43896d1e6214'


def idp_fpt_workflow() -> Flow:

    submission_bootstrap = SubmissionBootstrapBlock(reference_name='submission_bootstrap')

    image_correction = IDPImageCorrectionBlock(
        reference_name='image_correction', submission=submission_bootstrap.output('submission')
    )

    full_page_transcription = IDPFullPageTranscriptionBlock(
        reference_name='full_page_transcription', submission=image_correction.output('submission')
    )

    # Submission complete block finalizes submission processing and updates reporting data
    # Every flow needs a complete block because it initiates Quality Assurance tasks and
    # changes the submission's status to "Complete"
    # In this example, submission complete block receives the submission object from
    # marked_as_complete custom code block
    submission_complete = SubmissionCompleteBlock(
        reference_name='complete_submission',
        payload=full_page_transcription.output('submission'),
        submission=full_page_transcription.output('submission'),
        nlc_qa_sampling_ratio=0,
        field_id_qa_enabled=False,
        field_id_qa_sampling_ratio=0,
        table_id_qa_enabled=False,
        table_id_qa_sampling_ratio=0,
        transcription_qa_enabled=False,
        transcription_qa_sampling_ratio=0,
        table_cell_transcription_qa_enabled=False,
        table_cell_transcription_qa_sample_rate=0,
    )

    outputs = IDPOutputsBlock(
        inputs={'submission': submission_bootstrap.output('submission')}, blocks=[]
    )

    triggers = IDPTriggers(blocks=[])

    return Flow(
        uuid=UUID(FLOW_UUID),
        owner_email='flows.sdk@hyperscience.com',
        title='Full Page Transcription V35',
        manifest=Manifest(identifier=IDENTIFIER, input=[]),
        triggers=triggers,
        blocks=[
            submission_bootstrap,
            image_correction,
            full_page_transcription,
            submission_complete,
            outputs,
        ],
        description='IDP Full Page Transcription V35',
        output={'submission': submission_complete.output()},
    )


if __name__ == '__main__':
    export_flow(flow=idp_fpt_workflow())
