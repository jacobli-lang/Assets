from uuid import UUID

from flows_sdk.blocks import Block
from flows_sdk.flows import Flow, Manifest, Parameter
from flows_sdk.implementations.idp_v43.additional_blocks import JSONOutputsBlock
from flows_sdk.package_utils import export_flow
from flows_sdk.types import CompatibilitySpec
from flows_sdk.utils import str_to_deterministic_uuid_4, workflow_input

SUBMISSION_AWARE_ON_ERROR_FLOW_IDENTIFIER = 'SUBMISSION_AWARE_ON_ERROR_FLOW_3_EXAMPLE'
SUBMISSION_AWARE_ON_ERROR_FLOW_UUID = str(
    str_to_deterministic_uuid_4(SUBMISSION_AWARE_ON_ERROR_FLOW_IDENTIFIER)
)
SUBMISSION_AWARE_ON_ERROR_FLOW_TITLE = (
    'On-Error with included Submission data V3 - flows-sdk example'
)
SUBMISSION_AWARE_ON_ERROR_DESCRIPTION = (
    'Flow designed to be used as an "on-error" handler for submission-based flows.'
    '\n\n'
    'With the on-error flow configured, when the original flow fails for any reason, and all '
    'the configured auto-retries have been exhausted, the on-error flow will be triggered.'
    '\n\n'
    'The input it receives is the ID of the failed flow run, which can be used to query '
    'additional information about the failure.'
    '\n\n'
    'If you need more complex logic in this flow please consult the documentation of Flows SDK '
    '(https://flows-sdk.hyperscience.ai) and the available public APIs '
    '(https://docs.hyperscience.ai). Note that the custom logic should be implemented in the '
    'On-Error Subflow, so that it can be safely updated without losing the configured Output '
    'blocks. The Output blocks will receive the output of the On-Error Subflow as input.'
)

class OnErrorFlowInputKeys:
    failed_run_uuid: str = 'failed_run_uuid'

FAILED_FLOW_RUN_UUID_PARAMETER = Parameter(
    name=OnErrorFlowInputKeys.failed_run_uuid,
    type='string',
    title='Failed Flow Run UUID',
    description='UUID of the failed flow run that triggered this on_error flow',
    optional=False,
    ui={'hidden': True},
)
SUBMISSION_AWARE_ON_ERROR_CORE_FLOW_IDENTIFIER = 'SUBMISSION_AWARE_ON_ERROR_CORE_EXAMPLE'

def submission_aware_on_error_flow() -> Flow:
    flow_run_uuid = workflow_input(OnErrorFlowInputKeys.failed_run_uuid)

    on_error_core = Block(
        reference_name='on_error_core',
        identifier=SUBMISSION_AWARE_ON_ERROR_CORE_FLOW_IDENTIFIER,
        input={'failed_run_uuid': flow_run_uuid},
        compatibility_spec=CompatibilitySpec(filter_roles=['on_error_core']),
    )

    json_outputs_block = JSONOutputsBlock(inputs={'payload': on_error_core.output()})

    return Flow(
        uuid=UUID(SUBMISSION_AWARE_ON_ERROR_FLOW_UUID),
        owner_email='flows-sdk@hyperscience.ai',
        title=SUBMISSION_AWARE_ON_ERROR_FLOW_TITLE,
        description=SUBMISSION_AWARE_ON_ERROR_DESCRIPTION,
        manifest=Manifest(
            identifier=SUBMISSION_AWARE_ON_ERROR_FLOW_IDENTIFIER,
            roles=['on_error', 'supporting'],
            input=[FAILED_FLOW_RUN_UUID_PARAMETER],
        ),
        output={},
        input={},
        blocks=[
            on_error_core,
            json_outputs_block,
        ],
    )


def entry_point_workflow() -> Flow:
    return submission_aware_on_error_flow()


if __name__ == '__main__':
    export_flow(submission_aware_on_error_flow())
