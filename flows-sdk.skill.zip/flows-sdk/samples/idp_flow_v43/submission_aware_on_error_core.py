from uuid import UUID

from flows_sdk.blocks import PythonBlock
from flows_sdk.flows import Flow, Manifest, Parameter
from flows_sdk.implementations.idp_v43.additional_blocks import HyperscienceRestApiBlock
from flows_sdk.package_utils import export_flow
from flows_sdk.types import HsTask
from flows_sdk.utils import str_to_deterministic_uuid_4, workflow_input

SUBMISSION_AWARE_ON_ERROR_CORE_FLOW_IDENTIFIER = 'SUBMISSION_AWARE_ON_ERROR_CORE_EXAMPLE'
SUBMISSION_AWARE_ON_ERROR_CORE_FLOW_UUID = str(
    str_to_deterministic_uuid_4(SUBMISSION_AWARE_ON_ERROR_CORE_FLOW_IDENTIFIER)
)
SUBMISSION_AWARE_ON_ERROR_CORE_FLOW_TITLE = (
    'Retrieve error and submission information - flows-sdk example'
)
SUBMISSION_AWARE_ON_ERROR_CORE_DESCRIPTION = (
    'Core logic of the on-error flow. Compiles the data, relevant to the error. This includes '
    'metadata for the failed flow run and the JSON serialized submission data, if the flow run '
    'is linked to a submission. The flow run inputs, outputs and logs are excluded for '
    'performance reasons - their size is unpredictable.'
    '\n\n'
    'In this On-Error Subflow implementation, we fetch the failed flow run, alongside with the '
    'full submission metadata (if the submission ID was found). The data format of the output '
    'conforms to the schema documented here: https://docs.hyperscience.ai/#flows-runs and here: '
    'https://docs.hyperscience.ai/#submissions, under the respective keys "flow_run" and '
    '"submission".'
    '\n\n'
    'Any custom error handling logic should be added here. The main on-error flow should only be '
    'used for configuring the outputs in the Outputs block, i.e. where the compiled on-error data '
    'should be sent to.'
)


class OnErrorFlowInputKeys:
    failed_run_uuid: str = 'failed_run_uuid'

FAILED_FLOW_RUN_UUID_PARAMETER = Parameter(
    name=OnErrorFlowInputKeys.failed_run_uuid,
    type='string',
    title='Failed Flow Run UUID',
    description='UUID of the failed flow run that triggered this on_error flow',
    optional=False,
    ui={'hidden': True},
)


def submission_aware_on_error_core_flow() -> Flow:
    flow_run_uuid = workflow_input(OnErrorFlowInputKeys.failed_run_uuid)
    flow_run_rest_api_block = HyperscienceRestApiBlock(
        reference_name='flow_run_rest_api_block',
        title='Get Flow Run',
        description='Get the full metadata of the failed flow run',
        method='GET',
        app_endpoint=f'/api/v5/flow_runs/{flow_run_uuid}/summary',
    )

    def _get_correlation_id(_hs_task: HsTask) -> dict:
        return {'correlation_id': _hs_task.correlation_id}

    get_correlation_id_block = PythonBlock(
        reference_name='get_correlation_id',
        title='Get Correlation ID',
        description='Get the correlation ID for the failed Submission / Flow Run',
        code=_get_correlation_id,
    )

    fetch_submissions_block = HyperscienceRestApiBlock(
        reference_name='fetch_submission',
        title='Fetch Submission',
        description='Fetch the submission data for the failed flow run',
        method='GET',
        app_endpoint='/api/v5/submissions?debug=true'
        f'&correlation_id={get_correlation_id_block.output('correlation_id')}',
    )

    return Flow(
        uuid=UUID(SUBMISSION_AWARE_ON_ERROR_CORE_FLOW_UUID),
        owner_email='flows-sdk@hyperscience.ai',
        title=SUBMISSION_AWARE_ON_ERROR_CORE_FLOW_TITLE,
        description=SUBMISSION_AWARE_ON_ERROR_CORE_DESCRIPTION,
        manifest=Manifest(
            identifier=SUBMISSION_AWARE_ON_ERROR_CORE_FLOW_IDENTIFIER,
            roles=['on_error_core', 'supporting', 'read_only'],
            input=[FAILED_FLOW_RUN_UUID_PARAMETER]
        ),
        output={
            'flow_run': flow_run_rest_api_block.output('result.data'),
            'submission': fetch_submissions_block.output('result.data'),
        },
        input={},
        blocks=[
            flow_run_rest_api_block,
            get_correlation_id_block,
            fetch_submissions_block,
        ],
    )


def entry_point_workflow() -> Flow:
    return submission_aware_on_error_core_flow()


if __name__ == '__main__':
    export_flow(submission_aware_on_error_core_flow())
