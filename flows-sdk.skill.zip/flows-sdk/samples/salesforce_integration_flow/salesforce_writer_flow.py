"""Integration flow driven by the Salesforce Notifier output block.

The Salesforce Notifier output block does not write to Salesforce itself. For every payload of a
completed submission it runs the flow you select in its "Integration Flow" picker, passing down the
Salesforce credentials, the submission id and a reference to the rendered payload. Everything that
happens in Salesforce is therefore ordinary Python you own and can change: this sample looks up a
Salesforce record by the fields it is about to write and creates it only when nothing matches.

To be selectable in that picker a flow needs two things, both below:

* the ``salesforce_integration`` role, and
* the inputs the output block passes in - ``submission_id``, ``payload_uuid``, ``username``,
  ``consumer_key``, ``private_key`` and ``sandbox_environment``.

The credentials are entered once, on the output block, and forwarded from there, so they are never
stored in this file.

Everything else is configured here, through the manifest defaults: which Salesforce object to
write, how document fields and submission metadata map onto its fields, and whether to run in dry
run mode. A supporting flow has no settings panel of its own, so a manifest default is the only
place these values can come from.

Prerequisites:

* ``simple-salesforce`` and its dependencies uploaded under **Flows -> Python Packages**, for the
  same Python version this flow is built for. It is not a single wheel, and packages are tracked
  per Python version.
* A Salesforce connected app set up for JWT bearer authentication.

Nothing here is tied to an IDP version, because the flow never touches IDP: it takes a payload
reference and writes to Salesforce. Import it as it is, then add the output block to whichever
document processing flow you already run::

    HS_PYTHON_CODE_BLOCK_PYTHON_VERSION=3.13 hs-flows bundle salesforce_writer_flow.py \
        -o salesforce_writer_flow.zip

See `Salesforce Integration Flow <../pages/salesforce_integration_flow.html>`_ for the full walkthrough.
"""

from uuid import UUID

from flows_sdk.blocks import PythonBlock
from flows_sdk.flows import Flow, Manifest, Parameter
from flows_sdk.package_utils import export_flow
from flows_sdk.types import HsBlockInstance, HsTask
from flows_sdk.utils import workflow_input

IDENTIFIER = 'SALESFORCE_INTEGRATION_FLOW_EXAMPLE'
FLOW_UUID = UUID('9c1d4b7e-2f83-4a56-b0d1-7e5c8a3f42b6')

# Must match the output block's role filter, which is what narrows its "Integration Flow" picker.
SALESFORCE_INTEGRATION_ROLE = 'salesforce_integration'


class Inputs:
    # Passed in by the Salesforce Notifier output block (hidden, never configured here).
    SubmissionId = 'submission_id'
    PayloadUuid = 'payload_uuid'
    Username = 'username'
    ConsumerKey = 'consumer_key'
    PrivateKey = 'private_key'
    SandboxEnvironment = 'sandbox_environment'
    # Configured on this flow, through the manifest defaults below.
    SfObject = 'sf_object'
    MetadataFieldsMapping = 'metadata_fields_mapping'
    DocumentFieldsMapping = 'document_fields_mapping'
    DryRun = 'dry_run'


def _write_payload_to_salesforce(
    submission_id: int,
    payload_uuid: str,
    username: str,
    consumer_key: str,
    private_key: str,
    sandbox_environment: bool,
    sf_object: str,
    metadata_fields_mapping: dict,
    document_fields_mapping: dict,
    dry_run: bool,
    _hs_block_instance: HsBlockInstance,
    _hs_task: HsTask,
) -> dict:
    import json

    # `simple-salesforce` has to be installed for the platform's code-block interpreter, see the
    # module docstring. The import lives inside the function because it runs on the block, not
    # when the flow is built.
    from simple_salesforce import (  # type: ignore[import-not-found]
        Salesforce,  # pants: no-infer-dep
    )

    # A Python code block ships only THIS function's source, so every helper has to be defined
    # inside it. A module-level helper would raise NameError at runtime.

    def log_info(msg: str, *args: object) -> None:
        # `log()` applies {}-style formatting to the message, so values that may themselves
        # contain braces (a dict, a SOQL string) are passed as ARGS rather than interpolated
        # into `msg`: args are substituted, not re-parsed.
        _hs_block_instance.log(msg, *args, level=HsBlockInstance.LogLevel.INFO)

    def soql_literal(value: object) -> str:
        # SOQL string literals are single-quoted; escape backslashes and single quotes.
        escaped = str(value).replace('\\', '\\\\').replace("'", "\\'")
        return f"'{escaped}'"

    # The output block hands over a blob reference, one per rendered payload. The payload is the
    # same JSON the platform renders for its output blocks: a top-level `metadata` (submission
    # metadata) plus `output` (the serialized submission). With the "Full individual object" export
    # type each payload covers one document, with `output.documents` narrowed to it.
    blob = _hs_block_instance.fetch_blob(payload_uuid)
    payload = json.loads(blob.content.decode('utf-8'))
    metadata = payload.get('metadata') or {}
    documents = (payload.get('output') or {}).get('documents') or []

    def get_extracted_field(field_name: str) -> object:
        # A field in a v5 payload looks like:
        #   {"name": "Name", "output_name": "name", "id": 1, "state": "complete",
        #    "transcription": {"raw": "Jane Doe", "normalized": "Jane Doe",
        #                      "source": "machine_transcription", ...}, ...}
        # so a field is matched on either the layout field name or its output name, and
        # `transcription` is an object rather than a string. A plain string transcription is
        # accepted too, since that is what the flat export types send.
        for document in documents:
            for field in document.get('document_fields') or []:
                names = (field.get('name'), field.get('output_name'), field.get('field_name'))
                if field_name not in names:
                    continue
                transcription = field.get('transcription')
                if isinstance(transcription, dict):
                    # Prefer the normalized value, which is the platform's canonical one:
                    # "12-0719651" normalizes to "120719651" and text is upper-cased. Use
                    # `raw` instead where the verbatim string matters.
                    return transcription.get('normalized') or transcription.get('raw')
                return field.get('transcription_normalized') or transcription
        return None

    # Build the Salesforce record from the two mappings, source name -> Salesforce field API name.
    record: dict = {}

    for metadata_key, sf_field in (metadata_fields_mapping or {}).items():
        if metadata_key not in metadata:
            raise ValueError(
                f'Submission metadata has no key {metadata_key!r}. '
                f'Available keys: {sorted(metadata)}'
            )
        record[sf_field] = metadata[metadata_key]

    for document_field_name, sf_field in (document_fields_mapping or {}).items():
        value = get_extracted_field(document_field_name)
        if value is None:
            raise ValueError(
                f'No extracted value for document field {document_field_name!r} in payload '
                f'{payload_uuid} of submission {submission_id}.'
            )
        record[sf_field] = value

    if not sf_object:
        raise ValueError('sf_object is required (e.g. "Account").')
    if not record:
        raise ValueError(
            'Nothing to write: both metadata_fields_mapping and document_fields_mapping are empty.'
        )

    # JWT bearer authentication with the connected app credentials the output block passes in:
    # username is the JWT subject, consumer_key the issuer, private_key the RS256 signing key.
    # A PEM pasted into a form field can arrive with literal "\n", so normalize it first.
    private_key = private_key.replace('\\n', '\n')
    domain = 'test' if sandbox_environment else 'login'
    salesforce = Salesforce(
        username=username,
        consumer_key=consumer_key,
        privatekey=private_key,
        domain=domain,
    )

    # Look the record up by the very fields that are about to be written, AND'ed together, and
    # create it only when nothing matches. That keeps a re-run from duplicating records.
    where = ' AND '.join(f'{sf_field} = {soql_literal(v)}' for sf_field, v in record.items())
    query = f'SELECT Id FROM {sf_object} WHERE {where}'
    # Log the query before running it, so it is visible even if the query itself errors.
    log_info('Salesforce lookup query: {}', query)
    result = salesforce.query_all(query)
    count = result.get('totalSize', len(result.get('records', [])))
    log_info('Salesforce lookup on {} with {} -> {} record(s).', sf_object, record, count)

    created_id = None
    if dry_run:
        log_info('Dry run: not creating a {} record. Would have written {}.', sf_object, record)
    elif count == 0:
        created = getattr(salesforce, sf_object).create(record)
        created_id = created.get('id')
        log_info('No existing {}; created record {} with {}.', sf_object, created_id, record)
    else:
        log_info('{} existing {} record(s) matched; skipping create.', count, sf_object)

    return {
        'submission_id': submission_id,
        'payload_uuid': payload_uuid,
        'result_count': count,
        'lookup_fields': record,
        'query': query,
        'dry_run': dry_run,
        'created': created_id is not None,
        'salesforce_id': created_id,
    }


def workflow() -> Flow:
    write_to_salesforce = PythonBlock(
        reference_name='write_payload_to_salesforce',
        code=_write_payload_to_salesforce,
        # No `python_version` here: the block compiles to the Python version of the venv this
        # is built in, or to `HS_PYTHON_CODE_BLOCK_PYTHON_VERSION` if that is set. Pick the one
        # your platform runs, as described in the walkthrough.
        code_input={
            'submission_id': workflow_input(Inputs.SubmissionId),
            'payload_uuid': workflow_input(Inputs.PayloadUuid),
            'username': workflow_input(Inputs.Username),
            'consumer_key': workflow_input(Inputs.ConsumerKey),
            'private_key': workflow_input(Inputs.PrivateKey),
            'sandbox_environment': workflow_input(Inputs.SandboxEnvironment),
            'sf_object': workflow_input(Inputs.SfObject),
            'metadata_fields_mapping': workflow_input(Inputs.MetadataFieldsMapping),
            'document_fields_mapping': workflow_input(Inputs.DocumentFieldsMapping),
            'dry_run': workflow_input(Inputs.DryRun),
        },
        title='Write payload to Salesforce',
        description='Fetches the rendered submission payload, maps its metadata and extracted '
        'document fields to Salesforce field API names, and writes them to a Salesforce record '
        'using simple-salesforce.',
    )

    return Flow(
        uuid=FLOW_UUID,
        owner_email='flows-sdk@hyperscience.com',
        title='Salesforce Integration Flow - flows-sdk example',
        description='Writes one rendered submission payload to Salesforce. Driven by the '
        'Salesforce Notifier output block, which passes in the credentials, the submission id '
        'and the payload reference.',
        manifest=Manifest(
            identifier=IDENTIFIER,
            # 'supporting' marks this as a subflow, so the validator does not require values for
            # the inputs the caller supplies. The salesforce role is what makes the output
            # block's "Integration Flow" picker offer this flow.
            roles=['supporting', SALESFORCE_INTEGRATION_ROLE],
            input=[
                # Passed in by the output block, hidden because they are not configured here.
                Parameter(
                    name=Inputs.SubmissionId,
                    type='integer',
                    title='Submission ID',
                    ui={'hidden': True},
                ),
                Parameter(
                    name=Inputs.PayloadUuid,
                    type='string',
                    title='Payload UUID',
                    ui={'hidden': True},
                ),
                Parameter(
                    name=Inputs.Username,
                    type='string',
                    title='Associated Username',
                    ui={'hidden': True},
                ),
                Parameter(
                    name=Inputs.ConsumerKey,
                    type='Password',
                    title='Consumer Key',
                    secret=True,
                    ui={'hidden': True},
                ),
                Parameter(
                    name=Inputs.PrivateKey,
                    type='Password',
                    title='Private Key',
                    secret=True,
                    ui={'hidden': True},
                ),
                Parameter(
                    name=Inputs.SandboxEnvironment,
                    type='boolean',
                    title='Sandbox Environment',
                    value=False,
                    ui={'hidden': True},
                ),
                # Configured here, through these defaults. The output block passes a fixed input
                # set, and a supporting flow has no settings panel, so a default is the only way
                # to set them.
                Parameter(
                    name=Inputs.SfObject,
                    type='string',
                    title='Salesforce Object',
                    description='API name of the Salesforce object to look up and create, '
                    'e.g. Account.',
                    value='Account',
                ),
                Parameter(
                    name=Inputs.MetadataFieldsMapping,
                    type='json',
                    title='Metadata Field Mappings',
                    description='Map submission metadata keys to Salesforce field API names, e.g. '
                    '{"customer_id": "AccountNumber"}. Submission metadata is empty for documents '
                    'uploaded through the UI.',
                    value={},
                    optional=True,
                ),
                Parameter(
                    name=Inputs.DocumentFieldsMapping,
                    type='json',
                    title='Document Field Mappings',
                    description='Map extracted document field names to Salesforce field API '
                    'names, e.g. {"Name": "Name"}. A mapped field with no extracted value fails '
                    'the flow rather than writing a partial record.',
                    # "Name" comes from the W-9 layout shipped with the Document Processing
                    # Starter and maps onto a standard Account field, so nothing has to be created
                    # in Salesforce first. It is printed on the sample document, so machine
                    # transcription reads it without a human keyer - unlike its "Address", which
                    # is handwritten and comes back illegible.
                    value={'Name': 'Name'},
                ),
                Parameter(
                    name=Inputs.DryRun,
                    type='boolean',
                    title='Dry Run',
                    description='Run the Salesforce lookup and log what would be written, but do '
                    'not create the record. Turn this off to write for real.',
                    value=True,
                ),
            ],
        ),
        blocks=[write_to_salesforce],
        output={'result': write_to_salesforce.output()},
    )


def entry_point_workflow() -> Flow:
    return workflow()


if __name__ == '__main__':
    export_flow(entry_point_workflow())
