from typing import Any


class SomeClass:
    def __init__(self, value: Any):
        self.value = value

    def get_value(self) -> Any:
        return self.value


def entrypoint() -> Any:
    sc = SomeClass(1)
    return sc.get_value()
