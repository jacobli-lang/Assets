from uuid import UUID

from samples.ccb_module.code_module import entrypoint

from flows_sdk.blocks import CodeBlock
from flows_sdk.flows import Flow, Manifest
from flows_sdk.package_utils import export_flow

FLOW_IDENTIFIER = 'MODULE_FLOW'
FLOW_UUID = UUID('6156ebde-0e0d-4206-8670-ff4347c0d87f')


def entry_point_flow() -> Flow:

    ccb = CodeBlock(
        reference_name='hello_ccb',
        code=entrypoint,
        include_module=True,
    )

    return Flow(
        title='Module Flow',
        description='A simple Flow showcasing a CCB using entire module',
        blocks=[ccb],
        owner_email='flows.sdk@hyperscience.com',
        manifest=Manifest(identifier=FLOW_IDENTIFIER, input=[]),
        uuid=FLOW_UUID,
        input={},
    )


if __name__ == '__main__':
    export_flow(flow=entry_point_flow())
