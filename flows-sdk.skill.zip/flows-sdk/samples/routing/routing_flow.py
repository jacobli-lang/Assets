from typing import Any
from uuid import UUID

from flows_sdk.blocks import CodeBlock, Routing
from flows_sdk.flows import Flow, Manifest
from flows_sdk.package_utils import export_flow


def entry_point_flow() -> Flow:
    return example_flow_with_routing()


def example_flow_with_routing() -> Flow:

    ccb_before_routing = CodeBlock(
        reference_name='ccb_before_routing',
        code=lambda _: {'pre_routing': 'response CCB before routing'},
        code_input={'_': None},
    )

    decision_ccb = CodeBlock(
        reference_name='decision_ccb',
        code=lambda a_char: {'some_field': a_char},
        code_input={'a_char': 'A'},
    )

    ccb_A = CodeBlock(
        reference_name='ccb_A', code=lambda _: {'a': 'response from A'}, code_input={'_': None}
    )
    branch_A = Routing.Branch(case='A', blocks=[ccb_A], label='first', output=ccb_A._reference_name)

    branch_B = Routing.Branch(
        case='B', blocks=[], label='second', output=ccb_before_routing._reference_name
    )

    ccb_C = CodeBlock(
        reference_name='ccb_C', code=lambda _: {'c': 'response from C'}, code_input={'_': None}
    )
    default_branch = Routing.DefaultBranch(
        blocks=[ccb_C], label='default', output=ccb_C._reference_name
    )

    # 'decision' is like a switch..case statement - when a Branch 'case' is matched, it will be
    # scheduled for execution. If no case matches, a 'default_branch' can be defined as fallback.
    routing = Routing(
        reference_name='a_routing',
        decision=decision_ccb.output('some_field'),
        branches=[branch_A, branch_B],
        default_branch=default_branch,
    )

    def print_function(routing_output: Any) -> None:
        print(routing_output)
        return

    #   "routing_output": {
    #       "result": {
    #          "a": "response from A"
    #       }
    #    }
    print_ccb = CodeBlock(
        reference_name='print_ccb',
        code=print_function,
        code_input={'routing_output': routing.output()},
    )

    return Flow(
        title='Routing sample flow',
        description='A simple Flow showcasing how Routing is used',
        blocks=[ccb_before_routing, decision_ccb, routing, print_ccb],
        owner_email='flows.sdk@hyperscience.com',
        manifest=Manifest(identifier='routing_example', input=[]),
        uuid=UUID('4e3ab564-fcf5-41fb-a573-4bc2fd153b6d'),
        input={},
    )


if __name__ == '__main__':
    export_flow(flow=entry_point_flow())
